#include <lescegra/particle/particlesystem.h>

#include <lescegra/util/linkedlist.h>
#include <lescegra/particle/particlemodifier.h>

#include <stdlib.h>

LsgParticleSystem* LsgParticleSystem_create(void) {
    LsgParticleSystem* self = (LsgParticleSystem*)malloc(sizeof(LsgParticleSystem));
    
    LsgParticleSystem_init(self);
    
    return self;
}

void LsgParticleSystem_init(LsgParticleSystem* self) {
    LsgGroup_init(&self->super);
    
    ((LsgObject*)self)->destroy = (void (*)(LsgObject*))LsgParticleSystem_destroy;

    ((LsgNode*)self)->update = (void (*)(LsgNode*, float))LsgParticleSystem_update;
    
    self->modifiers = (LsgList*)LsgLinkedList_create();
}
    
void LsgParticleSystem_update(LsgParticleSystem* self, float now) {
    LsgIterator* it;
    
    it = self->modifiers->iterator(self->modifiers);
    while (it->hasNext(it)) {
        LsgParticleModifier* pm = (LsgParticleModifier*)it->next(it);
        pm->update(pm, self->super.children, now);
    }
    LsgObject_free((LsgObject*)it);

    LsgGroup_update(&self->super, now);
}

void LsgParticleSystem_destroy(LsgParticleSystem* self) {
    LsgObject_free((LsgObject*)self->modifiers);
    
    LsgGroup_destroy(&self->super);
}
