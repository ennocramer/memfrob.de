#include <lescegra/coll/bvolume.h>

#include <stdlib.h>
#include <stdio.h>

static int LsgBVolume_visible(LsgBVolume* self, LsgFrustum* frustum);
static void LsgBVolume_collideVertex(LsgBVolume* self, Vertex v, LsgList* b);
static void LsgBVolume_collideRay(LsgBVolume* self, Vertex v, Vertex d, LsgList* b);
static void LsgBVolume_collideSphere(LsgBVolume* self, Vertex c, float r, LsgList* b);
static void LsgBVolume_include(LsgBVolume* self, Vertex v);
static void LsgBVolume_merge(LsgBVolume* self, LsgBVolume* target);

void LsgBVolume_init(LsgBVolume* self) {
    LsgObject_init(&self->super);
    
    self->visible       = LsgBVolume_visible;
    self->collideVertex = LsgBVolume_collideVertex;
    self->collideRay    = LsgBVolume_collideRay;
    self->collideSphere = LsgBVolume_collideSphere;
    self->include       = LsgBVolume_include;
    self->merge         = LsgBVolume_merge;
    self->reset         = LsgBVolume_reset;
    self->valid         = 0;
}

void LsgBVolume_reset(LsgBVolume* self) {
    self->valid = 0;
}

static void LsgBVolume_errorAbstract(const char* method) {
    fprintf(stderr, "Method call to abstract method %s\n", method);
    fprintf(stderr, "A subclass of LsgBVolume failed to implement the abstract method %s as defined by LsgBVolume (%s)\n", method, __FILE__);
    abort();
}

static int LsgBVolume_visible(LsgBVolume* self, LsgFrustum* frustum) {
    LsgBVolume_errorAbstract("LsgBVolume_visible");
    return 0;
}

static void LsgBVolume_collideVertex(LsgBVolume* self, Vertex v, LsgList* b) {
    LsgBVolume_errorAbstract("LsgBVolume_collideVertex");
}

static void LsgBVolume_collideRay(LsgBVolume* self, Vertex v, Vertex d, LsgList* b) {
    LsgBVolume_errorAbstract("LsgBVolume_collideRay");
}

static void LsgBVolume_collideSphere(LsgBVolume* self, Vertex c, float r, LsgList* b) {
    LsgBVolume_errorAbstract("LsgBVolume_collideSphere");
}

static void LsgBVolume_include(LsgBVolume* self, Vertex v) {
    LsgBVolume_errorAbstract("LsgBVolume_include");
}

static void LsgBVolume_merge(LsgBVolume* self, LsgBVolume* target) {
    LsgBVolume_errorAbstract("LsgBVolume_merge");
}
