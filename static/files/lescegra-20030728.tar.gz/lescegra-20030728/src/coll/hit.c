#include <lescegra/coll/hit.h>

#include <stdlib.h>

LsgHit* LsgHit_create(void) {
    LsgHit* self = (LsgHit*)malloc(sizeof(LsgHit));
    
    LsgHit_init(self);
    
    return self;
}

void LsgHit_init(LsgHit* self) {
    LsgObject_init(&self->super);
    
    vertex_assign(self->intersection, 0.0, 0.0, 0.0);
    vertex_assign(self->normal, 0.0, 0.0, 0.0);
}
