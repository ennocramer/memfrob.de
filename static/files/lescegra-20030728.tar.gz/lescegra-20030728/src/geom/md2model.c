#include <lescegra/geom/md2model.h>

#include <lescegra/util/image.h>
#include <lescegra/coll/bbox.h>

#include <GL/gl.h>
#include <stdlib.h>
#include <stdio.h>

typedef struct {
    int magic;
    int version;
    int skin_width;
    int skin_height;
    int frame_size;

    int skin_count;
    int vertex_count;
    int tex_coord_count;
    int triangle_count;
    int glcommand_count;
    int frame_count;

    int skin_offset;
    int tex_coord_offset;
    int triangle_offset;
    int frame_offset;
    int glcommand_offset;
    int filesize;
} MD2FileHeader;

typedef char MD2FileSkin[64];

typedef struct {
    short int s;
    short int t;
} MD2FileTexCoord;

typedef struct {
    unsigned char v[3];
    unsigned char n;
} MD2FileVertex;

typedef struct {
    float scale[3];
    float translate[3];
    char  name[16];
    MD2FileVertex vertices[1];
} MD2FileFrame;

typedef struct {
    short int vertices[3];
    short int tex_coords[3];
} MD2FileTriangle;

/*
 * quake ii model normals
 * taken from utils3/qdata/anorms.h (q2source_12_11.zip from id software ftp server)
 * y and z values have been swapped to make models conform to right hand
 * coordinate system with y = up
 */
static Vertex normals[256] = {
    {-0.525731, 0.850651, 0.000000},
    {-0.442863, 0.864188, 0.238856},
    {-0.295242, 0.955423, 0.000000},
    {-0.309017, 0.809017, 0.500000},
    {-0.162460, 0.951056, 0.262866},
    {0.000000, 1.000000, 0.000000},
    {0.000000, 0.525731, 0.850651},
    {-0.147621, 0.681718, 0.716567},
    {0.147621, 0.681718, 0.716567},
    {0.000000, 0.850651, 0.525731},
    {0.309017, 0.809017, 0.500000},
    {0.525731, 0.850651, 0.000000},
    {0.295242, 0.955423, 0.000000},
    {0.442863, 0.864188, 0.238856},
    {0.162460, 0.951056, 0.262866},
    {-0.681718, 0.716567, 0.147621},
    {-0.809017, 0.500000, 0.309017},
    {-0.587785, 0.688191, 0.425325},
    {-0.850651, 0.000000, 0.525731},
    {-0.864188, 0.238856, 0.442863},
    {-0.716567, 0.147621, 0.681718},
    {-0.688191, 0.425325, 0.587785},
    {-0.500000, 0.309017, 0.809017},
    {-0.238856, 0.442863, 0.864188},
    {-0.425325, 0.587785, 0.688191},
    {-0.716567, -0.147621, 0.681718},
    {-0.500000, -0.309017, 0.809017},
    {-0.525731, 0.000000, 0.850651},
    {0.000000, -0.525731, 0.850651},
    {-0.238856, -0.442863, 0.864188},
    {0.000000, -0.295242, 0.955423},
    {-0.262866, -0.162460, 0.951056},
    {0.000000, 0.000000, 1.000000},
    {0.000000, 0.295242, 0.955423},
    {-0.262866, 0.162460, 0.951056},
    {0.238856, 0.442863, 0.864188},
    {0.262866, 0.162460, 0.951056},
    {0.500000, 0.309017, 0.809017},
    {0.238856, -0.442863, 0.864188},
    {0.262866, -0.162460, 0.951056},
    {0.500000, -0.309017, 0.809017},
    {0.850651, 0.000000, 0.525731},
    {0.716567, 0.147621, 0.681718},
    {0.716567, -0.147621, 0.681718},
    {0.525731, 0.000000, 0.850651},
    {0.425325, 0.587785, 0.688191},
    {0.864188, 0.238856, 0.442863},
    {0.688191, 0.425325, 0.587785},
    {0.809017, 0.500000, 0.309017},
    {0.681718, 0.716567, 0.147621},
    {0.587785, 0.688191, 0.425325},
    {0.955423, 0.000000, 0.295242},
    {1.000000, 0.000000, 0.000000},
    {0.951056, 0.262866, 0.162460},
    {0.850651, 0.000000, -0.525731},
    {0.955423, 0.000000, -0.295242},
    {0.864188, 0.238856, -0.442863},
    {0.951056, 0.262866, -0.162460},
    {0.809017, 0.500000, -0.309017},
    {0.681718, 0.716567, -0.147621},
    {0.850651, 0.525731, 0.000000},
    {0.864188, -0.238856, 0.442863},
    {0.809017, -0.500000, 0.309017},
    {0.951056, -0.262866, 0.162460},
    {0.525731, -0.850651, 0.000000},
    {0.681718, -0.716567, 0.147621},
    {0.681718, -0.716567, -0.147621},
    {0.850651, -0.525731, 0.000000},
    {0.809017, -0.500000, -0.309017},
    {0.864188, -0.238856, -0.442863},
    {0.951056, -0.262866, -0.162460},
    {0.147621, -0.681718, 0.716567},
    {0.309017, -0.809017, 0.500000},
    {0.425325, -0.587785, 0.688191},
    {0.442863, -0.864188, 0.238856},
    {0.587785, -0.688191, 0.425325},
    {0.688191, -0.425325, 0.587785},
    {-0.147621, -0.681718, 0.716567},
    {-0.309017, -0.809017, 0.500000},
    {0.000000, -0.850651, 0.525731},
    {-0.525731, -0.850651, 0.000000},
    {-0.442863, -0.864188, 0.238856},
    {-0.295242, -0.955423, 0.000000},
    {-0.162460, -0.951056, 0.262866},
    {0.000000, -1.000000, 0.000000},
    {0.295242, -0.955423, 0.000000},
    {0.162460, -0.951056, 0.262866},
    {-0.442863, -0.864188, -0.238856},
    {-0.309017, -0.809017, -0.500000},
    {-0.162460, -0.951056, -0.262866},
    {0.000000, -0.525731, -0.850651},
    {-0.147621, -0.681718, -0.716567},
    {0.147621, -0.681718, -0.716567},
    {0.000000, -0.850651, -0.525731},
    {0.309017, -0.809017, -0.500000},
    {0.442863, -0.864188, -0.238856},
    {0.162460, -0.951056, -0.262866},
    {0.238856, -0.442863, -0.864188},
    {0.500000, -0.309017, -0.809017},
    {0.425325, -0.587785, -0.688191},
    {0.716567, -0.147621, -0.681718},
    {0.688191, -0.425325, -0.587785},
    {0.587785, -0.688191, -0.425325},
    {0.000000, -0.295242, -0.955423},
    {0.000000, 0.000000, -1.000000},
    {0.262866, -0.162460, -0.951056},
    {0.000000, 0.525731, -0.850651},
    {0.000000, 0.295242, -0.955423},
    {0.238856, 0.442863, -0.864188},
    {0.262866, 0.162460, -0.951056},
    {0.500000, 0.309017, -0.809017},
    {0.716567, 0.147621, -0.681718},
    {0.525731, 0.000000, -0.850651},
    {-0.238856, -0.442863, -0.864188},
    {-0.500000, -0.309017, -0.809017},
    {-0.262866, -0.162460, -0.951056},
    {-0.850651, 0.000000, -0.525731},
    {-0.716567, -0.147621, -0.681718},
    {-0.716567, 0.147621, -0.681718},
    {-0.525731, 0.000000, -0.850651},
    {-0.500000, 0.309017, -0.809017},
    {-0.238856, 0.442863, -0.864188},
    {-0.262866, 0.162460, -0.951056},
    {-0.864188, 0.238856, -0.442863},
    {-0.809017, 0.500000, -0.309017},
    {-0.688191, 0.425325, -0.587785},
    {-0.681718, 0.716567, -0.147621},
    {-0.442863, 0.864188, -0.238856},
    {-0.587785, 0.688191, -0.425325},
    {-0.309017, 0.809017, -0.500000},
    {-0.147621, 0.681718, -0.716567},
    {-0.425325, 0.587785, -0.688191},
    {-0.162460, 0.951056, -0.262866},
    {0.442863, 0.864188, -0.238856},
    {0.162460, 0.951056, -0.262866},
    {0.309017, 0.809017, -0.500000},
    {0.147621, 0.681718, -0.716567},
    {0.000000, 0.850651, -0.525731},
    {0.425325, 0.587785, -0.688191},
    {0.587785, 0.688191, -0.425325},
    {0.688191, 0.425325, -0.587785},
    {-0.955423, 0.000000, 0.295242},
    {-0.951056, 0.262866, 0.162460},
    {-1.000000, 0.000000, 0.000000},
    {-0.850651, 0.525731, 0.000000},
    {-0.955423, 0.000000, -0.295242},
    {-0.951056, 0.262866, -0.162460},
    {-0.864188, -0.238856, 0.442863},
    {-0.951056, -0.262866, 0.162460},
    {-0.809017, -0.500000, 0.309017},
    {-0.864188, -0.238856, -0.442863},
    {-0.951056, -0.262866, -0.162460},
    {-0.809017, -0.500000, -0.309017},
    {-0.681718, -0.716567, 0.147621},
    {-0.681718, -0.716567, -0.147621},
    {-0.850651, -0.525731, 0.000000},
    {-0.688191, -0.425325, 0.587785},
    {-0.587785, -0.688191, 0.425325},
    {-0.425325, -0.587785, 0.688191},
    {-0.425325, -0.587785, -0.688191},
    {-0.587785, -0.688191, -0.425325},
    {-0.688191, -0.425325, -0.587785}
};

LsgMD2Model* LsgMD2Model_create(const char* filename) {
    LsgMD2Model* self = (LsgMD2Model*)malloc(sizeof(LsgMD2Model));

    LsgMD2Model_init(self, filename);

    return self;
}

void LsgMD2Model_load(LsgMD2Model* self, const char* filename);
void LsgMD2Model_init(LsgMD2Model* self, const char* filename) {
    LsgNode_init(&self->super);
    
    ((LsgObject*)self)->destroy = (void (*)(LsgObject*))LsgMD2Model_destroy;
    
    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))LsgMD2Model_display;
    
    ((LsgNode*)self)->bvolume = (LsgBVolume*)LsgBBox_create();

    self->frame = 0;
    self->skin  = -1;
    self->frame_count    = 0;
    self->triangle_count = 0;
    self->triangles      = NULL;
    self->tex_coords     = NULL;
    self->vertices       = NULL;
    self->normals        = NULL;
    self->skins          = NULL;
    
    LsgMD2Model_load(self, filename);
}

void LsgMD2Model_display(LsgMD2Model* self, LsgFrustum* frust) {
    Vertex* _vertices;
    int*    _normals;
    int t, v;

    glPushAttrib(GL_TEXTURE_BIT);
    
    if ((self->skin != -1) && (self->skins[self->skin] != 0)) {
        glBindTexture(GL_TEXTURE_2D, self->skins[self->skin]);
    }
    
    _vertices = self->vertices + (self->vertex_count * self->frame);
    _normals  = self->normals  + (self->vertex_count * self->frame);

    glBegin(GL_TRIANGLES);
    for (t = 0; t < self->triangle_count; ++t) {
        for (v = 0; v < 3; ++v) {
            int idx = self->triangles[t].vertices[v];

            glTexCoord2fv(self->tex_coords[self->triangles[t].tex_coords[v]]);
            glNormal3fv(normals[_normals[idx]]);
            glVertex3fv(_vertices[idx]);
        }
    }
    glEnd();

    glPopAttrib();
}

void LsgMD2Model_displayWireframe(LsgMD2Model* self, LsgFrustum* frust) {
    Vertex* _vertices;
    int*    _normals;
    int t, v;

    Vertex _v;
    Vertex _n;

    _vertices = self->vertices + (self->vertex_count * self->frame);
    _normals  = self->normals  + (self->vertex_count * self->frame);

    glPushAttrib(GL_ENABLE_BIT);
    glDisable(GL_LIGHTING);
    glDisable(GL_NORMALIZE);
    glDisable(GL_TEXTURE_2D);

    for (t = 0; t < self->triangle_count; ++t) {
        glColor3f(0.0, 0.0, 1.0);
        glBegin(GL_LINE_LOOP);
        for (v = 0; v < 3; ++v) {
            int idx = self->triangles[t].vertices[v];

            vertex_copy(_v, _vertices[idx]);
            vertex_copy(_n, normals[_normals[idx]]);

            glNormal3fv(_n);
            glVertex3fv(_v);

        }
        glEnd();

        glColor3f(1.0, 1.0, 1.0);
        glBegin(GL_LINES);
        for (v = 0; v < 3; ++v) {
            int idx = self->triangles[t].vertices[v];

            vertex_copy(_v, _vertices[idx]);
            vertex_copy(_n, normals[_normals[idx]]);
            glNormal3fv(_n);
            vertex_scale(_n, 5.0);

            glVertex3fv(_v);
            vertex_add(_v, _n);
            glVertex3fv(_v);
        }
        glEnd();
    }

    glPopAttrib();
}

void LsgMD2Model_destroy(LsgMD2Model* self) {
    if (self->triangles)  free(self->triangles);
    if (self->tex_coords) free(self->tex_coords);
    if (self->vertices)   free(self->vertices);
    if (self->normals)    free(self->normals);

    LsgNode_destroy(&self->super);
}

void LsgMD2Model_optimizeBBox(LsgMD2Model* self) {
    Vertex* _vertices;
    int i;
    
    self->super.bvolume->reset(self->super.bvolume);
    
    if (self->frame != -1) {
        _vertices = self->vertices + (self->vertex_count * self->frame);
        for (i = 0; i < self->vertex_count; ++i) {
            self->super.bvolume->include(self->super.bvolume, _vertices[i]);
        }
    }
    
    self->super.dirty = 1;
}

/* md2 model loader */
void LsgMD2Model_load(LsgMD2Model* self, const char* filename) {
    FILE* file;

    MD2FileHeader header;
    MD2FileSkin* skin;
    MD2FileTexCoord* tex_coord;
    MD2FileTriangle* triangle;
    MD2FileFrame* frame;
    unsigned char* buffer;
    int i,f;
    int fsize;

    /* open file */
    if (!(file = fopen(filename, "r"))) {
        fprintf(stderr, "%s: Could not open file\n", filename);
        return;
    }

    /* read header */
    if (fread(&header, sizeof(MD2FileHeader), 1, file) != 1) {
        fprintf(stderr, "%s: Could not read MD2 Header\n", filename);
        fclose(file);
        return;
    }

    /* check magic & version */
    if ((header.magic != 0x32504449) || (header.version != 8)) {
        fprintf(stderr, "%s: Unknown file format\n", filename);
        fclose(file);
        return;
    }

    /* read whole file */
    if (!(buffer = (unsigned char*)malloc(header.filesize))) {
        fprintf(stderr, "%s: Out ouf memory\n", filename);
        fclose(file);
        return;
    }

    fseek(file, 0, SEEK_SET);
    if (fread(buffer, header.filesize, 1, file) != 1) {
        fprintf(stderr, "%s: Read error\n", filename);
        fclose(file);
        free(buffer);
        return;
    }

    /* convert skins */
    skin = (MD2FileSkin*)(buffer + header.skin_offset);
    self->skins = (unsigned int*)malloc(sizeof(unsigned int) * header.skin_count);
    for (i = 0; i < header.skin_count; ++i) {
        LsgImage* image = LsgImage_loadPCX(skin[i]);
        if (image) {
            glGenTextures(1, &self->skins[i]);
            glBindTexture(GL_TEXTURE_2D, self->skins[i]);

            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, image->width, image->height, 0, GL_RGB, GL_UNSIGNED_BYTE, image->data);
            
            free(image);
            
            /* set skin to first successfully loaded texure */
            if (self->skin == -1) self->skin = i;
        } else {
            self->skins[i] = 0;
        }
    }

    /* convert texture coordinates */
    tex_coord = (MD2FileTexCoord*)(buffer + header.tex_coord_offset);
    self->tex_coords = (LsgTexCoord*)malloc(sizeof(LsgTexCoord) * header.tex_coord_count);
    for (i = 0; i < header.tex_coord_count; ++i) {
        self->tex_coords[i][0] = (float)tex_coord[i].s / header.skin_width;
        self->tex_coords[i][1] = (float)tex_coord[i].t / header.skin_height;
    }

    /* convert triangles */
    triangle = (MD2FileTriangle*)(buffer + header.triangle_offset);
    self->triangles = (LsgMD2Triangle*)malloc(sizeof(LsgMD2Triangle) * header.triangle_count);
    for (i = 0; i < header.triangle_count; ++i) {
        self->triangles[i].vertices[0] = (int)triangle[i].vertices[0];
        self->triangles[i].vertices[1] = (int)triangle[i].vertices[1];
        self->triangles[i].vertices[2] = (int)triangle[i].vertices[2];

        self->triangles[i].tex_coords[0] = (int)triangle[i].tex_coords[0];
        self->triangles[i].tex_coords[1] = (int)triangle[i].tex_coords[1];
        self->triangles[i].tex_coords[2] = (int)triangle[i].tex_coords[2];
    }

    /* convert frames */
    fsize = sizeof(MD2FileFrame) + (header.vertex_count - 1) * sizeof(MD2FileVertex);

    self->vertices = (Vertex*)malloc(header.frame_count * header.vertex_count * sizeof(Vertex));
    self->normals  = (int*)malloc(header.frame_count * header.vertex_count * sizeof(int));
    for (f = 0; f < header.frame_count; ++f) {
        frame = (MD2FileFrame*)(buffer + header.frame_offset + f * fsize);
        for (i = 0; i < header.vertex_count; ++i) {
            self->vertices[f * header.vertex_count + i][0] = (float)frame->vertices[i].v[0] * frame->scale[0] + frame->translate[0];
            self->vertices[f * header.vertex_count + i][2] = (float)frame->vertices[i].v[1] * frame->scale[1] + frame->translate[1];
            self->vertices[f * header.vertex_count + i][1] = (float)frame->vertices[i].v[2] * frame->scale[2] + frame->translate[2];

            self->super.bvolume->include(self->super.bvolume, self->vertices[f * header.vertex_count + i]);

            self->normals[f * header.vertex_count + i] = (int)frame->vertices[i].n;
        }
    }

    self->frame_count    = header.frame_count;
    self->triangle_count = header.triangle_count;
    self->vertex_count   = header.vertex_count;
    self->skin_count     = header.skin_count;

    free(buffer);
    fclose(file);
}
