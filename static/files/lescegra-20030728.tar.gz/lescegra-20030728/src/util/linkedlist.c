#include <lescegra/util/linkedlist.h>

#include <stdlib.h>

static LsgLinkedListElement* LsgLinkedList_createElement(void* data) {
    LsgLinkedListElement* el;

    el = (LsgLinkedListElement*)malloc(sizeof(LsgLinkedListElement));
    if (el) {
        el->next = NULL;
        el->value = data;
    }

    return el;
}

LsgLinkedList* LsgLinkedList_create(void) {
    LsgLinkedList* self = (LsgLinkedList*)malloc(sizeof(LsgLinkedList));

    LsgLinkedList_init(self);

    return self;
}

void LsgLinkedList_init(LsgLinkedList* self) {
    LsgList_init(&self->super);
    
    ((LsgObject*)self)->destroy = (void (*)(LsgObject*))LsgLinkedList_destroy;
    
    ((LsgList*)self)->count         = (int (*)(LsgList*))LsgLinkedList_count;
    ((LsgList*)self)->index         = (int (*)(LsgList*, void*))LsgLinkedList_index;
    ((LsgList*)self)->append        = (void (*)(LsgList*, void*))LsgLinkedList_append;
    ((LsgList*)self)->insert        = (void (*)(LsgList*, int, void*))LsgLinkedList_insert;
    ((LsgList*)self)->remove        = (void (*)(LsgList*, void*))LsgLinkedList_remove;
    ((LsgList*)self)->removeByIndex = (void (*)(LsgList*, int))LsgLinkedList_removeByIndex;
    ((LsgList*)self)->get           = (void* (*)(LsgList*, int))LsgLinkedList_get;
    ((LsgList*)self)->set           = (void (*)(LsgList*, int, void*))LsgLinkedList_set;
    ((LsgList*)self)->clear         = (void (*)(LsgList*))LsgLinkedList_clear;
    ((LsgList*)self)->iterator      = (LsgIterator* (*)(LsgList*))LsgLinkedList_iterator;
    
    self->first = NULL;
}

int LsgLinkedList_count(LsgLinkedList* self) {
    int count = 0;
    LsgLinkedListElement* elem;

    elem = self->first;
    while (elem) {
        ++count;
        elem = elem->next;
    }

    return count;
}

int LsgLinkedList_index(LsgLinkedList* self, void* object) {
    LsgLinkedListElement* el;
    int index = 0;
    
    el = self->first;
    while (el) {
        if (el->value == object) {
            return index;
        }
        el = el->next;
        ++index;
    }
    
    return -1;
}

void LsgLinkedList_append(LsgLinkedList* self, void* data) {
    LsgLinkedListElement* el;
    LsgLinkedListElement* nel;

    nel = LsgLinkedList_createElement(data);
    
    if (self->first) {
        el = self->first;
        while (el->next) {
            el = el->next;
        }
        el->next = nel;
    } else {
        self->first = nel;
    }
}

void LsgLinkedList_insert(LsgLinkedList* self, int index, void* data) {
    LsgLinkedListElement* el;
    LsgLinkedListElement* nel;
    int pos = 1;

    nel = LsgLinkedList_createElement(data);
    
    if ((index == 0) || (self->first == NULL)) {
        nel->next = self->first;
        self->first = nel;
    } else {
        el = self->first;
        while (el->next && (pos < index)) {
            ++pos;
            el = el->next;
        }

        nel->next = el->next;
        el->next = nel;
    }
}

void LsgLinkedList_remove(LsgLinkedList* self, void* data) {
    LsgLinkedListElement* el;
    LsgLinkedListElement* prev = NULL;
    
    el = self->first;
    while (el) {
        if (el->value == data) {
            if (prev) {
                prev->next = el->next;
            } else {
                self->first = el->next;
            }
            free(el);
            return;
        }
        prev = el;
        el = el->next;
    }
}

void LsgLinkedList_removeByIndex(LsgLinkedList* self, int index) {
    LsgLinkedListElement* el;
    LsgLinkedListElement* prev = NULL;
    int pos = 0;

    el = self->first;
    while (el && (pos < index)) {
        ++pos;
        prev = el;
        el = el->next;
    }

    if (prev) {
        prev->next = el->next;
    } else {
        self->first = el->next;
    }

    free(el);
}

void LsgLinkedList_set(LsgLinkedList* self, int index, void* data) {
    LsgLinkedListElement* el;
    int pos = 0;

    el = self->first;
    while (el && (pos < index)) {
        ++pos;
        el = el->next;
    }

    if (el) {
        el->value = data;
    }
}

void* LsgLinkedList_get(LsgLinkedList* self, int index) {
    LsgLinkedListElement* el;
    int pos = 0;

    el = self->first;
    while (el && (pos < index)) {
        ++pos;
        el = el->next;
    }

    if (el) {
        return el->value;
    } else {
        return NULL;
    }
}

void LsgLinkedList_clear(LsgLinkedList* self) {
    LsgLinkedListElement* el;
    LsgLinkedListElement* next_el;

    el = self->first;
    while (el) {
        next_el = el->next;
        free(el);
        el = next_el;
    }
    self->first = NULL;
}

LsgIterator* LsgLinkedList_iterator(LsgLinkedList* self) {
    LsgLinkedListIterator* it = (LsgLinkedListIterator*)malloc(sizeof(LsgLinkedListIterator));

    LsgLinkedListIterator_init(it, self);

    return (LsgIterator*)it;
}

void LsgLinkedList_destroy(LsgLinkedList* self) {
    ((LsgList*)self)->clear((LsgList*)self);
    
    LsgList_destroy(&self->super);
}

/* LsgLinkedListIterator ***********************************************************/

void LsgLinkedListIterator_init(LsgLinkedListIterator* self, LsgLinkedList* list) {
    LsgIterator_init(&self->super);

    ((LsgIterator*)self)->hasNext = (int (*)(LsgIterator*))LsgLinkedListIterator_hasNext;    
    ((LsgIterator*)self)->next    = (void* (*)(LsgIterator*))LsgLinkedListIterator_next;    
    ((LsgIterator*)self)->index   = (int (*)(LsgIterator*))LsgLinkedListIterator_index;    
    
    self->index = -1;
    self->element = list->first;
}

int LsgLinkedListIterator_hasNext(LsgLinkedListIterator* self) {
    return self->element != NULL;
}

void* LsgLinkedListIterator_next(LsgLinkedListIterator* self) {
    void* value;

    if (self->element) {
        value = self->element->value;
        self->element = self->element->next;
        ++(self->index);
        return value;
    } else {
        return NULL;
    }
}

int LsgLinkedListIterator_index(LsgLinkedListIterator* self) {
    return self->index;
}
