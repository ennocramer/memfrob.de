#include <lescegra/util/matrix.h>

#include <math.h>

#define MATRIX_ELEMENT(matrix, row, col) (matrix)[(col) * 4 + (row)]

#define MATRIX_SET_ROW(matrix, row, a, b, c, d) \
    MATRIX_ELEMENT(matrix, row, 0) = a; \
    MATRIX_ELEMENT(matrix, row, 1) = b; \
    MATRIX_ELEMENT(matrix, row, 2) = c; \
    MATRIX_ELEMENT(matrix, row, 3) = d;

#define MATRIX_INNER_PRODUCT(m1, m2, r, c) \
    (MATRIX_ELEMENT(m1, r, 0) * MATRIX_ELEMENT(m2, 0, c) + \
     MATRIX_ELEMENT(m1, r, 1) * MATRIX_ELEMENT(m2, 1, c) + \
     MATRIX_ELEMENT(m1, r, 2) * MATRIX_ELEMENT(m2, 2, c) + \
     MATRIX_ELEMENT(m1, r, 3) * MATRIX_ELEMENT(m2, 3, c))

/* beware: opengl matrices are column major numbered. so every line here
 * is one row in the matrix ... not that it would make any difference ;)
 */
const Matrix matrix_identity = {
    1, 0, 0, 0,
    0, 1, 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1
};

void matrix_load_identity(Matrix m) {
    matrix_copy(m, (float*)matrix_identity);
}

void matrix_load_translate(Matrix m, float x, float y, float z) {
    MATRIX_SET_ROW(m, 0,    1, 0, 0, x);
    MATRIX_SET_ROW(m, 1,    0, 1, 0, y);
    MATRIX_SET_ROW(m, 2,    0, 0, 1, z);
    MATRIX_SET_ROW(m, 3,    0, 0, 0, 1);
}

void matrix_load_translatev(Matrix m, Vertex v) {
    matrix_load_translate(m, v[0], v[1], v[2]);
}

void matrix_load_scale(Matrix m, float x, float y, float z) {
    MATRIX_SET_ROW(m, 0,    x, 0, 0, 0);
    MATRIX_SET_ROW(m, 1,    0, y, 0, 0);
    MATRIX_SET_ROW(m, 2,    0, 0, z, 0);
    MATRIX_SET_ROW(m, 3,    0, 0, 0, 1);
}

void matrix_load_scalev(Matrix m, Vertex v) {
    matrix_load_scale(m, v[0], v[1], v[2]);
}

void matrix_load_rotate(Matrix m, float x, float y, float z) {
    Matrix r;
    
    matrix_load_identity(m);
    
    MATRIX_SET_ROW(r, 0,          1,       0,       0,      0);
    MATRIX_SET_ROW(r, 1,          0,  cos(x), -sin(x),      0);
    MATRIX_SET_ROW(r, 2,          0,  sin(x),  cos(x),      0);
    MATRIX_SET_ROW(r, 3,          0,       0,       0,      1);
    matrix_mult(m, r);

    MATRIX_SET_ROW(r, 0,     cos(y),       0,  sin(y),      0);
    MATRIX_SET_ROW(r, 1,          0,       1,       0,      0);
    MATRIX_SET_ROW(r, 2,    -sin(y),       0,  cos(y),      0);
    MATRIX_SET_ROW(r, 3,          0,       0,       0,      1);
    matrix_mult(m, r);

    MATRIX_SET_ROW(r, 0,     cos(z), -sin(z),       0,      0);
    MATRIX_SET_ROW(r, 1,     sin(z),  cos(z),       0,      0);
    MATRIX_SET_ROW(r, 2,          0,       0,       1,      0);
    MATRIX_SET_ROW(r, 3,          0,       0,       0,      1);
    matrix_mult(m, r);
}

void matrix_load_rotatev(Matrix m, Vertex v) {
    matrix_load_rotate(m, v[0], v[1], v[2]);
}

void matrix_load_ortho(Matrix m, float x1, float x2, float y1, float y2, float z1, float z2) {
    MATRIX_SET_ROW(m, 0,    2/(x2-x1),         0,         0, (x2+x1)/(x2-x1));
    MATRIX_SET_ROW(m, 1,            0, 2/(y2-y1),         0, (y2+y1)/(y2-y1));
    MATRIX_SET_ROW(m, 2,            0,         0, 2/(z1-z2), (z2+z1)/(z2-z1));
    MATRIX_SET_ROW(m, 3,            0,         0,         0,               1);
}

void matrix_load_frustum(Matrix m, float x1, float x2, float y1, float y2, float z1, float z2) {
    MATRIX_SET_ROW(m, 0,    2*z1/(x2-x1),            0,               0,               0);
    MATRIX_SET_ROW(m, 1,               0, 2*z1/(y2-y1),               0,               0);
    MATRIX_SET_ROW(m, 2,               0,            0, (z2+z1)/(z1-z2), 2*z1*z2/(z1-z2));
    MATRIX_SET_ROW(m, 3,               0,            0,              -1,               0);
}

void matrix_load_perspective(Matrix m, float fovy, float aspect, float near, float far) {
#if 1
    float x,y;
    
    y = near * tan(fovy / 2.0);
    x = y * aspect;
    
    matrix_load_frustum(m, -x, x, -y, y, near, far);
#else
    float f;
    
    f = 1.0/tan(fovy / 2.0);
    
    MATRIX_SET_ROW(m, 0,    f / aspect, 0,                     0,                     0);
    MATRIX_SET_ROW(m, 1,             0, f,                     0,                     0);
    MATRIX_SET_ROW(m, 2,             0, 0, (near+far)/(near-far), 2*near*far/(near-far));
    MATRIX_SET_ROW(m, 3,             0, 0,                    -1,                     0);
#endif
}

void matrix_load_lookat(Matrix m, Vertex from, Vertex to, Vertex up) {
    Vertex x, y, z;
    Matrix m_trans;
    
    vertex_copy(z, to);
    vertex_sub(z, from);
    vertex_normalize(z);
    
    vertex_copy(x, z);
    vertex_cross(x, up);
    vertex_normalize(x);
    
    vertex_copy(y, x);
    vertex_cross(y, z);
/*  vertex_normalize(y); */
    
    MATRIX_SET_ROW(m, 0,  x[0],  x[1],  x[2],   0.0);
    MATRIX_SET_ROW(m, 1,  y[0],  y[1],  y[2],   0.0);
    MATRIX_SET_ROW(m, 2, -z[0], -z[1], -z[2],   0.0);
    MATRIX_SET_ROW(m, 3,   0.0,   0.0,   0.0,   1.0);
    
    matrix_load_translate(m_trans, -from[0], -from[1], -from[2]);
    
    matrix_mult(m, m_trans);
}

void matrix_load_pick(Matrix m, float x, float y, float w, float h,
        float vp_x, float vp_y, float vp_w, float vp_h) {
    float sx, sy, tx, ty;
    
    sx = vp_w / w;
    sy = vp_h / h;
    tx = (vp_w + 2.0 * (vp_x - x)) / w;
    ty = (vp_h + 2.0 * (vp_y - y)) / h;
    
    MATRIX_SET_ROW(m, 0,     sx, 0.0, 0.0,  tx);
    MATRIX_SET_ROW(m, 1,    0.0,  sy, 0.0,  ty);
    MATRIX_SET_ROW(m, 2,    0.0, 0.0, 1.0, 0.0);
    MATRIX_SET_ROW(m, 3,    0.0, 0.0, 0.0, 1.0);
}

void matrix_copy(Matrix dst, const Matrix src) {
    int i;
    
    for (i = 0; i < 16; ++i)
        dst[i] = src[i];
}

void matrix_mult(Matrix dst, const Matrix src) {
    int row, col;
    float buffer_row[4];
    
    for (row = 0; row < 4; ++row) {
        for (col = 0; col < 4; ++col) {
            buffer_row[col] = MATRIX_INNER_PRODUCT(dst, src, row, col);
        }
        for (col = 0; col < 4; ++col) {
            MATRIX_ELEMENT(dst, row, col) = buffer_row[col];
        }
    }
}

void matrix_premult(Matrix dst, const Matrix src) {
    int row, col;
    float buffer_col[4];
    
    for (col = 0; col < 4; ++col) {
        for (row = 0; row < 4; ++row) {
            buffer_col[row] = MATRIX_INNER_PRODUCT(src, dst, row, col);
        }
        for (row = 0; row < 4; ++row) {
            MATRIX_ELEMENT(dst, row, col) = buffer_col[row];
        }
    }
}

void matrix_transpose(Matrix m) {
    int r, c;
    float buff;
    
    for (r = 1; r < 4; ++r) {
        for (c = 0; c < r; ++c) {
            buff = MATRIX_ELEMENT(m, r, c);
            MATRIX_ELEMENT(m, r, c) = MATRIX_ELEMENT(m, c, r);
            MATRIX_ELEMENT(m, c, r) = buff;
        }
    }
}

void matrix_invert(Matrix m) {
    Matrix tmp;
    int row, col, i;
    float f;
    
    matrix_load_identity(tmp);
    
    for (i = 0; i < 4; ++i) {
        f = 1.0 / MATRIX_ELEMENT(m, i, i);
        for (col = i; col < 4; ++col) {
            MATRIX_ELEMENT(m, i, col) *= f;
        }
        for (col = 0; col < 4; ++col) {
            MATRIX_ELEMENT(tmp, i, col) *= f;
        }
        
        for (row = i + 1; row < 4; ++row) {
            f = MATRIX_ELEMENT(m, row, i);
            for (col = 0; col < 4; ++col) {
                MATRIX_ELEMENT(m, row, col) -= f * MATRIX_ELEMENT(m, i, col);
                MATRIX_ELEMENT(tmp, row, col) -= f * MATRIX_ELEMENT(tmp, i, col);
            }
        }
    }
    
    for (i = 3; i >= 0; --i) {
        for (row = i - 1; row >= 0; --row) {
            f = MATRIX_ELEMENT(m, row, i);
            for (col = 0; col < 4; ++col) {
                MATRIX_ELEMENT(m, row, col) -= f * MATRIX_ELEMENT(m, i, col);
                MATRIX_ELEMENT(tmp, row, col) -= f * MATRIX_ELEMENT(tmp, i, col);
            }
        }
    }
    
    matrix_copy(m, tmp);
}

void matrix_apply(const Matrix m, Vertex v) {
    int row;
    float buffer[4];
    
    for (row = 0; row < 4; ++row) {
        buffer[row] = MATRIX_ELEMENT(m, row, 0) * v[0] +
                      MATRIX_ELEMENT(m, row, 1) * v[1] +
                      MATRIX_ELEMENT(m, row, 2) * v[2] +
                      MATRIX_ELEMENT(m, row, 3) * 1.0;
    }
    
    for (row = 0; row < 3; ++row) {
        v[row] = buffer[row] / buffer[3];
    }
}

void matrix_preapply(const Matrix m, Vertex v) {
    int col;
    float buffer[4];
    
    for (col = 0; col < 4; ++col) {
        buffer[col] = MATRIX_ELEMENT(m, 0, col) * v[0] +
                      MATRIX_ELEMENT(m, 1, col) * v[1] +
                      MATRIX_ELEMENT(m, 2, col) * v[2] +
                      MATRIX_ELEMENT(m, 3, col) * 1.0;
    }
    
    for (col = 0; col < 3; ++col) {
        v[col] = buffer[col] / buffer[3];
    }
}

void matrix_applyVector(const Matrix m, Vertex v) {
    int row;
    Vertex buffer;
    
    for (row = 0; row < 3; ++row) {
        buffer[row] = MATRIX_ELEMENT(m, row, 0) * v[0] +
                      MATRIX_ELEMENT(m, row, 1) * v[1] +
                      MATRIX_ELEMENT(m, row, 2) * v[2];
    }
    
    vertex_copy(v, buffer);
}

void matrix_preapplyVector(const Matrix m, Vertex v) {
    int col;
    Vertex buffer;
    
    for (col = 0; col < 3; ++col) {
        buffer[col] = MATRIX_ELEMENT(m, 0, col) * v[0] +
                      MATRIX_ELEMENT(m, 1, col) * v[1] +
                      MATRIX_ELEMENT(m, 2, col) * v[2];
    }
    
    vertex_copy(v, buffer);
}
