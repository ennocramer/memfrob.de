#include <lescegra/util/endian.h>

LsgEndian_Endianess LsgEndian_endianess(void) {
    static char endian_little[2] = {1, 0};
    
    if (*((short int*)endian_little) == 1) {
        return LsgEndian_LITTLE;
    } else {
        return LsgEndian_BIG;
    }
}

void LsgEndian_swap(char* buffer, int size) {
    char tmp;
    char* src;
    char* dst;
    
    src = buffer;
    dst = buffer + size - 1;
    while (src < dst) {
        tmp = *src;
        *src = *dst;
        *dst = tmp;
        ++src; --dst;
    }
}

void LsgEndian_swapArray(char* buffer, int size, int count) {
    int c;
    
    for (c = 0; c < count; ++c) {
        LsgEndian_swap(buffer + c * size, size);
    }
}

void LsgEndian_swapShort(short int* buffer) {
    LsgEndian_swap((char*)buffer, sizeof(short int));
}

void LsgEndian_swapInt(int* buffer) {
    LsgEndian_swap((char*)buffer, sizeof(int));
}

void LsgEndian_swapLong(long int* buffer) {
    LsgEndian_swap((char*)buffer, sizeof(long int));
}
