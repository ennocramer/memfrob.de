#include <lescegra/util/image.h>

#include <lescegra/util/error.h>

#include <stdlib.h>
#include <string.h>

LsgImage* LsgImage_create(int width, int height, int bpp) {
    LsgImage* self = (LsgImage*)malloc(sizeof(LsgImage));
    
    LsgImage_init(self, width, height, bpp);
    
    return self;
}

void LsgImage_init(LsgImage* self, int width, int height, int bpp) {
    LsgObject_init(&self->super);
    
    ((LsgObject*)self)->destroy = (void (*)(LsgObject*))LsgImage_destroy;

    self->width = width;
    self->height = height;
    self->bpp = bpp;
    
    self->data = (unsigned char*)malloc(sizeof(unsigned char) * width * height * bpp);
}

void LsgImage_destroy(LsgImage* self) {
    if (self->data) free(self->data);
    
    LsgObject_destroy(&self->super);
}

void LsgImage_mirrorX(LsgImage* self) {
    unsigned char* tmp;
    int x, y;
    
    tmp = (unsigned char*)malloc(sizeof(unsigned char) * self->bpp);
    
    for (y = 0; y < self->height; ++y) {
        for (x = 0; x < self->width / 2; ++x) {
            memcpy(tmp, self->data + (y * self->width + x) * self->bpp, sizeof(unsigned char) * self->bpp);
            memcpy(self->data + (y * self->width + x) * self->bpp, self->data + (y * self->width + (self->width - x - 1)) * self->bpp, sizeof(unsigned char) * self->bpp);
            memcpy(self->data + (y * self->width + (self->width - x - 1)) * self->bpp, tmp, sizeof(unsigned char) * self->bpp);
        }
    }
}

void LsgImage_mirrorY(LsgImage* self) {
    unsigned char* tmp;
    int tmp_size;
    int y;
    
    tmp_size = self->width * self->bpp;
    tmp = (unsigned char*)malloc(sizeof(unsigned char) * tmp_size);
    
    for (y = 0; y < self->height / 2; ++y) {
        memcpy(tmp, self->data + y * tmp_size, sizeof(unsigned char) * tmp_size);
        memcpy(self->data + y * tmp_size, self->data + (self->height - y - 1) * tmp_size, sizeof(unsigned char) * tmp_size);
        memcpy(self->data + (self->height - y - 1) * tmp_size, tmp, sizeof(unsigned char) * tmp_size);
    }
    
    free(tmp);
}

LsgImage* LsgImage_load(const char* filename) {
    int len = strlen(filename);
    
    if (!strcmp(filename + len - 4, ".pcx")) {
        return LsgImage_loadPCX(filename);
    } else if (!strcmp(filename + len - 4, ".tga")) {
        return LsgImage_loadTGA(filename);
    } else {
        LsgError_addFormat(__FILE__, "LsgImage_load", __LINE__, "%s: Unknown image format\n", filename);
        return NULL;
    }
}
