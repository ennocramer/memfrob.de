#include <lescegra/util/list.h>

#include <stddef.h>

void LsgIterator_init(LsgIterator* self) {
    LsgObject_init(&self->super);
    
    self->hasNext = NULL;
    self->next    = NULL;
    self->index   = NULL;
}

void LsgList_init(LsgList* self) {
    LsgObject_init(&self->super);
    
    self->count         = NULL;
    self->contains      = LsgList_contains;
    self->index         = NULL;
    self->append        = LsgList_append;
    self->insert        = NULL;
    self->remove        = LsgList_remove;
    self->removeByIndex = NULL;
    self->get           = NULL;
    self->set           = NULL;
    self->clear         = NULL;
    self->iterator      = NULL;
}

int LsgList_contains(LsgList* self, void* object) {
    return self->index(self, object) != -1;
}

void LsgList_append(LsgList* self, void* object) {
    self->insert(self, self->count(self), object);
}

void LsgList_remove(LsgList* self, void* object) {
    int idx;
    
    idx = self->index(self, object);
    if (idx != -1) self->removeByIndex(self, idx);
}
