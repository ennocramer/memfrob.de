#include <lescegra/util/primitives.h>

#include <GL/gl.h>

#include <stdlib.h>
#include <math.h>

#ifndef M_PI
# define M_PI    3.14159265358979323846
#endif

void draw_sphere(float radius, int details) {
    float x1, x2, y1, y2, z1, z2;
    float r1, r2;
    int i, f;

    /* top */
    y2 = cos(M_PI * (float)1 / (float)details) * radius;
    r2 = sqrt(radius * radius - y2 * y2);

    glBegin(GL_TRIANGLE_FAN);
    glNormal3f(0.0, 1.0, 0.0);
    glVertex3f(0.0, radius, 0.0);
    for (f = 0; f <= 2*details; ++f) {
        float a = M_PI * (float)f / (float)details;

        x2 = r2 * sin(a);
        z2 = r2 * cos(a);

        glNormal3f(x2, y2, z2);
        glVertex3f(x2, y2, z2);
    }
    glEnd();

    /* middle */
    for (i = 1; i < details - 1; ++i) {
        y1 = cos(M_PI * (float)i / (float)details) * radius;
        y2 = cos(M_PI * (float)(i+1) / (float)details) * radius;

        r1 = sqrt(radius * radius - y1 * y1);
        r2 = sqrt(radius * radius - y2 * y2);

        glBegin(GL_TRIANGLE_STRIP);
        for (f = 0; f <= 2*details; ++f) {
            float a = M_PI * (float)f / (float)details;

            x1 = r1 * sin(a - ((i+1) & 1) * 0.5 * M_PI / (float)details);
            z1 = r1 * cos(a - ((i+1) & 1) * 0.5 * M_PI / (float)details);
            x2 = r2 * sin(a + (i & 1)     * 0.5 * M_PI / (float)details);
            z2 = r2 * cos(a + (i & 1)     * 0.5 * M_PI / (float)details);

            glNormal3f(x1, y1, z1);
            glVertex3f(x1, y1, z1);
            glNormal3f(x2, y2, z2);
            glVertex3f(x2, y2, z2);
        }
        glEnd();
    } 

    /* bottom */
    y1 = cos(M_PI * (float)(details - 1) / (float)details) * radius;
    r1 = sqrt(radius * radius - y1 * y1);

    glBegin(GL_TRIANGLE_FAN);
    glNormal3f(0.0, -1.0, 0.0);
    glVertex3f(0.0, -radius, 0.0);
    for (f = 0; f <= 2*details; ++f) {
        float a = M_PI * (float)f / (float)details;

        /* i is set by the previous for loop */
        x1 = r1 * sin(a - ((i+1) & 1) * 0.5 * M_PI / (float)details);
        z1 = r1 * cos(a - ((i+1) & 1) * 0.5 * M_PI / (float)details);

        glNormal3f(x1, y1, z1);
        glVertex3f(x1, y1, z1);
    }
    glEnd();
}
