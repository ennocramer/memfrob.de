#include <lescegra/util/image.h>

#include <lescegra/util/error.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

typedef struct {
    unsigned char id_length;
    unsigned char palette_type;
    unsigned char image_type;
    unsigned char palette_spec[5];
    unsigned char image_spec[10];
} TGAHeader;

static void putpixel(unsigned char* pixel, unsigned char* buffer, int buffersize) {
    if (buffersize == 4) {
        pixel[0] = buffer[3];
        pixel[1] = buffer[2];
        pixel[2] = buffer[1];
        pixel[3] = buffer[0];
    } else if (buffersize == 3) {
        pixel[0] = buffer[2];
        pixel[1] = buffer[1];
        pixel[2] = buffer[0];
    } else {
        pixel[0] = (buffer[1] & 0x7C) >> 2;
        pixel[1] = (buffer[1] & 0x03) | (buffer[0] & 0xE0) >> 5;
        pixel[2] = buffer[0] & 0x1F;
    }
}

LsgImage* LsgImage_loadTGA(const char* filename) {
    FILE* file = NULL;
    unsigned char* palette = NULL;
    LsgImage* image = NULL;

    TGAHeader header;
    unsigned char buffer[4];
    int cmap_len, pixel_size;
    int width, height, bpp;
    int pixel;

    /* open file */
    if (!(file = fopen(filename, "r"))) {
        LsgError_addFormat(__FILE__, "LsgImage_loadTGA", __LINE__, "%s: Could not open file\n", filename);
        goto LsgImage_loadTGA_Error;
    }

    /* read header */
    if (fread(&header, sizeof(TGAHeader), 1, file) != 1) {
        LsgError_addFormat(__FILE__, "LsgImage_loadTGA", __LINE__, "%s: Could not read TGA Header\n", filename);
        goto LsgImage_loadTGA_Error;
    }

    if ((header.image_type & ~0xB) || ((header.image_type && 0x3) == 0x3)) {
        LsgError_addFormat(__FILE__, "LsgImage_loadTGA", __LINE__, "%s: Usupported image format\n", filename);
        goto LsgImage_loadTGA_Error;
    }

    if ((header.image_type & 0x1) && (!header.palette_type)) {
        LsgError_addFormat(__FILE__, "LsgImage_loadTGA", __LINE__, "%s: Color-mapped image without color map\n", filename);
        goto LsgImage_loadTGA_Error;
    }

    bpp = pixel_size = (header.image_spec[8] + 7) / 8;

    /* skip image id */
    fseek(file, header.id_length, SEEK_CUR);

    /* read color palette data */
    if (header.palette_type) {
        int cmap_size, cmap_entry;
        
        cmap_entry = header.palette_spec[4] / 8;
        cmap_len = (header.palette_spec[3] << 8) + header.palette_spec[2];
        cmap_size = cmap_entry == 4 ? 4 : 3;

        if ((header.image_type & 0x3) == 0x1) {
            if (!(palette = (unsigned char*)malloc(sizeof(char) * cmap_len * cmap_size))) {
                LsgError_addFormat(__FILE__, "LsgImage_loadTGA", __LINE__, "%s: Out of memory\n", filename);
                goto LsgImage_loadTGA_Error;
            }

            for (pixel = 0; pixel < cmap_len; ++pixel) {
                if (fread(buffer, sizeof(unsigned char), cmap_entry, file) != cmap_entry) {
                    LsgError_addFormat(__FILE__, "LsgImage_loadTGA", __LINE__, "%s: Error reading palette\n", filename);
                    goto LsgImage_loadTGA_Error;
                }

                putpixel(palette + pixel * cmap_size, buffer, cmap_entry);
            }
            
            bpp = cmap_size;
        } else {
            fseek(file, cmap_len * cmap_entry, SEEK_CUR);
        }
    }
    
    width = (header.image_spec[5] << 8) + header.image_spec[4];
    height = (header.image_spec[7] << 8) + header.image_spec[6];
    if (!(image = LsgImage_create(width, height, bpp)) || !image->data) {
        LsgError_addFormat(__FILE__, "LsgImage_loadTGA", __LINE__, "%s: Out of memory\n", filename);
        goto LsgImage_loadTGA_Error;
    }

    pixel = 0;
    /* load pixel data */
    /* RLE encoded */
    if (header.image_type & 0x8) {
        int count;
        
        while (pixel < width * height) {
            if (fread(buffer, sizeof(unsigned char), 1, file) != 1) {
                LsgError_addFormat(__FILE__, "LsgImage_loadTGA", __LINE__, "%s: I/O Error\n", filename);
                goto LsgImage_loadTGA_Error;
            }
            
            count = (buffer[0] & 0x7F) + 1;
            /* RLE packet */
            if (buffer[0] & 0x80) {
                unsigned char color[4];
                if (fread(buffer, sizeof(unsigned char), pixel_size, file) != pixel_size) {
                    LsgError_addFormat(__FILE__, "LsgImage_loadTGA", __LINE__, "%s: I/O Error\n", filename);
                    goto LsgImage_loadTGA_Error;
                }
                if (palette) {
                    int idx, i;

                    for (i = 0, idx = 0; i < pixel_size; ++i) {
                        idx += buffer[i] << (8 * i);
                    }

                    memcpy(color, palette + idx * bpp, sizeof(unsigned char) * bpp);
                } else {
                    putpixel(color, buffer, pixel_size);
                }
                
                while (count--) {
                    memcpy(image->data + pixel * bpp, color, sizeof(unsigned char) * bpp);
                    ++pixel;
                }
                
            /* RAW packet */
            } else {
                while (count--) {
                    if (fread(buffer, sizeof(unsigned char), pixel_size, file) != pixel_size) {
                        LsgError_addFormat(__FILE__, "LsgImage_loadTGA", __LINE__, "%s: I/O Error\n", filename);
                        goto LsgImage_loadTGA_Error;
                    }
                    if (palette) {
                        int idx, i;

                        for (i = 0, idx = 0; i < pixel_size; ++i) {
                            idx += buffer[i] << (8 * i);
                        }

                        memcpy(image->data + pixel * bpp, palette + idx * bpp, sizeof(unsigned char) * bpp);
                    } else {
                        putpixel(image->data + pixel * bpp, buffer, pixel_size);
                    }
                    ++pixel;
                }
            }
        }
        
    /* uncompressed */
    } else {
        while (pixel < width * height) {
            if (fread(buffer, sizeof(unsigned char), pixel_size, file) != pixel_size) {
                LsgError_addFormat(__FILE__, "LsgImage_loadTGA", __LINE__, "%s: I/O Error\n", filename);
                goto LsgImage_loadTGA_Error;
            }
            
            if (palette) {
                int idx, i;
                
                for (i = 0, idx = 0; i < pixel_size; ++i) {
                    idx += buffer[i] << (8 * i);
                }
                
                memcpy(image->data + pixel++ * bpp, palette + idx * bpp, sizeof(unsigned char) * bpp);
            } else {
                putpixel(image->data + pixel++ * bpp, buffer, pixel_size);
            }
        }
    }
    
    if (!(header.image_spec[9] & 0x20)) LsgImage_mirrorY(image);

    if (palette) free(palette);
    fclose(file);
    return image;

    LsgImage_loadTGA_Error:
        if (file) fclose(file);
        if (palette) free(palette);
        if (image) LsgObject_free((LsgObject*)image);
        return NULL;
}
