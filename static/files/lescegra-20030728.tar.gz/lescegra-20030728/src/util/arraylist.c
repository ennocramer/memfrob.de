#include <lescegra/util/arraylist.h>

#include <stdlib.h>
#include <string.h>

#define LSG_ARRAYLIST_CAPACITY 256

static void LsgArrayList_grow(LsgArrayList* self) {
    self->capacity *= 2;
    self->elements = realloc(self->elements, sizeof(void*) * self->capacity);
}

static void LsgArrayList_shrink(LsgArrayList* self) {
    self->capacity /= 2;
    self->elements = realloc(self->elements, sizeof(void*) * self->capacity);
}

LsgArrayList* LsgArrayList_create(void) {
    LsgArrayList* self = (LsgArrayList*)malloc(sizeof(LsgArrayList));

    LsgArrayList_init(self);

    return self;
}

void LsgArrayList_init(LsgArrayList* self) {
    LsgList_init(&self->super);
    
    ((LsgObject*)self)->destroy = (void (*)(LsgObject*))LsgArrayList_destroy;
    
    ((LsgList*)self)->count         = (int (*)(LsgList*))LsgArrayList_count;
    ((LsgList*)self)->index         = (int (*)(LsgList*, void*))LsgArrayList_index;
    ((LsgList*)self)->insert        = (void (*)(LsgList*, int, void*))LsgArrayList_insert;
    ((LsgList*)self)->removeByIndex = (void (*)(LsgList*, int))LsgArrayList_removeByIndex;
    ((LsgList*)self)->get           = (void* (*)(LsgList*, int))LsgArrayList_get;
    ((LsgList*)self)->set           = (void (*)(LsgList*, int, void*))LsgArrayList_set;
    ((LsgList*)self)->clear         = (void (*)(LsgList*))LsgArrayList_clear;
    ((LsgList*)self)->iterator      = (LsgIterator* (*)(LsgList*))LsgArrayList_iterator;
    
    self->count = 0;
    self->capacity = LSG_ARRAYLIST_CAPACITY;
    self->elements = (void**)malloc(sizeof(void*) * LSG_ARRAYLIST_CAPACITY);
}

int LsgArrayList_count(LsgArrayList* self) {
    return self->count;
}

int LsgArrayList_index(LsgArrayList* self, void* object) {
    int i;
    
    for (i = 0; i < self->count; ++i) {
        if (self->elements[i] == object) {
            return i;
        }
    }
    
    return -1;
}

void LsgArrayList_insert(LsgArrayList* self, int index, void* data) {
    if (self->count >= self->capacity) LsgArrayList_grow(self);
    
    if (index > self->count) index = self->count;
    
    memmove(self->elements + index + 1, self->elements + index, sizeof(void*) * (self->count - index));
    self->elements[index] = data;
    
    ++self->count;
}

void LsgArrayList_removeByIndex(LsgArrayList* self, int index) {
    if (index >= self->count) return;
    
    memmove(self->elements + index, self->elements + index + 1, sizeof(void*) * (self->count - index - 1));
    
    --self->count;
    
    if ((self->capacity > LSG_ARRAYLIST_CAPACITY) && (self->capacity / self->count >= 2)) LsgArrayList_shrink(self);
}

void LsgArrayList_set(LsgArrayList* self, int index, void* data) {
    if (index >= self->count) return;

    self->elements[index] = data;    
}

void* LsgArrayList_get(LsgArrayList* self, int index) {
    if (index >= self->count) return NULL;

    return self->elements[index];
}

void LsgArrayList_clear(LsgArrayList* self) {
    self->elements = realloc(self->elements, sizeof(void*) * LSG_ARRAYLIST_CAPACITY);
    
    self->count = 0;
}

LsgIterator* LsgArrayList_iterator(LsgArrayList* self) {
    LsgArrayListIterator* it = (LsgArrayListIterator*)malloc(sizeof(LsgArrayListIterator));

    LsgArrayListIterator_init(it, self);

    return (LsgIterator*)it;
}

void LsgArrayList_destroy(LsgArrayList* self) {
    free(self->elements);
    
    LsgList_destroy(&self->super);
}

/* LsgArrayListIterator ***********************************************************/

void LsgArrayListIterator_init(LsgArrayListIterator* self, LsgArrayList* list) {
    LsgIterator_init(&self->super);

    ((LsgIterator*)self)->hasNext = (int (*)(LsgIterator*))LsgArrayListIterator_hasNext;    
    ((LsgIterator*)self)->next    = (void* (*)(LsgIterator*))LsgArrayListIterator_next;    
    ((LsgIterator*)self)->index   = (int (*)(LsgIterator*))LsgArrayListIterator_index;    
    
    self->count    = list->count;
    self->elements = list->elements;
    self->index    = -1;
}

int LsgArrayListIterator_hasNext(LsgArrayListIterator* self) {
    return self->index < (self->count - 1);
}

void* LsgArrayListIterator_next(LsgArrayListIterator* self) {
    return self->elements[++self->index];
}

int LsgArrayListIterator_index(LsgArrayListIterator* self) {
    return self->index;
}
