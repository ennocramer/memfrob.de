#include <lescegra/sg/interpolator.h>

#include <stdlib.h>

struct control {
    Vertex v;
    float t;
};

Interpolator* interpolator_create(Vertex target, InterpolatorMode mode) {
    Interpolator* self = (Interpolator*)malloc(sizeof(Interpolator));
    
    interpolator_init(self, target, mode);
    
    return self;
}

void interpolator_init(Interpolator* self, Vertex target, InterpolatorMode mode) {
    node_init(&self->super);
    ((Node*)self)->update  = (void (*)(Node*, float))interpolator_update;
    ((Object*)self)->destroy = (void (*)(Object*))interpolator_destroy;
    
    self->target = target;
    self->mode = mode;
    self->control = list_create();
}

void interpolator_update_step(Interpolator* self, float now);
void interpolator_update_linear(Interpolator* self, float now);
void interpolator_update_bezier(Interpolator* self, float now);
void interpolator_update_catmull(Interpolator* self, float now);

void interpolator_update(Interpolator* self, float now) {
    if (list_count(self->control) == 0) return;
    
    switch (self->mode) {
        case STEP:
            interpolator_update_step(self, now);
            break;
        case LINEAR:
            interpolator_update_linear(self, now);
            break;
        case BEZIER:
            interpolator_update_bezier(self, now);
            break;
        case CATMULL_ROM:
            interpolator_update_catmull(self, now);
            break;
    }
}

void interpolator_update_step(Interpolator* self, float now) {    
    Iterator* it;
    struct control* v1 = NULL;
    struct control* v2 = NULL;

    it = iterator_create(self->control);
    do {
        v1 = v2;
        v2 = (struct control*)iterator_next(it);
    } while (iterator_has_next(it) && (v2->t < now)); /* v2 cannot be NULL */
    object_free((Object*)it);

    if (!v1 || (v2->t < now)) {
        vertex_copy(self->target, v2->v);
    } else {
        vertex_copy(self->target, v1->v);
    }
}

void interpolator_update_linear(Interpolator* self, float now) {    
    Iterator* it;
    struct control* v1 = NULL;
    struct control* v2 = NULL;

    it = iterator_create(self->control);
    do {
        v1 = v2;
        v2 = (struct control*)iterator_next(it);
    } while (iterator_has_next(it) && (v2->t < now)); /* v2 cannot be NULL */
    object_free((Object*)it);

    if (!v1 || (v2->t < now)) {
        vertex_copy(self->target, v2->v);
    } else {
        float t = (now - v1->t) / (v2->t - v1->t);
        
        vertex_copy(self->target, v2->v);
        vertex_sub(self->target, v1->v);
        vertex_scale(self->target, t);
        vertex_add(self->target, v1->v);
    }
}

#define LINEAR_INTERPOLATE(dst, v1, v2, t) \
    vertex_copy(dst, v2); \
    vertex_sub(dst, v1); \
    vertex_scale(dst, t); \
    vertex_add(dst, v1)

void interpolator_update_bezier(Interpolator* self, float now) {
    Iterator* it;
    struct control* v1 = NULL;
    struct control* v2 = NULL;
    struct control* v3 = NULL;
    int p = 0;
    
    it = iterator_create(self->control);
    do {
        v1 = v2;
        v2 = v3;
        v3 = (struct control*)iterator_next(it);
        ++p;
    } while (iterator_has_next(it) && (!v3 || (v3->t < now)));
    object_free((Object*)it);

    if (!v1 && !v2) {
        vertex_copy(self->target, v3->v);
    } else if (!v1 || (now > v3->t)) {
        LINEAR_INTERPOLATE(self->target, v2->v, v3->v, 0.5);
    } else {
        Vertex p1, p2, s1, s2;
        float t;

        LINEAR_INTERPOLATE(p1, v1->v, v2->v, 0.5);
        LINEAR_INTERPOLATE(p2, v2->v, v3->v, 0.5);
        
        t = (now - v2->t) / (v3->t - v2->t);
        
        LINEAR_INTERPOLATE(s1, p1, v2->v, t);
        LINEAR_INTERPOLATE(s2, v2->v, p2, t);
        
        LINEAR_INTERPOLATE(self->target, s1, s2, t);
    }
}

void interpolator_update_catmull(Interpolator* self, float now) {
    Iterator* it;
    struct control* v1 = NULL;
    struct control* v2 = NULL;
    struct control* v3 = NULL;
    struct control* v4 = NULL;
    
    it = iterator_create(self->control);
    do {
        v1 = v2;
        v2 = v3;
        v3 = v4;
        v4 = (struct control*)iterator_next(it);
    } while (iterator_has_next(it) && (!v3 || (v3->t < now)));
    object_free((Object*)it);
    
    if (!v1 || (v3->t < now)) {
        vertex_copy(self->target, v3->v);
    } else {
        float t;
        float h1,h2,h3,h4;
        Vertex buffer;
        
        t = (now - v2->t) / (v3->t - v2->t);
        
        h1 = 2.0*t*t*t - 3.0*t*t + 1.0;
        h2 = -2.0*t*t*t + 3.0*t*t;
        h3 = t*t*t - 2.0*t*t + t;
        h4 = t*t*t - t*t;
        
        /* interpolate from v2 -> v3*/
        
        /* v2 */
        vertex_copy(self->target, v2->v);
        vertex_scale(self->target, h1);
        
        /* v3 */
        vertex_copy(buffer, v3->v);
        vertex_scale(buffer, h2);
        vertex_add(self->target, buffer);
        
        /* v'2 */
        vertex_copy(buffer, v3->v);
        vertex_sub(buffer, v1->v);
        vertex_scale(buffer, h3);
        vertex_add(self->target, buffer);

        /* v'3 */
        vertex_copy(buffer, v4->v);
        vertex_sub(buffer, v2->v);
        vertex_scale(buffer, h4);
        vertex_add(self->target, buffer);
    }
}

void interpolator_destroy(Interpolator* self) {
    object_free((Object*)self->control);
    
    object_destroy(&self->super.super);
}

void interpolator_add_control(Interpolator* self, Vertex v, float time) {
    struct control* ctrl;
    struct control* ci;
    int pos;
    Iterator* it;
    
    ctrl = (struct control*)malloc(sizeof(struct control));
    vertex_copy(ctrl->v, v);
    ctrl->t = time;
    
    pos = list_count(self->control);
    
    it = iterator_create(self->control);
    while (iterator_has_next(it)) {
        ci = (struct control*)iterator_next(it);
        if (ci->t > ctrl->t) {
            pos = iterator_index(it);
            break;
        }
    }
    object_free((Object*)it);
    
    list_insert(self->control, pos, ctrl);
}
