#include <lescegra/sg/camera.h>

#include <stdlib.h>

void LsgCamera_init(LsgCamera* self) {
    LsgObject_init(&self->super);
    
    /**
     * Force implementation of display in child classes
     */
    self->display = NULL;
}
