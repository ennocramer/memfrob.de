#include <lescegra/sg/name.h>

#include <GL/gl.h>
#include <stdlib.h>

LsgName* LsgName_create(int name) {
    LsgName* self = (LsgName*)malloc(sizeof(LsgName));
    
    LsgName_init(self, name);
    
    return self;
}

void LsgName_init(LsgName* self, int name) {
    LsgGroup_init(&self->super);
    
    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))LsgName_display;
    
    self->name = name;
}

void LsgName_display(LsgName* self, LsgFrustum* frust) {
    glPushName(self->name);
    
    LsgGroup_display(&self->super, frust);
    
    glPopName();
}
