#include <lescegra/sg/coords.h>

#include <lescegra/coll/bbox.h>

#include <GL/gl.h>

#include <stdlib.h>

LsgCoords* LsgCoords_create(float size){
    LsgCoords* self = (LsgCoords*)malloc(sizeof(LsgCoords));
    
    LsgCoords_init(self, size);
    
    return self;
}

void LsgCoords_init(LsgCoords* self, float size) {
    LsgBBox* bb;
    
    LsgNode_init(&self->super);
    
    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))LsgCoords_display;
    
    bb = LsgBBox_create();
    vertex_assign(bb->min, 0.0, 0.0, 0.0);
    vertex_assign(bb->max, size, size, size);
    bb->super.valid = 1;
    
    ((LsgNode*)self)->bvolume = (LsgBVolume*)bb;
    
    self->size = size;
}

void LsgCoords_display(LsgCoords* self, LsgFrustum* frust) {
    glPushAttrib(GL_ENABLE_BIT);
    glDisable(GL_LIGHTING);
    glDisable(GL_NORMALIZE);
    glDisable(GL_TEXTURE_2D);
    
    glBegin(GL_LINES);
        glColor3f(1.0, 0.0, 0.0);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(self->size, 0.0, 0.0);

        glColor3f(0.0, 1.0, 0.0);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(0.0, self->size, 0.0);

        glColor3f(0.0, 0.0, 1.0);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(0.0, 0.0, self->size);
    glEnd();

    glPopAttrib();    
}
