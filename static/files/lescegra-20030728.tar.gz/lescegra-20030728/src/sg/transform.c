#include <lescegra/sg/transform.h>

#include <GL/gl.h>

#include <stdlib.h>

LsgTransform* LsgTransform_create(void) {
    LsgTransform* self = (LsgTransform*)malloc(sizeof(LsgTransform));
    
    LsgTransform_init(self);
    
    return self;
}

void LsgTransform_init(LsgTransform* self) {
    LsgGroup_initWithBounds(&self->super, (LsgBVolume*)LsgTransformBBox_create(self));
    
    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))LsgTransform_display;
    
    matrix_load_identity(self->tm);
}

void LsgTransform_display(LsgTransform* self, LsgFrustum* frust) {
    LsgFrustum nfrust;
    Matrix m;
    
    /* transform frustum */
    matrix_copy(m, frust->modelview);
    matrix_mult(m, self->tm);
    LsgFrustum_init(&nfrust, frust->projection, m);
    
    /* transform opengl modelview matrix */
    glPushMatrix();
    glMultMatrixf(self->tm);
    
    /* display child nodes with transformed view frustum */
    LsgGroup_display(&self->super, &nfrust);
    
    /* restore opengl modelview matrix */
    glPopMatrix();
}

/******************************************************************************/

LsgTransformBBox* LsgTransformBBox_create(LsgTransform* tfm) {
    LsgTransformBBox* self = malloc(sizeof(LsgTransformBBox));
    
    LsgTransformBBox_init(self, tfm);
    
    return self;
}

void LsgTransformBBox_init(LsgTransformBBox* self, LsgTransform* tfm) {
    LsgGroupBBox_init(&self->super, (LsgGroup*)tfm);
    
    ((LsgBVolume*)self)->visible = (int (*)(LsgBVolume*, LsgFrustum*))LsgTransformBBox_visible;
    ((LsgBVolume*)self)->collideVertex = (void (*)(LsgBVolume*, Vertex, LsgList*))LsgTransformBBox_collideVertex;
    ((LsgBVolume*)self)->collideRay = (void (*)(LsgBVolume*, Vertex, Vertex, LsgList*))LsgTransformBBox_collideRay;
    ((LsgBVolume*)self)->collideSphere = (void (*)(LsgBVolume*, Vertex, float, LsgList*))LsgTransformBBox_collideSphere;
    ((LsgBVolume*)self)->merge = (void (*)(LsgBVolume*, LsgBVolume*))LsgTransfromBBox_merge;
}

int LsgTransformBBox_visible(LsgTransformBBox* self, LsgFrustum* vf) {
    LsgFrustum vf_t;
    Matrix m;
    
    matrix_copy(m, vf->modelview);
    matrix_mult(m, ((LsgTransform*)self->super.group)->tm);
    
    LsgFrustum_init(&vf_t, vf->projection, m);
    
    return LsgGroupBBox_visible(&self->super, &vf_t);
}

static void LsgTransformBBox_collideFixHits(LsgList* buffer, int from, Matrix tm, Matrix tm_invtrans) {
    LsgHit* hit;
    int i;
    
    for (i = from; i < buffer->count(buffer); ++i) {
        hit = (LsgHit*)buffer->get(buffer, i);
        
        matrix_apply(tm, hit->intersection);
        matrix_applyVector(tm_invtrans, hit->normal);
        vertex_normalize(hit->normal);
    }
}

void LsgTransformBBox_collideVertex(LsgTransformBBox* self, Vertex v, LsgList* buffer) {
    Matrix tm_inv;
    Vertex v_t;
    int from;
    
    matrix_copy(tm_inv, ((LsgTransform*)self->super.group)->tm);
    matrix_invert(tm_inv);
    
    vertex_copy(v_t, v);
    matrix_apply(tm_inv, v_t);
    
    from = buffer->count(buffer);
    
    LsgGroupBBox_collideVertex(&self->super, v_t, buffer);
    
    matrix_transpose(tm_inv);

    LsgTransformBBox_collideFixHits(buffer, from, ((LsgTransform*)self->super.group)->tm, tm_inv);
}

void LsgTransformBBox_collideRay(LsgTransformBBox* self, Vertex from, Vertex dir, LsgList* buffer) {
    Matrix tm_inv;
    Vertex from_t, dir_t;
    int from_idx;
    
    matrix_copy(tm_inv, ((LsgTransform*)self->super.group)->tm);
    matrix_invert(tm_inv);
    
    vertex_copy(from_t, from);
    matrix_apply(tm_inv, from_t);
    
    vertex_copy(dir_t, dir);
    matrix_applyVector(tm_inv, dir_t);
    
    from_idx = buffer->count(buffer);
    
    LsgGroupBBox_collideRay(&self->super, from_t, dir_t, buffer);
    
    matrix_transpose(tm_inv);

    LsgTransformBBox_collideFixHits(buffer, from_idx, ((LsgTransform*)self->super.group)->tm, tm_inv);
}

#define MAX(a, b) ((a) > (b) ? (a) : (b))

void LsgTransformBBox_collideSphere(LsgTransformBBox* self, Vertex center, float radius, LsgList* buffer) {
    Matrix tm_inv;
    Vertex ctr_t;
    float rad_t;
    int from;
    
    matrix_copy(tm_inv, ((LsgTransform*)self->super.group)->tm);
    matrix_invert(tm_inv);
    
    vertex_copy(ctr_t, center);
    matrix_apply(tm_inv, ctr_t);
    
    rad_t = radius * MAX(MAX(
            ((LsgTransform*)self->super.group)->tm[0],
            ((LsgTransform*)self->super.group)->tm[5]),
            ((LsgTransform*)self->super.group)->tm[10]);
    
    from = buffer->count(buffer);
    
    LsgGroupBBox_collideSphere(&self->super, ctr_t, rad_t, buffer);
    
    matrix_transpose(tm_inv);

    LsgTransformBBox_collideFixHits(buffer, from, ((LsgTransform*)self->super.group)->tm, tm_inv);
}

void LsgTransfromBBox_merge(LsgTransformBBox* self, LsgBVolume* target) {
    Vertex v;
    int i, d;
    
    for (i = 0; i < 8; ++i) {
        for (d = 0; d < 3; ++d) {
            v[d] = (i & (1 << d)) ? ((LsgBBox*)self)->min[d] : ((LsgBBox*)self)->max[d];
        }

        matrix_apply(((LsgTransform*)self->super.group)->tm, v);

        target->include(target, v);
    }
}
