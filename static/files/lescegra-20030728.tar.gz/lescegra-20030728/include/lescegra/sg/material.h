/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_MATERIAL_H
#define LSG_MATERIAL_H 1

/**
 * \file  material.h
 * \brief Material properties
 */

#include <lescegra/sg/group.h>

/**
 * \ingroup scene
 * \brief   Material properties
 *
 * Apply material properties to all children.
 */
typedef struct {
    LsgGroup super;
    float ambient[4];
    float diffuse[4];
    float specular[4];
    float shininess;
} LsgMaterial;

/**
 * \relates LsgMaterial
 * Allocate and initialize a material node.
 * @return A new material node
 */
LsgMaterial* LsgMaterial_create(void);

/**
 * \relates LsgMaterial
 * Constructor method for LsgMaterial. Create a new material node with default
 * color values.
 * @param self      The instance variable
 */
void LsgMaterial_init(LsgMaterial* self);

/**
 * \relates LsgMaterial
 * Set material properties and display all children.
 * @param self      The instance variable
 * @param frustum   The view frustum
 */
void LsgMaterial_display(LsgMaterial* self, LsgFrustum* frustum);

#define LsgMaterial_clean(self)         LsgGroup_clean(&(self)->super)
#define LsgMaterial_update(self, now)   LsgGroup_update(&(self)->super, now)
#define LsgMaterial_collide(self, v, n) LsgGroup_collide(&(self)->super, v, n)

#endif
