/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_MD2MODEL_H
#define LSG_MD2MODEL_H 1

/**
 * \file  md2model.h
 * \brief Quake II model container and loader
 */

#include <lescegra/sg/node.h>

#include <lescegra/util/vertex.h>

typedef float LsgTexCoord[2];

typedef struct {
    int vertices[3];
    int tex_coords[3];
} LsgMD2Triangle;

/**
 * \ingroup geometry
 * \brief   Quake II model container
 *
 * Container class for a Quake II model with animation frames and skin
 * textures.
 */
typedef struct {
    LsgNode super;
    int frame;
    int skin;
    int frame_count;
    int triangle_count;
    int vertex_count;
    int skin_count;
    LsgMD2Triangle* triangles;
    LsgTexCoord*    tex_coords;
    Vertex*         vertices;
    int*            normals;
    unsigned int*   skins;
} LsgMD2Model;

/**
 * Allocate and initialize a LsgMD2Model instance.
 * @param filename  The name of the file containing the Quake II model data
 * @return A new LsgMD2Model instance
 */
LsgMD2Model* LsgMD2Model_create(const char* filename);

/**
 * Constructor method for LsgMD2Model. Load a Quake II model from the given
 * file.
 * @param self      The instance variable
 * @param filename  The name of the Quake II model file
 */
void LsgMD2Model_init(LsgMD2Model* self, const char* filename);
void LsgMD2Model_display(LsgMD2Model* self, LsgFrustum* frust);
void LsgMD2Model_displayWireframe(LsgMD2Model* self, LsgFrustum* frust);
void LsgMD2Model_destroy(LsgMD2Model* self);

/**
 * Optimize the nodes bounding box to exactly fit the current frame.
 * @param self      The instance variable
 */
void LsgMD2Model_optimizeBBox(LsgMD2Model* self);

#define LsgMD2Model_clean(self)       LsgNode_clean(&(self)->super)
#define LsgMD2Model_update(self, now) LsgNode_update(&(self)->super, now)

#endif
