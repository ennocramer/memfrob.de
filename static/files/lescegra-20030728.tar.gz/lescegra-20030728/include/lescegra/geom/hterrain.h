/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_HTERRAIN_H
#define LSG_HTERRAIN_H 1

/**
 * \file  hterrain.h
 * \brief Hierarchical subdivided terrain
 */

#include <lescegra/sg/node.h>

#include <lescegra/util/vertex.h>
#include <lescegra/util/image.h>
#include <lescegra/coll/frustum.h>
#include <lescegra/coll/octree.h>

/* normal first to allow self->frame being used as vertex array */
typedef struct {
    Vertex normal;
    Vertex point;
} LsgHTerrainFrame;

/**
 * \ingroup geometry
 * \brief   Hierarchical subdivided terrain
 *
 * A hierarchical subdivided terrain node to allow swift rendering of
 * static terrain with up to several million vertices.
 */
typedef struct {
    LsgNode super;
    int resolution[2];
    LsgHTerrainFrame* frame;
    LsgOctree* octree;
    int chunk;
} LsgHTerrain;

LsgHTerrain* LsgHTerrain_create(LsgImage* img, int divisions, Vertex dimension, int chunk);
void LsgHTerrain_init(LsgHTerrain* self, LsgImage* img, int divisions, Vertex dimension, int chunk);
void LsgHTerrain_display(LsgHTerrain* self, LsgFrustum* frust);
void LsgHTerrain_destroy(LsgHTerrain* self);

#define LsgHTerrain_clean(self)       LsgNode_clean(&(self)->super)
#define LsgHTerrain_update(self, now) LsgNode_update(&(self)->super, now)

/******************************************************************************/

#include <lescegra/coll/bbox.h>

typedef struct {
    LsgBBox super;
    LsgHTerrain* terrain;
} LsgHTerrainBVolume;

LsgHTerrainBVolume* LsgHTerrainBVolume_create(LsgHTerrain* terrain);
void LsgHTerrainBVolume_init(LsgHTerrainBVolume* self, LsgHTerrain* terrain);
int LsgHTerrainBVolume_visible(LsgHTerrainBVolume* self, LsgFrustum* frustum);
void LsgHTerrainBVolume_collideVertex(LsgHTerrainBVolume* self, Vertex v, LsgList* buffer);
void LsgHTerrainBVolume_collideRay(LsgHTerrainBVolume* self, Vertex from, Vertex dir, LsgList* buffer);
void LsgHTerrainBVolume_collideSphere(LsgHTerrainBVolume* self, Vertex center, float radius, LsgList* buffer);

#endif
