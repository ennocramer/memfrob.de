/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_ERROR_H
#define LSH_ERROR_H 1

/**
 * \file  error.h
 * \brief Error handling
 */

#include <lescegra/util/object.h>

/**
 * \brief Error Message
 *
 * Encapsulate an error message and the location where it has been reported.
 */
typedef struct {
    LsgObject super;
    char* message;
    char* file;
    char* method;
    int line;
} LsgError;

/**
 * \relates LsgError
 * Allocate and initialize a new LsgError instance.
 * \note Use the macros \c __FILE__ and \c __LINE__ for \a file and \a line
 * respectively.
 * @param message   The error message
 * @param file      The source file from where the error is reported
 * @param method    The method reporting the error
 * @param line      The line of the source file where the error is reported
 */
LsgError* LsgError_create(const char* message, const char* file, const char* method, int line);

/**
 * \relates LsgError
 * Constructor for LsgError.
 * @param self      The instance variable
 * @param message   The error message
 * @param file      The source file from where the error is reported
 * @param method    The method reporting the error
 * @param line      The line of the source file where the error is reported
 */
void LsgError_init(LsgError* self, const char* message, const char* file, const char* method, int line);

/**
 * \relates LsgError
 * Convert the error message to a simple string.
 * \note The generated string has to be free'd by the caller.
 * @param self      The instance variable
 * @return a newly allocated string containing the complete error message and
 * the location of the error report
 */
char* LsgError_toString(LsgError* self);

/**
 * \relates LsgError
 * Destructor for LsgError.
 * @param self      The instance variable
 */
void LsgError_destroy(LsgError* self);

/**
 * \relates LsgError
 * Return the number of error currently stored in the global error list.
 * @return the number of errors currently stored
 */
int LsgError_count(void);

/**
 * \relates LsgError
 * Store an error in the global error list.
 * @param error     The error to store
 */
void LsgError_add(LsgError* error);

/**
 * \relates LsgError
 * Create and add an error to the global error list.
 * @param file      The source file from where the error is reported
 * @param method    The method reporting the error
 * @param line      The line of the source file where the error is reported
 * @param message   The error message
 */
void LsgError_addMessage(const char* file, const char* method, int line, const char* message);

/**
 * \relates LsgError
 * Format an error message and add an error to the global error list with.
 * @param file      The source file from where the error is reported
 * @param method    The method reporting the error
 * @param line      The line of the source file where the error is reported
 * @param format    The error message template
 */
void LsgError_addFormat(const char* file, const char* method, int line, const char* format, ...);

/**
 * \relates LsgError
 * Return an error from the global error list.
 * @param num       The index of the error in the global error list
 * @return the error stored at index \a num in the global error list
 * or \c NULL if num is greater than or equal to the value returned by
 * \c LsgError_count
 */
const LsgError* LsgError_get(int num);

/**
 * \relates LsgError
 * Empty the global error list.
 */
void LsgError_clear(void);

#endif
