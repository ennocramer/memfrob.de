/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_LINKEDLIST_H
#define LSG_LINKEDLIST_H 1

#include <lescegra/util/list.h>

/**
 * \file  linkedlist.h
 * \brief A single linked list
 */

typedef struct LsgLinkedListElement LsgLinkedListElement;
struct LsgLinkedListElement {
    void* value;
    LsgLinkedListElement* next;
};

/**
 * \ingroup util
 * \brief   Linked list
 *
 * A linked list
 */
typedef struct {
    LsgList super;
    LsgLinkedListElement* first;
} LsgLinkedList;

LsgLinkedList* LsgLinkedList_create(void);
void LsgLinkedList_init(LsgLinkedList* self);
int LsgLinkedList_count(LsgLinkedList* self);
int LsgLinkedList_index(LsgLinkedList* self, void* object);
void LsgLinkedList_append(LsgLinkedList* self, void* data);
void LsgLinkedList_insert(LsgLinkedList* self, int index, void* data);
void LsgLinkedList_remove(LsgLinkedList* self, void* data);
void LsgLinkedList_removeByIndex(LsgLinkedList* self, int index);
void LsgLinkedList_clear(LsgLinkedList* self);
void LsgLinkedList_set(LsgLinkedList* self, int index, void* data);
void* LsgLinkedList_get(LsgLinkedList* self, int index);
LsgIterator* LsgLinkedList_iterator(LsgLinkedList* self);
void LsgLinkedList_destroy(LsgLinkedList* self);

#define LsgLinkedList_contains(self, data)   LsgList_contains(&(self)->super, data)

/**
 * \brief Iterator for LsgLinkedList
 *
 * An terator for the LsgLinkedList
 */
typedef struct {
    LsgIterator super;
    LsgLinkedListElement* element;
    int index;
} LsgLinkedListIterator;

void LsgLinkedListIterator_init(LsgLinkedListIterator* self, LsgLinkedList* list);
int LsgLinkedListIterator_hasNext(LsgLinkedListIterator* self);
void* LsgLinkedListIterator_next(LsgLinkedListIterator* self);
int LsgLinkedListIterator_index(LsgLinkedListIterator* self);

#endif
