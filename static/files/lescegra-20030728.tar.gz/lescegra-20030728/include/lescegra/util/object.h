/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_OBJECT_H
#define LSG_OBJECT_H 1

/**
 * \file  object.h
 * \brief Object hierarchy base class
 */

typedef struct LsgObject LsgObject;

/**
 * \brief Object hierarchy base class
 *
 * Abstract base class for the object hierarchy.
 */
struct LsgObject {
    /**
     * Ye olde virtual destructor method
     */
    void (*destroy)(LsgObject*);
};

/**
 * \relates LsgObject
 * Constructor method for LsgObject.
 * @param self  The instace variable
 */
void LsgObject_init(LsgObject* self);

/**
 * \relates LsgObject
 * Destructor method for LsgObject.
 * @param self  The instance variable
 */
void LsgObject_destroy(LsgObject* self);

/**
 * \relates LsgObject
 * Non virtual destructor for LsgObject instances.
 * Calls the virtual destructor method and afterwards frees the allocated memory.
 * @param self  The instance variable
 */
void LsgObject_free(LsgObject* obj);

#endif
