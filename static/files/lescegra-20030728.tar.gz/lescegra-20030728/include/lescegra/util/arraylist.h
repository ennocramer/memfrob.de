/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_ARRAYLIST_H
#define LSG_ARRAYLIST_H 1

#include <lescegra/util/list.h>

typedef struct {
    LsgList super;
    int count;
    int capacity;
    void** elements;
} LsgArrayList;

LsgArrayList* LsgArrayList_create(void);
void LsgArrayList_init(LsgArrayList* self);
int LsgArrayList_count(LsgArrayList* self);
int LsgArrayList_index(LsgArrayList* self, void* object);
void LsgArrayList_insert(LsgArrayList* self, int index, void* data);
void LsgArrayList_removeByIndex(LsgArrayList* self, int index);
void LsgArrayList_clear(LsgArrayList* self);
void LsgArrayList_set(LsgArrayList* self, int index, void* data);
void* LsgArrayList_get(LsgArrayList* self, int index);
LsgIterator* LsgArrayList_iterator(LsgArrayList* self);
void LsgArrayList_destroy(LsgArrayList* self);

#define LsgArrayList_contains(self, data)   LsgList_contains(&(self)->super, data)
#define LsgArrayList_append(self, data)     LsgList_append(&(self)->super, data)
#define LsgArrayList_remove(self, data)     LsgList_remove(&(self)->super, data)

typedef struct {
    LsgIterator super;
    int count;
    void** elements;
    int index;
} LsgArrayListIterator;

void LsgArrayListIterator_init(LsgArrayListIterator* self, LsgArrayList* list);
int LsgArrayListIterator_hasNext(LsgArrayListIterator* self);
void* LsgArrayListIterator_next(LsgArrayListIterator* self);
int LsgArrayListIterator_index(LsgArrayListIterator* self);

#endif
