#include <lescegra.h>

#include <GL/glut.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#ifndef M_PI
# define M_PI		3.14159265358979323846	/* pi */
#endif

LsgGroup* scene;
LsgPerspectiveCam* camera;
LsgMD2Model* model;

static float cam_rot = 0.0;
static float cam_dist = 100.0;

static int mouse_x = 0;
static int mouse_y = 0;

static int animate_model = 0;

static float color_ambi[4] = {1.0, 1.0, 1.0, 1.0};
static float color_diff[4] = {1.0, 1.0, 1.0, 1.0};
static float color_spec[4] = {1.0, 1.0, 1.0, 1.0};
static float color_shine   = 50;

int tex = -1;

void display(void) {
    LsgFrustum viewfrustum;
    int error;

    LsgFrustum_init(&viewfrustum, matrix_identity, matrix_identity);
    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    /* reset viewing matrizes */
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    if ((tex != -1) && (model->skin == -1))
        glBindTexture(GL_TEXTURE_2D, tex);

    /* display the scene */
    camera->super.display((LsgCamera*)camera, &viewfrustum, (LsgNode*)scene);

    /* force rendering of cached geometry */
    glFlush();
    glutSwapBuffers();

    if ((error = glGetError()) != GL_NO_ERROR) {
        printf("%s\n", gluErrorString(error));
    }
}

void reshape(int w, int h) {
    float aspect = (float)w / (float)h;

    camera->aspect = aspect;
    glViewport(0, 0, w, h);
}

void animate(int time) {
    float now = (float)time / 1000.0;

    if (animate_model) {
        model->frame = (int)(15.0 / 1000.0 * time) % model->frame_count;
        LsgMD2Model_optimizeBBox(model);
    }

    scene->super.update((LsgNode*)scene, now);
    scene->super.clean((LsgNode*)scene);

    glutTimerFunc(1000 / 25, animate, time + 1000 / 25);
    glutPostRedisplay();
}

void mouse_drag(int x, int y) {
    int dx = x - mouse_x;
/*    int dy = y - mouse_y;*/

    cam_rot += dx * M_PI / 500.0;
    vertex_assign(camera->location, cam_dist * cos(cam_rot), 30.0, cam_dist * sin(cam_rot));

    mouse_x = x;
    mouse_y = y;
}

void mouse_down(int button, int state, int x, int y) {
    mouse_x = x;
    mouse_y = y;
}

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 'w':
        case 'W':
            if (model->super.display == (void (*)(LsgNode*, LsgFrustum*))LsgMD2Model_display) {
                model->super.display = (void (*)(LsgNode*, LsgFrustum*))LsgMD2Model_displayWireframe;
            } else {
                model->super.display = (void (*)(LsgNode*, LsgFrustum*))LsgMD2Model_display;
            }
            break;

        case 'n':
        case 'N':
            model->frame = (model->frame + 1) % model->frame_count;
            LsgMD2Model_optimizeBBox(model);
            break;

        case 'p':
        case 'P':
            model->frame = (model->frame - 1 + model->frame_count) % model->frame_count;
            LsgMD2Model_optimizeBBox(model);
            break;

        case 's':
        case 'S':
            if (model->skin_count > 0)
                model->skin = (model->skin + 1) % model->skin_count;
            break;

        case ' ':
            animate_model = !animate_model;
            break;

        case  27:
        case 'q':
        case 'Q':
            exit(0);
    }
}

void init_video(const char* texture) {
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutCreateWindow("lescegra example: md2 viewer");

    glClearColor(0.0, 0.0, 0.0, 0.0);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_TEXTURE_2D);

    glMaterialfv(GL_FRONT, GL_AMBIENT, color_ambi);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, color_diff);
    glMaterialfv(GL_FRONT, GL_SPECULAR, color_spec);
    glMaterialfv(GL_FRONT, GL_SHININESS, &color_shine);

    if (texture) {
        LsgImage* image = LsgImage_load(texture);

        glGenTextures(1, (unsigned int*)&tex);
        glBindTexture(GL_TEXTURE_2D, tex);

        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, image->width, image->height, 0, GL_RGB, GL_UNSIGNED_BYTE, image->data);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

        glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

        free(image);
    }

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMotionFunc(mouse_drag);
    glutMouseFunc(mouse_down);

    glutTimerFunc(0, animate, 0);

    glutKeyboardFunc(keyboard);
}

void init_scene(const char* modelfile) {
    LsgLight* light;

    /* create the camera */
    camera = LsgPerspectiveCam_create();
    vertex_assign(camera->location, cam_dist, 30.0, 0.0);
    vertex_assign(camera->lookat,   0.0, 0.0, 0.0);
    vertex_assign(camera->up,       0.0, 1.0, 0.0);
    camera->dmin   =  20.0;
    camera->dmax   = 180.0;
    camera->fovy   =  50.0;
    camera->aspect =   1.0;

    /* create the scene container */
    scene = LsgGroup_create();

    light = LsgLight_create(GL_LIGHT0);
    vertex_assign(light->color, 1.0, 1.0, 1.0);
    vertex_assign(light->location, 40.0, 60.0, 80.0);
    light->color[3] = 1.0;
    light->location[3] = 1.0;
    LsgLight_enable(light);
    LsgList_append(scene->children, light);

    model = LsgMD2Model_create(modelfile);
    LsgMD2Model_optimizeBBox(model);
    LsgList_append(scene->children, model);
    
    LsgList_append(scene->children, LsgCoords_create(50.0));
}

int main(int argc, char* argv[]) {
    if ((argc < 2) || (argc > 3) || !strcmp("--help", argv[1]) || !strcmp("-h", argv[1])) {
        fprintf(stderr, "usage: %s <model> [<texture>]\n\n", argv[0]);
        fprintf(stderr, "control:\n");
        fprintf(stderr, "  space - toggle model animation\n");
        fprintf(stderr, "  n/p   - next/previous model animation frame\n");
        fprintf(stderr, "  s     - change model skin\n");
        fprintf(stderr, "  w     - toggle wireframe mode\n");
        fprintf(stderr, "  q     - exit\n");
        return 1;
    }

    glutInit(&argc, argv);

    init_video(argc == 3 ? argv[2] : NULL);
    init_scene(argv[1]);

    /* disable skin from model if skin is supplied on command line */
    if (argc == 3) model->skin = -1;

    glutMainLoop();

    return 0;
}
