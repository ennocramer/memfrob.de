#include "io.h"

#include <SDL/SDL.h>

#include <GL/gl.h>
#include <GL/glu.h>

#include <lescegra.h>

#include "bitmap.h"
#include "scene.h"
#include "logic.h"
#include "settings.h"

#include <stdarg.h>
#include <math.h>

static SDL_Surface* screen = NULL;

static int flags      = 0;
static int quit       = 0;
static int wireframe  = 0;
static int culling    = 1;
static int flat       = 1;
static int fullscreen = 0;

static float io_fps(void) {
    static float delta = 0.0;
    static float alpha = 0.8;
    static unsigned long int last = 0;

    unsigned long int now = SDL_GetTicks();

    delta = alpha * delta + (1.0 - alpha) * (now - last);
    last = now;
     
    return 1000.0 / delta;
}

static void io_render(void) {
    static LsgFrustum* vf = NULL;
    int error;

    if (!vf)
        vf = LsgFrustum_create(matrix_identity, matrix_identity);

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glPushAttrib(GL_VIEWPORT_BIT | GL_COLOR_BUFFER_BIT);

    if (flags & IO_STEREO) {
        if (flags & IO_CAVE) {
            /* stereo cave */
            glDrawBuffer(GL_BACK_LEFT);

            glViewport(0, screen->h / 2, screen->w, screen->h / 2);
            vertex_copy(wcam[0]->location, head);
            vertex_sub(wcam[0]->location, eyes);
            LsgCamera_display(LSG_CAMERA(wcam[0]), vf, scene);

            glViewport(0, 0, screen->w, screen->h / 2);
            vertex_copy(wcam[1]->location, head);
            vertex_sub(wcam[1]->location, eyes);
            LsgCamera_display(LSG_CAMERA(wcam[1]), vf, scene);

            glClear(GL_DEPTH_BUFFER_BIT);

            glDrawBuffer(GL_BACK_RIGHT);

            glViewport(0, screen->h / 2, screen->w, screen->h / 2);
            vertex_copy(wcam[0]->location, head);
            vertex_add(wcam[0]->location, eyes);
            LsgCamera_display(LSG_CAMERA(wcam[0]), vf, scene);

            glViewport(0, 0, screen->w, screen->h / 2);
            vertex_copy(wcam[1]->location, head);
            vertex_add(wcam[1]->location, eyes);
            LsgCamera_display(LSG_CAMERA(wcam[1]), vf, scene);
            
        } else {
            /* stereo helper cam */
            glViewport(0, 0, screen->w, screen->h);

            glDrawBuffer(GL_BACK_LEFT);
            vertex_copy(pcam->location, head);
            vertex_sub(pcam->location, eyes);
            LsgCamera_display(LSG_CAMERA(pcam), vf, scene);

            glDrawBuffer(GL_BACK_RIGHT);
            glClear(GL_DEPTH_BUFFER_BIT);
            vertex_copy(pcam->location, head);
            vertex_add(pcam->location, eyes);
            LsgCamera_display(LSG_CAMERA(pcam), vf, scene);
        }

    } else {
        if (flags & IO_CAVE) {
            /* mono cave */
            glViewport(0, screen->h / 2, screen->w, screen->h / 2);
            vertex_copy(wcam[0]->location, head);
            LsgCamera_display(LSG_CAMERA(wcam[0]), vf, scene);

            glViewport(0, 0, screen->w, screen->h / 2);
            vertex_copy(wcam[1]->location, head);
            LsgCamera_display(LSG_CAMERA(wcam[1]), vf, scene);

        } else {
            /* mono helper cam */
            glViewport(0, 0, screen->w, screen->h);
            vertex_copy(pcam->location, head);
            LsgCamera_display(LSG_CAMERA(pcam), vf, scene);
        }
    }

    glPopAttrib();

    { /* display stats */
        float x, y;

        glPushAttrib(GL_ENABLE_BIT | GL_CURRENT_BIT);
        glDisable(GL_LIGHTING);
        glDisable(GL_FOG);
        glColor4f(0.0, 0.0, 0.0, 0.0);

        x = -1.0 + (float)10 / (float)screen->w;
        y = -1.0 + (float)10 / (float)screen->h;

        bitmap_print(x, y, "FPS:      %.2f", io_fps());

        if (IS_LSG_VLTME(terrain)) {
            y = -1.0 + (float)100 / (float)screen->h;

            bitmap_print(x, y, "VERTICES: %d", LSG_VLTME(terrain)->mesh->count);
        }

        glPopAttrib();
    }

    glFlush();

    SDL_GL_SwapBuffers();

    if ((error = glGetError()) != GL_NO_ERROR) {
        LsgError_reportFormat(
            __FILE__, "display", __LINE__,
            "OpenGL Error: %s", gluErrorString(error)
        );
    }
}

static void io_resize(int width, int height) {
    SDL_SetVideoMode(
        width, height,
        screen->format->BitsPerPixel,
        screen->flags
    );
}

static void io_toggle_fullscreen(void) {
    fullscreen = !fullscreen;

    SDL_WM_ToggleFullScreen(screen);
    SDL_WM_GrabInput(fullscreen ? SDL_GRAB_ON : SDL_GRAB_OFF);
    SDL_ShowCursor(!fullscreen);

    /* change surface size to match screen resolution */
    if (fullscreen) {
        SDL_Rect** modes = SDL_ListModes(screen->format, screen->flags);
        int idx = 0;
        
        while ((modes[idx]->w >= screen->w) && (modes[idx]->h >= screen->h))
            ++idx;

        io_resize(modes[idx-1]->w, modes[idx-1]->h);
    }
}

static void io_keydown(SDL_KeyboardEvent ev) {
    switch (ev.keysym.sym) {
        case SDLK_w:
            wireframe = !wireframe;
            glPolygonMode(GL_FRONT_AND_BACK, wireframe ? GL_LINE : GL_FILL);
            break;

        case SDLK_c:
            culling = !culling;
            if (culling)
                glEnable(GL_CULL_FACE);
            else
                glDisable(GL_CULL_FACE);
            break;

        case SDLK_s:
            flat = !flat;
            glShadeModel(flat ? GL_FLAT : GL_SMOOTH);
            break;

        case SDLK_f:
            io_toggle_fullscreen();
            break;

        case SDLK_ESCAPE:
        case SDLK_q:
            quit = 1;
            break;

        default:
            break;
    }
}

#define MOUSE_SENSITIVITY (0.005)

static void io_motion(SDL_MouseMotionEvent ev) {
    Vertex move;

    if (!ev.state || (!ev.xrel && !ev.yrel))
        return;

    vertex_assign(move, ev.xrel, 0, -ev.yrel);
    vertex_scale(move, MOUSE_SENSITIVITY);
   
    vertex_add(head, move);
}

static void io_init_gl(void) {
    glEnable(GL_DEPTH_TEST);
    
    glFrontFace(GL_CCW);
    glCullFace(GL_BACK);

    if (culling)
        glEnable(GL_CULL_FACE);
    else
        glDisable(GL_CULL_FACE);

    glShadeModel(GL_FLAT);

    glPolygonMode(GL_FRONT_AND_BACK, wireframe ? GL_LINE : GL_FILL);

    glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
    glHint(GL_FOG_HINT, GL_NICEST);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

    glClearColor(WATER_COLOR, 1.0);

    { /* TODO: fixme */
        static float map_s[4] = { 0.1, 0.0, 0.0, 1.0 };
        static float map_t[4] = { 0.0, 0.1, 0.0, 1.0 };

        glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
        glTexGenfv(GL_S, GL_OBJECT_PLANE, map_s);

        glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
        glTexGenfv(GL_T, GL_OBJECT_PLANE, map_t);
        
        glEnable(GL_TEXTURE_GEN_S);
        glEnable(GL_TEXTURE_GEN_T);
    }
}

int io_init(int opt_flags) {
    flags = opt_flags;

    SDL_Init(SDL_INIT_VIDEO);

    /* configure OpenGL display buffer */
    SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 5);
    SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 5);
    SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 5);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 16);
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

    if (flags & IO_STEREO)
        SDL_GL_SetAttribute(SDL_GL_STEREO, 1);

    screen = SDL_SetVideoMode(
        640, 480, 0,
        SDL_RESIZABLE | SDL_HWSURFACE | SDL_OPENGL
    );

    if (screen) {
        SDL_WM_SetCaption("aquapark", NULL);
        
        if (flags & IO_FULLSCREEN)
            io_toggle_fullscreen();

        io_init_gl();
    }

    return screen != NULL;
}

void io_run(void) {
    SDL_Event event;

    while (!quit) {
        if (SDL_PollEvent(&event)) {
            do {
                switch(event.type) {
                    case SDL_KEYDOWN:
                        io_keydown(event.key);
                        break;
                        
                    case SDL_MOUSEMOTION:
                        io_motion(event.motion);
                        break;
                        
                    case SDL_VIDEORESIZE:
                        io_resize(event.resize.w, event.resize.h);
                        break;
                        
                    case SDL_QUIT:
                        quit = 1;
                        break;
                        
                    default:
                        break;
                }
            } while (SDL_PollEvent(&event));
        }

        logic_update();
        io_render();
    }
}

void io_quit(void) {
    SDL_Quit();
}
