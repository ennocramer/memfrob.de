#ifndef SCENE_H
#define SCENE_H 1

#include <lescegra/sg/node.h>
#include <lescegra/sg/transform.h>
#include <lescegra/particle/source.h>
#include <lescegra/geom/vltme.h>
#include <lescegra/sg/windowcam.h>
#include <lescegra/sg/perspectivecam.h>

#include "caustics.h"

extern Vertex submarine;
extern Vertex submarine_lookat;
extern Vertex head;
extern Vertex eyes;

extern LsgNode* scene;

extern LsgTransform* inv_sub_pos;
extern LsgCaustics* caustics;
extern LsgParticleSource* psource[2];
extern LsgVLTME* terrain;

extern LsgWindowCam* wcam[2];
extern LsgPerspectiveCam* pcam;

int scene_init(void);
void scene_quit(void);

#endif

