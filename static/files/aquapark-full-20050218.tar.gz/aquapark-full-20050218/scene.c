#include "scene.h"

#include <lescegra.h>

#include "settings.h"

#include <GL/gl.h>

#include <stdlib.h>

Vertex submarine_lookat = { 0.0, 0.0, 0.0 };
Vertex submarine = { 0.0,  0.0, 0.0 };
Vertex head      = { 0.0,  0.0, 0.0 };
Vertex eyes      = { 0.03, 0.0, 0.0 };

LsgNode* scene = NULL;

LsgTransform* inv_sub_pos     = NULL;
LsgCaustics* caustics         = NULL;
LsgParticleSource* psource[2] = { NULL, NULL };
LsgVLTME* terrain             = NULL;

LsgWindowCam* wcam[2]   = { NULL, NULL };
LsgPerspectiveCam* pcam = NULL;

static Vertex s_world[2] = {
    { -500.0, -500.0,   0.0 },
    {  500.0,  500.0, 200.0 }
};


static Vertex s_windows[2][3] = {
    {
        { 0.0, 1.0, 0.0 },
        { 2.0, 0.0, 0.0 },
        { 0.0, 0.0, 2.0 }
    },
    {
        { 0.0, 0.0, -1.0 },
        { -2.0, 0.0, 0.0 },
        { 0.0, -2.0, 0.0 }
    }
};

static void scene_render_rays(LsgList* particles) {
    static Vertex direction = { 80.0, 80.0, 350.0 };
    LsgIterator* it;

    glPushAttrib(
        GL_ENABLE_BIT
        | GL_CURRENT_BIT
        | GL_DEPTH_BUFFER_BIT
    );

    glEnable(GL_BLEND);

    glDepthMask(GL_FALSE);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    it = LsgList_iterator(particles);
    while (LsgIterator_hasNext(it)) {
        LsgParticle* p = LsgIterator_next(it);

        Vertex v, dx;
        int s;

        float max_alpha = 1.0 - 2.0 * p->age / RAY_LIFETIME;
        max_alpha = (1.0 - max_alpha * max_alpha) * RAY_ALPHA;

        vertex_copy(v, p->location);
        vertex_sub(v, submarine);
        vertex_sub(v, head);

        vertex_copy(dx, direction);
        vertex_cross(dx, v);
        vertex_scale(dx, RAY_SIZE / vertex_length(dx) / (float)RAY_RESOLUTION);

        glBegin(GL_TRIANGLE_STRIP);

        for (s = 0; s <= RAY_RESOLUTION; ++s) {
            float alpha = 1.0 - 2.0 * (float)s / (float)RAY_RESOLUTION;
            alpha = (1.0 - alpha * alpha) * max_alpha;

            glColor4f(1.0, 1.0, 1.0, alpha);

            vertex_copy(v, dx);
            vertex_scale(v, s);
            vertex_add(v, p->location);

            glVertex3fv(v);
            vertex_add(v, direction);
            glVertex3fv(v);
        }

        glEnd();
    }

    glPopAttrib();
}

static void scene_render_particles(LsgList* particles) {
    LsgIterator* it;

    glPushAttrib(
        GL_ENABLE_BIT
        | GL_CURRENT_BIT
        | GL_DEPTH_BUFFER_BIT
    );

    glEnable(GL_BLEND);
    glEnable(GL_POINT_SMOOTH);

    glPointSize(PARTICLE_SIZE);
    glColor4f(1.0, 1.0, 1.0, PARTICLE_ALPHA);

    glDepthMask(GL_FALSE);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);

    glBegin(GL_POINTS);
    it = LsgList_iterator(particles);
    while (LsgIterator_hasNext(it)) {
        LsgParticle* p = LsgIterator_next(it);

        glVertex3fv(p->location);
    }
    LsgObject_free(LSG_OBJECT(it));
    glEnd();

    glPopAttrib();
}

int scene_init(void) {
    LsgGroup* root;
    LsgGroup* inside;
    LsgGroup* outside;
    LsgGroup* world;

    { /* inside submarine */
    }

    { /* outside submarine */
        inv_sub_pos = LsgTransform_create();

        outside = LSG_GROUP(inv_sub_pos);
        root = outside; /* just for now */

        { /* env: fog */
            LsgEnvironment* env = LsgEnvironment_create();
            LsgFog* fog;

            /* fog */
            fog = LsgFog_create(LSG_FOG_LINEAR);
            vertex_assign(fog->color, WATER_COLOR); fog->color[3] = 0.0;
            fog->start = 30.0;
            fog->end   = 100.0;

            /* append states */
            LsgList_append(env->states, fog);

            LsgList_append(outside->children, env);

            { /* env: light and caustics */
                LsgEnvironment* env2 = LsgEnvironment_create();
                LsgLight* light;

                /* light */
                light = LsgLight_create(0);
                vertex_assign(light->color, 1.0, 1.0, 1.0);
                vertex_assign(light->location, 1.0, 1.0, 1.0);
                light->location[3] = 0.0;

                /* append states */
                LsgList_append(env2->states, light);

#ifdef GL_ARB_multitexture
                { /* caustics */
                    caustics = LsgCaustics_create(
                        "data/textures/caust%02i.png", 32
                    );
                
                    vertex_assign(caustics->map_s, 0.02, 0.0, 0.0);
                    vertex_assign(caustics->map_t, 0.0, 0.02, 0.0);
                    
                    caustics->speed = 32.0 / 2.0;

                    LsgList_append(env2->states, caustics);
                }
#endif

                LsgList_append(LSG_GROUP(env)->children, env2);

                world = LSG_GROUP(env2);

                { /* terrain with texture */
                    LsgMaterial* mat = LsgMaterial_create();
                    LsgTexture* tex;
                    LsgImage* img;

                    vertex_assign(mat->ambient,  0.3, 0.3, 0.3);
                    vertex_assign(mat->diffuse,  0.8, 0.8, 0.8);
                    vertex_assign(mat->specular, 0.0, 0.0, 0.0);

                    img = LsgImage_load("data/textures/sand.png");

                    if (img) {
                        tex = LsgTexture_create(img, GL_RGB, GL_MODULATE);
                        LsgList_append(mat->textures, tex);
                    }

                    LsgObject_free(LSG_OBJECT(img));
                    
                    LsgList_append(world->children, mat);
                    
                    {
                        Matrix tm, m;
                        LsgImage* img;

                        matrix_load_translate(tm, -500.0, -500.0, 0.0);
                        matrix_load_scale(m, 1000.0, 1000.0, 200.0);
                        matrix_mult(tm, m);

                        img = LsgImage_load("data/terrain.png");
                        
                        if (!img) {
                            fprintf(
                                stderr,
                                "CRITICAL: missing terrain data, aborting\n"
                            );
                            exit(EXIT_FAILURE);
                        }

                        terrain = LsgVLTME_createFromImage(
                            img, tm
                        );

                        LsgList_append(LSG_GROUP(mat)->children, terrain);
                        
                        LsgObject_free(LSG_OBJECT(img));
                    }
                }
            }

            { /* rays */
                LsgParticleSystem* psys = LsgParticleSystem_create(
                    scene_render_rays,
                    s_world[0], s_world[1], 0
                );

                LsgParticleSource* source =
                    LsgParticleSource_create(RAY_COUNT);
                vertex_assign(source->location, 0.0, 0.0, -100.0);
                vertex_assign(source->location_error, 200.0, 200.0, 0.0);
                vertex_assign(source->velocity, 5.0, 5.0, 0.0);
                vertex_assign(source->velocity_error, 2.0, 2.0, 0.0);
                source->lifetime = RAY_LIFETIME;
                source->birth_rate = RAY_COUNT / RAY_LIFETIME;

                vertex_copy(psys->system->vmin, s_world[0]);
                vertex_copy(psys->system->vmin, s_world[1]);

                LsgList_append(psys->modifiers, source);
                LsgList_append(LSG_GROUP(env)->children, psys);

                psource[0] = source;
            }

            { /* particles */
                LsgParticleSystem* psys = LsgParticleSystem_create(
                    scene_render_particles,
                    s_world[0], s_world[1], 0
                );

                LsgParticleSource* source =
                    LsgParticleSource_create(PARTICLE_COUNT);
                vertex_assign(source->location, 0.0, 0.0, 0.0);
                vertex_assign(source->location_error, 150.0, 150.0, 150.0);
                vertex_assign(source->velocity, 0.0, 0.0, 0.0);
                vertex_assign(source->velocity_error, 1.0, 1.0, 1.0);
                source->lifetime = PARTICLE_LIFETIME;
                source->birth_rate = PARTICLE_COUNT / PARTICLE_LIFETIME;

                LsgList_append(psys->modifiers, source);
                LsgList_append(LSG_GROUP(env)->children, psys);

                psource[1] = source;
            }
        }
    }

    { /* cameras */
        wcam[0] = LsgWindowCam_create();
        LsgWindowCam_setWindow(
            wcam[0],
            s_windows[0][0], s_windows[0][1], s_windows[0][2],
            0.1,
            100.0
        );

        wcam[1] = LsgWindowCam_create();
        LsgWindowCam_setWindow(
            wcam[1],
            s_windows[1][0], s_windows[1][1], s_windows[1][2],
            0.1,
            100.0
        );

        pcam = LsgPerspectiveCam_create();
        vertex_assign(pcam->lookat, 0.0, 1.0, 0.0);
        vertex_assign(pcam->up,     0.0, 0.0, 1.0);
        pcam->fovy   = 90.0;
        pcam->aspect = 1.0;
        pcam->dmin   = 0.1;
        pcam->dmax   = 101.0;
    }

    scene = LSG_NODE(root);
    LsgObject_ref(LSG_OBJECT(scene));

    return 1;
}

void scene_quit(void) {
    LsgObject_free(LSG_OBJECT(pcam));
    LsgObject_free(LSG_OBJECT(wcam[0]));
    LsgObject_free(LSG_OBJECT(wcam[1]));

    if (terrain && IS_LSG_VLTME(terrain))
        free((void*)LSG_VLTME(terrain)->nodes);

    if (scene)
        LsgObject_unref(LSG_OBJECT(scene));
}
