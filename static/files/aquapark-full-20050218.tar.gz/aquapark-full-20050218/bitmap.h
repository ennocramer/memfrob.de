#ifndef BITMAP_H
#define BITMAP_H 1

void bitmap_print(float x, float y, const char* format, ...);

#endif
