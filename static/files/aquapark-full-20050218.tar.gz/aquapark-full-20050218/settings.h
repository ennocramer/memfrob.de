#ifndef SETTINGS_H
#define SETTINGS_H 1

/* half distance between eyes */
#define EYE_DIST 0.03

/* background / fog color */
#define WATER_COLOR 0.2, 0.3, 0.3

/* light ray parameter */
#define RAY_SIZE  8.0
#define RAY_ALPHA 0.3
#define RAY_COUNT 40
#define RAY_LIFETIME 2.0
#define RAY_RESOLUTION 10

/* particle parameter */
#define PARTICLE_SIZE  6.0
#define PARTICLE_ALPHA 0.4
#define PARTICLE_COUNT 500
#define PARTICLE_LIFETIME 10.0

/* approximate terrain mesh size  */
#define TERRAIN_VERTEX_COUNT 10000

#endif
