#ifndef SUBMARINE_H
#define SUBMARINE_H

void submarine_init(void);
void submarine_update(float now);
void submarine_quit(void);

#endif
