/**
 * \page pg_style Coding Style
 *
 * \section pg_style_indention Sourcecode Indention
 *
 * - Use space for indention (no tabs)
 * - Block indention is 4 spaces
 * - No space after opening / before closing parenthesis
 * - No space after function names
 * - No line break before braces
 *
 * \b Example:
 * \code
 * void foo(float x, float y) {
 *     if (x > y) {
 *         bar(x);
 *     } else {
 *         bar(y);
 *     }
 * }
 * \endcode
 *
 * \section pg_style_naming Naming Conventions
 *
 * All type names (\c struct, \c enum and \c typedef) start with
 * the prefix \b Lsg. Method names are prefixed with their
 * corresponding class/package name, seperated by an underscore.
 * Multiple words are joined directly with every, except for the
 * first, words first letter in uppercase.
 * 
 * Defines are all uppercase, beginning with the class/package
 * name. Multiple words are separated by underscores.
 *
 * \b Examples:
 * - Classes
 *   - LsgObject
 *   - LsgNode
 *   - LsgArraylistIterator
 * - Methods
 *   - LsgObject_free
 *   - LsgNode_display
 *   - LsgList_hasNext
 * - Defines and enum values
 *   - LSG_CLASS_ID_NONE
 *   - LSG_ERROR_CURRENT_FUNCTION
 */
