/**
 * \mainpage lescegra - a 3D graphics engine
 * \version 1.0 (beta)
 * \author  Enno Cramer <uebergeek@web.de>
 * \date    2003
 *
 * \section main_about About
 * Lescegra is an object oriented 3D graphics engine based on the OpenGL API.
 * It is written in strict ANSI C and depends only on an OpenGL implementation
 * and libz.
 * If you wish to build the tutorial, you will also need SDL.
 *
 * \section main_docs Documentation
 * - \ref pg_usage
 * - \ref pg_coll
 * - \ref pg_class
 * - \ref pg_style
 *
 * \section main_license License
 * Lescegra is liscensed under the GNU Library General Public License (LGPL);
 * either version 2, or (at your option) any later version.
 */
