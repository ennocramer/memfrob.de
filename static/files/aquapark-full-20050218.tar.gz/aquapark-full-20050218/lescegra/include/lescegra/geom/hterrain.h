/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_HTERRAIN_H
#define LSG_HTERRAIN_H 1

/**
 * \file  hterrain.h
 * \brief Hierarchical subdivided terrain
 */

#include <lescegra/sg/node.h>

#include <lescegra/base/vertex.h>
#include <lescegra/util/image.h>
#include <lescegra/coll/frustum.h>
#include <lescegra/coll/octree.h>

/* normal first to allow self->frame being used as vertex array */
typedef struct {
    Vertex normal;
    Vertex point;
} LsgHTerrainFrame;

typedef struct LsgHTerrain LsgHTerrain;
typedef struct LsgHTerrainClass LsgHTerrainClass;

/**
 * \ingroup geometry
 * \brief   Hierarchical subdivided terrain
 *
 * A hierarchical subdivided terrain node to allow swift rendering of
 * static terrain with up to several million vertices.
 */
struct LsgHTerrain {
    LsgNode parent;

    LsgHTerrainFrame* frame;
    LsgOctree* octree;
    int resolution[2];
    int chunk;
};

struct LsgHTerrainClass {
    LsgNodeClass parent;
};

LsgClassID LsgHTerrain_classID(void);

#define IS_LSG_HTERRAIN(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgHTerrain_classID())

#define LSG_HTERRAIN(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgHTerrain*, LsgHTerrain_classID(), (instance))

#define LSG_HTERRAIN_CLASS(class) \
    LSG_CLASS_CAST(LsgHTerrainClass*, LsgHTerrain_classID(), (class))

LsgHTerrain* LsgHTerrain_create(
    const LsgImage* img,
    const Matrix transform,
    int divisions,
    int chunk
);

void LsgHTerrain_init(
    LsgHTerrain* self,
    const LsgImage* img,
    const Matrix transform,
    int divisions,
    int chunk
);

#endif
