/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_FOG_H
#define LSG_FOG_H 1

/**
 * \file  fog.h
 * \brief Fog effect
 */

#include <lescegra/sg/state.h>

enum LsgFogType {
    LSG_FOG_LINEAR,
    LSG_FOG_EXP,
    LSG_FOG_EXP2
};

typedef struct LsgFog LsgFog;
typedef struct LsgFogClass LsgFogClass;

/**
 * \ingroup scene
 * \brief   Fog effect
 *
 * Node defining a fogging effect with color and fog function.
 */
struct LsgFog {
    LsgState parent;

    int type;
    float color[4];
    float start;
    float end;
    float density;
};

struct LsgFogClass {
    LsgStateClass parent;
};

#define IS_LSG_FOG(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgFog_classID())

#define LSG_FOG(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgFog*, LsgFog_classID(), (instance))

#define LSG_FOG_CLASS(class) \
    LSG_CLASS_CAST(LsgFogClass*, LsgFog_classID(), (class))

LsgClassID LsgFog_classID(void);

LsgFog* LsgFog_create(enum LsgFogType type);
void LsgFog_init(LsgFog* self, enum LsgFogType type);

#endif
