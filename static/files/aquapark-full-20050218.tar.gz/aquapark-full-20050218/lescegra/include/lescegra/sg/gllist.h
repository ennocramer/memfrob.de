/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_GLLIST_H
#define LSG_GLLIST_H

/**
 * \file  gllist.h
 * \brief OpenGL list node
 */

#include <lescegra/sg/node.h>

typedef struct LsgGLList LsgGLList;
typedef struct LsgGLListClass LsgGLListClass;

/**
 * \brief OpenGL list node
 *
 * Encapsulate an OpenGL list in a scene graph node.
 */
struct LsgGLList {
    LsgNode parent;

    int list;
};

struct LsgGLListClass {
    LsgNodeClass parent;
};

LsgClassID LsgGLList_classID(void);

#define IS_LSG_GLLIST(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgGLList_classID())

#define LSG_GLLIST(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgGLList*, LsgGLList_classID(), (instance))

#define LSG_GLLIST_CLASS(class) \
    LSG_CLASS_CAST(LsgGLListClass*, LsgGLList_classID(), (class))

/**
 * \relates LsgGLList
 * Allocate and initialize a LsgGLList.
 * @return A new LsgGLList instance
 */
LsgGLList* LsgGLList_create(void);

/**
 * \relates LsgGLList
 * Constructor method for LsgGLList. Create a new and initially empty OpenGL list.
 * @param self      The instance variable
 */
void LsgGLList_init(LsgGLList* self);

#endif
