/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_ORTHOCAM_H
#define LSG_ORTHOCAM_H 1

/**
 * \file  orthocam.h
 * \brief Orthogonal projection camera
 */

#include <lescegra/sg/camera.h>

#include <lescegra/base/vertex.h>

typedef struct LsgOrthoCam LsgOrthoCam;
typedef struct LsgOrthoCamClass LsgOrthoCamClass;

/**
 * \brief Orthogonal projection
 *
 * A camera with an axes parallel view cube defind by minimal and maximal value
 * for each axis.
 */
struct LsgOrthoCam {
    LsgCamera parent;

    Vertex min;
    Vertex max;
};

struct LsgOrthoCamClass {
    LsgCameraClass parent;
};

#define IS_LSG_ORTHO_CAM(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgOrthoCam_classID())

#define LSG_ORTHO_CAM(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgOrthoCam*, LsgOrthoCam_classID(), (instance))

#define LSG_ORTHO_CAM_CLASS(class) \
    LSG_CLASS_CAST(LsgOrthoCamClass*, LsgOrthoCam_classID(), (class))

LsgClassID LsgOrthoCam_classID(void);

/**
 * \relates LsgOrthoCam
 * Allocate and initialize a new LsgOrthoCam.
 * @return A new LsgOrthoCam instance
 */
LsgOrthoCam* LsgOrthoCam_create(void);

/**
 * \relates LsgOrthoCam
 * Constructor method for LsgOrthoCam. Initialize view cube to [-1, +1] in all
 * dimensions.
 * @param self      The instance variable
 */
void LsgOrthoCam_init(LsgOrthoCam* self);

#endif
