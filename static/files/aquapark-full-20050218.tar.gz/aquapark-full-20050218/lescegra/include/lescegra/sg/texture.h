/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_TEXTURE_H
#define LSG_TEXTURE_H 1

/**
 * \file  texture.h
 * \brief Texture properties
 */

#include <lescegra/base/object.h>

#include <lescegra/util/image.h>

typedef struct LsgTexture LsgTexture;
typedef struct LsgTextureClass LsgTextureClass;

/**
 * \ingroup scene
 * \brief   Texture properties
 *
 * Apply a texture properties to all children.
 */
struct LsgTexture {
    LsgObject parent;

    unsigned int id;
    unsigned int mode;
};

struct LsgTextureClass {
    LsgObjectClass parent;
};

LsgClassID LsgTexture_classID(void);

#define IS_LSG_TEXTURE(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgTexture_classID())

#define LSG_TEXTURE(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgTexture*, LsgTexture_classID(), (instance))

#define LSG_TEXTURE_CLASS(class) \
    LSG_CLASS_CAST(LsgTextureClass*, LsgTexture_classID(), (class))

/**
 * \relates LsgTexture
 * Allocate and initialize a texture node.
 * @param data      The texture color data
 * @param type      The texture type
 * @param mode      The texture environment mode
 * @return A new texture node
 */
LsgTexture* LsgTexture_create(LsgImage* data, int type, unsigned int mode);

/**
 * \relates LsgTexture Constructor method for LsgTexture. Create a new
 * texture object of a given type with the provided pixel data.
 * @param self      The instance variable
 * @param data      The texture color data
 * @param type      The texture type
 * @param mode      The texture environment mode
 */
void LsgTexture_init(LsgTexture* self, LsgImage* data, int type, unsigned int mode);

#endif
