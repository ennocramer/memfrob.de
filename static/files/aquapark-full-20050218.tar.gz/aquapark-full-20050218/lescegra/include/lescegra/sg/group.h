/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_GROUP_H
#define LSG_GROUP_H 1

/**
 * \file  group.h
 * \brief Basic grouping node
 */

#include <lescegra/sg/node.h>

#include <lescegra/util/list.h>
#include <lescegra/coll/frustum.h>

typedef struct LsgGroup LsgGroup;
typedef struct LsgGroupClass LsgGroupClass;

/**
 * \ingroup scene
 * \brief   Basic grouping node
 *
 * The junction base class for the scene graph. Allows grouping of nodes and
 * thereby hierarchical view frustum culling and collision detection.
 */
struct LsgGroup {
    LsgNode parent;

    LsgList* children;
};

struct LsgGroupClass {
    LsgNodeClass parent;
};

LsgClassID LsgGroup_classID(void);

#define IS_LSG_GROUP(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgGroup_classID())

#define LSG_GROUP(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgGroup*, LsgGroup_classID(), (instance))

#define LSG_GROUP_CLASS(class) \
    LSG_CLASS_CAST(LsgGroupClass*, LsgGroup_classID(), (class))

/**
 * \relates LsgGroup
 * Allocate and initialize a new LsgGroup.
 * @return A new LsgGroup instance
 */
LsgGroup* LsgGroup_create(void);

/**
 * \relates LsgGroup
 * Constructor method for LsgGroup.
 * @param self          The instance variable
 */
void LsgGroup_init(LsgGroup* self);

#endif
