/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_TRANSFORM_H
#define LSG_TRANSFORM_H 1

/**
 * \file  transform.h
 * \brief Geometry transformation node
 */

#include <lescegra/sg/group.h>

#include <lescegra/base/matrix.h>
#include <lescegra/coll/frustum.h>

typedef struct LsgTransform LsgTransform;
typedef struct LsgTransformClass LsgTransformClass;

/**
 * \ingroup scene
 * \brief   Geometry transformation node
 *
 * Apply a transformation matrix to all subnodes.
 */
struct LsgTransform {
    LsgGroup parent;

    Matrix tm;
};

struct LsgTransformClass {
    LsgGroupClass parent;
};

LsgClassID LsgTransform_classID(void);

#define IS_LSG_TRANSFORM(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgTransform_classID())

#define LSG_TRANSFORM(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgTransform*, LsgTransform_classID(), (instance))

#define LSG_TRANSFORM_CLASS(class) \
    LSG_CLASS_CAST(LsgTransformClass*, LsgTransform_classID(), (class))

/**
 * \relates LsgTransform
 * Allocate and initialize a transformation node.
 * @return a new LsgTransform instance
 */
LsgTransform* LsgTransform_create(void);

/**
 * \relates LsgTransform
 * Constructor method for LsgTransform. Initialize the transformation to identity.
 * @param self      The instance variable
 */
void LsgTransform_init(LsgTransform* self);

#endif
