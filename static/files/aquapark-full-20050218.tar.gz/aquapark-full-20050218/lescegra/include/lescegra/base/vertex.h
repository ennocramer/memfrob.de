/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_VERTEX_H
#define LSG_VERTEX_H 1

/**
 * \file  vertex.h
 * \brief Vertex (3 dimensional vector)
 */

/**
 * \brief 3 dimensional vector
 *
 * A three dimensional vector
 */
typedef float Vertex[3];

/**
 * Assign all three components of a vertex.
 * @param dst   The destination vertex
 * @param x     The value for the first component
 * @param y     The value for the second component
 * @param z     The value for the third component
 */
void vertex_assign(Vertex dst, float x, float y, float z);

/**
 * Copy a vertex into another.
 * @param dst   The destination vertex
 * @param src   The source vertex
 */
void vertex_copy(Vertex dst, const Vertex src);

/**
 * Add a vertex to another.
 * @param dst   The destination vertex
 * @param src   The vertex to add
 */
void vertex_add(Vertex dst, const Vertex src);

/**
 * Subtract a vertex from another.
 * @param dst   The destination vertex
 * @param src   The vertex to subtract
 */
void vertex_sub(Vertex dst, const Vertex src);

/**
 * Multiply two vertices component wise.
 * @param dst   The destination vertex
 * @param src   The vertex to multiply onto dst
 */
void vertex_mul(Vertex dst, const Vertex src);

/**
 * Divide two vertices component wise.
 * @param dst   The destination vertex
 * @param src   The vertex by which to divide dst
 */
void vertex_div(Vertex dst, const Vertex src);

/**
 * Compute the component wise minimum of two vertices.
 * @param dst   The destination vertex
 * @param src   The second vertex
 */
void vertex_min(Vertex dst, const Vertex src);

/**
 * Compute the component wise maximum of two vertices.
 * @param dst   The destination vertex
 * @param src   The second vertex
 */
void vertex_max(Vertex dst, const Vertex src);

/**
 * Scale a vertex by a scalar value.
 * @param dst   The vertex to scale
 * @param scale The scale factor
 */
void vertex_scale(Vertex dst, float scale);

/**
 * Compute the dot product of two vertices.
 * @param a     The first vertex
 * @param b     The second vertex
 * @return The dot product of a and b (a * b == |a| * |b| * cos(a, b))
 */
float vertex_dot(const Vertex a, const Vertex b);

/**
 * Compute the cross product of two vertices.
 * dst = dst x src
 * @param dst   The destination vertex and the first factor
 * @param src   The second factor
 */
void vertex_cross(Vertex dst, const Vertex src);

/**
 * Compute the euclidean length of a vertex.
 * @param src   The vertex
 * @return The euclidean length of vertex src (|src|)
 */
float vertex_length(const Vertex src);

/**
 * Normalize a vertex so that its length is 1.
 * @param dst   The vertex to normalize
 */
void vertex_normalize(Vertex dst);

#endif
