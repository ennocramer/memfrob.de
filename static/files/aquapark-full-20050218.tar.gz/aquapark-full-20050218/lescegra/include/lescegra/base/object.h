/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_OBJECT_H
#define LSG_OBJECT_H 1

#include <lescegra/base/class.h>

/**
 * \file  object.h
 * \brief Object hierarchy base class
 */

typedef struct LsgObject LsgObject;
typedef struct LsgObjectClass LsgObjectClass;

/**
 * \brief Object hierarchy base class
 *
 * Abstract base class for the object hierarchy.
 */
struct LsgObject {
    LsgClassInstance parent;

    unsigned int ref_count;
};

struct LsgObjectClass {
    LsgClass parent;

    /**
     * Ye olde virtual destructor method
     */
    void (*destroy)(LsgObject*);
};

LsgClassID LsgObject_classID(void);

#define IS_LSG_OBJECT(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgObject_classID())

#define LSG_OBJECT(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgObject*, LsgObject_classID(), (instance))

#define LSG_OBJECT_CLASS(class) \
    LSG_CLASS_CAST(LsgObjectClass*, LsgObject_classID(), (class))

/**
 * \relates LsgObject
 * Constructor method for LsgObject.
 * @param self  The instace variable
 */
void LsgObject_init(LsgObject* self);

/**
 * \relates LsgObject
 * Non virtual destructor for LsgObject instances.
 * Calls the virtual destructor method and afterwards frees the allocated memory.
 * @param self  The instance variable
 */
void LsgObject_free(LsgObject* self);

void LsgObject_ref(LsgObject* self);
void LsgObject_unref(LsgObject* self);

#endif
