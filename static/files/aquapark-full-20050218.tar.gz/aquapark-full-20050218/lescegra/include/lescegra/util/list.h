/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_LIST_H
#define LSG_LIST_H

/**
 * \file  list.h
 * \brief Interface for lists and list iterators
 */

#include <lescegra/base/object.h>

typedef struct LsgIterator LsgIterator;
typedef struct LsgIteratorClass LsgIteratorClass;

struct LsgIterator {
    LsgObject parent;
};

struct LsgIteratorClass {
    LsgObjectClass parent;
    
    int   (*hasNext)(LsgIterator* self);
    void* (*next)(LsgIterator* self);
};

#define IS_LSG_ITERATOR(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgIterator_classID())

#define LSG_ITERATOR(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgIterator*, LsgIterator_classID(), (instance))

#define LSG_ITERATOR_CLASS(class) \
    LSG_CLASS_CAST(LsgIteratorClass*, LsgIterator_classID(), (class))

LsgClassID LsgIterator_classID(void);

void LsgIterator_init(LsgIterator* self);

int   LsgIterator_hasNext(LsgIterator* self);
void* LsgIterator_next(LsgIterator* self);

/* LsgList */

typedef struct LsgList LsgList;
typedef struct LsgListClass LsgListClass;

struct LsgList {
    LsgObject parent;

    int ref_elements;
};

struct LsgListClass {
    LsgObjectClass parent;
    
    int   (*count)(LsgList* self);
    int   (*contains)(LsgList* self, void* object);
    int   (*index)(LsgList* self, void* object);
    void  (*append)(LsgList* self, void* object);
    void  (*insert)(LsgList* self, int index, void* object);
    int   (*remove)(LsgList* self, void* object);
    void* (*removeByIndex)(LsgList* self, int index);
    void* (*get)(LsgList* self, int index);
    void* (*set)(LsgList* self, int index, void* object);
    void  (*clear)(LsgList* self);
    LsgIterator* (*iterator)(LsgList* self);
};

LsgClassID LsgList_classID(void);

#define IS_LSG_LIST(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgList_classID())

#define LSG_LIST(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgList*, LsgList_classID(), (instance))

#define LSG_LIST_CLASS(class) \
    LSG_CLASS_CAST(LsgListClass*, LsgList_classID(), (class))

void  LsgList_init(LsgList* self);

void  LsgList_refElements(LsgList* self, int ref);

int   LsgList_count(LsgList* self);
int   LsgList_contains(LsgList* self, void* object);
int   LsgList_index(LsgList* self, void* object);
void  LsgList_append(LsgList* self, void* object);
void  LsgList_insert(LsgList* self, int index, void* object);
int   LsgList_remove(LsgList* self, void* object);
void* LsgList_removeByIndex(LsgList* self, int index);
void* LsgList_get(LsgList* self, int index);
void* LsgList_set(LsgList* self, int index, void* object);
void  LsgList_clear(LsgList* self);
LsgIterator* LsgList_iterator(LsgList* self);

#endif
