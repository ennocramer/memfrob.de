/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_RANDOM_H
#define LSG_RANDOM_H 1

/**
 * \file  random.h
 * \brief Pseudo random number generator
 */

#include <lescegra/base/object.h>

#define LSG_RANDOM_STATE_SIZE 624

typedef struct LsgRandom LsgRandom;
typedef struct LsgRandomClass LsgRandomClass;

/**
 * \ingroup util
 * \brief   Pseudo random number generator
 *
 * A pseudo random number generator utilizing the Mersenne Twister algorithm.
 * \see http://www.math.keio.ac.jp/~matumoto/emt.html
 */
struct LsgRandom {
    LsgObject parent;
    unsigned long int state[LSG_RANDOM_STATE_SIZE];
    int index;
};

struct LsgRandomClass {
    LsgObjectClass parent;
};

LsgClassID LsgRandom_classID(void);

#define IS_LSG_RANDOM(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgRandom_classID())

#define LSG_RANDOM(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgRandom*, LsgRandom_classID(), (instance))

#define LSG_RANDOM_CLASS(class) \
    LSG_CLASS_CAST(LsgRandomClass*, LsgRandom_classID(), (class))

/**
 * \relates LsgRandom
 * Allocate and initialize a new LsgRandom instance with the given seed value.
 * @param seed      The seed value
 * @return a new LsgRandom instance
 */
LsgRandom* LsgRandom_create(unsigned long int seed);

/**
 * \relates LsgRandom
 * Initialize the instance with a given seed.
 * @param self      The instance variable
 * @param seed      The seed value
 */
void LsgRandom_init(LsgRandom* self, unsigned long int seed);


/**
 * \relates LsgRandom
 * Reseed the random number generator.
 * @param self      The instance variable
 * @param seed      The seed value
 */
void LsgRandom_seed(LsgRandom* self, unsigned long int seed);

/**
 * \relates LsgRandom
 * Return a random \c unsigned \c long \c int between \c 0 and \c MAX_ULONG
 * inclusive.
 * @param self      The instance variable
 * @return a random value between \c 0 and \c MAX_ULONG
 */
unsigned long int LsgRandom_generate(LsgRandom* self);

/**
 * \relates LsgRandom
 * Return a random \c float between \c 0.0 and \c 1.0 inclusive.
 * @param self      The instance variable
 * @return a random value between \c 0.0 and \c 1.0
 */
float LsgRandom_random(LsgRandom* self);

/**
 * \relates LsgRandom
 * Return a random \c float between \c 0.0 and a given maximal value (inclusive).
 * @param self      The instance variable
 * @param limit     The highest allowed return value
 * @return a random value between \c 0.0 and \a limit
 */
float LsgRandom_randomMax(LsgRandom* self, float limit);

/**
 * \relates LsgRandom
 * Return a random \c float between \c -1.0 and \c +1.0 inclusive.
 * @param self      The instance variable
 * @return a random value between \c -1.0 and \c +1.0
 */
float LsgRandom_randomError(LsgRandom* self);

/**
 * \relates LsgRandom
 * Return a random \c float from a given interval.
 * @param self      The instance variable
 * @param base      The center of the interval
 * @param error     The maximum distance between the return value and \a base
 * @return a random value from the interval [ \a base - \a error, \a base + \a error ]
 */
float LsgRandom_randomRange(LsgRandom* self, float base, float error);

#endif
