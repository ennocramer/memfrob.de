/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_BVOLUME_H
#define LSG_BVOLUME_H 1

#include <lescegra/base/object.h>

#include <lescegra/coll/frustum.h>

#include <lescegra/coll/hit.h>

#include <lescegra/base/vertex.h>
#include <lescegra/util/list.h>

typedef struct LsgBVolume LsgBVolume;
typedef struct LsgBVolumeClass LsgBVolumeClass;

typedef struct LsgGenericBVolume LsgGenericBVolume;
typedef struct LsgGenericBVolumeClass LsgGenericBVolumeClass;

struct LsgBVolume {
    LsgObject parent;

    int valid;
};

struct LsgBVolumeClass {
    LsgObjectClass parent;

    int  (*visible)(const LsgBVolume* self, const LsgFrustum* vf);
    void (*collideVertex)(const LsgBVolume* self, const Vertex v, LsgList* buffer);
    void (*collideRay)(const LsgBVolume* self, const Vertex from, const Vertex dir, LsgList* buffer);
    void (*collideSphere)(const LsgBVolume* self, const Vertex center, float radius, LsgList* buffer);
    void (*merge)(const LsgBVolume* self, LsgGenericBVolume* target);
};

LsgClassID LsgBVolume_classID(void);

#define IS_LSG_BVOLUME(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgBVolume_classID())

#define LSG_BVOLUME(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgBVolume*, LsgBVolume_classID(), (instance))

#define LSG_BVOLUME_CLASS(class) \
    LSG_CLASS_CAST(LsgBVolumeClass*, LsgBVolume_classID(), (class))


void LsgBVolume_init(LsgBVolume* self);

int  LsgBVolume_visible(const LsgBVolume* self, const LsgFrustum* vf);
void LsgBVolume_collideVertex(const LsgBVolume* self, const Vertex v, LsgList* buffer);
void LsgBVolume_collideRay(const LsgBVolume* self, const Vertex from, const Vertex dir, LsgList* buffer);
void LsgBVolume_collideSphere(const LsgBVolume* self, const Vertex center, float radius, LsgList* buffer);
void LsgBVolume_merge(const LsgBVolume* self, LsgGenericBVolume* target);

struct LsgGenericBVolume {
    LsgBVolume parent;
};

struct LsgGenericBVolumeClass {
    LsgBVolumeClass parent;
    void (*include)(LsgGenericBVolume* self, const Vertex v);
    void (*reset)(LsgGenericBVolume* self);
};

LsgClassID LsgGenericBVolume_classID(void);

#define LSG_GENERIC_BVOLUME(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgGenericBVolume*, LsgGenericBVolume_classID(), (instance))

#define LSG_GENERIC_BVOLUME_CLASS(class) \
    LSG_CLASS_CAST(LsgGenericBVolumeClass*, LsgGenericBVolume_classID(), (class))

void LsgGenericBVolume_init(LsgGenericBVolume* self);
void LsgGenericBVolume_include(LsgGenericBVolume* self, const Vertex v);
void LsgGenericBVolume_reset(LsgGenericBVolume* self);

#endif
