/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_PARTICLE_GRAVITY_H
#define LSG_PARTICLE_GRAVITY_H 1

/**
 * \file  gravity.h
 * \brief Gravitational force attracting particles
 */

#include <lescegra/particle/system.h>

typedef struct LsgParticleGravity LsgParticleGravity;
typedef struct LsgParticleGravityClass LsgParticleGravityClass;

/**
 * \ingroup particle
 * \brief   Gravitational force attracting particles
 *
 * Attract particles with gravitational force (a = mass * 1 / dist ^ 2)
 */
struct LsgParticleGravity {
    LsgParticleModifier parent;

    float mass;
};

struct LsgParticleGravityClass {
    LsgParticleModifierClass parent;
};

LsgClassID LsgParticleGravity_classID(void);

#define IS_LSG_PARTICLE_GRAVITY(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgParticleGravity_classID())

#define LSG_PARTICLE_GRAVITY(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgParticleGravity*, LsgParticleGravity_classID(), (instance))

#define LSG_PARTICLE_GRAVITY_CLASS(class) \
    LSG_CLASS_CAST(LsgParticleGravityClass*, LsgParticleGravity_classID(), (class))

LsgParticleGravity* LsgParticleGravity_create(void);
void LsgParticleGravity_init(LsgParticleGravity* self);

#endif
