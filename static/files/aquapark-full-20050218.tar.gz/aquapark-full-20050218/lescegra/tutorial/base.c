#include "base.h"

#include <GL/glu.h>
#include <GL/gl.h>
#include <SDL/SDL.h>

#include <stdlib.h>
#include <stdio.h>

LsgCamera* g_camera = NULL;
LsgNode*   g_scene  = NULL;

static SDL_Surface* screen = NULL;

static int quit      = 0;
static int wireframe = 0;
static int culling   = 1;

static void base_update(float now) {
    LsgNode_update(g_scene, now);
    LsgNode_clean(g_scene);
}

static void base_display(void) {
    static LsgFrustum* frustum = NULL;
    int error;

    if (!frustum)
        frustum = LsgFrustum_create(matrix_identity, matrix_identity);

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    /* reset viewing matrizes */
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    LsgCamera_display(g_camera, frustum, g_scene);

    /* force rendering of cached geometry */
    glFlush();

    if ((error = glGetError()) != GL_NO_ERROR) {
        LsgError_reportFormat(
            __FILE__, "base_display", __LINE__,
            "OpenGL Error: %s", gluErrorString(error)
        );
    }

    SDL_GL_SwapBuffers();
}

static void base_ev_keydown(SDL_KeyboardEvent event) {
    switch (event.keysym.sym) {
        case SDLK_w:
            wireframe ^= 1;
            glPolygonMode(GL_FRONT_AND_BACK, wireframe ? GL_LINE : GL_FILL);
            break;

        case SDLK_c:
            culling ^= 1;
            if (culling)
                glEnable(GL_CULL_FACE);
            else
                glDisable(GL_CULL_FACE);
            break;

        case SDLK_q:
        case SDLK_ESCAPE:
            quit = 1;
            break;
        default:
            break;
    }
}

void base_loop(void) {
    Uint32 start;
    SDL_Event event;

    start = SDL_GetTicks();

    while (!quit) {
        SDL_Delay(20);

        base_update((SDL_GetTicks() - start) / 1000.0);
        base_display();

        while (SDL_PollEvent(&event)) {
            switch(event.type) {
                case SDL_KEYDOWN:
                    base_ev_keydown(event.key);
                    break;
                case SDL_QUIT:
                    quit = 1;
                    break;
                default:
                    break;
            }
        }
    }
}

int base_init(const char* title) {
    SDL_Init(SDL_INIT_VIDEO);

    /* configure OpenGL display buffer */
    SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 5);
    SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 5);
    SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 5);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 16);
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

    /* create a new window */
    screen = SDL_SetVideoMode(
        320, 240, 16,
        SDL_HWSURFACE | SDL_RESIZABLE | SDL_OPENGL
    );
    SDL_WM_SetCaption(title, NULL);

    if (!screen) {
        fprintf(stderr, "FATAL: Could not initialize video mode\n");
        return 0;
    }

    /* initialize gl context */
    glEnable(GL_DEPTH_TEST);

    glFrontFace(GL_CCW);
    glCullFace(GL_BACK);
    glEnable(GL_CULL_FACE);
    
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

    glHint(GL_FOG_HINT, GL_NICEST);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

    glClearColor(0.0, 0.0, 0.0, 1.0);

    return 1;
}

void base_quit(void) {
    /* free scene graph and camera */
    LsgObject_free(LSG_OBJECT(g_scene));
    LsgObject_free(LSG_OBJECT(g_camera));

    /* close window */
    SDL_FreeSurface(screen);
    SDL_Quit();
}
