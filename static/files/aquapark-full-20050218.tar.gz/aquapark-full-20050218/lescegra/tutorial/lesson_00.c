#include "base.h"

#include <stdlib.h>

static void scene_init(void) {
    /* create a camera and a scene */
    LsgPerspectiveCam* camera = LsgPerspectiveCam_create();
    LsgCoords* scene = LsgCoords_create(1.0);

    /* position camera */
    vertex_assign(camera->location, 1.0, 2.0, 1.0);
    vertex_assign(camera->lookat,   0.0, 0.0, 0.0);
    vertex_assign(camera->up,       0.0, 1.0, 0.0);
    camera->fovy = 45.0;
    camera->aspect = 320.0 / 240.0;
    camera->dmin = 0.1;
    camera->dmax = 5.0;

    g_camera = LSG_CAMERA(camera);
    g_scene  = LSG_NODE(scene);
}

int main(int argc, char* argv[]) {
    if (!base_init("lescegra tutorial - lesson 00"))
        return EXIT_FAILURE;

    scene_init();
    base_loop();
    base_quit();

    return EXIT_SUCCESS;
}
