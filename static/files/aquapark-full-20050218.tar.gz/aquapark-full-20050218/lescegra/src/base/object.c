#include <lescegra/base/object.h>

#include <lescegra/base/error.h>

#include <stdlib.h>
#include <stdio.h>

static void LsgObject_destroy_impl(LsgObject* self);

static void LsgObject_staticInit(LsgObjectClass* class, LsgObject* instance) {
    instance->ref_count = 0;

    class->destroy = LsgObject_destroy_impl;
}

LsgClassID LsgObject_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgObject",
            LSG_CLASS_ID_NONE,
            LSG_CLASS_FLAG_ABSTRACT,
            sizeof(LsgObjectClass),
            sizeof(LsgObject),
            (LsgClassStaticInitializer)LsgObject_staticInit
        );
    }

    return classid;
}

void LsgObject_init(LsgObject* self) {
}

static void LsgObject_destroy_impl(LsgObject* self) {
}

void LsgObject_free(LsgObject* obj) {
    if (obj)
        ((LsgObjectClass*)((LsgClassInstance*)obj)->class)->destroy(obj);

    free(obj);
}

void LsgObject_ref(LsgObject* self) {
    ++self->ref_count;
}

void LsgObject_unref(LsgObject* self) {
    if (self->ref_count == 0) {
        LsgError_reportFormat(
            __FILE__, "LsgObject_unref", __LINE__,
            "unref'ing object without references"
        );

    } else {
        --self->ref_count;
    }

    if (self->ref_count == 0)
        LsgObject_free(self);
}
