#include <lescegra/coll/bvolume.h>

#include <stdlib.h>
#include <stdio.h>

static int  LsgBVolume_visible_impl(const LsgBVolume* self, const LsgFrustum* vf);
static void LsgBVolume_collideVertex_impl(const LsgBVolume* self, const Vertex v, LsgList* buffer);
static void LsgBVolume_collideRay_impl(const LsgBVolume* self, const Vertex from, const Vertex dir, LsgList* buffer);
static void LsgBVolume_collideSphere_impl(const LsgBVolume* self, const Vertex center, float radius, LsgList* buffer);
static void LsgBVolume_merge_impl(const LsgBVolume* self, LsgGenericBVolume* target);

static void LsgBVolume_staticInit(LsgBVolumeClass* class, LsgBVolume* instance) {
    class->visible       = LsgBVolume_visible_impl;
    class->collideVertex = LsgBVolume_collideVertex_impl;
    class->collideRay    = LsgBVolume_collideRay_impl;
    class->collideSphere = LsgBVolume_collideSphere_impl;
    class->merge         = LsgBVolume_merge_impl;

    instance->valid = 0;
}

LsgClassID LsgBVolume_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgBVolume",
            LsgObject_classID(),
            LSG_CLASS_FLAG_ABSTRACT,
            sizeof(LsgBVolumeClass),
            sizeof(LsgBVolume),
            (LsgClassStaticInitializer)LsgBVolume_staticInit
        );
    }

    return classid;
}

void LsgBVolume_init(LsgBVolume* self) {
    LsgObject_init(&self->parent);
}

static int LsgBVolume_visible_impl(const LsgBVolume* self, const LsgFrustum* frustum) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgIterator_classID(), "visible");

    return 0;
}

int  LsgBVolume_visible(const LsgBVolume* self, const LsgFrustum* vf) {
    LsgBVolumeClass* class = (LsgBVolumeClass*)((LsgClassInstance*)self)->class;

    return class->visible(self, vf);
}

static void LsgBVolume_collideVertex_impl(const LsgBVolume* self, const Vertex v, LsgList* b) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgIterator_classID(), "collideVertex");
}

void LsgBVolume_collideVertex(const LsgBVolume* self, const Vertex v, LsgList* buffer) {
    LsgBVolumeClass* class = (LsgBVolumeClass*)((LsgClassInstance*)self)->class;

    class->collideVertex(self, v, buffer);
}

static void LsgBVolume_collideRay_impl(const LsgBVolume* self, const Vertex from, const Vertex dir, LsgList* b) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgIterator_classID(), "collideRay");
}

void LsgBVolume_collideRay(const LsgBVolume* self, const Vertex from, const Vertex dir, LsgList* buffer) {
    LsgBVolumeClass* class = (LsgBVolumeClass*)((LsgClassInstance*)self)->class;

    class->collideRay(self, from, dir, buffer);
}

static void LsgBVolume_collideSphere_impl(const LsgBVolume* self, const Vertex center, float r, LsgList* b) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgIterator_classID(), "collideSphere");
}

void LsgBVolume_collideSphere(const LsgBVolume* self, const Vertex center, float radius, LsgList* buffer) {
    LsgBVolumeClass* class = (LsgBVolumeClass*)((LsgClassInstance*)self)->class;

    class->collideSphere(self, center, radius, buffer);
}

static void LsgBVolume_merge_impl(const LsgBVolume* self, LsgGenericBVolume* target) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgIterator_classID(), "merge");
}

void LsgBVolume_merge(const LsgBVolume* self, LsgGenericBVolume* target) {
    LsgBVolumeClass* class = (LsgBVolumeClass*)((LsgClassInstance*)self)->class;

    class->merge(self, target);
}
