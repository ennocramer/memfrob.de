#include <lescegra/coll/hit.h>

#include <stdlib.h>

static void LsgHit_staticInit(LsgHitClass* class, LsgHit* instance) {
    vertex_assign(instance->intersection, 0.0, 0.0, 0.0);
    vertex_assign(instance->normal,       0.0, 0.0, 0.0);
}

LsgClassID LsgHit_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgHit",
            LsgObject_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgHitClass),
            sizeof(LsgHit),
            (LsgClassStaticInitializer)LsgHit_staticInit
        );
    }

    return classid;
}

LsgHit* LsgHit_create(void) {
    LsgHit* self = (LsgHit*)LsgClass_alloc(LsgHit_classID());

    if (self)
        LsgHit_init(self);

    return self;
}

void LsgHit_init(LsgHit* self) {
    LsgObject_init(&self->parent);

    vertex_assign(self->intersection, 0.0, 0.0, 0.0);
    vertex_assign(self->normal, 0.0, 0.0, 0.0);
}
