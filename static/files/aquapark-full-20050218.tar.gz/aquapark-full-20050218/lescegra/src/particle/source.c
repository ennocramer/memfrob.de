#include <lescegra/particle/source.h>

#include <lescegra/util/arraylist.h>

#include <stdlib.h>

static void LsgParticleSource_update(
    LsgParticleSource*,
    LsgParticleSystem*,
    float
);

static void LsgParticleSource_destroy(
    LsgParticleSource*
);

static void LsgParticleSource_staticInit(
    LsgParticleSourceClass* class,
    LsgParticleSource* instance
) {
    ((LsgParticleModifierClass*)class)->update =
        (void (*)(LsgParticleModifier*, LsgParticleSystem*, float))LsgParticleSource_update;

    ((LsgObjectClass*)class)->destroy = 
        (void (*)(LsgObject*))LsgParticleSource_destroy;

    instance->rng = NULL;
    instance->inactive = NULL;

    vertex_assign(instance->location, 0.0, 0.0, 0.0);
    vertex_assign(instance->velocity, 0.0, 0.0, 0.0);

    vertex_assign(instance->location_error, 0.0, 0.0, 0.0);
    vertex_assign(instance->velocity_error, 0.0, 0.0, 0.0);

    instance->birth_rate  = 10.0;
    instance->birth_accum = 0.0;

    instance->lifetime = 1.0;

    instance->particles = NULL;
    instance->max = 0;
}

static LsgObjectClass* s_pclass = NULL;

LsgClassID LsgParticleSource_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgParticleSource",
            LsgParticleModifier_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgParticleSourceClass),
            sizeof(LsgParticleSource),
            (LsgClassStaticInitializer)LsgParticleSource_staticInit
        );

        s_pclass = LSG_OBJECT_CLASS(LsgClass_getParentClass(classid));
    }

    return classid;
}

LsgParticleSource* LsgParticleSource_create(unsigned long int max) {
    LsgParticleSource* self =
        (LsgParticleSource*)LsgClass_alloc(LsgParticleSource_classID());

    if (self)
        LsgParticleSource_init(self, max);

    return self;
}

void LsgParticleSource_init(LsgParticleSource* self, unsigned long int max) {
    LsgParticleModifier_init(&self->parent);

    self->rng      = LsgRandom_create(0);
    self->inactive = LSG_LIST(LsgArrayList_create());

    self->particles = malloc(max * sizeof(LsgParticle));
    self->max = max;

    while (max-- > 0)
        LsgList_append(self->inactive, self->particles + max);
}

static void LsgParticleSource_update(
    LsgParticleSource* self,
    LsgParticleSystem* system,
    float time
) {
    LsgList* list;
    LsgIterator* it;
    Vertex error;

    list = LSG_LIST(LsgArrayList_create());
    LsgOctree_getAll(system->system, list);
    it = LsgList_iterator(list);
    while (LsgIterator_hasNext(it)) {
        LsgParticle* p = (LsgParticle*)LsgIterator_next(it);

        /* skip particle if it's not ours */
        if ((p < self->particles) || (p >= (self->particles + self->max)))
            continue;

        if (p->age > self->lifetime) {
            LsgList_remove(p->container->data, p);

            LsgList_append(
                self->inactive,
                p
            );
        }
    }
    LsgObject_free(LSG_OBJECT(it));
    LsgObject_free(LSG_OBJECT(list));

    self->birth_accum += self->birth_rate * time;

    if ((unsigned int)self->birth_accum > LsgList_count(self->inactive))
        self->birth_accum = (float)LsgList_count(self->inactive);

    while (self->birth_accum >= 1.0) {
        LsgParticle* p = LsgList_removeByIndex(
            self->inactive,
            LsgList_count(self->inactive) - 1
        );

        /* location */
        vertex_copy(p->location, self->location);
        vertex_add(p->location, self->parent.particle.location);
        vertex_assign(
            error,
            LsgRandom_randomError(self->rng),
            LsgRandom_randomError(self->rng),
            LsgRandom_randomError(self->rng)
        );
        vertex_mul(error, self->location_error);
        vertex_add(p->location, error);
        
        /* velocity */
        vertex_copy(p->velocity, self->velocity);
        vertex_add(p->velocity, self->parent.particle.velocity);
        vertex_assign(
            error,
            LsgRandom_randomError(self->rng),
            LsgRandom_randomError(self->rng),
            LsgRandom_randomError(self->rng)
        );
        vertex_mul(error, self->velocity_error);
        vertex_add(p->velocity, error);

        /* acceleration */
        vertex_assign(p->acceleration, 0.0, 0.0, 0.0);
        
        /* fix time granularity */
        p->age = LsgRandom_random(self->rng) * time;

        vertex_copy(error, p->velocity);
        vertex_scale(error, p->age);
        vertex_add(p->location, error);

        p->container = LsgOctree_add(system->system, p->location, p->location, p);
        self->birth_accum -= 1.0;
    }
}

static void LsgParticleSource_destroy(LsgParticleSource* self) {
    free(self->particles);

    LsgObject_free(LSG_OBJECT(self->inactive));
    LsgObject_free(LSG_OBJECT(self->rng));

    s_pclass->destroy(LSG_OBJECT(self));
}
