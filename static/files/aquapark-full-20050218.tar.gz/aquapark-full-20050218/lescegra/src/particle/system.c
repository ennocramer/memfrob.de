#include <lescegra/particle/system.h>

#include <lescegra/util/arraylist.h>

#include <stdlib.h>

/* ParticleModifier ***************************************************/

static void LsgParticleModifier_update_impl(
    LsgParticleModifier* self,
    LsgParticleSystem* system,
    float time
);

static void LsgParticleModifier_staticInit(
    LsgParticleModifierClass* class,
    LsgParticleModifier* instance
) {
    class->update = LsgParticleModifier_update_impl;

    vertex_assign(instance->particle.location,     0.0, 0.0, 0.0);
    vertex_assign(instance->particle.velocity,     0.0, 0.0, 0.0);
    vertex_assign(instance->particle.acceleration, 0.0, 0.0, 0.0);

    instance->particle.age = 0.0;
    instance->particle.user_data = NULL;
}

LsgClassID LsgParticleModifier_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgParticleModifier",
            LsgObject_classID(),
            LSG_CLASS_FLAG_ABSTRACT,
            sizeof(LsgParticleModifierClass),
            sizeof(LsgParticleModifier),
            (LsgClassStaticInitializer)LsgParticleModifier_staticInit
        );
    }

    return classid;
}

void LsgParticleModifier_init(LsgParticleModifier* self) {
    LsgObject_init(&self->parent);
}

void LsgParticleModifier_update(
    LsgParticleModifier* self,
    LsgParticleSystem* system,
    float time
) {
    LsgParticleModifierClass* class =
        (LsgParticleModifierClass*)((LsgClassInstance*)self)->class;

    class->update(self, system, time);
}

static void LsgParticleModifier_update_impl(
    LsgParticleModifier* self,
    LsgParticleSystem* system,
    float time
) {
    LsgClass_abortAbstract(
        (LsgClassInstance*)self, LsgParticleModifier_classID(), "update"
    );
}


/* ParticleSystem *****************************************************/

static void LsgParticleSystem_update(LsgParticleSystem*, float);
static void LsgParticleSystem_display(const LsgParticleSystem*, const LsgFrustum*);
static void LsgParticleSystem_destroy(LsgParticleSystem*);

static void LsgParticleSystem_staticInit(LsgParticleSystemClass* class, LsgParticleSystem* instance) {
    ((LsgNodeClass*)class)->update =
        (void (*)(LsgNode*, float))LsgParticleSystem_update;
    ((LsgNodeClass*)class)->display =
        (void (*)(const LsgNode*, const LsgFrustum*))LsgParticleSystem_display;

    ((LsgObjectClass*)class)->destroy =
        (void (*)(LsgObject*))LsgParticleSystem_destroy;

    instance->system    = NULL;
    instance->modifiers = NULL;

    instance->renderer = NULL;

    instance->last = 0.0;
}

static LsgObjectClass* s_pclass = NULL;

LsgClassID LsgParticleSystem_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgParticleSystem",
            LsgNode_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgParticleSystemClass),
            sizeof(LsgParticleSystem),
            (LsgClassStaticInitializer)LsgParticleSystem_staticInit
        );

        s_pclass = LSG_OBJECT_CLASS(LsgClass_getParentClass(classid));
    }

    return classid;
}

LsgParticleSystem* LsgParticleSystem_create(
    LsgParticleRenderer renderer,
    Vertex min, Vertex max, int div
) {
    LsgParticleSystem* self =
        (LsgParticleSystem*)LsgClass_alloc(LsgParticleSystem_classID());

    if (self)
        LsgParticleSystem_init(self, renderer, min, max, div);

    return self;
}

void LsgParticleSystem_init(
    LsgParticleSystem* self,
    LsgParticleRenderer renderer,
    Vertex min, Vertex max, int div
) {
    LsgNode_init(&self->parent);

    self->system = LsgOctree_create(min, max, div);
    self->modifiers = LSG_LIST(LsgArrayList_create());

    self->renderer = renderer;

    LsgList_refElements(self->modifiers, 1);
}

static void LsgParticleSystem_update(LsgParticleSystem* self, float now) {
    LsgList* list;
    LsgIterator* it;
    Vertex v;
    float time = now - self->last;

    it = LsgList_iterator(self->modifiers);
    while (LsgIterator_hasNext(it)) {
        LsgParticleModifier* pm = LSG_PARTICLE_MODIFIER(LsgIterator_next(it));
        LsgParticleModifier_update(pm, self, time);
    }
    LsgObject_free(LSG_OBJECT(it));

    list = LSG_LIST(LsgArrayList_create());
    LsgOctree_getAll(self->system, list);

    it = LsgList_iterator(list);
    while (LsgIterator_hasNext(it)) {
        LsgParticle* p = (LsgParticle*)LsgIterator_next(it);

        vertex_copy(v, p->acceleration);
        vertex_scale(v, time);
        vertex_add(p->velocity, v);

        vertex_copy(v, p->velocity);
        vertex_scale(v, time);
        vertex_add(p->location, v);

        vertex_assign(p->acceleration, 0.0, 0.0, 0.0);

        p->age += time;
    }
    LsgObject_free(LSG_OBJECT(it));

    LsgObject_free(LSG_OBJECT(list));

    self->last = now;
}

static void LsgParticleSystem_display(
    const LsgParticleSystem* self,
    const LsgFrustum* frust
) {
    LsgList* list = LSG_LIST(LsgArrayList_create());
    LsgOctree_getVisible(self->system, frust, list);

    self->renderer(list);

    LsgObject_free(LSG_OBJECT(list));
}

static void LsgParticleSystem_destroy(LsgParticleSystem* self) {
    LsgObject_free(LSG_OBJECT(self->modifiers));
    LsgObject_free(LSG_OBJECT(self->system));

    s_pclass->destroy(LSG_OBJECT(self));
}
