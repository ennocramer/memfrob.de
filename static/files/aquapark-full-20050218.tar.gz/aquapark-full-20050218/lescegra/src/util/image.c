#include <lescegra/util/image.h>

#include <lescegra/base/error.h>

#include <errno.h>
#include <stdlib.h>
#include <string.h>

#include <config.h>

static void LsgImage_destroy(LsgImage* self);

static void LsgImage_staticInit(LsgImageClass* class, LsgImage* instance) {
    ((LsgObjectClass*)class)->destroy = (void (*)(LsgObject*))LsgImage_destroy;

    instance->data   = NULL;
    instance->width  = 0;
    instance->height = 0;
    instance->bpp    = 0;
}

static LsgObjectClass* s_pclass = NULL;

LsgClassID LsgImage_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgImage",
            LsgObject_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgImageClass),
            sizeof(LsgImage),
            (LsgClassStaticInitializer)LsgImage_staticInit
        );

        s_pclass = LSG_OBJECT_CLASS(LsgClass_getParentClass(classid));
    }

    return classid;
}

LsgImage* LsgImage_create(int width, int height, int bpp) {
    LsgImage* self = (LsgImage*)LsgClass_alloc(LsgImage_classID());

    if (self)
        LsgImage_init(self, width, height, bpp);

    return self;
}

void LsgImage_init(LsgImage* self, int width, int height, int bpp) {
    LsgObject_init(&self->parent);

    self->width = width;
    self->height = height;
    self->bpp = bpp;

    self->data = (unsigned char*)malloc(sizeof(unsigned char) * width * height * bpp);
    assert(self->data != NULL);
}

void LsgImage_copy(LsgImage* self, int x, int y, int w, int h, LsgImage* dst, int dst_x, int dst_y) {
    int bpp;
    int r, c, b;

    if ((x >= self->width) || (y >= self->height)
    || (dst_x >= dst->width) || (dst_y >= dst->height)
    || (w < 1) || (h < 1)) return;

    /* clip on source image */
    if (x < 0) {
        w     += x;
        dst_x -= x;
        x      = 0;
    }

    if (y < 0) {
        h     += y;
        dst_y -= y;
        y      = 0;
    }

    if ((x + w) > self->width)
        w = self->width - x;

    if ((y + h) > self->height)
        h = self->height - y;

    /* clip on destination image */
    if (dst_x < 0) {
        x     -= dst_x;
        w     += dst_x;
        dst_x  = 0;
    }

    if (dst_y < 0) {
        y     -= dst_y;
        w     += dst_y;
        dst_y  = 0;
    }

    if ((dst_x + w) >= dst->width)
        w = dst->width - dst_x;

    if ((dst_y + h) >= dst->height)
        h = dst->height - dst_y;

    /* copy that data */
    bpp = self->bpp < dst->bpp ? self->bpp : dst->bpp;

    for (r = 0; r < h; ++r) {
        for (c = 0; c < w; ++c) {
            for (b = 0; b < bpp; ++b) {
                dst->data[((dst_y + r) * dst->width + (dst_x + c)) * dst->bpp + b] =
                        self->data[((y + r) * self->width + (x + c)) * self->bpp + b];
            }
        }
    }
}

void LsgImage_mirrorX(LsgImage* self) {
    unsigned char* tmp;
    int x, y;

    tmp = (unsigned char*)malloc(sizeof(unsigned char) * self->bpp);

    for (y = 0; y < self->height; ++y) {
        for (x = 0; x < self->width / 2; ++x) {
            memcpy(tmp, self->data + (y * self->width + x) * self->bpp, sizeof(unsigned char) * self->bpp);
            memcpy(self->data + (y * self->width + x) * self->bpp, self->data + (y * self->width + (self->width - x - 1)) * self->bpp, sizeof(unsigned char) * self->bpp);
            memcpy(self->data + (y * self->width + (self->width - x - 1)) * self->bpp, tmp, sizeof(unsigned char) * self->bpp);
        }
    }
}

void LsgImage_mirrorY(LsgImage* self) {
    unsigned char* tmp;
    int tmp_size;
    int y;

    tmp_size = self->width * self->bpp;
    tmp = (unsigned char*)malloc(sizeof(unsigned char) * tmp_size);

    for (y = 0; y < self->height / 2; ++y) {
        memcpy(tmp, self->data + y * tmp_size, sizeof(unsigned char) * tmp_size);
        memcpy(self->data + y * tmp_size, self->data + (self->height - y - 1) * tmp_size, sizeof(unsigned char) * tmp_size);
        memcpy(self->data + (self->height - y - 1) * tmp_size, tmp, sizeof(unsigned char) * tmp_size);
    }

    free(tmp);
}

static void LsgImage_destroy(LsgImage* self) {
    free(self->data);

    s_pclass->destroy((LsgObject*)self);
}

LsgImage* LsgImage_load(const char* filename) {
    LsgImage* image = NULL;
    FILE* stream    = NULL;

    /* open file */
    if (!(stream = fopen(filename, "rb"))) {
        LsgError_reportFormat(
            __FILE__, "LsgImage_load", __LINE__,
            "%s: %s", filename, strerror(errno)
        );

    } else {
        image = LsgImage_loadStream(filename, stream);
    }

    if (stream)
        fclose(stream);

    return image;
}

LsgImage* LsgImage_loadPCX(const char* filename, FILE* stream);
LsgImage* LsgImage_loadPNG(const char* filename, FILE* stream);
LsgImage* LsgImage_loadTGA(const char* filename, FILE* stream);

typedef enum {
    FORMAT_UNKNOWN,
    FORMAT_PNG,
    FORMAT_PCX,
    FORMAT_TGA
} ImageFormat;

static ImageFormat LsgImage_identify(
    const char* filename,
    const unsigned char* buffer,
    unsigned int cnt
) {
    unsigned int slen = strlen(filename);
    const char* ext = filename + slen - (slen >= 4 ? 4 : 0);

    /* try to detect image format by content */
    if ((cnt >= 8) && !strncmp((const char*)buffer, "\211PNG\r\n\032\n", 8))
        return FORMAT_PNG;
        
    if ((cnt >= 1) && (buffer[0] == 10)) /* is this wise? */
        return FORMAT_PCX;

    /* fallback to extension */
    if (!strcmp(ext, ".png") || !strcmp(ext, ".PNG"))
        return FORMAT_PNG;

    if (!strcmp(ext, ".pcx") || !strcmp(ext, ".PCX"))
        return FORMAT_PCX;

    if (!strcmp(ext, ".tga") || !strcmp(ext, ".TGA"))
        return FORMAT_TGA;

    return FORMAT_UNKNOWN;
}

LsgImage* LsgImage_loadStream(const char* filename, FILE* stream) {
    unsigned char magic[32];
    unsigned int  read_count;

    ImageFormat format;

    read_count = fread(magic, 1, sizeof(magic), stream);
    
    if (fseek(stream, -read_count, SEEK_CUR) == -1) {
        LsgError_reportFormat(
            __FILE__, "LsgImage_loadStream", __LINE__,
            "%s: %s", filename, strerror(errno)
        );
        return NULL;
    }

    format = LsgImage_identify(filename, magic, read_count);

    switch (format) {
        case FORMAT_PCX:
            return LsgImage_loadPCX(filename, stream);

#ifdef HAVE_LIBZ
        case FORMAT_PNG:
            return LsgImage_loadPNG(filename, stream);
#endif

        case FORMAT_TGA:
            return LsgImage_loadTGA(filename, stream);

        default:
            LsgError_reportFormat(
                __FILE__, "LsgImage_loadStream", __LINE__,
                "%s: %s", filename, "unknown image format"
            );
            return NULL;
    }
}
