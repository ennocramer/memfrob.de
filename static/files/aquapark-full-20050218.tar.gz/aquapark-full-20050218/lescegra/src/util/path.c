#include <lescegra/util/path.h>

#include <lescegra/util/arraylist.h>

#include <stdlib.h>

static void LsgPath_destroy(LsgPath*);

static void LsgPath_staticInit(LsgPathClass* class, LsgPath* instance) {
    ((LsgObjectClass*)class)->destroy =
        (void (*)(LsgObject*))LsgPath_destroy;

    instance->keys = NULL;
    instance->mode = LSG_PATH_STEP;
}

static LsgObjectClass* s_pclass = NULL;

LsgClassID LsgPath_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgPath",
            LsgObject_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgPathClass),
            sizeof(LsgPath),
            (LsgClassStaticInitializer)LsgPath_staticInit
        );

        s_pclass = LSG_OBJECT_CLASS(LsgClass_getParentClass(classid));
    }

    return classid;
}

LsgPath* LsgPath_create(LsgPath_Mode mode) {
    LsgPath* self =
        (LsgPath*)LsgClass_alloc(LsgPath_classID());

    if (self)
        LsgPath_init(self, mode);

    return self;
}

void LsgPath_init(LsgPath* self, LsgPath_Mode mode) {
    LsgObject_init(&self->parent);

    self->keys = LSG_LIST(LsgArrayList_create());
    self->mode = mode;
}

static void LsgPath_interpolateLinear(
    const Vertex prev,
    const Vertex next,
    float time,
    Vertex v
) {
    vertex_copy(v, next);
    vertex_sub(v, prev);
    vertex_scale(v, time);
    vertex_add(v, prev);
}

static void LsgPath_interpolateBezier(
    const Vertex prev,
    const Vertex mid,
    const Vertex next,
    float time,
    Vertex v
) {
    Vertex p1, p2, s1, s2;

    LsgPath_interpolateLinear(
        prev, mid, 0.5, p1
    );
    LsgPath_interpolateLinear(
        mid, next, 0.5, p2
    );

    LsgPath_interpolateLinear(
        p1, mid, time, s1
    );
    LsgPath_interpolateLinear(
        mid, p2, time, s2
    );
    LsgPath_interpolateLinear(
        s1, s2, time, v
    );
}

static void LsgPath_interpolateCatmullRom(
    const Vertex prev_trend,
    const Vertex prev,
    const Vertex next,
    const Vertex next_trend,
    float time,
    Vertex v
) {
    Vertex buffer;
    float f_prev, f_next, f_prev_trend, f_next_trend;
    
    f_prev =  2.0*time*time*time - 3.0*time*time + 1.0;
    f_next = -2.0*time*time*time + 3.0*time*time;
    f_prev_trend = time*time*time - 2.0*time*time + time;
    f_next_trend = time*time*time - time*time;
        
    /* prev */
    vertex_copy(v, prev);
    vertex_scale(v, f_prev);
        
    /* next */
    vertex_copy(buffer, next);
    vertex_scale(buffer, f_next);
    vertex_add(v, buffer);
        
    /* prev_trend */
    vertex_copy(buffer, next);
    vertex_sub(buffer, prev_trend);
    vertex_scale(buffer, f_prev_trend);
    vertex_add(v, buffer);
    
    /* next_trend */
    vertex_copy(buffer, next_trend);
    vertex_sub(buffer, prev);
    vertex_scale(buffer, f_next_trend);
    vertex_add(v, buffer);
}

void LsgPath_interpolate(LsgPath* self, float time, Vertex v) {
    LsgPath_Key* key0 = NULL;
    LsgPath_Key* key1 = NULL;
    LsgPath_Key* key2 = NULL;
    LsgPath_Key* key3 = NULL;

    LsgIterator* it;
    float t;

    if (LsgList_count(self->keys) == 0)
        return;

    /* GOAL: key3 < key2 < time < key1 < key0 */
    it = LsgList_iterator(self->keys);
    do {
        key3 = key2;
        key2 = key1;
        key1 = key0;
        key0 = LsgIterator_next(it);
    } while (LsgIterator_hasNext(it) && (!key1 || key1->time <= time));
    LsgObject_free(LSG_OBJECT(it));

    /* if we have too few keys to fill key0-3 we shift keys
     * until key2 has the best possible value */
    while (!key1 || ((key1->time <= time) && key0)) {
        key2 = key1;
        key1 = key0;
        key0 = NULL;
    }
    
    if (key2 && key1)
        t = (time - key2->time) / (key1->time - key2->time);
    else
        t = 0.0;

    if (        /* catmull rom interpolation */
        (self->mode == LSG_PATH_CATMULL_ROM)
         && key3 && key2 && key1 && key0
    ) {
        LsgPath_interpolateCatmullRom(
            key3->v, key2->v, key1->v, key0->v, t, v
        );

    } else if ( /* bezier interpolation */
        (self->mode == LSG_PATH_BEZIER)
         && key2 && key1 && key0
    ) {
        LsgPath_interpolateBezier(
            key2->v, key1->v, key0->v, t, v
        );

    } else if ( /* linear interpolation */
        (self->mode == LSG_PATH_LINEAR)
         && key2 && key1
    ) {
        LsgPath_interpolateLinear(
            key2->v, key1->v, t, v
        );

    } else if ( /* no interpolation */
        (self->mode == LSG_PATH_STEP)
         && key2
    ) {
            vertex_copy(v, key2->v);
    }
}

void LsgPath_addKey(LsgPath* self, Vertex v, float time) {
    LsgPath_Key* new_key;
    LsgPath_Key* key;
    int pos;
    
    new_key = malloc(sizeof(LsgPath_Key));
    vertex_copy(new_key->v, v);
    new_key->time = time;
    

    for (pos = LsgList_count(self->keys); pos > 0; --pos) {
        key = LsgList_get(self->keys, pos - 1);
        if (key->time < time) {
            LsgList_insert(self->keys, pos, new_key);
            break;
        }
    }

    if (pos == 0)
        LsgList_insert(self->keys, 0, new_key);
}

void LsgPath_clear(LsgPath* self) {
    LsgIterator* it = LsgList_iterator(self->keys);
    while (LsgIterator_hasNext(it))
        free(LsgIterator_next(it));
    LsgObject_free(LSG_OBJECT(it));

    LsgList_clear(self->keys);
}

static void LsgPath_destroy(LsgPath* self) {
    LsgPath_clear(self);
    LsgObject_free(LSG_OBJECT(self->keys));
    
    s_pclass->destroy(LSG_OBJECT(self));
}
