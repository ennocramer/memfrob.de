#include <lescegra/sg/perspectivecam.h>

#ifndef M_PI
# define M_PI		3.14159265358979323846	/* pi */
#endif

static void LsgPerspectiveCam_load(
    const LsgPerspectiveCam* self,
    Matrix proj,
    Matrix mview
);

static void LsgPerspectiveCam_staticInit(
    LsgPerspectiveCamClass* class,
    LsgPerspectiveCam* instance
) {
    ((LsgCameraClass*)class)->load =
        (void (*)(const LsgCamera*, Matrix, Matrix))LsgPerspectiveCam_load;

    vertex_assign(instance->location, 0.0, 0.0, -1.0);
    vertex_assign(instance->lookat,   0.0, 0.0, 0.0);
    vertex_assign(instance->up,       0.0, 1.0, 0.0);

    instance->fovy   = 45.0;
    instance->aspect = 1.0;
    instance->dmin   = 0.01;
    instance->dmax   = 10.0;
}

LsgClassID LsgPerspectiveCam_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgPerspectiveCam",
            LsgCamera_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgPerspectiveCamClass),
            sizeof(LsgPerspectiveCam),
            (LsgClassStaticInitializer)LsgPerspectiveCam_staticInit
        );
    }

    return classid;
}

LsgPerspectiveCam* LsgPerspectiveCam_create(void) {
    LsgPerspectiveCam* self =
        (LsgPerspectiveCam*)LsgClass_alloc(LsgPerspectiveCam_classID());

    if (self)
        LsgPerspectiveCam_init(self);

    return self;
}

void LsgPerspectiveCam_init(LsgPerspectiveCam* self) {
    LsgCamera_init(&self->parent);
}

static void LsgPerspectiveCam_load(
    const LsgPerspectiveCam* self,
    Matrix proj,
    Matrix mview
) {
    matrix_load_perspective(
        proj,
        self->fovy * M_PI / 180.0,
        self->aspect, self->dmin, self->dmax
    );

    matrix_load_lookat(
        mview,
        self->location,
        self->lookat,
        self->up
    );
}
