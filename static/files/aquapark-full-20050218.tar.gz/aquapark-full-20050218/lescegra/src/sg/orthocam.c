#include <lescegra/sg/orthocam.h>

static void LsgOrthoCam_load(
    const LsgOrthoCam* self,
    Matrix proj,
    Matrix mview
);

static void LsgOrthoCam_staticInit(
    LsgOrthoCamClass* class,
    LsgOrthoCam* instance
) {
    ((LsgCameraClass*)class)->load =
        (void (*)(const LsgCamera*, Matrix, Matrix))LsgOrthoCam_load;

    vertex_assign(instance->min, -1.0, -1.0, -1.0);
    vertex_assign(instance->max,  1.0,  1.0,  1.0);
}

LsgClassID LsgOrthoCam_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgOrthoCam",
            LsgCamera_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgOrthoCamClass),
            sizeof(LsgOrthoCam),
            (LsgClassStaticInitializer)LsgOrthoCam_staticInit
        );
    }

    return classid;
}

LsgOrthoCam* LsgOrthoCam_create(void) {
    LsgOrthoCam* self = (LsgOrthoCam*)LsgClass_alloc(LsgOrthoCam_classID());

    if (self)
        LsgOrthoCam_init(self);

    return self;
}

void LsgOrthoCam_init(LsgOrthoCam* self) {
    LsgCamera_init(&self->parent);
}

static void LsgOrthoCam_load(
    const LsgOrthoCam* self,
    Matrix proj,
    Matrix mview
) {
    matrix_load_ortho(
        proj,
        self->min[0], self->max[0],
        self->min[1], self->max[1],
        self->min[2], self->max[2]
    );

    matrix_load_identity(mview);
}
