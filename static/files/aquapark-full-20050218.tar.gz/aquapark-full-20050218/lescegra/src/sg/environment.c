#include <lescegra/sg/environment.h>

#include <lescegra/sg/state.h>
#include <lescegra/util/arraylist.h>

#include <stdlib.h>

static void LsgEnvironment_display(const LsgEnvironment*, const LsgFrustum*);
static void LsgEnvironment_destroy(LsgEnvironment*);

static void LsgEnvironment_staticInit(LsgEnvironmentClass* class, LsgEnvironment* instance) {
    ((LsgNodeClass*)class)->display =
        (void (*)(const LsgNode*, const LsgFrustum*))LsgEnvironment_display;

    ((LsgObjectClass*)class)->destroy =
        (void (*)(LsgObject*))LsgEnvironment_destroy;
}

static LsgNodeClass* s_pclass = NULL;

LsgClassID LsgEnvironment_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgEnvironment",
            LsgGroup_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgEnvironmentClass),
            sizeof(LsgEnvironment),
            (LsgClassStaticInitializer)LsgEnvironment_staticInit
        );

        s_pclass = LSG_NODE_CLASS(LsgClass_getParentClass(classid));
    }

    return classid;
}

LsgEnvironment* LsgEnvironment_create(void) {
    LsgEnvironment* self = (LsgEnvironment*)LsgClass_alloc(LsgEnvironment_classID());

    if (self)
        LsgEnvironment_init(self);

    return self;
}

void LsgEnvironment_init(LsgEnvironment* self) {
    LsgGroup_init(&self->parent);

    self->states = LSG_LIST(LsgArrayList_create());
}

static void LsgEnvironment_display(
    const LsgEnvironment* self,
    const LsgFrustum* frustum
) {
    int i;
    
    for (i = 0; i < LsgList_count(self->states); ++i)
        LsgState_apply(LSG_STATE(LsgList_get(self->states, i)));

    s_pclass->display(LSG_NODE(self), frustum);

    for (i = LsgList_count(self->states) - 1; i >= 0; --i)
        LsgState_restore(LSG_STATE(LsgList_get(self->states, i)));
}

void LsgEnvironment_destroy(LsgEnvironment* self) {
    LsgObject_free(LSG_OBJECT(self->states));

    ((LsgObjectClass*)s_pclass)->destroy(LSG_OBJECT(self));
}
