#include "caustics.h"

#include <lescegra/base/vertex.h>
#include <lescegra/util/features.h>
#include <lescegra/util/arraylist.h>
#include <lescegra/sg/texture.h>

#define GL_GLEXT_PROTOTYPES
#include <GL/gl.h>
#ifdef HAVE_GL_GLEXT_H
# include <GL/glext.h>
#endif

#include <stdlib.h>

static void LsgCaustics_apply(const LsgCaustics*);
static void LsgCaustics_restore(const LsgCaustics*);

static void LsgCaustics_staticInit(LsgCausticsClass* class, LsgCaustics* instance) {
    ((LsgStateClass*)class)->apply =
        (void (*)(const LsgState*))LsgCaustics_apply;
    ((LsgStateClass*)class)->restore =
        (void (*)(const LsgState*))LsgCaustics_restore;

    instance->textures = NULL;

    vertex_assign(instance->map_s, 1.0, 0.0, 0.0);
    instance->map_s[3] = 1.0;
    vertex_assign(instance->map_t, 0.0, 1.0, 0.0);
    instance->map_t[3] = 1.0;

    instance->unit = 1;

    instance->speed = 1.0;
    instance->current = 0;
}

LsgClassID LsgCaustics_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgCaustics",
            LsgState_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgCausticsClass),
            sizeof(LsgCaustics),
            (LsgClassStaticInitializer)LsgCaustics_staticInit
        );
    }

    return classid;
}

LsgCaustics* LsgCaustics_create(const char* format, int count) {
    LsgCaustics* self = (LsgCaustics*)LsgClass_alloc(LsgCaustics_classID());

    if (self)
        LsgCaustics_init(self, format, count);

    return self;
}

void LsgCaustics_init(
    LsgCaustics* self,
    const char* format,
    int count
) {
    char file[256];
    int i;

    LsgState_init(&self->parent);

    self->textures = LSG_LIST(LsgArrayList_create());

    for (i = 0; i < count; ++i) {
        LsgImage* img;

        sprintf(file, format, i);

        img = LsgImage_load(file);

        if (!img)
            continue;

        LsgList_append(
            self->textures,
            LsgTexture_create(img, GL_LUMINANCE, GL_MODULATE)
        );
        LsgObject_free(LSG_OBJECT(img));
    }
}

void LsgCaustics_update(LsgCaustics* self, float now) {
    self->current = (int)(now * self->speed) % LsgList_count(self->textures);
}

static void LsgCaustics_apply(const LsgCaustics* self) {
        LsgTexture* tex =
            LSG_TEXTURE(LsgList_get(self->textures, self->current));

        glPushAttrib(GL_TEXTURE_BIT);

#ifdef GL_ARB_multitexture
    if (LsgFeatures_numTextureUnits() > 1) {
        glPushAttrib(GL_CURRENT_BIT);

        glActiveTextureARB(GL_TEXTURE0_ARB + self->unit);

        glEnable(GL_TEXTURE_2D);

        glBindTexture(GL_TEXTURE_2D, tex->id);
        glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, tex->mode);

        glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
        glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
        glTexGenfv(GL_S, GL_EYE_PLANE, self->map_s);
        glTexGenfv(GL_T, GL_EYE_PLANE, self->map_t);

        glEnable(GL_TEXTURE_GEN_S);
        glEnable(GL_TEXTURE_GEN_T);
 
        glPopAttrib();
    }
#endif
}

static void LsgCaustics_restore(const LsgCaustics* self) {
    glPopAttrib();
}
