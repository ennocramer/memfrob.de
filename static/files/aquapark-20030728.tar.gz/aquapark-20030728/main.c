/*********************************************
**********************************************  
**                                          **
**  project     aquapark                    **
**              Computergrafik      ss2003  **
**              FH-Wedel                    **
**                                          **
**  authors     enno cramer         ii5476  **
**              martin salzburg     mi4402  **
**                                          **
**********************************************
*********************************************/

#include "callback.h"

#include "global.h"
#include "scene.h"
#include "hud.h"
#include "callback.h"

#include <GL/glut.h>

#include <lescegra/util/image.h>
#include <stdlib.h>

/**
 *  init OpenGL basics
 */
void init_video(void) {
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
#if GLUT_GAME_MODE == 1
    glutEnterGameMode();
    glutSetCursor(GLUT_CURSOR_NONE);
#else
    glutCreateWindow("AquaPark");
#endif

    glClearColor(global_water_color[0], global_water_color[1], global_water_color[2], 1.0);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_FOG);
    glEnable(GL_LIGHTING);
    glEnable(GL_CULL_FACE);
    glEnable(GL_NORMALIZE);
    
/*    glActiveTextureARB(GL_TEXTURE1_ARB);
    glEnable(GL_TEXTURE_2D); */
    glActiveTextureARB(GL_TEXTURE0_ARB);
    glEnable(GL_TEXTURE_2D);
    
    glCullFace(GL_BACK);
}

/**
 * calls init functions 
 *
 * @return              programm return value
 * @param   argc        command line argument count
 * @param   argv        command line arguments
 */
int main(int argc, char* argv[]) {
    glutInit(&argc, argv);

    init_video();
    init_callback();
    init_scene();
    init_hud();

    glutMainLoop();

    return 0;
}
