#include "fish.h"

#include "util.h"
#include "global.h"

#include <lescegra/util/random.h>

#include <GL/gl.h>

#include <math.h>
#include <stdlib.h>

#define FISH_ACCELERATION        5.0
#define FISH_ACCELERATION_FACTOR 3.0
#define FISH_FRICTION            0.05
#define FISH_SPEED               sqrt(FISH_ACCELERATION / FISH_FRICTION) 
#define FISH_FLEE_DISTANCE       30.0

#define FISH_COLL_FACTOR   8.0

#define FISH_SWARM_DISTANCE 10.0
#define FISH_SWARM_FACTOR   5.0

#define FISH_LEVEL         10.0

#define SQR(a) ((a) * (a))

static float fish_mat_ambi[4] = {0.4, 0.4, 0.4, 1.0};
static float fish_mat_diff[4] = {0.7, 0.7, 0.7, 1.0};
static float fish_mat_spec[4] = {0.2, 0.2, 0.2, 1.0};

Fish* fish_create(LsgMD2Model* model, Vertex location, Vertex speed, float time) {
    Fish* self = (Fish*)malloc(sizeof(Fish));
    
    fish_init(self, model, location, speed, time, 10.0);
    
    return self;
}

void fish_init(Fish* self, LsgMD2Model* model, Vertex location, Vertex speed, float time, float favorite_height) {
    LsgParticle_init(&self->super, location, speed, time);

    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))fish_display;
    ((LsgNode*)self)->update  = (void (*)(LsgNode*, float))fish_update;
    
    ((LsgNode*)self)->bvolume = ((LsgNode*)model)->bvolume;

    self->model = model;
    self->favorite_height = favorite_height;

    /* LsgBBox_combine(self->super.super.bbox, model->super.bbox); */
}

int isnan(double);
#if 0
static void fish_move_collide_static(Fish* self, float now) {
    LsgIterator* it;
    Vertex direction, dist, v;
    float len, factor, coll_distance;
    
    vertex_assign(direction, 0.0, 0.0, 0.0);
    
    /* s = 1/2 * v^2 / a */
    coll_distance = 0.5 * vertex_dot(self->super.speed, self->super.speed) / FISH_ACCELERATION;
    
    if (coll_distance < 0.001) return;

    it = LsgIterator_create(global_objects_static);
    while (LsgIterator_hasNext(it)) {
        LsgNode* node = (LsgNode*) LsgIterator_next(it);
        
        node->collide(node, self->super.location, dist);
        ((LsgNode*)self)->collide((LsgNode*)self, dist, v);
        vertex_sub(dist, v);
        
        if ((len = vertex_length(dist)) > (FISH_COLL_FACTOR * coll_distance)) continue;
        /* TODO: besser machen */
        if (len == 0.0) continue;

        factor = 1.0 - (len - coll_distance) / ((FISH_COLL_FACTOR - 1.0) * coll_distance);
    
        vertex_scale(dist, -1.0 / len * factor);
        vertex_add(direction, dist);
    }
    LsgObject_free((LsgObject*)it);

    if ((len = vertex_length(direction)) < 0.001) return;
    
    vertex_scale(direction, FISH_ACCELERATION / len * (now - self->super.time));
    vertex_add(self->super.speed, direction);
}

static void fish_move_collide_dynamic(Fish* self, float now) {
    LsgIterator* it;
    Vertex direction, dist, v;
    float len, factor, coll_distance;
    
    vertex_assign(direction, 0.0, 0.0, 0.0);
    
    /* s = 1/2 * v^2 / a */
    coll_distance = 0.5 * vertex_dot(self->super.speed, self->super.speed) / FISH_ACCELERATION;
    
    if (coll_distance < 0.001) return;

    it = LsgIterator_create(global_objects_dynamic);
    while (LsgIterator_hasNext(it)) {
        LsgNode* node = (LsgNode*) LsgIterator_next(it);
        
        node->collide(node, self->super.location, dist);
        ((LsgNode*)self)->collide((LsgNode*)self, dist, v);
        vertex_sub(dist, v);
        
        if ((len = vertex_length(dist)) > (FISH_COLL_FACTOR * coll_distance)) continue;
        /* TODO: besser machen */
        if (len == 0.0) continue;

        factor = 1.0 - (len - coll_distance) / ((FISH_COLL_FACTOR - 1.0) * coll_distance);
        
        vertex_scale(dist, -1.0 / len * factor);
        vertex_add(direction, dist);
    }
    LsgObject_free((LsgObject*)it);

    if ((len = vertex_length(direction)) < 0.001) return;
    
    vertex_scale(direction, FISH_ACCELERATION / len * (now - self->super.time));
    vertex_add(self->super.speed, direction);
}

static float fish_move_flee_camera(Fish* self, Vertex direction, float percent) {
    Vertex dist;
    float len, factor;

    ((LsgNode*)self)->collide((LsgNode*)self, ego_cam->location, dist);
    vertex_sub(dist, ego_cam->location);

    if ((len = vertex_length(dist)) > FISH_FLEE_DISTANCE) return 0.0;

    factor = 2.0 - 2.0 * len / FISH_FLEE_DISTANCE;

    vertex_scale(dist, 1.0 / len * factor);
    vertex_add(direction, dist);

    return factor;
}

static float fish_move_keep_level(Fish* self, Vertex direction, float percent) {
    Vertex dist, v;
    float factor;

    if (percent > 0.0) {
        global_terrain->collide(global_terrain, self->super.location, v);
        ((LsgNode*)self)->collide((LsgNode*)self, v, dist);
        vertex_sub(dist, v);

        factor = (dist[1] - FISH_LEVEL) / (5.0 * FISH_LEVEL);
        if (factor < 0.0) return 0.0;
        if (factor > 1.0) factor = 1.0;
        
        factor *= percent;
        direction[1] -= factor;
        
        return factor;
    } else {
        return 0.0;
    }
}

static float fish_move_free(Fish* self, Vertex direction, float percent) {
    Vertex v;
    float alpha;
    
    if (percent > 0.0) {
        vertex_copy(v, self->super.speed);
        
        alpha = atan(v[0] / v[2]);
        
        if (alpha != alpha) {
            alpha = 0.0;
        } else if (v[2] < 0.0) {
            alpha += M_PI;
        }
        
        alpha += random_error() * M_PI * 0.3;
        v[0] = sin(alpha);
        v[1] = v[1] * 0.2;
        v[2] = cos(alpha);
        
        vertex_scale(v, percent / vertex_length(v));

        vertex_add(direction, v);
    }
    
    return 0.0;
}
#endif
void fish_update(Fish* self, float now) {
#if 0    
    Vertex direction;
    float percent = 1.0;
    
    vertex_assign(direction, 0.0, 0.0, 0.0);
    percent -= fish_move_flee_camera(self, direction, percent);
    percent -= fish_move_keep_level(self, direction, percent);
    percent -= fish_move_free(self, direction, percent);
    
    vertex_normalize(direction);
    vertex_scale(direction, FISH_ACCELERATION * (now - self->super.time));
    vertex_add(self->super.speed, direction);

    fish_move_collide_static(self, now);
    fish_move_collide_dynamic(self, now);
    
    /* friction */
    vertex_copy(direction, self->super.speed);
    percent = FISH_FRICTION * vertex_dot(direction, direction) * (now - self->super.time);
    percent = MIN(1.0, percent);
    vertex_scale(direction, percent);
    vertex_sub(self->super.speed, direction);

    /* move fish */
    LsgParticle_update(&self->super, now);

    util_range_vertex(self->super.location);
    
    /* update bbox */
    LsgBBox_clear(self->super.super.bbox);
    LsgBBox_combine(self->super.super.bbox, self->model->super.bbox);
    vertex_add(((LsgNode*)self)->bbox->min, self->super.location);
    vertex_add(((LsgNode*)self)->bbox->max, self->super.location);
    ((LsgNode*)self)->bbox->valid = 1;
    ((LsgNode*)self)->dirty = 1;
#endif
}

#include <GL/glut.h>
#define M_PI 3.14159265358979323846
#define SQR(a) ((a) * (a))
void fish_display(Fish* self, LsgFrustum* frust) {
    float fsin, fcos;
    float alpha, beta;
    
    fsin = self->super.speed[0];
    fcos = self->super.speed[2];
    
    alpha = atan(fsin / fcos);
    if (fcos < 0.0) alpha += M_PI;
    
    fcos = sqrt(fsin * fsin + fcos * fcos);
    fsin = self->super.speed[1];
    
    beta = atan(fsin / fcos);
    
    glPushMatrix();
    glTranslatef(self->super.location[0], self->super.location[1], self->super.location[2]);
    glRotatef(alpha * 180.0 / M_PI, 0.0, 1.0, 0.0);
    glRotatef(beta * 180.0 / M_PI, -1.0, 0.0, 0.0);
    
    glPushAttrib(GL_LIGHTING_BIT);
    glMaterialfv(GL_FRONT, GL_AMBIENT, fish_mat_ambi);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, fish_mat_diff);
    glMaterialfv(GL_FRONT, GL_SPECULAR, fish_mat_spec);
    self->model->frame = (self->model->frame + 1)%19;        
    self->model->super.display((LsgNode*) self->model, frust);
    glPopAttrib();
    
    glPopMatrix();
}
