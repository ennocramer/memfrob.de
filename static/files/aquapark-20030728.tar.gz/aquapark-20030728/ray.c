/*********************************************
**********************************************  
**                                          **
**  project     aquapark                    **
**              Computergrafik      ss2003  **
**              FH-Wedel                    **
**                                          **
**  authors     enno cramer         ii5476  **
**              martin salzburg     mi4402  **
**                                          **
**********************************************
*********************************************/

/**
 * class ray
 * generates light ray
 */

#include "ray.h"

#include "global.h"
#include "util.h"

#include <lescegra/util/random.h>
#include <lescegra/coll/bbox.h>

#include "global.h"

#include <GL/gl.h>

#include <stdlib.h>
#include <math.h>

/**
 * create new instance of ray
 * 
 * @return                  new ray instance
 * @param   camera          camera position       
 * @param   direction       light ray direction
 * @param   time            timestamp   
 */
Ray* ray_create(LsgObserverCam* camera, Vertex direction, float time) {
    Ray* self = (Ray*)malloc(sizeof(Ray));
    
    ray_init(self, camera, direction, time);
    
    return self;
}

static void ray_randomize(Ray* self);

/**
 * constructor of ray
 *
 * @param   self            object reference
 * @param   direction       light ray direction
 * @param   time            timestamp
 */
void ray_init(Ray* self, LsgObserverCam* camera, Vertex direction, float time) {
    LsgNode_init(&self->super);
    
    ((LsgNode*)self)->update  = (void (*)(LsgNode*, float))ray_update;
    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))ray_display;
    
    ((LsgNode*)self)->bvolume = (LsgBVolume*)LsgBBox_create();
    
    self->camera  = camera;
    vertex_copy(self->direction, direction);
    vertex_scale(self->direction, -(global_world_size[1] + camera->dmax + SKY_OFFSET) / direction[1]);
    self->birth = time - random_max(RAY_LIFETIME);
    self->time = time;
    
    ray_randomize(self);
}

/**
 * manage / watch lifecycle of ray
 *
 * @param   self            object reference
 * @param   now             timestamp
 */
void ray_update(Ray* self, float now) {
    self->time = now;
    if ((now - self->birth) > RAY_LIFETIME) {
        self->birth += ceil((now - self->birth) / RAY_LIFETIME) * RAY_LIFETIME;
        ray_randomize(self);
    }
}

/**
 * draw ray 
 *
 * @param   self            object reference
 * @param   frust           view frustum 
 */
void ray_display(Ray* self, LsgFrustum* frust) {
    Vertex up, side, v;
    int i;
    float f, a, max_alpha;
    
    vertex_assign(up, 0.0, -1.0, 0.0);
    vertex_copy(side, self->location);
    util_distance(side, self->camera->location);
    vertex_cross(side, up);
    vertex_normalize(side);
    vertex_scale(side, RAY_WIDTH);
    
    glPushAttrib(GL_ENABLE_BIT);
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_LIGHTING);
    
    glDepthMask(GL_FALSE);
    
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    
    max_alpha = (self->time - self->birth) / RAY_LIFETIME - 0.5 * RAY_LIFETIME;
    max_alpha = 1.0 - 4.0 * max_alpha * max_alpha;
    max_alpha *= RAY_MAX_ALPHA;
    
    glBegin(GL_TRIANGLE_STRIP);
    for (i = 0; i <= RAY_RESOLUTION; ++i) {
        f = (float)i / (float)RAY_RESOLUTION;
        
        a = f - 0.5;
        a = 1.0 - 4.0 * a * a;
        a *= max_alpha;
        
        glColor4f(1.0, 1.0, 1.0, a);
        
        vertex_copy(v, side);
        vertex_scale(v, -f);
        vertex_add(v, self->location);
    
        glVertex3fv(v);

        vertex_add(v, self->direction);
    
        glVertex3fv(v);
    }
    glEnd();
    
    glDepthMask(GL_TRUE);
    
    glPopAttrib();
}

/**
 * generate new ray position
 *
 * @param   self            object reference
 */
static void ray_randomize(Ray* self) {
    Vertex v;
    
    vertex_assign(self->location, random_max(global_world_size[0]), global_world_size[1] + self->camera->dmax + SKY_OFFSET, random_max(global_world_size[2]));
    
    self->super.bvolume->reset(self->super.bvolume);
    
    vertex_copy(v, self->location);
    v[0] += RAY_WIDTH;
/*    v[1] += RAY_WIDTH; */
    v[2] += RAY_WIDTH;
    self->super.bvolume->include(self->super.bvolume, v);
    
    vertex_copy(v, self->location);
    v[0] -= RAY_WIDTH;
/*    v[1] -= RAY_WIDTH; */
    v[2] -= RAY_WIDTH;
    self->super.bvolume->include(self->super.bvolume, v);
    
    vertex_copy(v, self->location);
    vertex_add(v, self->direction);
    v[0] += RAY_WIDTH;
/*    v[1] += RAY_WIDTH; */
    v[2] += RAY_WIDTH;
    self->super.bvolume->include(self->super.bvolume, v);
    
    vertex_copy(v, self->location);
    vertex_add(v, self->direction);
    v[0] -= RAY_WIDTH;
/*    v[1] -= RAY_WIDTH; */
    v[2] -= RAY_WIDTH;
    self->super.bvolume->include(self->super.bvolume, v);
}
