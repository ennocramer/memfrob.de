/*********************************************
**********************************************  
**                                          **
**  project     aquapark                    **
**              Computergrafik      ss2003  **
**              FH-Wedel                    **
**                                          **
**  authors     enno cramer         ii5476  **
**              martin salzburg     mi4402  **
**                                          **
**********************************************
*********************************************/

#include "util.h"

#include "global.h"

/**
 * keeps the position within worldsize 
 *
 * @param   position            object position            
 */
void util_range_vertex(Vertex position) {
    int i;

    /* i += 2 --> do not wrap y */
    for (i = 0; i < 3; i += 2) {
        while (position[i] >= global_world_size[i]) {
            position[i] -= global_world_size[i];
        }
        while (position[i] < 0.0) {
            position[i] += global_world_size[i];
        }
    }
}

/**
 * get the shortest way from a to b within the tiled 2x2 worldsize 
 *
 * @param   a                   position a           
 * @param   b                   position b
 */
void util_distance(Vertex a, Vertex b) {
    int i;
    
    vertex_sub(a, b);
    
    /* i += 2 --> do not wrap y */
    for (i = 0; i < 3; i += 2) {
        if (a[i] > (0.5 * global_world_size[i])) {
            a[i] = a[i] - global_world_size[i];
        } else if (a[i] < (-0.5 * global_world_size[i])) {
            a[i] = a[i] + global_world_size[i];
        }
    }
}
