/*********************************************
**********************************************  
**                                          **
**  project     aquapark                    **
**              Computergrafik      ss2003  **
**              FH-Wedel                    **
**                                          **
**  authors     enno cramer         ii5476  **
**              martin salzburg     mi4402  **
**                                          **
**********************************************
*********************************************/

#ifndef CAUSTICS_H
#define CAUSTICS_H 1

/**
 * class caustics
 * draws an animated luminance texture on all subnodes
 */
 
#include <lescegra/sg/group.h>

typedef struct {
    LsgGroup super;
    float map_s[4];
    float map_t[4];
    unsigned int textures[32];
    int current;
    float time_scale;
} Caustics;

/**
 * create new instance of caustics
 * 
 * @return                  new caustics instance
 * @param   template        texture files for caustics animation       
 * @param   count           animation frame number
 */
Caustics* caustics_create(const char* template, int count);

/**
 * constructor of caustics
 *
 * @param   self            object reference
 * @param   template        texture files for caustics animation 
 * @param   count           animation frame number
 */
void caustics_init(Caustics* self, const char* template, int count);

/**
 * animate luminance texture
 *
 * @param   self            object reference
 * @param   now             timestamp
 */
void caustics_update(Caustics* self, float now);

/**
 * bind current luminace texture to second texture engine and draw subnodes
 *
 * @param   self            object reference
 * @param   frust           view frustum
 */
void caustics_display(Caustics* self, LsgFrustum* frust);

#define caustics_clean(self)   LsgGroup_clean(&(self)->super)
#define caustics_destroy(self) LsgGroup_destroy(&(self)->super)

#endif
