/*********************************************
**********************************************  
**                                          **
**  project     aquapark                    **
**              Computergrafik      ss2003  **
**              FH-Wedel                    **
**                                          **
**  authors     enno cramer         ii5476  **
**              martin salzburg     mi4402  **
**                                          **
**********************************************
*********************************************/

#include "hud.h"

#include "mdmap.h"
#include "global.h"

#include <lescegra.h>

#include <GL/glu.h>

#include <stdlib.h>

LsgOrthoCam* hud_cam;
LsgNode* hud;

#define MAP_RESOLUTION 64
static Vertex map_size = {0.3, 0.2, 0.3};
static Vertex map_location = {0.7, -0.7, -0.7};

/**
 *  inits hud
 */
void init_hud(void) {
    LsgGroup* hudgrp;
    
    LsgLight* light;
    
    MDMap* map;
    LsgTransform* map_tfm;
    LsgImage* img;
    LsgImage* img2;
    
    /* create overlay camera */
    hud_cam = LsgOrthoCam_create();
    
    /* create overlay root node */
    hudgrp = LsgGroup_create();
    
    /* create light */
    light = LsgLight_create(GL_LIGHT0);
    vertex_assign(light->location, 0.0, 1.0, -1.0);
    light->location[3] = 0.0;
    vertex_assign(light->color, 1.0, 1.0, 1.0);
    light->color[3] = 1.0;
    LsgLight_enable(light);
    
    /* create map node */
    img2 = LsgImage_loadPCX(TERRAIN_FILE_NAME);
    img  = LsgImage_create(MAP_RESOLUTION, MAP_RESOLUTION, img2->bpp);
    gluScaleImage(GL_RGB, img2->width, img2->height, GL_UNSIGNED_BYTE, img2->data,
            img->width, img->height, GL_UNSIGNED_BYTE, img->data);
    free(img2);
    map = mdmap_create(ego_cam, global_world_size, img, map_size);
    free(img);
    
    map_tfm = LsgTransform_create();
    {
        Matrix m;
        matrix_load_translatev(map_tfm->tm, map_location);
        matrix_load_rotate(m, 0.25 * M_PI, 0.25 * M_PI, 0.0);
        matrix_mult(map_tfm->tm, m);
    }
    map_tfm->super.children->append(map_tfm->super.children, map);
    
    hudgrp->children->append(hudgrp->children, light);
    hudgrp->children->append(hudgrp->children, map_tfm);
    
    hud = (LsgNode*)hudgrp;
}
