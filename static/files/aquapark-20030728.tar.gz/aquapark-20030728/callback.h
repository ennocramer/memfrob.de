/*********************************************
**********************************************  
**                                          **
**  project     aquapark                    **
**              Computergrafik      ss2003  **
**              FH-Wedel                    **
**                                          **
**  authors     enno cramer         ii5476  **
**              martin salzburg     mi4402  **
**                                          **
**********************************************
*********************************************/

#ifndef CALLBACK_H
#define CALLBACK_H 1

/**
 * inits all callback functions
 */
void init_callback(void);

#endif
