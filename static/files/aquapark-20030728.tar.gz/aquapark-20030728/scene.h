/*********************************************
**********************************************  
**                                          **
**  project     aquapark                    **
**              Computergrafik      ss2003  **
**              FH-Wedel                    **
**                                          **
**  authors     enno cramer         ii5476  **
**              martin salzburg     mi4402  **
**                                          **
**********************************************
*********************************************/

#ifndef SCENE_H
#define SCENE_H

#include <lescegra/sg/camera.h>
#include "caustics.h"
#include "worldtiler.h"

extern LsgObserverCam* ego_cam;
extern LsgNode* scene;
extern LsgNode* terrain;

/**
 * inits scene
 */
void init_scene(void);

#endif
