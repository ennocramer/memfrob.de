/*********************************************
**********************************************  
**                                          **
**  project     aquapark                    **
**              Computergrafik      ss2003  **
**              FH-Wedel                    **
**                                          **
**  authors     enno cramer         ii5476  **
**              martin salzburg     mi4402  **
**                                          **
**********************************************
*********************************************/

#include "scene.h"

#include <lescegra.h>

#include "caustics.h"
#include "ray.h"
#include "fish.h"
#include "global.h"

#include <GL/gl.h>

#include <stdlib.h>
#include <stdio.h>

Vertex global_world_size  = {1000.0, 200.0, 1000.0};
Vertex global_sun         = {30.0, 200.0, 20.0};
Vertex global_water_color = {0.3, 0.7, 0.8};

LsgList*  global_objects_static = NULL;
LsgList*  global_objects_dynamic = NULL;

LsgNode*  global_terrain;
LsgObserverCam* ego_cam;

LsgNode* scene;
LsgNode* terrain;

Vertex obj_location = {0.0, 0.0, 0.0};
Vertex obj_rotation = {0.0, 0.0, 0.0};
LsgTransform* obj_transform = NULL;
LsgMD2Model*  obj_model     = NULL;

static float land_map_s[4] = {0.1, 0.0, 0.0, 1.0};
static float land_map_t[4] = {0.0, 0.0, 0.1, 1.0};
static float caust_map_s[4] = {0.04, 0.0, 0.0, 1.0};
static float caust_map_t[4] = {0.0, 0.0, 0.04, 1.0};

static void init_scene_drop_barrels(LsgGroup* parent) {
    LsgMD2Model* model;
    LsgImage* img;
    
    LsgList* hits;
    LsgIterator* it;
    LsgHit* hit;
    Vertex ray_from, ray_dir;
    
    int i;
    
    vertex_assign(ray_dir, 0.0, -1.0, 0.0);
    
    hits = (LsgList*)LsgArrayList_create();
    
    /* f�sser */
    model = LsgMD2Model_create("models/fassAtom.md2");
    img = LsgImage_loadPCX("textures/fassAtom.pcx");
    model->skins = (unsigned int*)malloc(sizeof(unsigned int));
    glGenTextures(1, &model->skins[0]);
    glBindTexture(GL_TEXTURE_2D, model->skins[0]);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, img->width, img->height, 0, GL_RGB, GL_UNSIGNED_BYTE, img->data);
    model->skin = 0;
    model->skin_count = 1;
    free(img);
    
    for (i = 0; i < 50; ++i) {
        LsgTransform* tfm;
        
        vertex_assign(ray_from, random(), 1.0, random());
        vertex_mul(ray_from, global_world_size); 
        terrain->bvolume->collideRay(terrain->bvolume, ray_from, ray_dir, hits);
        
        if (hits->count(hits) < 1) {
            fprintf(stderr, "argh\n");
            abort();
        }
        
        hit = (LsgHit*)hits->get(hits, 0);
        
        tfm = LsgTransform_create();
        matrix_load_translatev(tfm->tm, hit->intersection);
        tfm->super.children->append(tfm->super.children, model);
        parent->children->append(parent->children, tfm);
        
        it = hits->iterator(hits);
        while (it->hasNext(it)) {
            LsgObject_free((LsgObject*)it->next(it));
        }
        LsgObject_free((LsgObject*)it);
        hits->clear(hits);
        
        global_objects_static->append(global_objects_static, tfm);
    }

    model = LsgMD2Model_create("models/fassExplosiv.md2");
    img = LsgImage_loadPCX("textures/fassExplosiv.pcx");
    model->skins = (unsigned int*)malloc(sizeof(unsigned int));
    glGenTextures(1, &model->skins[0]);
    glBindTexture(GL_TEXTURE_2D, model->skins[0]);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, img->width, img->height, 0, GL_RGB, GL_UNSIGNED_BYTE, img->data);
    model->skin = 0;
    model->skin_count = 1;
    free(img);
    
    for (i = 0; i < 50; ++i) {
        LsgTransform* tfm;
        
        vertex_assign(ray_from, random(), 1.0, random());
        vertex_mul(ray_from, global_world_size); 
        terrain->bvolume->collideRay(terrain->bvolume, ray_from, ray_dir, hits);
        
        if (hits->count(hits) < 1) {
            fprintf(stderr, "argh\n");
            abort();
        }
        
        hit = (LsgHit*)hits->get(hits, 0);
        
        tfm = LsgTransform_create();
        matrix_load_translatev(tfm->tm, hit->intersection);
        tfm->super.children->append(tfm->super.children, model);
        parent->children->append(parent->children, tfm);
        
        it = hits->iterator(hits);
        while (it->hasNext(it)) {
            LsgObject_free((LsgObject*)it->next(it));
        }
        LsgObject_free((LsgObject*)it);
        hits->clear(hits);
        
        global_objects_static->append(global_objects_static, tfm);
    }
    
    LsgObject_free((LsgObject*)hits);
}

/**
 * inits scene
 */
void init_scene(void) {
    LsgFog* fog;
    
    WorldTiler* tiler;
    WorldTiler* ray_tiler;
    
    LsgLight* sun;
    
    Caustics* caustics;
    LsgImage* img;
    LsgTexture* terrain_tex;
    LsgImage* landscape_data;
    LsgGLList* helper;
    
    int i;
    Fish* fish;
    
    LsgNode* skybox;
    
    /* create the ego_cam */
    ego_cam = LsgObserverCam_create();
    vertex_assign(ego_cam->location, 500.0, 100.0, 500.0);
    vertex_assign(ego_cam->heading,  0.0, 0.0, 1.0);
    vertex_assign(ego_cam->up,       0.0, 1.0, 0.0);
    ego_cam->dmin   =   1.0;
    ego_cam->dmax   = 100.0;
    ego_cam->fovy   =  45.0;
    ego_cam->aspect =   1.0;
    
    /* build the scene graph
     * fog --> tiler --> sun      
     *     |         |-> caustics --> terrain_tex --> terrain
     *     |         \-> lots o' fishies
     *     \-> ray_tiler --> lots o' rays
     */
    
    /* fog */    
    fog = LsgFog_create(FOG_LINEAR);
    vertex_copy(fog->color, global_water_color);
    fog->start =   5.0;
    fog->end   = 100.0;

    /* world tiler */
    tiler     = worldtiler_create(global_world_size, ego_cam);
    ray_tiler = worldtiler_create(global_world_size, ego_cam);
    fog->super.children->append(fog->super.children, tiler);
    fog->super.children->append(fog->super.children, ray_tiler);
    
    /* sun */
    sun = LsgLight_create(GL_LIGHT0);
    vertex_copy(sun->location, global_sun);
    sun->location[3] = 0.0;
    vertex_assign(sun->color, 1.0, 0.9, 0.9);
    sun->color[3] = 1.0;
    LsgLight_enable(sun);
    tiler->super.children->append(tiler->super.children, sun);

    /* caustics texture */
    caustics = caustics_create("textures/caust%02i.pcx", 32);
    for (i = 0; i < 4; ++i) {
        caustics->map_s[i] = caust_map_s[i];
        caustics->map_t[i] = caust_map_t[i];
    }
    tiler->super.children->append(tiler->super.children, caustics);
    
    helper = LsgGLList_create();
    glNewList(helper->list, GL_COMPILE);
    glEnable(GL_TEXTURE_GEN_S);
    glEnable(GL_TEXTURE_GEN_T);
    glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
    glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
    glTexGenfv(GL_S, GL_OBJECT_PLANE, land_map_s);
    glTexGenfv(GL_T, GL_OBJECT_PLANE, land_map_t);
    glEndList();
    caustics->super.children->append(caustics->super.children, helper);
    
    /* terrain texture */    
    img = LsgImage_loadPCX("textures/sand.pcx");
    terrain_tex = LsgTexture_create(img, GL_RGB, GL_MODULATE, 0);
    free(img);
    caustics->super.children->append(caustics->super.children, terrain_tex);

    helper = LsgGLList_create();
    glNewList(helper->list, GL_COMPILE);
    glDisable(GL_TEXTURE_GEN_T);
    glDisable(GL_TEXTURE_GEN_S);
    glEndList();
    caustics->super.children->append(caustics->super.children, helper);
    
    /* terrain
     * chunk size 4 --> 4 x 4 vertices, 32 triangles per chunk
     * divisions 6  --> 4 x 4 chunks per octree leaf (1024 x 1024 pixel bitmap)
     * practical values (reasonable cpu burden for display, limited memory consumption) */
    landscape_data = LsgImage_loadPCX(TERRAIN_FILE_NAME);
    terrain = (LsgNode*)LsgHTerrain_create(landscape_data, 7, global_world_size, 2);
    free(landscape_data);
    terrain_tex->super.children->append(terrain_tex->super.children, terrain);

    /* assign global scene variable */
    scene = (LsgNode*)fog;

    /* ray effects */    
    {
        Vertex dir;
        
        vertex_copy(dir, global_sun);
        vertex_scale(dir, -1.0);
        
        for (i = 0; i < 500; ++i) {
            Ray* r = ray_create(ego_cam, dir, 0.0);
            ray_tiler->super.children->append(ray_tiler->super.children, r);
        }
    }
    
    /* shuffle static objects into global list */
    global_objects_static = (LsgList*)LsgLinkedList_create();
    global_objects_dynamic = (LsgList*)LsgLinkedList_create();
    
    global_objects_static->append(global_objects_static, terrain);

#if 0
    /* fish */
    model = LsgMD2Model_create("models/fish.md2");
    img = LsgImage_loadPCX("textures/fish.pcx");
    model->skins = (unsigned int*)malloc(sizeof(unsigned int));
    glGenTextures(1, &model->skins[0]);
    glBindTexture(GL_TEXTURE_2D, model->skins[0]);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, img->width, img->height, 0, GL_RGB, GL_UNSIGNED_BYTE, img->data);
    model->skin = 0;
    model->skin_count = 1;
    free(img);
    
    for (i = 0; i < 100; ++i) { 
        vertex_assign(loc, random(), 0.5, random());
        vertex_mul(loc, global_world_size); 
        vertex_assign(speed, 0.0, 0.0, 0.0);
        fish = fish_create(model, loc, speed, 0.0);
        caustics->super.children->append(caustics->super.children, fish);
        global_objects_dynamic->append(global_objects_dynamic, fish);
    }
#endif
    
    init_scene_drop_barrels((LsgGroup*)caustics);
    
    /* assign global terrain */
    global_terrain = terrain;
    
    /* keep all beings in the world */
    skybox = (LsgNode*)malloc(sizeof(LsgNode));
    LsgNode_init(skybox);
/*    vertex_assign(skybox->bbox->min, 0.0, global_world_size[1] + SKY_OFFSET, 0.0);
    vertex_assign(skybox->bbox->max, global_world_size[0], global_world_size[1] + SKY_OFFSET + 1.0, global_world_size[2]);
    skybox->bbox->valid = 1;
    global_objects_static->append(global_objects_static, skybox);*/
}
