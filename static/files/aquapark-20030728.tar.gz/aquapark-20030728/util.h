/*********************************************
**********************************************  
**                                          **
**  project     aquapark                    **
**              Computergrafik      ss2003  **
**              FH-Wedel                    **
**                                          **
**  authors     enno cramer         ii5476  **
**              martin salzburg     mi4402  **
**                                          **
**********************************************
*********************************************/

#ifndef UTIL_H
#define UTIL_H 1

#include <lescegra/util/vertex.h>

/**
 * keeps the position within worldsize 
 *
 * @param   position            object position            
 */
void util_range_vertex(Vertex position);

/**
 * get the shortest way from a to b within the tiled 2x2 worldsize 
 *
 * @param   a                   position a           
 * @param   b                   position b
 */
void util_distance(Vertex a, Vertex b);

#endif
