/*********************************************
**********************************************  
**                                          **
**  project     aquapark                    **
**              Computergrafik      ss2003  **
**              FH-Wedel                    **
**                                          **
**  authors     enno cramer         ii5476  **
**              martin salzburg     mi4402  **
**                                          **
**********************************************
*********************************************/

#ifndef WORLDTILER_H
#define WORLDTILER_H 1

/** class worldtiler
 *  tiles a world 2x2 times.
 */

#include <lescegra/sg/group.h>

#include <lescegra/sg/observercam.h>

typedef struct {
    LsgGroup super;
    Vertex dimension;
    LsgObserverCam* eye;
} WorldTiler;

/** 
 * create a new instance of worldtiler
 *
 * @return                  new worldtiler instance
 * @param   dimension       world dimension 
 * @param   eye             eye of the beholder
 */
WorldTiler* worldtiler_create(Vertex dimension, LsgObserverCam* eye);

/**
 * constructor of worldtiler
 *
 * @param   self            object reference
 * @param   dimension       world dimension
 * @param   eye             eye of the beholder
 */
void worldtiler_init(WorldTiler* self, Vertex dimension, LsgObserverCam* eye);

/**
 * display all subnodes 4 times according to location of eye
 *
 * @param   self            object reference
 * @param   frust           view frustum 
 */
void worldtiler_display(WorldTiler* self, LsgFrustum* frust);

/** 
 * reused parent implementation
 */
#define worldtiler_clean(self)       LsgGroup_clean(&(self)->super)
#define worldtiler_update(self, now) LsgGroup_update(&(self)->super, now)

#endif
