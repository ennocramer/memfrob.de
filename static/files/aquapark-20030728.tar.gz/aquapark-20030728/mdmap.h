#ifndef MDMAP_H
#define MDMAP_H 1

#include <lescegra/sg/node.h>

#include <lescegra/sg/observercam.h>
#include <lescegra/geom/terrain.h>

typedef struct {
    LsgNode super;
    LsgObserverCam* observer;
    Vertex world;
    LsgTerrain* map;
    Vertex dimension;
} MDMap;

MDMap* mdmap_create(LsgObserverCam* observer, Vertex world, LsgImage* hf, Vertex dimension);
void mdmap_init(MDMap* self, LsgObserverCam* observer, Vertex world, LsgImage* hf, Vertex dimension);
void mdmap_display(MDMap* self, LsgFrustum* frustum);
void mdmap_destroy(MDMap* self);

#define mdmap_clean(self)         LsgNode_clean(&(self)->super)
#define mdmap_update(self, now)   LsgNode_update(&(self)->super, now)
#define mdmap_collide(self, v, n) LsgNode_collide(&(self)->super, v, n)

#endif
