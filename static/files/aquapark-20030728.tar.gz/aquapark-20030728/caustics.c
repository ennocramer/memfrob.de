/*********************************************
**********************************************  
**                                          **
**  project     aquapark                    **
**              Computergrafik      ss2003  **
**              FH-Wedel                    **
**                                          **
**  authors     enno cramer         ii5476  **
**              martin salzburg     mi4402  **
**                                          **
**********************************************
*********************************************/

/**
 * class caustics
 * draws an animated luminance texture on all subnodes
 */

#include "caustics.h"

#include <lescegra/util/image.h>

#include <GL/gl.h>

#include <stdlib.h>
#include <stdio.h>

/**
 * create new instance of caustics
 * 
 * @return                  new caustics instance
 * @param   template        texture files for caustics animation       
 * @param   count           animation frame number
 */
Caustics* caustics_create(const char* template, int count) {
    Caustics* self = (Caustics*)malloc(sizeof(Caustics));
    
    caustics_init(self, template, count);
    
    return self;
}

/**
 * constructor of caustics
 *
 * @param   self            object reference
 * @param   template        texture files for caustics animation 
 * @param   count           animation frame number
 */
void caustics_init(Caustics* self, const char* template, int count) {
    LsgImage* img;
    char file[256];
    int i;
    
    LsgGroup_init(&self->super);
    
    ((LsgNode*)self)->update  = (void (*)(LsgNode*, float))caustics_update;
    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))caustics_display;
    
    self->map_s[0] = 1.0;
    self->map_s[1] = 0.0;
    self->map_s[2] = 0.0;
    self->map_s[3] = 1.0;
    self->map_t[0] = 0.0;
    self->map_t[1] = 0.0;
    self->map_t[2] = 1.0;
    self->map_t[3] = 1.0;
    self->current = 0;
    self->time_scale = 16.0;
    
    glGenTextures(count, self->textures);
    for (i = 0; i < count; ++i) {
        sprintf(file, template, i);
        img = LsgImage_loadPCX(file);
        glBindTexture(GL_TEXTURE_2D, self->textures[i]);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, img->width, img->height, 0, GL_RGB, GL_UNSIGNED_BYTE, img->data);
        free(img);
    }
}

/**
 * animate luminance texture
 *
 * @param   self            object reference
 * @param   now             timestamp
 */
void caustics_update(Caustics* self, float now) {
    self->current = (int)(now * self->time_scale) % 32;
    
    LsgGroup_update(&self->super, now);
}

/**
 * bind current luminace texture to second texture engine and draw subnodes
 *
 * @param   self            object reference
 * @param   frust           view frustum
 */
void caustics_display(Caustics* self, LsgFrustum* frust) {
    if (self->current != -1) {
        glActiveTextureARB(GL_TEXTURE1_ARB);
        
        glPushAttrib(GL_TEXTURE_BIT);
        
        glBindTexture(GL_TEXTURE_2D, self->textures[self->current]);
        glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
        glEnable(GL_TEXTURE_2D);

        glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
        glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
        glTexGenfv(GL_S, GL_OBJECT_PLANE, self->map_s);
        glTexGenfv(GL_T, GL_OBJECT_PLANE, self->map_t);
        
        glEnable(GL_TEXTURE_GEN_S);
        glEnable(GL_TEXTURE_GEN_T);
        
        glActiveTextureARB(GL_TEXTURE0_ARB);
        LsgGroup_display(&self->super, frust);
        glActiveTextureARB(GL_TEXTURE1_ARB);
                
        glPopAttrib();
        
        glActiveTextureARB(GL_TEXTURE0_ARB);
    } else {
        LsgGroup_display(&self->super, frust);
    }
}
