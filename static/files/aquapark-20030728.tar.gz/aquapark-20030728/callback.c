/*********************************************
**********************************************  
**                                          **
**  project     aquapark                    **
**              Computergrafik      ss2003  **
**              FH-Wedel                    **
**                                          **
**  authors     enno cramer         ii5476  **
**              martin salzburg     mi4402  **
**                                          **
**********************************************
*********************************************/

#include "callback.h"

#include "scene.h"
#include "global.h"
#include "util.h"

#include <lescegra/util/arraylist.h>

#include <GL/glut.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

static int mouse_button = -1;
static int mouse_x = 0;
static int mouse_y = 0;

static int viewport[4] = {0, 0, 0, 0};

static int wireframe = 0;
static int octree = 0;

static float color_ambi[4] = {0.3, 0.3, 0.3, 1.0};
static float color_diff[4] = {0.7, 0.7, 0.7, 0.5};
static float color_spec[4] = {0.0, 0.0, 0.0, 0.5};
static float color_shine   = 50;

static float light_ambi[4] = {1.0, 1.0, 1.0, 1.0};

/**
 * display scene
 */
void display(void) {
    LsgFrustum frustum;
    int error;

    glMaterialfv(GL_FRONT, GL_AMBIENT, color_ambi);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, color_diff);
    glMaterialfv(GL_FRONT, GL_SPECULAR, color_spec);
    glMaterialfv(GL_FRONT, GL_SHININESS, &color_shine);
    
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, light_ambi);
    
    /* reset viewing matrizes */
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    /* create identity frustum */
    LsgFrustum_init(&frustum, matrix_identity, matrix_identity);

    /* display scene */    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    ego_cam->super.display((LsgCamera*)ego_cam, &frustum, scene);

    /* display HUD */
    glClear(GL_DEPTH_BUFFER_BIT);    
    hud_cam->super.display((LsgCamera*)hud_cam, &frustum, hud);
    
    /* force rendering of cached geometry */
    glFlush();
    glutSwapBuffers();
    
    if ((error = glGetError()) != GL_NO_ERROR) {
        printf("%s\n", gluErrorString(error));
    }
}

/**
 * sets viewport to windowsize
 *
 * @param   w                   window width
 * @param   h                   window height
 */
void reshape(int w, int h) {
    float aspect = (float)w / (float)h;

    ego_cam->aspect = aspect;
    
    viewport[2] = w;
    viewport[3] = h;
    glViewport(0, 0, w, h);
    
#if GLUT_GAME_MODE == 1
    mouse_x = viewport[2] / 2;
    mouse_y = viewport[3] / 2;
    glutWarpPointer(mouse_x, mouse_y);
#endif
}

/**
 * handles animation and scene update
 *
 * @param   time                animation time
 */
void animate(int time) {
    LsgList* hits = NULL;
    LsgHit* hit = NULL;
    LsgIterator* it;
    Vertex move;
    
    float now = (float)glutGet(GLUT_ELAPSED_TIME) / 1000.0;
    
    if (mouse_button == GLUT_MIDDLE_BUTTON) {
        vertex_copy(move, ego_cam->heading);
        vertex_scale(move, 20.0 * 1.0 / 25.0);
        vertex_add(ego_cam->location, move);
        util_range_vertex(ego_cam->location);
        
        vertex_assign(move, 0.0, 0.0, 0.0);
        
        hits = (LsgList*)LsgArrayList_create();
        
        it = global_objects_static->iterator(global_objects_static);
        while (it->hasNext(it)) {
            LsgNode* node = (LsgNode*)it->next(it);
            
            node->bvolume->collideSphere(node->bvolume, ego_cam->location, CAMERA_COLLIDE_DISTANCE, hits);

        }
        LsgObject_free((LsgObject*)it);

        if (hits->count(hits)) {
            it = hits->iterator(hits);
            while (it->hasNext(it)) {
                hit = (LsgHit*)it->next(it);

                vertex_sub(hit->intersection, ego_cam->location);
                vertex_scale(hit->normal, CAMERA_COLLIDE_DISTANCE - vertex_length(hit->intersection));
                vertex_add(move, hit->normal);

                LsgObject_free((LsgObject*)hit);
            }
            LsgObject_free((LsgObject*)it);

            vertex_scale(move, 1.0 / (float)hits->count(hits));
            vertex_add(ego_cam->location, move);
            util_range_vertex(ego_cam->location);
        }
        
        LsgObject_free((LsgObject*)hits);
    }
    
    scene->update(scene, now);
    scene->clean(scene);
    
    glutTimerFunc(1000 / 25, animate, time + 1000 / 25);
    glutPostRedisplay();
}

#define vertex_dump(n, v) printf("%s: (%.2f, %.2f, %.2f)\n", n, v[0], v[1], v[2])

/**
 * tracks mouse dragging
 *
 * @param   x                   cursor position x
 * @param   y                   cursor position y
 */
void mouse_drag(int x, int y) {
    int dx = x - mouse_x;
    int dy = y - mouse_y;
    
    Vertex axes[3];
    Vertex view;
    float alpha, beta;

    if (!dx && !dy) return;
    
#if GLUT_GAME_MODE != 1    
    if ((mouse_button == GLUT_RIGHT_BUTTON)
     || (mouse_button == GLUT_MIDDLE_BUTTON)) {
#endif
        vertex_copy(view, ego_cam->heading);
        vertex_normalize(view);
        
        vertex_copy(axes[2], view);
        
        vertex_copy(axes[1], ego_cam->up);
        vertex_normalize(axes[1]);
        
        vertex_copy(axes[0], axes[1]);
        vertex_cross(axes[0], axes[2]);
        vertex_normalize(axes[0]);
        
        vertex_copy(axes[2], axes[0]);
        vertex_cross(axes[2], axes[1]);
        
        alpha = acos(vertex_dot(axes[1], view));
        alpha += (float)dy * MOUSE_SENSITIVITY;
        alpha = MAX(MIN(alpha, 0.99 * M_PI), 0.01 * M_PI);
        
        beta = (float)dx * MOUSE_SENSITIVITY;
        
        vertex_scale(axes[0], -sin(beta) * sin(alpha));
        vertex_scale(axes[1], cos(alpha));
        vertex_scale(axes[2], cos(beta) * sin(alpha));
        
        vertex_assign(ego_cam->heading, 0.0, 0.0, 0.0);
        vertex_add(ego_cam->heading, axes[0]);
        vertex_add(ego_cam->heading, axes[1]);
        vertex_add(ego_cam->heading, axes[2]);
#if GLUT_GAME_MODE != 1    
    }
#endif

#if GLUT_GAME_MODE == 1
    mouse_x = viewport[2] / 2;
    mouse_y = viewport[3] / 2;
    glutWarpPointer(mouse_x, mouse_y);
#else
    mouse_x = x;
    mouse_y = y;
#endif
}

/**
 * tracks mouse input
 * 
 * @param   button              activated mouse button 
 * @param   state               state of activated button
 * @param   x                   cursor position x
 * @param   y                   cursor position y
 */
void mouse_down(int button, int state, int x, int y) {
    mouse_x = x;
    mouse_y = y;
    mouse_button = state == GLUT_DOWN ? button : -1;
    
    /* picking */
    if ((state == GLUT_DOWN) && (button == GLUT_LEFT_BUTTON)) {
        LsgFrustum frustum;
        Matrix m;
        unsigned int buffer[512];
        
        unsigned int* ptr;
        int hits, names;
        int hit, name;
        
        glSelectBuffer(512, buffer);
        glRenderMode(GL_SELECT);
        
        /* initialize transformation matrices */
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPickMatrix(mouse_x, viewport[3] - mouse_y, 5, 5, viewport);
        
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        
        /* initialize viewing frustum */
        matrix_load_pick(m, mouse_x, viewport[3] - mouse_y, 5, 5,
                viewport[0], viewport[1], viewport[2], viewport[3]);
        LsgFrustum_init(&frustum, m, matrix_identity);
        
        /* render to selection buffer */
        ego_cam->super.display((LsgCamera*)ego_cam, &frustum, scene);
    
        hits = glRenderMode(GL_RENDER);
        
        /* process selection buffer */
        ptr = buffer;
        printf("SELECTION RESULT: %d HITS\n", hits);
        for (hit = 0; hit < hits; ++hit) {
            printf("hit %d\n", hit);
            names = *ptr++;
            
            if (names == 0) { ptr += 2; continue; }
            printf("  z_min = %f\n", (float)*ptr++);
            printf("  z_max = %f\n", (float)*ptr++);
            
            for (name = 0; name < names; ++name) {
                printf("  name%d = %d\n", name, *ptr++);
            }
        }
    }
}

/**
 * tracks keyboard input 
 *
 * @param   key                 aktivated key
 * @param   x                   cursor position x
 * @param   y                   cursor position y
 */
void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 'w':
        case 'W':
            if (wireframe) {
                glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
            } else {
                glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
            }
            wireframe = !wireframe;
            break;
        
        case 'o':
        case 'O':
            octree = !octree;
            break;
        
        case 'c':
        case 'C':
            if (glIsEnabled(GL_CULL_FACE)) {
                glDisable(GL_CULL_FACE);
            } else {
                glEnable(GL_CULL_FACE);
            }
            break;
        
        case  27:
        case 'q':
        case 'Q':
            exit(0);
    }
}

/**
 * inits all callback functions
 */
void init_callback(void) {
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMotionFunc(mouse_drag);
#if GLUT_GAME_MODE == 1
    glutPassiveMotionFunc(mouse_drag);
#endif
    glutMouseFunc(mouse_down);

    glutTimerFunc(0, animate, 0);

    glutKeyboardFunc(keyboard);
}
