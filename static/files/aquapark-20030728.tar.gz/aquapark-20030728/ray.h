/*********************************************
**********************************************  
**                                          **
**  project     aquapark                    **
**              Computergrafik      ss2003  **
**              FH-Wedel                    **
**                                          **
**  authors     enno cramer         ii5476  **
**              martin salzburg     mi4402  **
**                                          **
**********************************************
*********************************************/

#ifndef RAY_H
#define RAY_H 1

/**
 * class ray
 * generates light ray
 */

#include <lescegra/sg/node.h>

#include <lescegra/sg/observercam.h>

typedef struct {
    LsgNode super;
    LsgObserverCam* camera;
    Vertex direction;
    Vertex location;
    float birth;
    float time;
} Ray;

/**
 * create new instance of ray
 * 
 * @return                  new ray instance
 * @param   camera          camera position       
 * @param   direction       light ray direction
 * @param   time            timestamp   
 */
Ray* ray_create(LsgObserverCam* camera, Vertex direction, float time);

/**
 * constructor of ray
 *
 * @param   self            object reference
 * @param   direction       light ray direction
 * @param   time            timestamp
 */
void ray_init(Ray* self, LsgObserverCam* camera, Vertex direction, float time);

/**
 * add lifetime and phase out
 *
 * @param   self            object reference
 * @param   now             timestamp
 */
void ray_update(Ray* self, float now);

/**
 * draw ray 
 *
 * @param   self            object reference
 * @param   frust           view frustum 
 */
void ray_display(Ray* self, LsgFrustum* frust);

/**
 * reused parent implementation
 */
#define ray_clean(self)   LsgNode_clean(&(self)->super)
#define ray_destroy(self) LsgNode_destroy(&(self)->super)

#endif
