/*********************************************
**********************************************  
**                                          **
**  project     aquapark                    **
**              Computergrafik      ss2003  **
**              FH-Wedel                    **
**                                          **
**  authors     enno cramer         ii5476  **
**              martin salzburg     mi4402  **
**                                          **
**********************************************
*********************************************/

/** class worldtiler
 *  tiles a world 2x2 times.
 */

#include "worldtiler.h"

#include <GL/gl.h>

#include <stdlib.h>

/** 
 * create a new instance of worldtiler
 *
 * @return                  new worldtiler instance
 * @param   dimension       world dimension 
 * @param   eye             eye of the beholder
 */
WorldTiler* worldtiler_create(Vertex dimension, LsgObserverCam* eye) {
    WorldTiler* self = (WorldTiler*)malloc(sizeof(WorldTiler));
    
    worldtiler_init(self, dimension, eye);
    
    return self;
}

/**
 * constructor of worldtiler
 *
 * @param   self            object reference
 * @param   dimension       world dimension
 * @param   eye             eye of the beholder
 */
void worldtiler_init(WorldTiler* self, Vertex dimension, LsgObserverCam* eye) {
    LsgGroup_init(&self->super);
    
    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))worldtiler_display;
    
    vertex_copy(self->dimension, dimension);
    self->eye = eye;
}

/**
 * display all subnodes 4 times according to location of eye
 *
 * @param   self            object reference
 * @param   frust           view frustum 
 */
void worldtiler_display(WorldTiler* self, LsgFrustum* frust) {
    LsgFrustum nfrust;
    Matrix mv, m;
    float fx, fz;
    float dx, dz;
    int i, j;
    
    if (self->eye->location[0] < self->dimension[0] / 2.0) {
        fx = -1.0;
    } else {
        fx = 1.0;
    }
    
    if (self->eye->location[2] < self->dimension[2] / 2.0) {
        fz = -1.0;
    } else {
        fz = 1.0;
    }
    
    for (i = 0; i < 2; ++i) {
        for (j = 0; j < 2; ++j) {
            dx = i * fx * self->dimension[0];
            dz = j * fz * self->dimension[2];
            
            /* build new view frustum */
            matrix_copy(mv, frust->modelview);
            matrix_load_translate(m, dx, 0.0, dz);
            matrix_mult(mv, m);
            
            LsgFrustum_init(&nfrust, frust->projection, mv);
            
            /* translate "subworld" */
            glPushMatrix();
            glTranslatef(dx, 0.0, dz);
            
            LsgGroup_display(&self->super, &nfrust);
            
            glPopMatrix();
        }
    }
    
    glPushAttrib(GL_ENABLE_BIT);
    glColor3f(1.0, 0.0, 0.0);
    glBegin(GL_LINES);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(0.0, self->dimension[1], 0.0);

        glVertex3f(self->dimension[0],                0.0,                0.0);
        glVertex3f(self->dimension[0], self->dimension[1],                0.0);

        glVertex3f(               0.0,                0.0, self->dimension[2]);
        glVertex3f(               0.0, self->dimension[1], self->dimension[2]);

        glVertex3f(self->dimension[0],                0.0, self->dimension[2]);
        glVertex3f(self->dimension[0], self->dimension[1], self->dimension[2]);
    glEnd();
    glPopAttrib();
}
