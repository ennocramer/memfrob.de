#ifndef FISH_H
#define FISH_H 1

#include <lescegra/particle/particle.h>

#include <lescegra/geom/md2model.h>

typedef struct {
    LsgParticle super;
    LsgMD2Model* model;
    float favorite_height;
} Fish;

Fish* fish_create(LsgMD2Model* model, Vertex location, Vertex speed, float time);
void fish_init(Fish* self, LsgMD2Model* model, Vertex location, Vertex speed, float time, float favorite_height);
void fish_update(Fish* self, float now);
void fish_display(Fish* self, LsgFrustum* frust);

#endif
