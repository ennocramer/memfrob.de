/*********************************************
**********************************************
**                                          **
**  project     aquapark                    **
**              Computergrafik      ss2003  **
**              FH-Wedel                    **
**                                          **
**  authors     enno cramer         ii5476  **
**              martin salzburg     mi4402  **
**                                          **
**********************************************
*********************************************/

#ifndef GLOBAL_H
#define GLOBAL_H

/**
 * config and global settings
 */

#include <lescegra/util/list.h>
#include <lescegra/util/vertex.h>

#include <lescegra/sg/node.h>
#include <lescegra/sg/observercam.h>
#include <lescegra/sg/orthocam.h>

/* useful define */
#ifndef M_PI
# define M_PI		3.14159265358979323846
#endif

#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))

#define GLUT_GAME_MODE 1

#define MOUSE_SENSITIVITY M_PI / 2000.0
#define CAMERA_COLLIDE_DISTANCE 5.0

#define SKY_OFFSET  20.0

#define RAY_LIFETIME   1.00
#define RAY_RESOLUTION 4
#define RAY_WIDTH      2.00
#define RAY_MAX_ALPHA  0.15

extern Vertex global_world_size;
extern Vertex global_sun;
extern Vertex global_water_color;

extern LsgList*  global_objects_static;
extern LsgList*  global_objects_dynamic;

extern LsgNode*  global_terrain;
extern LsgObserverCam* ego_cam;

#define TERRAIN_FILE_NAME "landscape.pcx"

extern LsgOrthoCam* hud_cam;
extern LsgNode* hud;

/* HUD_GLOBUS */
#define HUD_GLOBUS_RESOLUTION    128
#define HUD_GLOBUS_POS_X        -0.8
#define HUD_GLOBUS_POS_Y        -0.8

#include <lescegra/sg/transform.h>

extern Vertex obj_location;
extern Vertex obj_rotation;
extern LsgTransform* obj_transform;

#endif
