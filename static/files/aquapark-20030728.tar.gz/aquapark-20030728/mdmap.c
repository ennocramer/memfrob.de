#include "mdmap.h"

#include <GL/gl.h>

#include <stdlib.h>

static float map_clr_ambi[4] = {0.4, 0.4, 0.4, 1.0};
static float map_clr_diff[4] = {0.6, 0.6, 0.6, 1.0};
static float map_clr_spec[4] = {0.3, 0.3, 0.3, 1.0};

MDMap* mdmap_create(LsgObserverCam* observer, Vertex world, LsgImage* hf, Vertex dimension) {
    MDMap* self = (MDMap*)malloc(sizeof(MDMap));
    
    mdmap_init(self, observer, world, hf, dimension);
    
    return self;
}

void mdmap_init(MDMap* self, LsgObserverCam* observer, Vertex world, LsgImage* hf, Vertex dimension) {
    LsgNode_init(&self->super);
    
    ((LsgObject*)self)->destroy = (void (*)(LsgObject*))mdmap_destroy;
    
    ((LsgNode*)self)->display   = (void (*)(LsgNode*, LsgFrustum*))mdmap_display;
    
    self->observer = observer;
    vertex_copy(self->world, world);
    
    self->map = LsgTerrain_create(hf, dimension);
    vertex_copy(self->dimension, dimension);
}

void mdmap_display(MDMap* self, LsgFrustum* frustum) {
    Vertex v, v2;
    
    glPushAttrib(GL_ENABLE_BIT);
    glDisable(GL_TEXTURE_2D);
    
    glPushAttrib(GL_LIGHTING);
    glMaterialfv(GL_FRONT, GL_AMBIENT,   map_clr_ambi);
    glMaterialfv(GL_FRONT, GL_DIFFUSE,   map_clr_diff);
    glMaterialfv(GL_FRONT, GL_SPECULAR,  map_clr_spec);

    ((LsgNode*)self->map)->display((LsgNode*)self->map, frustum);
    
    glPopAttrib();

    glDisable(GL_LIGHTING);
    glDisable(GL_NORMALIZE);
    
    glColor3f(1.0, 0.0, 0.0);
    vertex_copy(v, self->dimension);
    vertex_scale(v, 0.5);
    
    glBegin(GL_LINES);
        glVertex3f(-v[0], -v[1], -v[2]);
        glVertex3f(-v[0], -v[1], +v[2]);
        
        glVertex3f(-v[0], -v[1], -v[2]);
        glVertex3f(-v[0], +v[1], -v[2]);
        
        glVertex3f(-v[0], -v[1], -v[2]);
        glVertex3f(+v[0], -v[1], -v[2]);
        

        glVertex3f(-v[0], -v[1], +v[2]);
        glVertex3f(-v[0], +v[1], +v[2]);
        
        glVertex3f(-v[0], -v[1], +v[2]);
        glVertex3f(+v[0], -v[1], +v[2]);
        
        
        glVertex3f(-v[0], +v[1], -v[2]);
        glVertex3f(-v[0], +v[1], +v[2]);
        
        glVertex3f(-v[0], +v[1], -v[2]);
        glVertex3f(+v[0], +v[1], -v[2]);
        
        
        glVertex3f(+v[0], -v[1], -v[2]);
        glVertex3f(+v[0], -v[1], +v[2]);
        
        glVertex3f(+v[0], -v[1], -v[2]);
        glVertex3f(+v[0], +v[1], -v[2]);

        
        glVertex3f(-v[0], +v[1], +v[2]);
        glVertex3f(+v[0], +v[1], +v[2]);

            
        glVertex3f(+v[0], -v[1], +v[2]);
        glVertex3f(+v[0], +v[1], +v[2]);

            
        glVertex3f(+v[0], +v[1], -v[2]);
        glVertex3f(+v[0], +v[1], +v[2]);
    glEnd();
    
    glColor3f(1.0, 1.0, 0.0);
    vertex_copy(v2, self->observer->location);
    vertex_div(v2, self->world);
    vertex_mul(v2, self->dimension);
    
    vertex_sub(v2, v);
    
    glBegin(GL_LINES);
        glVertex3f(-v[0], v2[1], v2[2]);
        glVertex3f(+v[0], v2[1], v2[2]);

        glVertex3f(v2[0], -v[1], v2[2]);
        glVertex3f(v2[0], +v[1], v2[2]);

        glVertex3f(v2[0], v2[1], -v[2]);
        glVertex3f(v2[0], v2[1], +v[2]);
    glEnd();

    glPopAttrib();
}

void mdmap_destroy(MDMap* self) {
    LsgObject_free((LsgObject*)self->map);
    
    LsgNode_destroy(&self->super);
}
