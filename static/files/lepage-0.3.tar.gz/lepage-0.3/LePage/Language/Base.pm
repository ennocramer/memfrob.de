#!/usr/bin/perl

use strict;

package LePage::Language::Base;

use vars qw($VERSION);

$VERSION = '0.5';

#
# Grammar
#
package LePage::Grammar;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $self = {
        components => shift,
    };
    
    return bless($self, $class);
}

sub components {
    my $self = shift;
    
    return @{$self->{components}};
}

sub dump {
    my ($self, $fd) = @_;
    
    foreach my $component ($self->components()) {
        $component->dump($fd);
        $fd->print("\n");
    }
}

#
# Rule
#
package LePage::Rule;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $self = {
        name => shift,
        productions => shift,
    };
    
    return bless($self, $class);
}

sub name {
    my $self = shift;
    
    return $self->{name};
}

sub productions {
    my $self = shift;
    
    return @{$self->{productions}};
}

sub dump {
    my ($self, $fd) = @_;
    
    $fd->print($self->{name});
    $fd->print(":\n");
    
    my $first = 1;
    
    foreach my $prod ($self->productions()) {
        unless ($first) {
            $fd->print("\t| ");
        } else {
            $fd->print("\t  ");
            $first = 0;
        }
        $prod->dump($fd);
        $fd->print("\n");
    }
    
    $fd->print("\t;\n");
}

#
# Production
#
package LePage::Production;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $self = {
        items => shift,
    };
    
    return bless($self, $class);
}

sub items {
    my $self = shift;
    
    return @{$self->{items}};
}

sub dump {
    my ($self, $fd) = @_;
    
    my $first = 1;
    foreach my $item ($self->items()) {
        unless ($first) {
            $fd->print(' ');
        } else {
            $first = 0;
        }
        $item->dump($fd);
    }
}

#
# Subrule
#
package LePage::Subrule;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $self = {
        name => shift,
        repeat => shift,
    };
    
    return bless($self, $class);
}

sub name {
    my $self = shift;
    
    return $self->{name};
}

sub repeat {
    my $self = shift;
    
    my $r = $self->{repeat};
    if (ref($r) eq 'ARRAY') {
        return @{$r};
    # backwards comp
    } else {
        return ($r eq '(?)' ? (0,1) : ($r eq '(s)' ? (1,0) : ($r eq '(s?)' ? (0,0) : (1,1))));
    }
}

sub repeat_as_string {
    my $self = shift;

    my ($min, $max) = $self->repeat();
    
    if (($min == 1) && ($max == 1)) {
        return '';
    } elsif (($min == 0) && ($max == 0)) {
        return '(s?)';
    } elsif (($min == 1) && ($max == 0)) {
        return '(s)';
    } elsif (($min == 0) && ($max == 1)) {
        return '(?)';
    } else {
        return '('.$min.'..'.$max.')';
    }
}

sub dump {
    my ($self, $fd) = @_;
    
   
    $fd->print($self->name());
    $fd->print($self->repeat_as_string());
}

#
# Literal
#
package LePage::Terminal::Literal;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $self = {
        string => shift,
    };
    
    return bless($self, $class);
}

sub string {
    my $self = shift;

    return $self->{string};
}

sub dump {
    my ($self, $fd) = @_;
    
    $fd->print("'");
    $fd->print($self->string());
    $fd->print("'");
}

#
# CharGroup
#
package LePage::Terminal::CharGroup;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $self = {
        chars => shift,
    };
    
    return bless($self, $class);
}

sub chars {
    my $self = shift;
    
    return $self->{chars};
}

sub dump {
    my ($self, $fd) = @_;
    
    $fd->print('[');
    $fd->print($self->chars());
    $fd->print(']');
}

#
# Regexp
#
package LePage::Terminal::Regexp;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $self = {
        regexp => shift,
    };
    
    return bless($self, $class);
}

sub regexp {
    my $self = shift;
    
    return $self->{regexp};
}

sub dump {
    my ($self, $fd) = @_;
    
    $fd->print('/');
    $fd->print($self->regexp());
    $fd->print('/');
}

#
# Action
#
package LePage::Action;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $self = {
        block => shift,
    };
    
    return bless($self, $class);
}

sub block {
    my $self = shift;
    
    return $self->{block};
}

sub dump {
    my ($self, $fd) = @_;
    
    $fd->print("\n");
    $fd->print($self->block());
}

#
# Bracket
#
package LePage::Bracket;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $self = {
        productions => shift,
        repeat => shift,
    };
    
    return bless($self, $class);
}

sub productions {
    my $self = shift;
    
    return @{$self->{productions}};
}

sub repeat {
    my $self = shift;
    
    my $r = $self->{repeat};
    if (ref($r) eq 'ARRAY') {
        return @{$r};
    # backwards comp
    } else {
        return ($r eq '(?)' ? (0,1) : ($r eq '(s)' ? (1,0) : ($r eq '(s?)' ? (0,0) : (1,1))));
    }
}

sub repeat_as_string {
    my $self = shift;

    my ($min, $max) = $self->repeat();
    
    if (($min == 1) && ($max == 1)) {
        return '';
    } elsif (($min == 0) && ($max == 0)) {
        return '(s?)';
    } elsif (($min == 1) && ($max == 0)) {
        return '(s)';
    } elsif (($min == 0) && ($max == 1)) {
        return '(?)';
    } else {
        return '('.$min.'..'.$max.')';
    }
}

sub dump {
    my ($self, $fd) = @_;
    
    $fd->print('( ');
    my $first = 1;
    foreach my $prod ($self->productions()) {
        unless ($first) {
            $fd->print(' | ');
        } else {
            $first = 0;
        }
        $prod->dump($fd);
    }
    $fd->print(' )');
    $fd->print($self->repeat_as_string());
}

#
# Skip
#
package LePage::Directive::Skip;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $self = {
        skip => shift,
    };
    
    return bless($self, $class);
}

sub skip {
    my $self = shift;
    
    return $self->{skip};
}

sub dump {
    my ($self, $fd) = @_;
    
    $fd->print('<skip: ');
    $fd->print($self->skip());
    $fd->print('>');
}

#
# Reject
#
package LePage::Directive::Reject;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $self = {
        reject => shift,
    };
    
    return bless($self, $class);
}

sub reject {
    my $self = shift;
    
    return $self->{reject};
}

sub dump {
    my ($self, $fd) = @_;
    
    $fd->print('<reject: ');
    $fd->print($self->reject());
    $fd->print('>');
}

#
# Error
#
package LePage::Directive::Error;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $self = {
        error => shift,
    };
    
    return bless($self, $class);
}

sub error {
    my $self = shift;
    
    return $self->{error};
}

sub dump {
    my ($self, $fd) = @_;
    
    $fd->print('<error: ');
    $fd->print($self->error());
    $fd->print('>');
}

#
# List
#
package LePage::Directive::List;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $self = {
        item => shift,
        skip => shift,
    };
    
    return bless($self, $class);
}

sub item {
    my $self = shift;
    
    return $self->{item};
}

sub skip {
    my $self = shift;
    
    return $self->{skip};
}

sub dump {
    my ($self, $fd) = @_;
    
    $fd->print('<list: ');
    $self->item()->dump($fd);
    $fd->print(' ');
    $self->skip()->dump($fd);
    $fd->print('>');
}

################################################
# BACKWARD COMPATIBILITY 
################################################

#
# Directive
#
package LePage::Directive;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $self = {
        type => shift,
        param => shift,
    };
    
    return bless($self, $class);
}

sub dump {
    my ($self, $fd) = @_;
    
    $fd->print(__PACKAGE__);
}

#
# Comment
#
package LePage::Comment;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $self = {
        text => shift,
    };
    
    return bless($self, $class);
}

sub text {
    my $self = shift;
    
    return $self->{text};
}

sub dump {
    my ($self, $fd) = @_;
    
    $fd->print('# ');
    $fd->print($self->text());
}

1;

__END__
