#!/usr/bin/perl

use strict;

package LePage::Language::Perl;

use vars qw($VERSION);

# nothing much to see here
$VERSION = '0.5';

#
# Grammar
#
package LePage::Grammar;

# write the whole parser to $fd
sub code {
    my ($self, $fd, $pkg) = @_;

    # Package header    
    $fd->print(<<EOF);
#!/usr/bin/perl
package $pkg;

# Generated with LePage ($::VERSION)
# Using LePage::Language::Perl ($LePage::Language::Perl::VERSION)

use strict;

sub new {
    my \$proto = shift;
    my \$class = ref(\$proto) || \$proto;
    
    return bless({}, \$class);
}

EOF

    my $first_rule = undef;

    # The various defined rules
    # no foreach ... brackets define new rule while processing
    for (my $i = 0; $i < scalar $self->components(); ++$i) {
        my $component = ($self->components())[$i];
        $component->code($fd, $self, $pkg);
        $first_rule = $component->name() if ((! defined $first_rule) && (ref($component) eq 'LePage::Rule'));
    }
    
    if (defined($first_rule)) {
        $fd->print(<<EOF);
sub parse {
    my (\$self, \$text) = \@_;
    
    my \$context = ${pkg}::Context->new(\$text);
    
    my \$result = \$self->rule_${first_rule}(\$context);
    return wantarray ? (\$result, \$context) : \$result;
}

EOF
    } else {
        $fd->print(<<EOF);
sub parse {
    return 0;
}

EOF
    }
    
    # Package footer
    $fd->print(<<EOF);
package ${pkg}::Context;

sub new {
    my \$class = shift;
    
    my \$text = shift;
    
    my \$self = {
        skip   => qr/\\s*/,
        text   => \$text,
        errors => [],
        
        linecount => &_linecount(\$text),
    };
    
    return bless(\$self, \$class);
}

sub getline {
    my (\$self) = \@_;

    return \$self->{linecount} - &_linecount(\$self->{text}) + 1;
}

sub text {
    my \$self = shift;
    
    return \$self->{text};
}

sub error {
    my \$self = shift;
    
    return wantarray ? \@{\$self->{errors}} : \$self->{errors}->[0];
}

sub _linecount {
    my (\$text) = \@_;
    
    my (\$pos, \$cnt) = (1, 0);
    while ((\$pos = index(\$text, "\\n", \$pos)) >= 0) {
        ++\$pos; ++\$cnt;
    }
    
    return \$cnt;
}

1;

__END__
EOF
}

#
# Rule
#
package LePage::Rule;

# write one rule definition (sub) to $fd
sub code {
    my ($self, $fd, $grammar, $pkg) = @_;
    
    my $rule = $self->name();
    
    # rule method header
    $fd->print(<<EOF);
# parser subroutine for grammar rule $rule
sub rule_$rule {
    my (\$self, \$context) = \@_;
    
    my \$return = undef;

    my \$_old_skip = \$context->{skip};
    my \$_old_text = \$context->{text};   

    my \$_ret = undef;
    my \$_key = undef;

EOF
    
    my $i = 0;
    foreach my $prod ($self->productions()) {
        $prod->code($fd, $grammar, $pkg, $rule, ++$i);
    }
    
    # rule method footer
    $fd->print(<<EOF);
    return undef;
    
    RULE_${rule}_SUCCEED:
    \$context->{skip}  = \$_old_skip;
    \$context->{error} = [];
    return defined(\$return) ? \$return : \$_ret;
}

EOF
}

#
# Production
#
package LePage::Production;

# write parser block for one production
sub code {
    my ($self, $fd, $grammar, $pkg, $rule, $prod) = @_;
    
    $fd->print(<<EOF);
    # rule($rule)production($prod)
    {
        my \@item = qw($rule);
        my \%item = (_RULE_ => '$rule');

        \$return = undef;
        
EOF

    for (my $i = 0; $i < scalar $self->items(); ) { # increment in next line
        my $item = ($self->items())[$i++];
        my $type = ref($item);
        $fd->print(<<EOF);
        # rule($rule)production($prod)item($i): $type
EOF

        $item->code($fd, $grammar, $pkg, $rule, $prod, $i);
        $fd->print(<<EOF) unless (ref($item) eq 'LePage::Comment');;
        goto RULE_${rule}_PROD_${prod}_FAIL unless (defined(\$_ret));
        push \@item, \$_ret;
        \$item{\$_key} = \$_ret;
        
EOF
    }

    $fd->print(<<EOF);
        goto RULE_${rule}_SUCCEED;
    
        RULE_${rule}_PROD_${prod}_FAIL:
        \$context->{text} = \$_old_text;
        \$context->{skip} = \$_old_skip;
    }
    
EOF
}

#
# Subrule
#
package LePage::Subrule;

sub code {
    my ($self, $fd, $grammar, $pkg, $rule, $prod, $item) = @_;
    
    my $subrule = $self->name();
    my ($min, $max) = $self->repeat();
    
    if (($min != 1) || ($max != 1)) {
        my $repeat = $self->repeat_as_string();
        $fd->print(<<EOF);
        # GRAMMAR: $subrule$repeat
        \$_key = '$subrule';
        {
            my \@_ret = ();

            my (\$min, \$max) = ($min, $max);

            do {
                \$_ret = \$self->rule_$subrule(\$context);
                push \@_ret, \$_ret if (defined \$_ret);
            } while (defined(\$_ret) && ((\$max == 0) || (scalar \@_ret < \$max)));

            \$_ret = scalar \@_ret >= \$min ? \\\@_ret : undef;
        }
EOF
    } else {
        $fd->print(<<EOF);
        # GRAMMAR: $subrule
        \$_key = '$subrule';
        \$_ret = \$self->rule_$subrule(\$context);
EOF
    }
}

#
# Literal
#
package LePage::Terminal::Literal;

sub code {
    my ($self, $fd, $grammar, $pkg, $rule, $prod, $item) = @_;

    $fd->print(<<EOF);
        # GRAMMAR: '$self->{string}'
        \$_key = '_LITERAL_';
        if (\$context->{text} =~ s/\\A\$context->{skip}//) {
            my \$str = '$self->{string}';
            my \$len = length(\$str);
            
            if (substr(\$context->{text}, 0, \$len) eq \$str) {
                \$context->{text} = substr(\$context->{text}, \$len);
                \$_ret = \$str;
            } else {
                \$_ret = undef;
            }
        }
EOF
}

#
# Regexp
#
package LePage::Terminal::Regexp;

sub code {
    my ($self, $fd, $grammar, $pkg, $rule, $prod, $item) = @_;

    my $re = $self->regexp();
        
    $fd->print(<<EOF);
        # GRAMMAR: /$re/
        \$_key = '_REGEXP_';
        \$_ret = (\$context->{text} =~ s/\\A\$context->{skip}// and \$context->{text} =~ s/\\A$re//) ? \$& : undef;
EOF
}

#
# Action
#
package LePage::Action;

sub code {
    my ($self, $fd, $grammar, $pkg, $rule, $prod, $item) = @_;
    
    my $block = $self->block();
    
    $fd->print(<<EOF);
        # GRAMMAR: see below :)
        \$_key = '_ACTION_';
        \$_ret = do $block;
EOF
}

#
# Bracket
#
package LePage::Bracket;

sub code {
    my ($self, $fd, $grammar, $pkg, $rule, $prod, $item) = @_;

    # add a new subrule
    push @{$grammar->{components}}, bless({
        name => "${rule}_P${prod}I${item}BRACKET",
        productions => $self->{productions}
    }, 'LePage::Rule');
        
    # wheee ... we replace ourselves with a new subrule call
    my $subcall = bless({
        name => "${rule}_P${prod}I${item}BRACKET",
        repeat => [ $self->repeat() ]
    }, 'LePage::Subrule');
    $subcall->code($fd, $grammar, $pkg, $rule, $prod, $item);
}

#
# Skip
#
package LePage::Directive::Skip;

sub code {
    my ($self, $fd, $grammar, $pkg, $rule, $prod, $item) = @_;

    my $skip = $self->skip();

    $fd->print(<<EOF);
        # GRAMMAR: <skip: $skip >
        \$_key = '_DIRECTIVE_';
EOF

    $skip = 'qr/\\s*/' unless ($skip =~ /\S/);
    $fd->print(<<EOF);
        \$_ret = \$context->{skip};
        \$context->{skip} = $skip;
EOF
}

#
# Reject
#
package LePage::Directive::Reject;

sub code {
    my ($self, $fd, $grammar, $pkg, $rule, $prod, $item) = @_;

    my $reject = $self->reject();

    $fd->print(<<EOF);
        # GRAMMAR: <reject: $reject >
        \$_key = '_DIRECTIVE_';
EOF

    $reject = '1' unless ($reject =~ /\S/);
    $fd->print(<<EOF);
        \$_ret = ($reject) ? undef : 0;
EOF
}

#
# Error
#
package LePage::Directive::Error;

sub code {
    my ($self, $fd, $grammar, $pkg, $rule, $prod, $item) = @_;

    my $msg = $self->error();

    $fd->print(<<EOF);
        # GRAMMAR: <error: $msg >
        \$_key = '_DIRECTIVE_';
EOF

    $msg = "'syntax error in rule $rule (production $prod item $item)'" unless ($msg =~ /\S/);
    $fd->print(<<EOF);
        \$_ret = undef;
        push \@{\$context->{errors}}, [\$context->getline(), $msg];
EOF
}

#
# List
#
package LePage::Directive::List;

sub code {
    my ($self, $fd, $grammar, $pkg, $rule, $prod, $item) = @_;

    $fd->print(<<EOF);
        # GRAMMAR: <list: ... >
        \$_key = '_DIRECTIVE_';
EOF

    # add a new subrule
    push @{$grammar->{components}}, bless({
        name => "${rule}_P${prod}I${item}LIST",
        productions => [
            bless ({
                items => [
                    $self->item(),
                    bless({
                        productions => [
                            bless({
                                items => [ $self->skip(), $self->item() ],
                            }, 'LePage::Production'),
                        ],
                        repeat => [0, 0],
                    }, 'LePage::Bracket'),
                    bless({
                        block => '{ $return = [ $item[1], @{$item[2]} ]; }',
                    }, 'LePage::Action'),
                ],
            }, 'LePage::Production'),
        ],
    }, 'LePage::Rule');

    # wheee ... we replace ourselves with a new subrule call
    my $subcall = bless({
        name => "${rule}_P${prod}I${item}LIST",
        repeat => $self->{repeat}
    }, 'LePage::Subrule');
    
    $subcall->code($fd, $grammar, $pkg, $rule, $prod, $item);
}
################################################
# BACKWARD COMPATIBILITY 
################################################

#
# Directive
#
package LePage::Directive;

sub code {
    my ($self, $fd, $grammar, $pkg, $rule, $prod, $item) = @_;

    my $type = $self->{type};
    my $param = $self->{param};    
    
    $fd->print(<<EOF);
        # GRAMMAR: <$type:$param>
        \$_key = '_DIRECTIVE_';
EOF
    if ($type eq 'skip') {
        $param = 'qr/\\s*/' unless (defined($param) && ($param ne ''));
        $fd->print(<<EOF);
        \$_ret = \$context->{skip};
        \$context->{skip} = $param;
EOF
    } elsif ($type eq 'reject') {
        $param = '1' unless (defined($param) && ($param ne ''));
        $fd->print(<<EOF);
        \$_ret = ($param) ? undef : 0;
EOF
    } elsif ($type eq 'error') {
        $param = "'syntax error at line '.\$self->getline(\$context).' in rule $rule (production $prod item $item)'" unless (defined($param) && ($param ne ''));
        $fd->print(<<EOF);
        push \@{\$context->{error}}, $param;
        \$_ret = undef;
EOF
    } elsif ($type eq 'leftop') {
        # add a new subrule
        push @{$grammar->{components}}, bless({
            name => "${rule}_P${prod}I${item}LEFTOP",
            productions => [
                bless ({
                    items => [
                        $param->[0],
                        bless({
                            productions => [
                                bless({
                                    items => [ $param->[1], $param->[2] ],
                                }, 'LePage::Production'),
                            ],
                            repeat => '(s?)',
                        }, 'LePage::Bracket'),
                        bless({
                            block => '{ $return = [ $item[1], @{$item[2]} ]; }',
                        }, 'LePage::Action'),
                    ],
                }, 'LePage::Production'),
            ],
        }, 'LePage::Rule');

        # wheee ... we replace ourselves with a new subrule call
        my $subcall = bless({
            name => "${rule}_P${prod}I${item}LEFTOP",
            repeat => $self->{repeat}
        }, 'LePage::Subrule');
        $subcall->code($fd, $grammar, $pkg, $rule, $prod, $item);
    }
}

#
# Comment
#
package LePage::Comment;

sub code {
    my ($self, $fd) = @_;
    
    $fd->print('# ');
    $fd->print($self->text());
    $fd->print("\n");
}

1;

__END__
