#!/usr/bin/perl
package LePage::Parser;

# Generated with LePage (0.2)
# Using LePage::Language::Perl (0.5)

use strict;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    return bless({}, $class);
}

# parser subroutine for grammar rule grammar
sub rule_grammar {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(grammar)production(1)
    {
        my @item = qw(grammar);
        my %item = (_RULE_ => 'grammar');

        $return = undef;
        
        # rule(grammar)production(1)item(1): LePage::Subrule
        # GRAMMAR: component(s?)
        $_key = 'component';
        {
            my @_ret = ();

            my ($min, $max) = (0, 0);

            do {
                $_ret = $self->rule_component($context);
                push @_ret, $_ret if (defined $_ret);
            } while (defined($_ret) && (($max == 0) || (scalar @_ret < $max)));

            $_ret = scalar @_ret >= $min ? \@_ret : undef;
        }
        goto RULE_grammar_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(grammar)production(1)item(2): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $return = LePage::Grammar->new($item[-1]);
};
        goto RULE_grammar_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_grammar_SUCCEED;
    
        RULE_grammar_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_grammar_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule component
sub rule_component {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(component)production(1)
    {
        my @item = qw(component);
        my %item = (_RULE_ => 'component');

        $return = undef;
        
        # rule(component)production(1)item(1): LePage::Subrule
        # GRAMMAR: rule
        $_key = 'rule';
        $_ret = $self->rule_rule($context);
        goto RULE_component_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_component_SUCCEED;
    
        RULE_component_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    # rule(component)production(2)
    {
        my @item = qw(component);
        my %item = (_RULE_ => 'component');

        $return = undef;
        
        # rule(component)production(2)item(1): LePage::Subrule
        # GRAMMAR: comment
        $_key = 'comment';
        $_ret = $self->rule_comment($context);
        goto RULE_component_PROD_2_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_component_SUCCEED;
    
        RULE_component_PROD_2_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_component_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule rule
sub rule_rule {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(rule)production(1)
    {
        my @item = qw(rule);
        my %item = (_RULE_ => 'rule');

        $return = undef;
        
        # rule(rule)production(1)item(1): LePage::Subrule
        # GRAMMAR: identifier
        $_key = 'identifier';
        $_ret = $self->rule_identifier($context);
        goto RULE_rule_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(rule)production(1)item(2): LePage::Terminal::Literal
        # GRAMMAR: ':'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = ':';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_rule_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(rule)production(1)item(3): LePage::Subrule
        # GRAMMAR: production
        $_key = 'production';
        $_ret = $self->rule_production($context);
        goto RULE_rule_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(rule)production(1)item(4): LePage::Bracket
        # GRAMMAR: rule_P1I4BRACKET(s?)
        $_key = 'rule_P1I4BRACKET';
        {
            my @_ret = ();

            my ($min, $max) = (0, 0);

            do {
                $_ret = $self->rule_rule_P1I4BRACKET($context);
                push @_ret, $_ret if (defined $_ret);
            } while (defined($_ret) && (($max == 0) || (scalar @_ret < $max)));

            $_ret = scalar @_ret >= $min ? \@_ret : undef;
        }
        goto RULE_rule_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(rule)production(1)item(5): LePage::Terminal::Literal
        # GRAMMAR: ';'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = ';';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_rule_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(rule)production(1)item(6): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $return = LePage::Rule->new($item[1], [ $item[3], @{$item[4]} ]);
};
        goto RULE_rule_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_rule_SUCCEED;
    
        RULE_rule_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_rule_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule production
sub rule_production {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(production)production(1)
    {
        my @item = qw(production);
        my %item = (_RULE_ => 'production');

        $return = undef;
        
        # rule(production)production(1)item(1): LePage::Subrule
        # GRAMMAR: item(s?)
        $_key = 'item';
        {
            my @_ret = ();

            my ($min, $max) = (0, 0);

            do {
                $_ret = $self->rule_item($context);
                push @_ret, $_ret if (defined $_ret);
            } while (defined($_ret) && (($max == 0) || (scalar @_ret < $max)));

            $_ret = scalar @_ret >= $min ? \@_ret : undef;
        }
        goto RULE_production_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(production)production(1)item(2): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $return = LePage::Production->new($item[1]);
};
        goto RULE_production_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_production_SUCCEED;
    
        RULE_production_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_production_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule item
sub rule_item {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(item)production(1)
    {
        my @item = qw(item);
        my %item = (_RULE_ => 'item');

        $return = undef;
        
        # rule(item)production(1)item(1): LePage::Subrule
        # GRAMMAR: simpleitem
        $_key = 'simpleitem';
        $_ret = $self->rule_simpleitem($context);
        goto RULE_item_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_item_SUCCEED;
    
        RULE_item_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    # rule(item)production(2)
    {
        my @item = qw(item);
        my %item = (_RULE_ => 'item');

        $return = undef;
        
        # rule(item)production(2)item(1): LePage::Subrule
        # GRAMMAR: action
        $_key = 'action';
        $_ret = $self->rule_action($context);
        goto RULE_item_PROD_2_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_item_SUCCEED;
    
        RULE_item_PROD_2_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    # rule(item)production(3)
    {
        my @item = qw(item);
        my %item = (_RULE_ => 'item');

        $return = undef;
        
        # rule(item)production(3)item(1): LePage::Subrule
        # GRAMMAR: bracket
        $_key = 'bracket';
        $_ret = $self->rule_bracket($context);
        goto RULE_item_PROD_3_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_item_SUCCEED;
    
        RULE_item_PROD_3_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    # rule(item)production(4)
    {
        my @item = qw(item);
        my %item = (_RULE_ => 'item');

        $return = undef;
        
        # rule(item)production(4)item(1): LePage::Subrule
        # GRAMMAR: directive
        $_key = 'directive';
        $_ret = $self->rule_directive($context);
        goto RULE_item_PROD_4_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_item_SUCCEED;
    
        RULE_item_PROD_4_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    # rule(item)production(5)
    {
        my @item = qw(item);
        my %item = (_RULE_ => 'item');

        $return = undef;
        
        # rule(item)production(5)item(1): LePage::Subrule
        # GRAMMAR: comment
        $_key = 'comment';
        $_ret = $self->rule_comment($context);
        goto RULE_item_PROD_5_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_item_SUCCEED;
    
        RULE_item_PROD_5_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_item_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule simpleitem
sub rule_simpleitem {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(simpleitem)production(1)
    {
        my @item = qw(simpleitem);
        my %item = (_RULE_ => 'simpleitem');

        $return = undef;
        
        # rule(simpleitem)production(1)item(1): LePage::Subrule
        # GRAMMAR: subrule
        $_key = 'subrule';
        $_ret = $self->rule_subrule($context);
        goto RULE_simpleitem_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_simpleitem_SUCCEED;
    
        RULE_simpleitem_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    # rule(simpleitem)production(2)
    {
        my @item = qw(simpleitem);
        my %item = (_RULE_ => 'simpleitem');

        $return = undef;
        
        # rule(simpleitem)production(2)item(1): LePage::Subrule
        # GRAMMAR: terminal
        $_key = 'terminal';
        $_ret = $self->rule_terminal($context);
        goto RULE_simpleitem_PROD_2_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_simpleitem_SUCCEED;
    
        RULE_simpleitem_PROD_2_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_simpleitem_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule subrule
sub rule_subrule {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(subrule)production(1)
    {
        my @item = qw(subrule);
        my %item = (_RULE_ => 'subrule');

        $return = undef;
        
        # rule(subrule)production(1)item(1): LePage::Subrule
        # GRAMMAR: identifier
        $_key = 'identifier';
        $_ret = $self->rule_identifier($context);
        goto RULE_subrule_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(subrule)production(1)item(2): LePage::Subrule
        # GRAMMAR: repeat
        $_key = 'repeat';
        $_ret = $self->rule_repeat($context);
        goto RULE_subrule_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(subrule)production(1)item(3): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $return = LePage::Subrule->new($item[1], $item[2]);
};
        goto RULE_subrule_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_subrule_SUCCEED;
    
        RULE_subrule_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_subrule_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule repeat
sub rule_repeat {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(repeat)production(1)
    {
        my @item = qw(repeat);
        my %item = (_RULE_ => 'repeat');

        $return = undef;
        
        # rule(repeat)production(1)item(1): LePage::Terminal::Literal
        # GRAMMAR: '(?)'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '(?)';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_repeat_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(repeat)production(1)item(2): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $return = [ 0, 1 ];
};
        goto RULE_repeat_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_repeat_SUCCEED;
    
        RULE_repeat_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    # rule(repeat)production(2)
    {
        my @item = qw(repeat);
        my %item = (_RULE_ => 'repeat');

        $return = undef;
        
        # rule(repeat)production(2)item(1): LePage::Terminal::Literal
        # GRAMMAR: '(s?)'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '(s?)';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_repeat_PROD_2_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(repeat)production(2)item(2): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $return = [ 0, 0 ];
};
        goto RULE_repeat_PROD_2_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_repeat_SUCCEED;
    
        RULE_repeat_PROD_2_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    # rule(repeat)production(3)
    {
        my @item = qw(repeat);
        my %item = (_RULE_ => 'repeat');

        $return = undef;
        
        # rule(repeat)production(3)item(1): LePage::Terminal::Literal
        # GRAMMAR: '(s)'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '(s)';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_repeat_PROD_3_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(repeat)production(3)item(2): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $return = [ 1, 0 ];
};
        goto RULE_repeat_PROD_3_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_repeat_SUCCEED;
    
        RULE_repeat_PROD_3_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    # rule(repeat)production(4)
    {
        my @item = qw(repeat);
        my %item = (_RULE_ => 'repeat');

        $return = undef;
        
        # rule(repeat)production(4)item(1): LePage::Terminal::Literal
        # GRAMMAR: '('
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '(';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_repeat_PROD_4_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(repeat)production(4)item(2): LePage::Terminal::Regexp
        # GRAMMAR: /\d*/
        $_key = '_REGEXP_';
        $_ret = ($context->{text} =~ s/\A$context->{skip}// and $context->{text} =~ s/\A\d*//) ? $& : undef;
        goto RULE_repeat_PROD_4_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(repeat)production(4)item(3): LePage::Terminal::Literal
        # GRAMMAR: '..'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '..';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_repeat_PROD_4_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(repeat)production(4)item(4): LePage::Terminal::Regexp
        # GRAMMAR: /\d*/
        $_key = '_REGEXP_';
        $_ret = ($context->{text} =~ s/\A$context->{skip}// and $context->{text} =~ s/\A\d*//) ? $& : undef;
        goto RULE_repeat_PROD_4_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(repeat)production(4)item(5): LePage::Terminal::Literal
        # GRAMMAR: ')'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = ')';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_repeat_PROD_4_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(repeat)production(4)item(6): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $return = [ ($item[2] || 0), ($item[4] || 0) ];
};
        goto RULE_repeat_PROD_4_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_repeat_SUCCEED;
    
        RULE_repeat_PROD_4_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    # rule(repeat)production(5)
    {
        my @item = qw(repeat);
        my %item = (_RULE_ => 'repeat');

        $return = undef;
        
        # rule(repeat)production(5)item(1): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $return = [ 1, 1 ];
};
        goto RULE_repeat_PROD_5_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_repeat_SUCCEED;
    
        RULE_repeat_PROD_5_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_repeat_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule terminal
sub rule_terminal {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(terminal)production(1)
    {
        my @item = qw(terminal);
        my %item = (_RULE_ => 'terminal');

        $return = undef;
        
        # rule(terminal)production(1)item(1): LePage::Subrule
        # GRAMMAR: literal
        $_key = 'literal';
        $_ret = $self->rule_literal($context);
        goto RULE_terminal_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_terminal_SUCCEED;
    
        RULE_terminal_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    # rule(terminal)production(2)
    {
        my @item = qw(terminal);
        my %item = (_RULE_ => 'terminal');

        $return = undef;
        
        # rule(terminal)production(2)item(1): LePage::Subrule
        # GRAMMAR: chargroup
        $_key = 'chargroup';
        $_ret = $self->rule_chargroup($context);
        goto RULE_terminal_PROD_2_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_terminal_SUCCEED;
    
        RULE_terminal_PROD_2_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    # rule(terminal)production(3)
    {
        my @item = qw(terminal);
        my %item = (_RULE_ => 'terminal');

        $return = undef;
        
        # rule(terminal)production(3)item(1): LePage::Subrule
        # GRAMMAR: regexp
        $_key = 'regexp';
        $_ret = $self->rule_regexp($context);
        goto RULE_terminal_PROD_3_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_terminal_SUCCEED;
    
        RULE_terminal_PROD_3_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_terminal_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule literal
sub rule_literal {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(literal)production(1)
    {
        my @item = qw(literal);
        my %item = (_RULE_ => 'literal');

        $return = undef;
        
        # rule(literal)production(1)item(1): LePage::Terminal::Literal
        # GRAMMAR: '\''
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '\'';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_literal_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(literal)production(1)item(2): LePage::Terminal::Regexp
        # GRAMMAR: /(\\.|[^'])*/
        $_key = '_REGEXP_';
        $_ret = ($context->{text} =~ s/\A$context->{skip}// and $context->{text} =~ s/\A(\\.|[^'])*//) ? $& : undef;
        goto RULE_literal_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(literal)production(1)item(3): LePage::Terminal::Literal
        # GRAMMAR: '\''
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '\'';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_literal_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(literal)production(1)item(4): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $return = LePage::Terminal::Literal->new($item[2]);
};
        goto RULE_literal_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_literal_SUCCEED;
    
        RULE_literal_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_literal_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule chargroup
sub rule_chargroup {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(chargroup)production(1)
    {
        my @item = qw(chargroup);
        my %item = (_RULE_ => 'chargroup');

        $return = undef;
        
        # rule(chargroup)production(1)item(1): LePage::Terminal::Literal
        # GRAMMAR: '['
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '[';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_chargroup_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(chargroup)production(1)item(2): LePage::Terminal::Regexp
        # GRAMMAR: /(\\.|[^\]])*/
        $_key = '_REGEXP_';
        $_ret = ($context->{text} =~ s/\A$context->{skip}// and $context->{text} =~ s/\A(\\.|[^\]])*//) ? $& : undef;
        goto RULE_chargroup_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(chargroup)production(1)item(3): LePage::Terminal::Literal
        # GRAMMAR: ']'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = ']';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_chargroup_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(chargroup)production(1)item(4): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $return = LePage::Terminal::CharGroup->new($item[2]);
};
        goto RULE_chargroup_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_chargroup_SUCCEED;
    
        RULE_chargroup_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_chargroup_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule regexp
sub rule_regexp {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(regexp)production(1)
    {
        my @item = qw(regexp);
        my %item = (_RULE_ => 'regexp');

        $return = undef;
        
        # rule(regexp)production(1)item(1): LePage::Terminal::Literal
        # GRAMMAR: '/'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '/';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_regexp_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(regexp)production(1)item(2): LePage::Terminal::Regexp
        # GRAMMAR: /(\\.|[^\/])*/
        $_key = '_REGEXP_';
        $_ret = ($context->{text} =~ s/\A$context->{skip}// and $context->{text} =~ s/\A(\\.|[^\/])*//) ? $& : undef;
        goto RULE_regexp_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(regexp)production(1)item(3): LePage::Terminal::Literal
        # GRAMMAR: '/'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '/';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_regexp_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(regexp)production(1)item(4): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $return = LePage::Terminal::Regexp->new($item[2]);
};
        goto RULE_regexp_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_regexp_SUCCEED;
    
        RULE_regexp_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_regexp_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule action
sub rule_action {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(action)production(1)
    {
        my @item = qw(action);
        my %item = (_RULE_ => 'action');

        $return = undef;
        
        # rule(action)production(1)item(1): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    use Text::Balanced qw(extract_codeblock);
    
    my $block = extract_codeblock($context->{text});
    if ($block) {
        $return = LePage::Action->new($block);
    } else {
        $return = undef;
    }
    $return;
};
        goto RULE_action_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_action_SUCCEED;
    
        RULE_action_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_action_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule bracket
sub rule_bracket {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(bracket)production(1)
    {
        my @item = qw(bracket);
        my %item = (_RULE_ => 'bracket');

        $return = undef;
        
        # rule(bracket)production(1)item(1): LePage::Terminal::Literal
        # GRAMMAR: '('
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '(';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_bracket_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(bracket)production(1)item(2): LePage::Subrule
        # GRAMMAR: production
        $_key = 'production';
        $_ret = $self->rule_production($context);
        goto RULE_bracket_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(bracket)production(1)item(3): LePage::Bracket
        # GRAMMAR: bracket_P1I3BRACKET(s?)
        $_key = 'bracket_P1I3BRACKET';
        {
            my @_ret = ();

            my ($min, $max) = (0, 0);

            do {
                $_ret = $self->rule_bracket_P1I3BRACKET($context);
                push @_ret, $_ret if (defined $_ret);
            } while (defined($_ret) && (($max == 0) || (scalar @_ret < $max)));

            $_ret = scalar @_ret >= $min ? \@_ret : undef;
        }
        goto RULE_bracket_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(bracket)production(1)item(4): LePage::Terminal::Literal
        # GRAMMAR: ')'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = ')';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_bracket_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(bracket)production(1)item(5): LePage::Subrule
        # GRAMMAR: repeat
        $_key = 'repeat';
        $_ret = $self->rule_repeat($context);
        goto RULE_bracket_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(bracket)production(1)item(6): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $return = LePage::Bracket->new([ $item[2], @{$item[3]} ], $item[5]);
};
        goto RULE_bracket_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_bracket_SUCCEED;
    
        RULE_bracket_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_bracket_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule directive
sub rule_directive {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(directive)production(1)
    {
        my @item = qw(directive);
        my %item = (_RULE_ => 'directive');

        $return = undef;
        
        # rule(directive)production(1)item(1): LePage::Subrule
        # GRAMMAR: skip
        $_key = 'skip';
        $_ret = $self->rule_skip($context);
        goto RULE_directive_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_directive_SUCCEED;
    
        RULE_directive_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    # rule(directive)production(2)
    {
        my @item = qw(directive);
        my %item = (_RULE_ => 'directive');

        $return = undef;
        
        # rule(directive)production(2)item(1): LePage::Subrule
        # GRAMMAR: reject
        $_key = 'reject';
        $_ret = $self->rule_reject($context);
        goto RULE_directive_PROD_2_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_directive_SUCCEED;
    
        RULE_directive_PROD_2_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    # rule(directive)production(3)
    {
        my @item = qw(directive);
        my %item = (_RULE_ => 'directive');

        $return = undef;
        
        # rule(directive)production(3)item(1): LePage::Subrule
        # GRAMMAR: error
        $_key = 'error';
        $_ret = $self->rule_error($context);
        goto RULE_directive_PROD_3_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_directive_SUCCEED;
    
        RULE_directive_PROD_3_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    # rule(directive)production(4)
    {
        my @item = qw(directive);
        my %item = (_RULE_ => 'directive');

        $return = undef;
        
        # rule(directive)production(4)item(1): LePage::Subrule
        # GRAMMAR: list
        $_key = 'list';
        $_ret = $self->rule_list($context);
        goto RULE_directive_PROD_4_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_directive_SUCCEED;
    
        RULE_directive_PROD_4_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_directive_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule skip
sub rule_skip {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(skip)production(1)
    {
        my @item = qw(skip);
        my %item = (_RULE_ => 'skip');

        $return = undef;
        
        # rule(skip)production(1)item(1): LePage::Terminal::Literal
        # GRAMMAR: '<'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '<';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_skip_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(skip)production(1)item(2): LePage::Terminal::Literal
        # GRAMMAR: 'skip'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = 'skip';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_skip_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(skip)production(1)item(3): LePage::Terminal::Literal
        # GRAMMAR: ':'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = ':';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_skip_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(skip)production(1)item(4): LePage::Terminal::Regexp
        # GRAMMAR: /(\\.|[^>])*/
        $_key = '_REGEXP_';
        $_ret = ($context->{text} =~ s/\A$context->{skip}// and $context->{text} =~ s/\A(\\.|[^>])*//) ? $& : undef;
        goto RULE_skip_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(skip)production(1)item(5): LePage::Terminal::Literal
        # GRAMMAR: '>'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '>';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_skip_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(skip)production(1)item(6): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $item[4] =~ s/\\>/>/g;
    $return = LePage::Directive::Skip->new($item[4]);
};
        goto RULE_skip_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_skip_SUCCEED;
    
        RULE_skip_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_skip_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule reject
sub rule_reject {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(reject)production(1)
    {
        my @item = qw(reject);
        my %item = (_RULE_ => 'reject');

        $return = undef;
        
        # rule(reject)production(1)item(1): LePage::Terminal::Literal
        # GRAMMAR: '<'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '<';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_reject_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(reject)production(1)item(2): LePage::Terminal::Literal
        # GRAMMAR: 'reject'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = 'reject';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_reject_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(reject)production(1)item(3): LePage::Terminal::Literal
        # GRAMMAR: ':'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = ':';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_reject_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(reject)production(1)item(4): LePage::Terminal::Regexp
        # GRAMMAR: /(\\.|[^>])*/
        $_key = '_REGEXP_';
        $_ret = ($context->{text} =~ s/\A$context->{skip}// and $context->{text} =~ s/\A(\\.|[^>])*//) ? $& : undef;
        goto RULE_reject_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(reject)production(1)item(5): LePage::Terminal::Literal
        # GRAMMAR: '>'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '>';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_reject_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(reject)production(1)item(6): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $item[4] =~ s/\\>/>/g;
    $return = LePage::Directive::Reject->new($item[4]);
};
        goto RULE_reject_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_reject_SUCCEED;
    
        RULE_reject_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_reject_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule error
sub rule_error {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(error)production(1)
    {
        my @item = qw(error);
        my %item = (_RULE_ => 'error');

        $return = undef;
        
        # rule(error)production(1)item(1): LePage::Terminal::Literal
        # GRAMMAR: '<'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '<';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_error_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(error)production(1)item(2): LePage::Terminal::Literal
        # GRAMMAR: 'error'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = 'error';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_error_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(error)production(1)item(3): LePage::Terminal::Literal
        # GRAMMAR: ':'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = ':';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_error_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(error)production(1)item(4): LePage::Terminal::Regexp
        # GRAMMAR: /(\\.|[^>])*/
        $_key = '_REGEXP_';
        $_ret = ($context->{text} =~ s/\A$context->{skip}// and $context->{text} =~ s/\A(\\.|[^>])*//) ? $& : undef;
        goto RULE_error_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(error)production(1)item(5): LePage::Terminal::Literal
        # GRAMMAR: '>'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '>';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_error_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(error)production(1)item(6): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $item[4] =~ s/\\>/>/g;
    $return = LePage::Directive::Error->new($item[4]);
};
        goto RULE_error_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_error_SUCCEED;
    
        RULE_error_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_error_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule list
sub rule_list {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(list)production(1)
    {
        my @item = qw(list);
        my %item = (_RULE_ => 'list');

        $return = undef;
        
        # rule(list)production(1)item(1): LePage::Terminal::Literal
        # GRAMMAR: '<'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '<';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_list_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(list)production(1)item(2): LePage::Terminal::Literal
        # GRAMMAR: 'list'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = 'list';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_list_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(list)production(1)item(3): LePage::Terminal::Literal
        # GRAMMAR: ':'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = ':';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_list_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(list)production(1)item(4): LePage::Subrule
        # GRAMMAR: simpleitem
        $_key = 'simpleitem';
        $_ret = $self->rule_simpleitem($context);
        goto RULE_list_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(list)production(1)item(5): LePage::Subrule
        # GRAMMAR: simpleitem
        $_key = 'simpleitem';
        $_ret = $self->rule_simpleitem($context);
        goto RULE_list_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(list)production(1)item(6): LePage::Terminal::Literal
        # GRAMMAR: '>'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '>';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_list_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(list)production(1)item(7): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $return = LePage::Directive::List->new($item[4], $item[5]);
};
        goto RULE_list_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_list_SUCCEED;
    
        RULE_list_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_list_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule comment
sub rule_comment {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(comment)production(1)
    {
        my @item = qw(comment);
        my %item = (_RULE_ => 'comment');

        $return = undef;
        
        # rule(comment)production(1)item(1): LePage::Terminal::Literal
        # GRAMMAR: '#'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '#';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_comment_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(comment)production(1)item(2): LePage::Directive::Skip
        # GRAMMAR: <skip: /[\t ]*/ >
        $_key = '_DIRECTIVE_';
        $_ret = $context->{skip};
        $context->{skip} = /[\t ]*/;
        goto RULE_comment_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(comment)production(1)item(3): LePage::Terminal::Regexp
        # GRAMMAR: /[^\n]*/
        $_key = '_REGEXP_';
        $_ret = ($context->{text} =~ s/\A$context->{skip}// and $context->{text} =~ s/\A[^\n]*//) ? $& : undef;
        goto RULE_comment_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(comment)production(1)item(4): LePage::Action
        # GRAMMAR: see below :)
        $_key = '_ACTION_';
        $_ret = do {
    $return = LePage::Comment->new($item[1]);
};
        goto RULE_comment_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_comment_SUCCEED;
    
        RULE_comment_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_comment_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule identifier
sub rule_identifier {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(identifier)production(1)
    {
        my @item = qw(identifier);
        my %item = (_RULE_ => 'identifier');

        $return = undef;
        
        # rule(identifier)production(1)item(1): LePage::Terminal::Regexp
        # GRAMMAR: /[A-Za-z][A-Za-z0-9_]*/
        $_key = '_REGEXP_';
        $_ret = ($context->{text} =~ s/\A$context->{skip}// and $context->{text} =~ s/\A[A-Za-z][A-Za-z0-9_]*//) ? $& : undef;
        goto RULE_identifier_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_identifier_SUCCEED;
    
        RULE_identifier_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_identifier_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule rule_P1I4BRACKET
sub rule_rule_P1I4BRACKET {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(rule_P1I4BRACKET)production(1)
    {
        my @item = qw(rule_P1I4BRACKET);
        my %item = (_RULE_ => 'rule_P1I4BRACKET');

        $return = undef;
        
        # rule(rule_P1I4BRACKET)production(1)item(1): LePage::Terminal::Literal
        # GRAMMAR: '|'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '|';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_rule_P1I4BRACKET_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(rule_P1I4BRACKET)production(1)item(2): LePage::Subrule
        # GRAMMAR: production
        $_key = 'production';
        $_ret = $self->rule_production($context);
        goto RULE_rule_P1I4BRACKET_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_rule_P1I4BRACKET_SUCCEED;
    
        RULE_rule_P1I4BRACKET_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_rule_P1I4BRACKET_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

# parser subroutine for grammar rule bracket_P1I3BRACKET
sub rule_bracket_P1I3BRACKET {
    my ($self, $context) = @_;
    
    my $return = undef;

    my $_old_skip = $context->{skip};
    my $_old_text = $context->{text};   

    my $_ret = undef;
    my $_key = undef;

    # rule(bracket_P1I3BRACKET)production(1)
    {
        my @item = qw(bracket_P1I3BRACKET);
        my %item = (_RULE_ => 'bracket_P1I3BRACKET');

        $return = undef;
        
        # rule(bracket_P1I3BRACKET)production(1)item(1): LePage::Terminal::Literal
        # GRAMMAR: '|'
        $_key = '_LITERAL_';
        if ($context->{text} =~ s/\A$context->{skip}//) {
            my $str = '|';
            my $len = length($str);
            
            if (substr($context->{text}, 0, $len) eq $str) {
                $context->{text} = substr($context->{text}, $len);
                $_ret = $str;
            } else {
                $_ret = undef;
            }
        }
        goto RULE_bracket_P1I3BRACKET_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        # rule(bracket_P1I3BRACKET)production(1)item(2): LePage::Subrule
        # GRAMMAR: production
        $_key = 'production';
        $_ret = $self->rule_production($context);
        goto RULE_bracket_P1I3BRACKET_PROD_1_FAIL unless (defined($_ret));
        push @item, $_ret;
        $item{$_key} = $_ret;
        
        goto RULE_bracket_P1I3BRACKET_SUCCEED;
    
        RULE_bracket_P1I3BRACKET_PROD_1_FAIL:
        $context->{text} = $_old_text;
        $context->{skip} = $_old_skip;
    }
    
    return undef;
    
    RULE_bracket_P1I3BRACKET_SUCCEED:
    $context->{skip}  = $_old_skip;
    $context->{error} = [];
    return defined($return) ? $return : $_ret;
}

sub parse {
    my ($self, $text) = @_;
    
    my $context = LePage::Parser::Context->new($text);
    
    my $result = $self->rule_grammar($context);
    return wantarray ? ($result, $context) : $result;
}

package LePage::Parser::Context;

sub new {
    my $class = shift;
    
    my $text = shift;
    
    my $self = {
        skip   => qr/\s*/,
        text   => $text,
        errors => [],
        
        linecount => &_linecount($text),
    };
    
    return bless($self, $class);
}

sub getline {
    my ($self) = @_;

    return $self->{linecount} - &_linecount($self->{text}) + 1;
}

sub text {
    my $self = shift;
    
    return $self->{text};
}

sub error {
    my $self = shift;
    
    return wantarray ? @{$self->{errors}} : $self->{errors}->[0];
}

sub _linecount {
    my ($text) = @_;
    
    my ($pos, $cnt) = (1, 0);
    while (($pos = index($text, "\n", $pos)) >= 0) {
        ++$pos; ++$cnt;
    }
    
    return $cnt;
}

1;

__END__
