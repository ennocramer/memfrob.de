/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_PARTICLE_SYSTEM_H
#define LSG_PARTICLE_SYSTEM_H 1

#include <lescegra/sg/node.h>

#include <lescegra/util/list.h>
#include <lescegra/coll/octree.h>

typedef struct {
    Vertex location;
    Vertex velocity;
    Vertex acceleration;

    float age;
    void* user_data;

    LsgOctree* container;
} LsgParticle;

typedef struct LsgParticleModifier LsgParticleModifier;
typedef struct LsgParticleModifierClass LsgParticleModifierClass;

typedef void (*LsgParticleRenderer)(LsgList* particles);

typedef struct LsgParticleSystem LsgParticleSystem;
typedef struct LsgParticleSystemClass LsgParticleSystemClass;

/* ParticleModifier ***************************************************/

struct LsgParticleModifier {
    LsgObject parent;

    LsgParticle particle;
};

struct LsgParticleModifierClass {
    LsgObjectClass parent;

    void (*update)(LsgParticleModifier*, LsgParticleSystem*, float);
};

LsgClassID LsgParticleModifier_classID(void);

#define IS_LSG_PARTICLE_MODIFIER(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgParticleModifier_classID())

#define LSG_PARTICLE_MODIFIER(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgParticleModifier*, LsgParticleModifier_classID(), (instance))

#define LSG_PARTICLE_MODIFIER_CLASS(class) \
    LSG_CLASS_CAST(LsgParticleModifierClass*, LsgParticleModifier_classID(), (class))

void LsgParticleModifier_init(LsgParticleModifier* self);

void LsgParticleModifier_update(
    LsgParticleModifier* self,
    LsgParticleSystem* system,
    float time
);

/* ParticleSystem *****************************************************/

struct LsgParticleSystem {
    LsgNode parent;

    LsgOctree* system;
    LsgList* modifiers;

    LsgParticleRenderer renderer;

    float last;
};

struct LsgParticleSystemClass {
    LsgNodeClass parent;
};

LsgClassID LsgParticleSystem_classID(void);

#define IS_LSG_PARTICLE_SYSTEM(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgParticleSystem_classID())

#define LSG_PARTICLE_SYSTEM(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgParticleSystem*, LsgParticleSystem_classID(), (instance))

#define LSG_PARTICLE_SYSTEM_CLASS(class) \
    LSG_CLASS_CAST(LsgParticleSystemClass*, LsgParticleSystem_classID(), (class))

LsgParticleSystem* LsgParticleSystem_create(
    LsgParticleRenderer renderer,
    Vertex min, Vertex max, int div
);

void LsgParticleSystem_init(
    LsgParticleSystem* self,
    LsgParticleRenderer renderer,
    Vertex min, Vertex max, int div
);

#endif
