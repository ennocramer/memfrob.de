/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_PARTICLE_SOURCE_H
#define LSG_PARTICLE_SOURCE_H 1

/**
 * \file  particle/source.h
 * \brief Constant source of new particles
 */

#include <lescegra/particle/system.h>

#include <lescegra/util/random.h>

typedef struct LsgParticleSource LsgParticleSource;
typedef struct LsgParticleSourceClass LsgParticleSourceClass;

/**
 * \ingroup particle
 * \brief   Constant source of new particles
 *
 * Constantly create new particles and wipe old ones while time elapses.
 */
struct LsgParticleSource {
    LsgParticleModifier parent;

    LsgRandom* rng;
    LsgList* inactive;

    Vertex location;
    Vertex velocity;

    Vertex location_error;
    Vertex velocity_error;

    float birth_rate;
    float birth_accum;

    float lifetime;

    LsgParticle* particles;
    unsigned long int max;
};

struct LsgParticleSourceClass {
    LsgParticleModifierClass parent;
};

LsgClassID LsgParticleSource_classID(void);

#define IS_LSG_PARTICLE_SOURCE(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgParticleSource_classID())

#define LSG_PARTICLE_SOURCE(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgParticleSource*, LsgParticleSource_classID(), (instance))

#define LSG_PARTICLE_SOURCE_CLASS(class) \
    LSG_CLASS_CAST(LsgParticleSourceClass*, LsgParticleSource_ClassID(), (class))

LsgParticleSource* LsgParticleSource_create(unsigned long int max);

void LsgParticleSource_init(LsgParticleSource* self, unsigned long int max);

#endif
