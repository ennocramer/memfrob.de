/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_CLASS_H
#define LSG_CLASS_H 1

typedef unsigned int LsgClassID;

typedef struct {
    LsgClassID id;
} LsgClass;

typedef struct {
    const LsgClass* class;
} LsgClassInstance;

#define LSG_CLASS_ID_NONE      ((LsgClassID)0)

#define LSG_CLASS_FLAG_NONE     0x00
#define LSG_CLASS_FLAG_ABSTRACT 0x01
#define LSG_CLASS_FLAG_FINAL    0x02

typedef void (*LsgClassStaticInitializer)(LsgClass*, LsgClassInstance*);

LsgClassID LsgClass_register(
        const char*          name,
        LsgClassID           parent,
        unsigned int         flags,
        unsigned int         class_size,
        unsigned int         instance_size,
        LsgClassStaticInitializer static_init
);

LsgClassInstance* LsgClass_alloc(LsgClassID classid);

const LsgClass* LsgClass_getClass(LsgClassID classid);
const char*     LsgClass_getClassName(LsgClassID classid);
unsigned int    LsgClass_getFlags(LsgClassID classid);

LsgClassID      LsgClass_getParentID(LsgClassID classid);
const LsgClass* LsgClass_getParentClass(LsgClassID classid);
const char*     LsgClass_getParentClassName(LsgClassID classid);

int LsgClass_isInstanceOf(
    const LsgClassInstance* instance,
    LsgClassID classid
);

int LsgClass_isChildOf(
    const LsgClass* class,
    LsgClassID classid
);


LsgClassInstance* LsgClass_assertInstanceCast(
    LsgClassInstance* instance,
    LsgClassID classid,
    const char* file, const char* method, unsigned int line

);
LsgClass* LsgClass_assertClassCast(
    LsgClass* class,
    LsgClassID classid,
    const char* file, const char* method, unsigned int line
);

LsgClassInstance* LsgClass_instanceCast(
    LsgClassInstance* instance,
    LsgClassID classid
);

LsgClass* LsgClass_classCast(
    LsgClass* class,
    LsgClassID classid
);

void LsgClass_abortAbstract(
    const LsgClassInstance* instance,
    LsgClassID classid,
    const char* method
);

#ifdef __GNUC__
#    define LSG_CLASS_CURRENT_FUNCTION __PRETTY_FUNCTION__
#elif __STDC_VERSION__ >= 199901L
#    define LSG_CLASS_CURRENT_FUNCTION __func__
#else
#    define LSG_CLASS_CURRENT_FUNCTION ((const char*)0)
#endif

#define LSG_CLASS_ID_FROM_CLASS(class) \
    (((LsgClass*)(class))->id)

#define LSG_CLASS_FROM_INSTANCE(instance) \
    (((LsgClassInstance*)(instance))->class)

#define LSG_CLASS_ID_FROM_INSTANCE(instance) \
    (((LsgClassInstance*)(instance))->class->id)

#define LSG_CLASS_SOFT_INSTANCE_CAST(ctype, classid, instance) \
    ((ctype)LsgClass_instanceCast((LsgClassInstance*)(instance), (classid)))

#define LSG_CLASS_SOFT_CAST(ctype, classid, class) \
    ((ctype)LsgClass_classCast((LsgClass*)(class), (classid)))

#define LSG_CLASS_INSTANCE_OF(instance, class) \
    (LsgClass_isInstanceOf((LsgClassInstance*)(instance), (class)))

#if defined NDEBUG || defined LSG_CLASS_DISABLE_CAST_CHECK

#    define LSG_CLASS_INSTANCE_CAST(ctype, classid, instance) \
        ((ctype)(instance))

#    define LSG_CLASS_CAST(ctype, classid, class) \
        ((ctype)(class))

#else /* NO NDEBUG */

#   define LSG_CLASS_INSTANCE_CAST(ctype, classid, instance) \
        ((ctype)LsgClass_assertInstanceCast((LsgClassInstance*)(instance), (classid), __FILE__, LSG_CLASS_CURRENT_FUNCTION, __LINE__))

#    define LSG_CLASS_CAST(ctype, classid, class) \
        ((ctype)LsgClass_assertClassCast((LsgClass*)(class), (classid), __FILE__, LSG_CLASS_CURRENT_FUNCTION, __LINE__))

#endif

#endif
