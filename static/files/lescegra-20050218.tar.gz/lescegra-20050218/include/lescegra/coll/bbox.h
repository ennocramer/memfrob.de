/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_BBOX_H
#define LSG_BBOX_H 1

/**
 * \file  bbox.h
 * \brief Axis Aligned Bounding Box
 */

#include <lescegra/coll/bvolume.h>

#include <lescegra/base/vertex.h>
#include <lescegra/base/matrix.h>

typedef struct LsgBBox LsgBBox;
typedef struct LsgBBoxClass LsgBBoxClass;

/**
 * \brief Axis Aligned Bounding Box
 *
 * An axis aligned bounding box
 */
struct LsgBBox {
    LsgGenericBVolume parent;

    Vertex min;
    Vertex max;
};

struct LsgBBoxClass {
    LsgGenericBVolumeClass parent;
};

LsgClassID LsgBBox_classID(void);

#define IS_LSG_BBOX(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgBBox_classID())

#define LSG_BBOX(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgBBox*, LsgBBox_classID(), (instance))

#define LSG_BBOX_CLASS(class) \
    LSG_CLASS_CAST(LsgBBoxClass*, LsgBBox_classID(), (class))

/**
 * \relates LsgBBox
 * Allocate and initialize a bounding box.
 */
LsgBBox* LsgBBox_create(void);

/**
 * \relates LsgBBox
 * Constructor method for LsgBBox.
 * Initially set the bounding box state to invalid.
 * @param self  The instance variable
 */
void LsgBBox_init(LsgBBox* self);

#endif
