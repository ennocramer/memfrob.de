/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_HIT_H
#define LSG_HIT_H 1

#include <lescegra/base/object.h>

#include <lescegra/base/vertex.h>

typedef struct LsgHit LsgHit;
typedef struct LsgHitClass LsgHitClass;

struct LsgHit {
    LsgObject parent;

    Vertex intersection;
    Vertex normal;
};

struct LsgHitClass {
    LsgObjectClass parent;
};

LsgClassID LsgHit_classID(void);

#define IS_LSG_HIT(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgHit_classID())

#define LSG_HIT(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgHit*, LsgHit_classID(), (instance))

#define LSG_HIT_CLASS(class) \
    LSG_CLASS_CAST(LsgHitClass*, LsgHit_classID(), (class))

LsgHit* LsgHit_create(void);
void LsgHit_init(LsgHit* self);

#endif
