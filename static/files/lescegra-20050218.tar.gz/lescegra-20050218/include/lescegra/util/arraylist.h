/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_ARRAYLIST_H
#define LSG_ARRAYLIST_H 1

#include <lescegra/util/list.h>

typedef struct LsgArrayList LsgArrayList;
typedef struct LsgArrayListClass LsgArrayListClass;

struct LsgArrayList {
    LsgList parent;
    
    void**  elements;
    int     capacity;
    int     count;
};

struct LsgArrayListClass {
    LsgListClass parent;
};

LsgClassID LsgArrayList_classID(void);

#define IS_LSG_ARRAY_LIST(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgArrayList_classID())

#define LSG_ARRAY_LIST(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgArrayList*, LsgArrayList_classID(), (instance))

#define LSG_ARRAY_LIST_CLASS(class) \
    LSG_CLASS_CAST(LsgArrayListClass*, LsgArrayList_classID(), (class))

LsgArrayList* LsgArrayList_create(void);
void LsgArrayList_init(LsgArrayList* self);

/* LasArrayListIterator */

typedef struct LsgArrayListIterator LsgArrayListIterator;
typedef struct LsgArrayListIteratorClass LsgArrayListIteratorClass;

struct LsgArrayListIterator {
    LsgIterator parent;
    
    void**      elements;
    int         count;
    int         index;
};

struct LsgArrayListIteratorClass {
    LsgIteratorClass parent;
};

LsgClassID LsgArrayListIterator_classID(void);

#define LSG_ARRAY_LIST_ITERATOR(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgArrayListIterator*, LsgArrayListIterator_classID(), (instance))

#define LSG_ARRAY_LIST_ITERATOR_CLASS(class) \
    LSG_CLASS_CAST(LsgArrayListIteratorClass*, LsgArrayListIterator_classID(), (class))

LsgArrayListIterator* LsgArrayListIterator_create(LsgArrayList* list);
void LsgArrayListIterator_init(LsgArrayListIterator* self, LsgArrayList* list);

#endif
