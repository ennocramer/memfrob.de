/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_IMAGE_H
#define LSG_IMAGE_H 1

#include <lescegra/base/object.h>

#include <stdio.h>

/**
 * \file  image.h
 * \brief Bitmap
 */

#define IMAGE_GRAYSCALE       1
#define IMAGE_RGB             3
#define IMAGE_RGBA            4

#define IMAGE_LUMINANCE       1
#define IMAGE_LUMINANCE_ALPHA 2
#define IMAGE_COLOR           3
#define IMAGE_COLOR_ALPHA     4

typedef struct LsgImage LsgImage;
typedef struct LsgImageClass LsgImageClass;

/**
 * \brief Bitmap
 *
 * A bitmap with a variable number of color channels.
 * Every channel has a resolution of 8 bit per pixel.
 */
struct LsgImage {
    LsgObject parent;
    
    unsigned char* data;
    int width;
    int height;
    int bpp;
};

struct LsgImageClass {
    LsgObjectClass parent;
};

LsgClassID LsgImage_classID(void);

#define IS_LSG_IMAGE(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgImage_classID())

#define LSG_IMAGE(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgImage*, LsgImage_classID(), (instance))

#define LSG_IMAGE_CLASS(class) \
    LSG_CLASS_CAST(LsgImageClass*, LsgImage_classID(), (class))

/**
 * \relates LsgImage
 * Allocate and initialize an image with the given resolution and number
 * of channels.
 * @param width     The width of the bitmap
 * @param height    The height of the bitmap
 * @param bpp       The number of channels
 * @return An image with the given width, height and number of channels
 */
LsgImage* LsgImage_create(int width, int height, int bpp);

/**
 * \relates LsgImage
 * Constructor for LsgImage. Allocate a pixel buffer of the given dimension
 * and resolution.
 * @param self      The instance variable
 * @param width     The image width in pixel
 * @param height    The image height in pixel
 * @param bpp       The image resolution in byte per pixel (number of color channels)
 */
void LsgImage_init(LsgImage* self, int width, int height, int bpp);

/**
 * \relates LsgImage
 * Mirror the image horizontally.
 * @param self      The instance variable
 */
void LsgImage_mirrorX(LsgImage* self);

/**
 * \relates LsgImage
 * Mirror the image vertically.
 * @param self      The instance variable
 */
void LsgImage_mirrorY(LsgImage* self);

/**
 * \relates LsgImage
 * Copy part of the image.
 * @param self      The instance variable
 * @param x         Left border of the image region to copy
 * @param y         Upper border of the image region to cope
 * @param w         Width of the image region to copy
 * @param h         Height of the image region to copy
 * @param dst       The target image
 * @param dst_x     Left border of the target image region
 * @param dst_y     Upper border of the target image region
 */
void LsgImage_copy(LsgImage* self, int x, int y, int w, int h, LsgImage* dst, int dst_x, int dst_y);

/**
 * \relates LsgImage
 * Load an image stored in any of the supported image formats (currently
 * PCX and TGA). The apropriate loader is determined from the filename.
 * @param filename  The name of the image file to load
 * @return The bitmap stored  in the file referenced by filename
 */
LsgImage* LsgImage_load(const char* filename);

LsgImage* LsgImage_loadStream(const char* filename, FILE* stream);

#endif
