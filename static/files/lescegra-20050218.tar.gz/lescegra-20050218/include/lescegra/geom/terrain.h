/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_TERRAIN_H
#define LSG_TERRAIN_H 1

/**
 * \file  terrain.h
 * \brief Heightfield/Terrain
 */

#include <lescegra/sg/gllist.h>

#include <lescegra/base/vertex.h>
#include <lescegra/util/image.h>

typedef struct LsgTerrain LsgTerrain;
typedef struct LsgTerrainClass LsgTerrainClass;

/**
 * \ingroup geometry
 * \brief   Heightfield/Terrain
 *
 * Heightfield/Terrain using a single OpenGL list to store vertex /
 * normal data.
 */
struct LsgTerrain {
    LsgGLList parent;
};

struct LsgTerrainClass {
    LsgGLListClass parent;
};

LsgClassID LsgTerrain_classID(void);

#define IS_LSG_TERRAIN(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgTerrain_classID())

#define LSG_TERRAIN(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgTerrain*, LsgTerrain_classID(), (instance))

#define LSG_TERRAIN_CLASS(class) \
    LSG_CLASS_INSTANCE_CAST(LsgTerrainClass*, LsgTerrain_classID(), (class))

/**
 * \relates LsgTerrain
 * Allocate and initialize a terrain node.
 * @param hf        The bitmap used to construct the terrain
 * @param dim       The dimension of the constructed terrain
 * @return A new terrain node
 */
LsgTerrain* LsgTerrain_create(LsgImage* hf, Vertex dim);

/**
 * \relates LsgTerrain
 * Constructor method for LsgTerrain. Convert a bitmaps pixel values to vertices
 * and store them in an OpenGL list alongside with calculated normals.
 * @param self      The instance variable
 * @param hf        The bitmap used to construct the terrain
 * @param dim       The dimension of the constructed terrain
 */
void LsgTerrain_init(LsgTerrain* self, LsgImage* hf, Vertex dim);

#endif
