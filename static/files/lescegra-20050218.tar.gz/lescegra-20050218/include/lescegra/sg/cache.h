/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_CACHE_H
#define LSG_CACHE_H 1

/**
 * \file  cache.h
 * \brief Render cache
 */

#include <lescegra/sg/group.h>

typedef struct LsgCache LsgCache;
typedef struct LsgCacheClass LsgCacheClass;

/**
 * \brief Render cache
 *
 * Cache sub nodes in an OpenGL list for faster rendering. The dirty flag
 * is used to force an update of the cache.
 */
struct LsgCache {
    LsgGroup parent;

    int list;
    int valid;
};

struct LsgCacheClass {
    LsgGroupClass parent;
};

LsgClassID LsgCache_classID(void);

#define IS_LSG_CACHE(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgCache_classID())

#define LSG_CACHE(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgCache*, LsgCache_classID(), (instance))

#define LSG_CACHE_CLASS(class) \
    LSG_CLASS_CAST(LsgCacheClass*, LsgCache_classID(), (class))

LsgCache* LsgCache_create(void);
void LsgCache_init(LsgCache* self);

#endif
