/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_OBSERVERCAM_H
#define LSG_OBSERVERCAM_H 1

/**
 * \file  observercam.h
 * \brief Perspective camera with location and heading
 */

#include <lescegra/sg/camera.h>

#include <lescegra/base/vertex.h>

typedef struct LsgObserverCam LsgObserverCam;
typedef struct LsgObserverCamClass LsgObserverCamClass;

/**
 * \brief Perspective camera with location and heading
 *
 * A perspective camera that is defined by the three vertices location, heading
 * and up, the field-of-view and a minimal and maximal viewing distance.
 */
struct LsgObserverCam {
    LsgCamera parent;

    Vertex location;
    Vertex heading;
    Vertex up;
    float fovy;
    float aspect;
    float dmin;
    float dmax;
};

struct LsgObserverCamClass {
    LsgCameraClass parent;
};

LsgClassID LsgObserverCam_classID(void);

#define IS_LSG_OBSERVER_CAM(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgObserverCam_classID())

#define LSG_OBSERVER_CAM(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgObserverCam*, LsgObserverCam_classID(), (instance))

#define LSG_OBSERVER_CAM_CLASS(class) \
    LSG_CLASS_CAST(LsgObserverCamClass*, LsgObserverCam_classID(), (class))

/**
 * \relates LsgObserverCam
 * Allocate and initialize a LsgObserverCam.
 * @return A new LsgObserverCam instance
 */
LsgObserverCam* LsgObserverCam_create(void);

/**
 * \relates LsgObserverCam
 * Constructor method for LsgObserverCam. Initialize the LsgCamera as looking from
 * {0, 0, -1} along the positive z axis with the second (y) axis being up. The
 * initial field-of-view is 45 degrees in both directions.
 * @param self      The instance variable
 */
void LsgObserverCam_init(LsgObserverCam* self);

#endif
