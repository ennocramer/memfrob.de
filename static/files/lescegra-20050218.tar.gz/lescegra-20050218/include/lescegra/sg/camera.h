/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_CAMERA_H
#define LSG_CAMERA_H 1

/**
 * \file  camera.h
 * \brief Abstract camera interface
 */

#include <lescegra/base/object.h>

#include <lescegra/coll/frustum.h>
#include <lescegra/sg/node.h>

typedef struct LsgCamera LsgCamera;
typedef struct LsgCameraClass LsgCameraClass;

/**
 * \brief Abstract camera interface
 */
struct LsgCamera {
    LsgObject parent;
};

struct LsgCameraClass {
    LsgObjectClass parent;

    void (*load)(const LsgCamera* self, Matrix proj, Matrix mview);
};

LsgClassID LsgCamera_classID(void);

#define IS_LSG_CAMERA(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgCamera_classID())

#define LSG_CAMERA(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgCamera*, LsgCamera_classID(), (instance))

#define LSG_CAMERA_CLASS(class) \
    LSG_CLASS_CAST(LsgCameraClass*, LsgCamera_classID(), (class))

/**
 * \relates LsgCamera
 * Constructor method for LsgCamera. Does nearly nothing.
 * @param self      The instance variable
 */
void LsgCamera_init(LsgCamera* self);

/**
 * \relates LsgCamera
 * Load projection and modelview transformation matrizes.
 * @param self      The instance variable
 * @param proj      Buffer for the projective transformation
 * @param mview     Buffer for the modelview transformation
 */
void LsgCamera_load(const LsgCamera* self, Matrix proj, Matrix mview);

/**
 * \relates LsgCamera
 * Display node as seen through this camera.
 * @param self      The instance variable
 * @param frustum   The initial view frustum
 * @param node      The node to display
 */
void LsgCamera_display(const LsgCamera* self, const LsgFrustum* frustum, const LsgNode* node);

#endif
