/**
 * \page pg_usage Usage
 *
 * \section pg_usage_structure Program Structure
 *
 * A program that utilizes Lescegra to create 3D graphics roughly has
 * the following structure:
 *
 * -# initialize the display mode
 * -# set up the scene graph
 * -# run the update-display loop
 *   -# update the scene graph
 *   -# display the scene
 *
 * \note When using callback driven toolkits like GLUT the
 * update-display loop is replaced by a timeout handler repeatedly
 * updating the scene graph and triggering the redisplay of the scene.
 *
 *
 *
 * \section pg_usage_initvideo Initialize the Display Mode
 *
 * Before you can start using lescegra, you have to set up the OpenGL
 * display mode. This mostly means creating a window for your
 * application and enabling all OpenGL features you want to use.
 *
 * \b Example:
 * \code
 * void init_display(void) {
 *     // create a window (this is GLUT specific)
 *     glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
 *     glutCreateWindow("lescegra sample application");
 *
 *     // enable OpenGL features
 *     glEnable(GL_DEPTH_TEST);
 *     glEnable(GL_CULL_FACE);
 *
 *     glCullFace(GL_BACK);
 *
 *     glClearColor(0.0, 0.0, 0.0, 0.0);
 * }
 * \endcode
 *
 *
 *
 * \section pg_usage_setupscene Setting up the Scene
 *
 * After initializing the OpenGL display mode you have to set up your
 * scene graph and a suitable camera.
 *
 * \b Example:
 * \code
 * // out camera
 * static LsgCamera* camera;
 * // the root node for our scene graph
 * static LsgNode* scene;
 *
 * void init_scene(void) {
 *     LsgPerspectiveCam* pcam;
 *     LsgCoords* coords;
 *
 *     // create a camera
 *     pcam = LsgPerspectiveCam_create();
 *     vertex_assign(pcam->location, 3.0, 4.0, 2.0);
 *     vertex_assign(pcam->lookat,   0.0, 0.0, 0.0);
 *     vertex_assign(pcam->up,       0.0, 1.0, 0.0);
 *     pcam->fovy =   45.0;
 *     pcam->aspect =  1.0;
 *     pcam->dmin =    0.1;
 *     pcam->dmax =   10.0;
 *
 *     // create some geometry
 *     coords = LsgCoords_create(1.0);
 *
 *     // keep camera and root node for update and display
 *     camera = LSG_CAMERA(pcam);
 *     scene  = LSG_NODE(coords);
 * }
 * \endcode
 *
 *
 *
 * \section pg_usage_display Rendering the Scene
 *
 * To display your scene you have to do the following steps:
 * -# clear the screen
 * -# initialize the modelview and projection matrix
 * -# create the correct view frustum
 * -# render the scene with a camera
 * -# flush the OpenGL pipeline
 * -# swap the display buffers
 *
 * \note Steps 2 and 3 can mostly be moved into the program
 * initialization phase as the display process should restore the
 * transformation matrizes and the view frustum.
 *
 * \b Example:
 * \code
 * void display(void) {
 *     static LsgFrustum* viewfrustum = NULL;
 *
 *     if (!viewfrustum)
 *         viewfrustum = LsgFrustum_create(matrix_identity, matrix_identity);
 *
 *     // clear the screen
 *     glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
 *
 *     // reset transformation matrizes
 *     glMatrixMode(GL_PROJECTION);
 *     glLoadIdentity();
 *     glMatrixMode(GL_MODELVIEW);
 *     glLoadIdentity();
 *
 *     // this is where the real work is done
 *     LsgCamera_display(camera, viewfrustum, scene);
 *
 *     // force rendering
 *     glFlush();
 *     glutSwapBuffers();
 * }
 * \endcode
 */
