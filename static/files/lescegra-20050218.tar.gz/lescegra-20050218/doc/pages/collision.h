/**
 * \page pg_coll                      Collision Detection
 *
 * Every node can define an appropriate bounding volume to be used for
 * visibility determination and collision detection. A reference to
 * the bounding volume has to be provided in the \c bvolume member of
 * LsgNode.
 *
 * A node without a bounding volume or with an invalid bounding volume
 * will always be rendered and will invalidates its parent nodes
 * bounding volume.
 *
 *
 *
 * \section pg_coll_api               Interface
 *
 * The bounding volume base class is LsgBVolume. It defines a set of
 * virtual methods for visibility determination and collision
 * detection.
 *
 * \dontinclude bvolume.h
 * \skipline struct LsgBVolume {
 * \until }
 * \skipline struct LsgBVolumeClass {
 * \until }
 *
 *
 * \subsection pg_coll_api_frustum    View Frustum Culling
 *
 * \dontinclude bvolume.h
 * \skipline LsgBVolume_visible
 * \param self      A bounding volume
 * \param vf        The view frustum in local coordinates
 * \return 0 if the bounding volume is completely outside of the view
 *         frustum
 *
 * Checks if any part of the bounding volume is visible (inside the
 * current view frustum).
 *
 *
 * \subsection pg_coll_api_vertex     Vertex Collision
 *
 * \dontinclude bvolume.h
 * \skipline LsgBVolume_collideVertex
 * \param self      A bounding volume
 * \param v         A vertex
 * \param hits      A list to store eventual collision hits
 *
 * Checks if the vertex \c v is inside the bounding volume \c self and
 * appends the corresponding \c LsgHit objects to \c hits.
 *
 *
 * \subsection pg_coll_api_ray        Ray Collision
 *
 * \dontinclude bvolume.h
 * \skipline LsgBVolume_collideRay
 * \param self      A bounding volume
 * \param from      The ray starting point
 * \param direction The ray direction
 * \param hits      A List to store eventual collision hits
 *
 * Checks if the ray defined by \c from and \c direction intersects
 * with the bounding volume \c self. Any intersections are appended to
 * \c hits.
 *
 *
 * \subsection pg_coll_api_sphere     Sphere Collision
 *
 * \dontinclude bvolume.h
 * \skipline LsgBVolume_collideSphere
 * \param self      A bounding volume
 * \param center    The sphere center
 * \param radius    The sphere radius
 * \param hits      A List to store eventual collision hits
 *
 * Checks if the sphere defined by \c center and \c radius intersects
 * with the bounding volume \c self. Any intersections are appended to
 * \c hits.
 *
 *
 *
 * \section pg_coll_gp                General Purpose Bounding Volumes
 *
 * Often, especially for visibility determination, it is not necessary
 * to implement a specific bounding volume for geometry nodes. A
 * generic bounding volume, like a box or sphere, is often completely
 * sufficient.
 *
 * Therefore Lescegra provides a set of generic bounding volumes that
 * can be used directly with any geometry.
 *
 * \dontinclude bvolume.h
 * \skipline struct LsgGenericBVolume {
 * \until }
 * \skipline struct LsgGenericBVolumeClass {
 * \until }
 *
 *
 * \subsection pg_coll_gp_sphere      Bounding Sphere
 *
 * The class LsgBSphere defines a generic Bounding Sphere specified by
 * its center and radius.
 *
 * \note This class is not implemented yet.
 *
 *
 * \subsection pg_coll_gp_box         Bounding Box
 *
 * The class LsgBBox defines a generic Axis Aligned Bounding Box
 * (AABB) specified by its near lower left corner and far upper right
 * corner.
 *
 *
 * \subsection pg_coll_gb_include     Merging a Vertex into a Bounding Volume
 *
 * \dontinclude bvolume.h
 * \skipline LsgGenericBVolume_include
 * \param self      A generic bounding volume
 * \param v         A vertex
 *
 * Extend the bounding volume to include a given vertex.
 *
 *
 * \subsection pg_coll_custom_merge   Merging Two Bounding Volumes
 *
 * \dontinclude bvolume.h
 * \skipline LsgBVolume_merge
 * \param self      A bounding volume
 * \param target    A generic target bounding volume
 *
 * Merge the bounding volume into a generic bounding volume. This is
 * achieved by including a list of vertices that form a convex volume
 * including this bounding volume.
 */
