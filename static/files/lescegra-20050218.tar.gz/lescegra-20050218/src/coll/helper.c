#include <lescegra/coll/helper.h>

#include <stddef.h>
#include <math.h>

#ifndef M_PI
#define M_PI		3.14159265358979323846
#endif

LsgHit* LsgTriangle_collideRay(const Vertex v1, const Vertex v2, const Vertex v3, const Vertex from, const Vertex direction) {
    LsgHit* hit;
    Vertex edge[3];
    Vertex p[3];
    Vertex intersection, n;
    float d;

    /* build triangle edge vectors */
    vertex_copy(edge[0], v2);
    vertex_sub(edge[0], v1);
    vertex_normalize(edge[0]);
    vertex_copy(edge[1], v3);
    vertex_sub(edge[1], v2);
    vertex_normalize(edge[0]);
    vertex_copy(edge[2], v1);
    vertex_sub(edge[2], v3);
    vertex_normalize(edge[0]);

    /* calculate plane normal */
    vertex_copy(n, edge[0]);
    vertex_cross(n, edge[1]);
    vertex_normalize(n);

    d = 1.0  / vertex_dot(n, direction);

    /* if the ray and the plane are collinear, we get 1.0 / 0.0 --> NaN
     * which you can check by inequality to itself. we assume no collision
     * in the case of collinear ray and plane. */
    if (d != d) return NULL;

    /* calculate ray - plane intersection */
    vertex_copy(intersection, v1);
    vertex_sub(intersection, from);
    d *= vertex_dot(intersection, n);

    if (d < 0.0) return NULL; /* ray going away from plane */

    vertex_copy(intersection, direction);
    vertex_scale(intersection, d);
    vertex_add(intersection, from);

    /* compute direction vertex from each triangle corner to intersection point */
    vertex_copy(p[0], intersection);
    vertex_sub(p[0], v1);
    vertex_normalize(p[0]);
    vertex_copy(p[1], intersection);
    vertex_sub(p[1], v2);
    vertex_normalize(p[1]);
    vertex_copy(p[2], intersection);
    vertex_sub(p[2], v3);
    vertex_normalize(p[2]);

    /* check if the intersection is inside the triangle */
    if (acos(vertex_dot(p[0], p[2])) +
        acos(vertex_dot(p[1], p[0])) +
        acos(vertex_dot(p[2], p[1])) >= 1.99 * M_PI) {

        hit = LsgHit_create();
        vertex_copy(hit->normal, n);
        vertex_copy(hit->intersection, intersection);

        return hit;
    }

    return NULL;
}

LsgHit* LsgTriangle_collideSphere(const Vertex v1, const Vertex v2, const Vertex v3, const Vertex center, float radius) {
    LsgHit* hit;
    Vertex edge[3];
    Vertex p[3];
    Vertex ctr_proj, n, ep, ed;
    float d;

    /* build triangle edge vectors */
    vertex_copy(edge[0], v2);
    vertex_sub(edge[0], v1);
    vertex_normalize(edge[0]);
    vertex_copy(edge[1], v3);
    vertex_sub(edge[1], v2);
    vertex_normalize(edge[0]);
    vertex_copy(edge[2], v1);
    vertex_sub(edge[2], v3);
    vertex_normalize(edge[0]);

    /* calculate plane normal */
    vertex_copy(n, edge[0]);
    vertex_cross(n, edge[1]);
    vertex_normalize(n);

    /* calculate sphere center relative to first plane corner */
    vertex_copy(ctr_proj, center);
    vertex_sub(ctr_proj, v1);

    /* trivial reject (distance to triangle plane greater than sphere radius) */
    if (fabs(d = vertex_dot(ctr_proj, n)) > radius) return NULL;

    /* project sphere center onto triangle plane */
    vertex_copy(ctr_proj, n);
    vertex_scale(ctr_proj, -d);
    vertex_add(ctr_proj, center);

    /* compute direction vertex from each triangle corner to projected sphere center */
    vertex_copy(p[0], ctr_proj);
    vertex_sub(p[0], v1);
    vertex_copy(p[1], ctr_proj);
    vertex_sub(p[1], v2);
    vertex_copy(p[2], ctr_proj);
    vertex_sub(p[2], v3);

    /* check if the projected sphere center is inside the triangle */
    if (acos(vertex_dot(p[0], p[2]) / (vertex_length(p[0]) * vertex_length(p[2]))) +
        acos(vertex_dot(p[1], p[0]) / (vertex_length(p[1]) * vertex_length(p[0]))) +
        acos(vertex_dot(p[2], p[1]) / (vertex_length(p[2]) * vertex_length(p[1]))) >= 1.99 * M_PI) {

        hit = LsgHit_create();
        vertex_copy(hit->normal, n);
        vertex_copy(hit->intersection, ctr_proj);

        return hit;
    }

    /* sphere edge intersection test */
    /* edge v1 -> v2 */
    vertex_copy(ep, edge[0]);
    vertex_scale(ep, vertex_dot(ep, p[0]));
    vertex_add(ep, v1);

    vertex_copy(ed, center);
    vertex_sub(ed, ep);
    if (vertex_length(ed) <= radius) {
        hit = LsgHit_create();

        vertex_copy(hit->normal, n);
        vertex_copy(hit->intersection, ep);

        return hit;
    }

    /* edge v2 -> 32 */
    vertex_copy(ep, edge[1]);
    vertex_scale(ep, vertex_dot(ep, p[1]));
    vertex_add(ep, v2);

    vertex_copy(ed, center);
    vertex_sub(ed, ep);
    if (vertex_length(ed) <= radius) {
        hit = LsgHit_create();

        vertex_copy(hit->normal, n);
        vertex_copy(hit->intersection, ep);

        return hit;
    }

    /* edge v3 -> v1 */
    vertex_copy(ep, edge[2]);
    vertex_scale(ep, vertex_dot(ep, p[2]));
    vertex_add(ep, v3);

    vertex_copy(ed, center);
    vertex_sub(ed, ep);
    if (vertex_length(ed) <= radius) {
        hit = LsgHit_create();

        vertex_copy(hit->normal, n);
        vertex_copy(hit->intersection, ep);

        return hit;
    }

    return NULL;
}

int LsgSphere_visible(const Vertex center, float radius, const LsgFrustum* frustum) {
    int p;

    for (p = 0; p < 6; ++p) {
        if (vertex_dot(frustum->planes[p].normal, center) +
            frustum->planes[p].distance + radius < 0)
            return 0;
    }

    return 1;
}
