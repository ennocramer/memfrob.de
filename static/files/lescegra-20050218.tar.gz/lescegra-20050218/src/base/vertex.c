#include <lescegra/base/vertex.h>

#include <string.h>
#include <math.h>

void vertex_assign(Vertex dst, float x, float y, float z) {
    dst[0] = x;
    dst[1] = y;
    dst[2] = z;
}

void vertex_copy(Vertex dst, const Vertex src) {
    memcpy(dst, src, sizeof(Vertex));
}

void vertex_add(Vertex dst, const Vertex src) {
    dst[0] += src[0];
    dst[1] += src[1];
    dst[2] += src[2];
}

void vertex_sub(Vertex dst, const Vertex src) {
    dst[0] -= src[0];
    dst[1] -= src[1];
    dst[2] -= src[2];
}

void vertex_mul(Vertex dst, const Vertex src) {
    dst[0] *= src[0];
    dst[1] *= src[1];
    dst[2] *= src[2];
}

void vertex_div(Vertex dst, const Vertex src) {
    dst[0] /= src[0];
    dst[1] /= src[1];
    dst[2] /= src[2];
}

#define MIN(a, b) a < b ? a : b
void vertex_min(Vertex dst, const Vertex src) {
    dst[0] = MIN(dst[0], src[0]);
    dst[1] = MIN(dst[1], src[1]);
    dst[2] = MIN(dst[2], src[2]);
}

#define MAX(a, b) a > b ? a : b
void vertex_max(Vertex dst, const Vertex src) {
    dst[0] = MAX(dst[0], src[0]);
    dst[1] = MAX(dst[1], src[1]);
    dst[2] = MAX(dst[2], src[2]);
}

void vertex_scale(Vertex dst, float scale) {
    dst[0] *= scale;
    dst[1] *= scale;
    dst[2] *= scale;
}

float vertex_dot(const Vertex a, const Vertex b) {
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

void vertex_cross(Vertex dst, const Vertex src) {
    float a, b, c;
    
    a = dst[1] * src[2] - dst[2] * src[1];
    b = dst[2] * src[0] - dst[0] * src[2];
    c = dst[0] * src[1] - dst[1] * src[0];
    
    dst[0] = a;
    dst[1] = b;
    dst[2] = c;
}

float vertex_length(const Vertex src) {
    return sqrt(src[0]*src[0] + src[1]*src[1] + src[2]*src[2]);
}

void vertex_normalize(Vertex dst) {
    float len;
    
    len = vertex_length(dst);
    if (len) {
        vertex_scale(dst, 1.0 / len);
    }
}
