#include <lescegra/particle/gravity.h>

#include <lescegra/util/arraylist.h>

#include <stdlib.h>

static void LsgParticleGravity_update(
    LsgParticleGravity*,
    LsgParticleSystem*,
    float
);

static void LsgParticleGravity_staticInit(
    LsgParticleGravityClass* class,
    LsgParticleGravity* instance
) {
    ((LsgParticleModifierClass*)class)->update =
        (void (*)(LsgParticleModifier*, LsgParticleSystem*, float))LsgParticleGravity_update;

    instance->mass = 1.0;
}

LsgClassID LsgParticleGravity_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgParticleGravity",
            LsgParticleModifier_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgParticleGravityClass),
            sizeof(LsgParticleGravity),
            (LsgClassStaticInitializer)LsgParticleGravity_staticInit
        );
    }

    return classid;
}

LsgParticleGravity* LsgParticleGravity_create(void) {
    LsgParticleGravity* self =
        (LsgParticleGravity*)LsgClass_alloc(LsgParticleGravity_classID());

    if (self)
        LsgParticleGravity_init(self);

    return self;
}

void LsgParticleGravity_init(LsgParticleGravity* self) {
    LsgParticleModifier_init(&self->parent);
}

static void LsgParticleGravity_update(
    LsgParticleGravity* self,
    LsgParticleSystem* system,
    float time
) {
    LsgList* list;
    LsgIterator* it;
    Vertex diff;
    float dist;

    list = LSG_LIST(LsgArrayList_create());
    LsgOctree_getAll(system->system, list);
    it = LsgList_iterator(list);
    while (LsgIterator_hasNext(it)) {
        LsgParticle* p = (LsgParticle*)LsgIterator_next(it);

        vertex_copy(diff, self->parent.particle.location);
        vertex_sub(diff, p->location);

        dist = vertex_length(diff);
        vertex_scale(diff, self->mass / (dist * dist * dist));

        vertex_add(p->acceleration, diff);
    }
    LsgObject_free(LSG_OBJECT(it));
    LsgObject_free(LSG_OBJECT(list));
}
