#include <lescegra/sg/name.h>

#include <GL/gl.h>
#include <stdlib.h>

static void LsgName_display(const LsgName*, const LsgFrustum*);

static void LsgName_staticInit(LsgNameClass* class, LsgName* instance) {
    ((LsgNodeClass*)class)->display = (void (*)(const LsgNode*, const LsgFrustum*))LsgName_display;

    instance->name = 0;
}

static LsgNodeClass* s_pclass = NULL;

LsgClassID LsgName_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgName",
            LsgGroup_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgNameClass),
            sizeof(LsgName),
            (LsgClassStaticInitializer)LsgName_staticInit
        );

        s_pclass = LSG_NODE_CLASS(LsgClass_getParentClass(classid));
    }

    return classid;
}

LsgName* LsgName_create(int name) {
    LsgName* self = (LsgName*)LsgClass_alloc(LsgName_classID());

    if (self)
        LsgName_init(self, name);

    return self;
}

void LsgName_init(LsgName* self, int name) {
    LsgGroup_init(&self->parent);

    self->name = name;
}

static void LsgName_display(const LsgName* self, const LsgFrustum* frust) {
    glPushName(self->name);
    s_pclass->display((LsgNode*)self, frust);
    glPopName();
}
