#include <lescegra/sg/gllist.h>

#include <GL/gl.h>

#include <stdlib.h>
#include <math.h>

static void LsgGLList_display(const LsgGLList* self, const LsgFrustum* frust);
static void LsgGLList_destroy(LsgGLList* self);

static void LsgGLList_staticInit(LsgGLListClass* class, LsgGLList* instance) {
    ((LsgNodeClass*)class)->display = (void (*)(const LsgNode*, const LsgFrustum*))LsgGLList_display;

    ((LsgObjectClass*)class)->destroy = (void (*)(LsgObject*))LsgGLList_destroy;

    instance->list = 0;
}

static LsgObjectClass* s_pclass = NULL;

LsgClassID LsgGLList_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgGLList",
            LsgNode_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgGLListClass),
            sizeof(LsgGLList),
            (LsgClassStaticInitializer)LsgGLList_staticInit
        );

        s_pclass = LSG_OBJECT_CLASS(LsgClass_getParentClass(classid));
    }

    return classid;
}

LsgGLList* LsgGLList_create(void) {
    LsgGLList* self = (LsgGLList*)LsgClass_alloc(LsgGLList_classID());

    if (self)
        LsgGLList_init(self);

    return self;
}

void LsgGLList_init(LsgGLList* self) {
    LsgNode_init(&self->parent);

    self->list = glGenLists(1);
}

static void LsgGLList_display(const LsgGLList* self, const LsgFrustum* frust) {
    glCallList(self->list);
}

static void LsgGLList_destroy(LsgGLList* self) {
    glDeleteLists(self->list, 1);

    s_pclass->destroy((LsgObject*)self);
}
