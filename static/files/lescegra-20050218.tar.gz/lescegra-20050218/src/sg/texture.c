#include <lescegra/sg/texture.h>

#include <GL/gl.h>

#include <stdlib.h>

static void LsgTexture_destroy(LsgTexture*);

static void LsgTexture_staticInit(LsgTextureClass* class, LsgTexture* instance) {
    ((LsgObjectClass*)class)->destroy =
        (void (*)(LsgObject*))LsgTexture_destroy;

    instance->id   = 0;
    instance->mode = 0;
}

static LsgObjectClass* s_pclass = NULL;

LsgClassID LsgTexture_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgTexture",
            LsgObject_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgTextureClass),
            sizeof(LsgTexture),
            (LsgClassStaticInitializer)LsgTexture_staticInit
        );

        s_pclass = LSG_OBJECT_CLASS(LsgClass_getParentClass(classid));
    }

    return classid;
}

LsgTexture* LsgTexture_create(LsgImage* data, int type, unsigned int mode) {
    LsgTexture* self = (LsgTexture*)LsgClass_alloc(LsgTexture_classID());

    if (self)
        LsgTexture_init(self, data, type, mode);

    return self;
}

void LsgTexture_init(LsgTexture* self, LsgImage* data, int type, unsigned int mode) {
    GLenum format;

    LsgObject_init(&self->parent);

    glGenTextures(1, &self->id);
    self->mode = mode;

    switch (data->bpp) {
        case 1:
            format = GL_LUMINANCE;
            break;

        case 2:
            format = GL_LUMINANCE_ALPHA;
            break;

        case 3:
            format = GL_RGB;
            break;

        case 4:
            format = GL_RGBA;
            break;

        default:
            format = 0;
            break;
    }

    glPushAttrib(GL_TEXTURE_BIT);

    glBindTexture(GL_TEXTURE_2D, self->id);

    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

    /* LsgImage.data is byte aligned */
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    glTexImage2D(
        GL_TEXTURE_2D, 0,
        type, data->width, data->height, 0,
        format, GL_UNSIGNED_BYTE, data->data
    );

    glPopAttrib();
}

static void LsgTexture_destroy(LsgTexture* self) {
    glDeleteTextures(1, &self->id);

    s_pclass->destroy((LsgObject*)self);
}
