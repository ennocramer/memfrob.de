#include <lescegra/sg/state.h>

#include <stdlib.h>

static void LsgState_apply_impl(const LsgState* self);
static void LsgState_restore_impl(const LsgState* self);

static void LsgState_staticInit(LsgStateClass* class, LsgState* instance) {
    class->apply   = LsgState_apply_impl;
    class->restore = LsgState_restore_impl;
}

LsgClassID LsgState_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgState",
            LsgObject_classID(),
            LSG_CLASS_FLAG_ABSTRACT,
            sizeof(LsgStateClass),
            sizeof(LsgState),
            (LsgClassStaticInitializer)LsgState_staticInit
        );
    }

    return classid;
}

void LsgState_init(LsgState* self) {
    LsgObject_init(&self->parent);
}

static void LsgState_apply_impl(const LsgState* self) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgState_classID(), "apply");
}

void LsgState_apply(const LsgState* self) {
    LsgStateClass* class = (LsgStateClass*)((LsgClassInstance*)self)->class;

    class->apply(self);
}

static void LsgState_restore_impl(const LsgState* self) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgState_classID(), "restore");
}

void LsgState_restore(const LsgState* self) {
    LsgStateClass* class = (LsgStateClass*)((LsgClassInstance*)self)->class;

    class->restore(self);
}
