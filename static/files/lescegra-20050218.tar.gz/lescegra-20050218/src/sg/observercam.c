#include <lescegra/sg/observercam.h>

#ifndef M_PI
# define M_PI		3.14159265358979323846	/* pi */
#endif

static void LsgObserverCam_load(
    const LsgObserverCam*,
    Matrix proj,
    Matrix mview
);

static void LsgObserverCam_staticInit(
    LsgObserverCamClass* class,
    LsgObserverCam* instance
) {
    ((LsgCameraClass*)class)->load =
        (void (*)(const LsgCamera*, Matrix, Matrix))LsgObserverCam_load;

    vertex_assign(instance->location, 0.0, 0.0, -1.0);
    vertex_assign(instance->heading,  0.0, 0.0, 1.0);
    vertex_assign(instance->up,       0.0, 1.0, 0.0);

    instance->fovy   = 45.0;
    instance->aspect = 1.0;
    instance->dmin   = 0.01;
    instance->dmax   = 10.0;
}

LsgClassID LsgObserverCam_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgObserverCam",
            LsgCamera_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgObserverCamClass),
            sizeof(LsgObserverCam),
            (LsgClassStaticInitializer)LsgObserverCam_staticInit
        );
    }

    return classid;
}

LsgObserverCam* LsgObserverCam_create(void) {
    LsgObserverCam* self =
        (LsgObserverCam*)LsgClass_alloc(LsgObserverCam_classID());

    if (self)
        LsgObserverCam_init(self);

    return self;
}

void LsgObserverCam_init(LsgObserverCam* self) {
    LsgCamera_init(&self->parent);
}

static void LsgObserverCam_load(
    const LsgObserverCam* self,
    Matrix proj,
    Matrix mview
) {
    Vertex lookat;

    /* calculate lookat */
    vertex_copy(lookat, self->location);
    vertex_add(lookat, self->heading);

    /* build transformation matrizes */
    matrix_load_perspective(
        proj,
        self->fovy * M_PI / 180.0, self->aspect,
        self->dmin, self->dmax
    );

    matrix_load_lookat(
        mview,
        self->location,
        lookat,
        self->up
    );
}
