#include <lescegra/sg/light.h>

#include <GL/gl.h>

#include <stdlib.h>

static void LsgLight_apply(const LsgLight*);
static void LsgLight_restore(const LsgLight*);

static void LsgLight_staticInit(LsgLightClass* class, LsgLight* instance) {
    ((LsgStateClass*)class)->apply =
        (void (*)(const LsgState* self))LsgLight_apply;
    ((LsgStateClass*)class)->restore =
        (void (*)(const LsgState* self))LsgLight_restore;

    instance->color[0] =
        instance->color[1] =
        instance->color[2] =
        instance->color[3] = 1.0;

    instance->location[0] =
        instance->location[1] =
        instance->location[2] =
        instance->location[3] = 0.0;

    instance->num = 0;
}

LsgClassID LsgLight_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgLight",
            LsgState_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgLightClass),
            sizeof(LsgLight),
            (LsgClassStaticInitializer)LsgLight_staticInit
        );
    }

    return classid;
}

LsgLight* LsgLight_create(int num) {
    LsgLight* self = (LsgLight*)LsgClass_alloc(LsgLight_classID());

    if (self)
        LsgLight_init(self, num);

    return self;
}

void LsgLight_init(LsgLight* self, int num) {
    LsgState_init(&self->parent);

    self->num = num;
}

static void LsgLight_apply(const LsgLight* self) {
    glPushAttrib(GL_LIGHTING_BIT);

    glEnable(GL_LIGHT0 + self->num);

    glLightfv(GL_LIGHT0 + self->num, GL_POSITION, self->location);

    glLightfv(GL_LIGHT0 + self->num, GL_AMBIENT, self->color);
    glLightfv(GL_LIGHT0 + self->num, GL_DIFFUSE, self->color);
    glLightfv(GL_LIGHT0 + self->num, GL_SPECULAR, self->color);
}

static void LsgLight_restore(const LsgLight* self) {
    glPopAttrib();
}
