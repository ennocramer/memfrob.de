#include <lescegra/geom/hterrain.h>

#include <lescegra/util/arraylist.h>
#include <lescegra/coll/bbox.h>

#include <GL/gl.h>

#include <stdlib.h>
#include <float.h>

static void LsgHTerrain_display(const LsgHTerrain*, const LsgFrustum*);
static void LsgHTerrain_destroy(LsgHTerrain*);

static void LsgHTerrain_staticInit(
    LsgHTerrainClass* class,
    LsgHTerrain* instance
) {
    ((LsgNodeClass*)class)->display = 
        (void (*)(const LsgNode*, const LsgFrustum*))LsgHTerrain_display;

    ((LsgObjectClass*)class)->destroy = 
        (void (*)(LsgObject*))LsgHTerrain_destroy;

    instance->frame         = NULL;
    instance->octree        = NULL;
    instance->resolution[0] = 0;
    instance->resolution[1] = 0;
    instance->chunk         = 0;
}

static LsgObjectClass* s_pclass = NULL;

LsgClassID LsgHTerrain_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgHTerrain",
            LsgNode_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgHTerrainClass),
            sizeof(LsgHTerrain),
            (LsgClassStaticInitializer)LsgHTerrain_staticInit
        );

        s_pclass = LSG_OBJECT_CLASS(LsgClass_getParentClass(classid));
    }

    return classid;
}

LsgHTerrain* LsgHTerrain_create(
    const LsgImage* img,
    const Matrix transform,
    int divisions,
    int chunk
) {
    LsgHTerrain* self = (LsgHTerrain*)LsgClass_alloc(LsgHTerrain_classID());

    if (self)
        LsgHTerrain_init(self, img, transform, divisions, chunk);

    return self;
}

#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define FRAME_ELEMENT(self, x, y) ((self)->frame[(y) * (self)->resolution[0] + (x)])

static void LsgHTerrain_buildFrame(
    LsgHTerrain* self,
    const LsgImage* img,
    const Matrix transform
);

void LsgHTerrain_init(
    LsgHTerrain* self,
    const LsgImage* img,
    const Matrix transform,
    int divisions,
    int chunk
) {
    Vertex min, max, v;
    int x_min, x_max, y_min, y_max, y, x, i;

    LsgNode_init(&self->parent);

    self->resolution[0] = img->width;
    self->resolution[1] = img->height;
    self->frame   = (LsgHTerrainFrame*)malloc(
        sizeof(LsgHTerrainFrame) * self->resolution[0] * self->resolution[1]
    );

    /* build bounding box */
    vertex_assign(min, +1.0/0.0, +1.0/0.0, +1.0/0.0);
    vertex_assign(max, -1.0/0.0, -1.0/0.0, -1.0/0.0);
    for (i = 0; i < 7; ++i) {
        vertex_assign(
            v,
            (i / 1) % 2 == 0 ? 0.0 : 1.0,
            (i / 2) % 2 == 0 ? 0.0 : 1.0,
            (i / 4) % 2 == 0 ? 0.0 : 1.0
        );

        matrix_apply(transform, v);
        vertex_min(min, v);
        vertex_max(max, v);
    }

    self->octree = LsgOctree_create(min, max, divisions);
    self->chunk = chunk;

    /* build frame and surface */
    LsgHTerrain_buildFrame(self, img, transform);

    /* fill octree */
    for (y_min = 0; y_min < self->resolution[1] - 1; y_min += chunk) {
        y_max = MIN(y_min + chunk, self->resolution[1] - 1);
        for (x_min = 0; x_min < self->resolution[0] - 1; x_min += chunk) {
            x_max = MIN(x_min + chunk, self->resolution[0] - 1);

            vertex_copy(min, FRAME_ELEMENT(self, x_min, y_min).point);
            vertex_copy(max, FRAME_ELEMENT(self, x_min, y_min).point);

            for (y = y_min; y <= y_max; ++y) {
                for (x = x_min; x <= x_max; ++x) {
                    vertex_min(min, FRAME_ELEMENT(self, x, y).point);
                    vertex_max(max, FRAME_ELEMENT(self, x, y).point);
                }
            }

            /* yeah ... this is evil :)
             * we do not store a pointer in the octree but the array
             * index for the upper left corner of this chunk.
             * assumption: a cast from int to void* and back does not
             * discard any information
             */
            LsgOctree_add(
                self->octree,
                min, max,
                (void*)(y_min * self->resolution[0] + x_min)
            );
        }
    }
}

static void LsgHTerrain_buildFrame(
    LsgHTerrain* self,
    const LsgImage* img,
    const Matrix transform
) {
    Vertex v1, v2;
    int x, y, z, i;
    int xn, xp, yn, yp;
    int idx_src, idx_dst;

    /* calculate points */
    idx_src = idx_dst = -1;
    for (y = 0; y < img->height; ++y) {
        for (x = 0; x < img->width; ++x) {
            for (z = 0, i = 0; i < img->bpp; ++i) {
                z <<= 8;
                z += img->data[++idx_src];
            }

            ++idx_dst;
            vertex_assign(
                self->frame[idx_dst].point,
                (float)x/(float)(img->width - 1),
                (float)y/(float)(img->height - 1),
                (float)z/(float)((1UL << (img->bpp * 8)) - 1)
            );
            matrix_apply(transform, self->frame[idx_dst].point);
        }
    }

    /* calculate vertex normals */
    for (y = 0; y < self->resolution[1]; ++y) {
        yn = MIN(y + 1, self->resolution[1] - 1);
        yp = MAX(y - 1, 0);
        for (x = 0; x < self->resolution[0]; ++x) {
            xn = MIN(x + 1, self->resolution[0] - 1);
            xp = MAX(x - 1, 0);

            vertex_copy(v1, FRAME_ELEMENT(self, xn, y).point);
            vertex_sub(v1, FRAME_ELEMENT(self, xp, y).point);

            vertex_copy(v2, FRAME_ELEMENT(self, x, yn).point);
            vertex_sub(v2, FRAME_ELEMENT(self, x, yp).point);

            vertex_cross(v1, v2);
            vertex_normalize(v1);
            vertex_copy(FRAME_ELEMENT(self, x, y).normal, v1);
        }
    }
}

static void LsgHTerrain_displayOctree(
    const LsgOctree* octree,
    const LsgFrustum* frustum
) {
    int i;

    /* test visibility */
    for (i = 0; i < 6; ++i) {
        if (frustum->planes[i].normal[0] * octree->vmin[0] +
            frustum->planes[i].normal[1] * octree->vmin[1] +
            frustum->planes[i].normal[2] * octree->vmin[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * octree->vmin[0] +
            frustum->planes[i].normal[1] * octree->vmin[1] +
            frustum->planes[i].normal[2] * octree->vmax[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * octree->vmin[0] +
            frustum->planes[i].normal[1] * octree->vmax[1] +
            frustum->planes[i].normal[2] * octree->vmin[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * octree->vmin[0] +
            frustum->planes[i].normal[1] * octree->vmax[1] +
            frustum->planes[i].normal[2] * octree->vmax[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * octree->vmax[0] +
            frustum->planes[i].normal[1] * octree->vmin[1] +
            frustum->planes[i].normal[2] * octree->vmin[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * octree->vmax[0] +
            frustum->planes[i].normal[1] * octree->vmin[1] +
            frustum->planes[i].normal[2] * octree->vmax[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * octree->vmax[0] +
            frustum->planes[i].normal[1] * octree->vmax[1] +
            frustum->planes[i].normal[2] * octree->vmin[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * octree->vmax[0] +
            frustum->planes[i].normal[1] * octree->vmax[1] +
            frustum->planes[i].normal[2] * octree->vmax[2] +
            frustum->planes[i].distance > 0) continue;

        return;
    }

    glBegin(GL_LINES);
    glVertex3f(octree->vmin[0], octree->vmin[1], octree->vmin[2]);
    glVertex3f(octree->vmin[0], octree->vmin[1], octree->vmax[2]);

    glVertex3f(octree->vmin[0], octree->vmin[1], octree->vmin[2]);
    glVertex3f(octree->vmin[0], octree->vmax[1], octree->vmin[2]);

    glVertex3f(octree->vmin[0], octree->vmin[1], octree->vmin[2]);
    glVertex3f(octree->vmax[0], octree->vmin[1], octree->vmin[2]);


    glVertex3f(octree->vmin[0], octree->vmin[1], octree->vmax[2]);
    glVertex3f(octree->vmin[0], octree->vmax[1], octree->vmax[2]);

    glVertex3f(octree->vmin[0], octree->vmin[1], octree->vmax[2]);
    glVertex3f(octree->vmax[0], octree->vmin[1], octree->vmax[2]);


    glVertex3f(octree->vmin[0], octree->vmax[1], octree->vmin[2]);
    glVertex3f(octree->vmin[0], octree->vmax[1], octree->vmax[2]);

    glVertex3f(octree->vmin[0], octree->vmax[1], octree->vmin[2]);
    glVertex3f(octree->vmax[0], octree->vmax[1], octree->vmin[2]);


    glVertex3f(octree->vmax[0], octree->vmin[1], octree->vmin[2]);
    glVertex3f(octree->vmax[0], octree->vmin[1], octree->vmax[2]);

    glVertex3f(octree->vmax[0], octree->vmin[1], octree->vmin[2]);
    glVertex3f(octree->vmax[0], octree->vmax[1], octree->vmin[2]);


    glVertex3f(octree->vmin[0], octree->vmax[1], octree->vmax[2]);
    glVertex3f(octree->vmax[0], octree->vmax[1], octree->vmax[2]);


    glVertex3f(octree->vmax[0], octree->vmin[1], octree->vmax[2]);
    glVertex3f(octree->vmax[0], octree->vmax[1], octree->vmax[2]);


    glVertex3f(octree->vmax[0], octree->vmax[1], octree->vmin[2]);
    glVertex3f(octree->vmax[0], octree->vmax[1], octree->vmax[2]);
    glEnd();

    if (octree->divisions) {
        for (i = 0; i < 8; ++i) {
            if (octree->children[i])
                LsgHTerrain_displayOctree(octree->children[i], frustum);
        }
    }
}

static void LsgHTerrain_display(
    const LsgHTerrain* self,
    const LsgFrustum* frust
) {
    LsgList* list;
    LsgIterator* it;
    int idx, x, y, x_max, x_min, y_max, y_min;

    list = (LsgList*)LsgArrayList_create();
    LsgOctree_getVisible(self->octree, frust, list);

    if (LsgList_count(list)) {
        glPushClientAttrib(GL_CLIENT_VERTEX_ARRAY_BIT);
        glInterleavedArrays(GL_N3F_V3F, 0, self->frame);

        it = LsgList_iterator(list);
        while (LsgIterator_hasNext(it)) {
            idx = (int)LsgIterator_next(it);

            x_min = idx % self->resolution[0];
            x_max = x_min + self->chunk + 1;
            x_max = MIN(x_max, self->resolution[0]);
            y_min = idx / self->resolution[0];
            y_max = y_min + self->chunk;
            y_max = MIN(y_max, self->resolution[1] - 1);

            for (y = y_min; y < y_max; ++y) {
                glBegin(GL_TRIANGLE_STRIP);
                for (x = x_min; x < x_max; ++x) {
                    glArrayElement((y + 1) * self->resolution[0] + x);
                    glArrayElement( y      * self->resolution[0] + x);
                }
                glEnd();
            }
        }
        LsgObject_free((LsgObject*)it);

        glPopClientAttrib();
    }

    LsgObject_free((LsgObject*)list);
}

static void LsgHTerrain_destroy(LsgHTerrain* self) {
    LsgObject_free((LsgObject*)self->octree);

    free(self->frame);

    s_pclass->destroy((LsgObject*)self);
}
