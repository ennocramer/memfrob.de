#include <lescegra/geom/vltme.h>

#include <lescegra/base/error.h>
#include <lescegra/coll/helper.h>

#include <GL/gl.h>

#include <errno.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

#define IDX_SW 0
#define IDX_SE 1
#define IDX_NE 2
#define IDX_NW 3

#define IDX_C  4

#define IDX_S  5
#define IDX_E  6
#define IDX_N  7
#define IDX_W  8

#define QTREE_CHILD_L(apex, base) \
    (4*(apex)-7 + ((2*(apex)+(base)+2) & 3))
#define QTREE_CHILD_R(apex, base) \
    (4*(apex)-7 + ((2*(apex)+(base)+3) & 3))

#define QTREE_COUNT(levels) \
    (((1 << (levels)) - 1) * 5 / 3 + 4)

static void LsgVLTME_refine(
    LsgVLTME_Mesh* mesh,
    const LsgVLTME_MeshParams* params,
    const LsgVLTME_Node* nodes,
    unsigned int level,
    unsigned int apex,
    unsigned int base
);
static void LsgVLTME_appendMesh(
    LsgVLTME_Mesh* mesh,
    unsigned int index,
    unsigned int parity
);

static LsgVLTME_Node* LsgVLTME_convert(
    const LsgImage* img,
    const Matrix tm
);
static void LsgVLTME_computeErrors(
    LsgVLTME_Node* nodes,
    unsigned int resolution,
    unsigned int level
);
static void LsgVLTME_reindex(
    LsgVLTME_Node* qt_nodes,
    unsigned int qt_apex,
    unsigned int qt_base,
    const LsgVLTME_Node* lin_nodes,
    unsigned int lin_apex,
    unsigned int lin_v1,
    unsigned int lin_v2,
    unsigned int level
);

static void LsgVLTME_display(const LsgVLTME* self, const LsgFrustum* frustum);
static void LsgVLTME_destroy(LsgVLTME* self);

static void LsgVLTME_staticInit(LsgVLTMEClass* class, LsgVLTME* instance) {
    ((LsgNodeClass*)class)->display =
        (void (*)(const LsgNode*, const LsgFrustum*))LsgVLTME_display;

    ((LsgObjectClass*)class)->destroy =
        (void (*)(LsgObject*))LsgVLTME_destroy;

    instance->nodes           = NULL;
    instance->levels          = 0;

    instance->mesh            = NULL;

    instance->eye             = NULL;
    instance->error_threshold = 1.0;
}

static LsgObjectClass* s_pclass = NULL;

LsgClassID LsgVLTME_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgVLTME",
            LsgNode_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgVLTMEClass),
            sizeof(LsgVLTME),
            (LsgClassStaticInitializer)LsgVLTME_staticInit
        );

        s_pclass = LSG_OBJECT_CLASS(LsgClass_getParentClass(classid));
    }

    return classid;
}

LsgVLTME* LsgVLTME_create(
    const LsgVLTME_Node* nodes,
    unsigned int levels
) {
    LsgVLTME* self = (LsgVLTME*)LsgClass_alloc(LsgVLTME_classID());

    if (self)
        LsgVLTME_init(self, nodes, levels);

    return self;
}

void LsgVLTME_init(
    LsgVLTME* self,
    const LsgVLTME_Node* nodes,
    unsigned int levels
) {
    self->nodes  = nodes;
    self->levels = levels;

    self->mesh = LsgVLTME_createMesh();
}


LsgVLTME_Mesh* LsgVLTME_createMesh(void) {
    LsgVLTME_Mesh* mesh = malloc(sizeof(LsgVLTME_Mesh));

    mesh->indices = malloc(256 * sizeof(int));
    mesh->size    = 256;
    mesh->count   = 0;
    mesh->parity  = 0;

    return mesh;
}

void LsgVLTME_freeMesh(LsgVLTME_Mesh* mesh) {
    if (mesh)
        free(mesh->indices);

    free(mesh);
}

void LsgVLTME_buildMesh(
    LsgVLTME_Mesh* mesh,
    const LsgVLTME_MeshParams* params,
    const LsgVLTME_Node* nodes,
    unsigned int levels
) {
    unsigned int parity = levels & 0x01;

    mesh->indices[0] = mesh->indices[1] = IDX_SW;
    mesh->count  = 2;
    mesh->parity = parity;

    LsgVLTME_refine(mesh, params, nodes, levels - 1, IDX_C, IDX_S);
    LsgVLTME_appendMesh(mesh, IDX_SE, parity);

    LsgVLTME_refine(mesh, params, nodes, levels - 1, IDX_C, IDX_E);
    LsgVLTME_appendMesh(mesh, IDX_NE, parity);

    LsgVLTME_refine(mesh, params, nodes, levels - 1, IDX_C, IDX_N);
    LsgVLTME_appendMesh(mesh, IDX_NW, parity);

    LsgVLTME_refine(mesh, params, nodes, levels - 1, IDX_C, IDX_W);
    LsgVLTME_appendMesh(mesh, IDX_SW, parity);
}

static void LsgVLTME_display(const LsgVLTME* self, const LsgFrustum* frustum) {
    if (!self->mesh)
        return;

    if (self->eye) {
        LsgVLTME_MeshParams params;

        params.frustum         = frustum;
        params.eye             = self->eye;
        params.error_threshold = self->error_threshold;

        LsgVLTME_buildMesh(self->mesh, &params, self->nodes, self->levels);
    }

    glPushClientAttrib(GL_CLIENT_VERTEX_ARRAY_BIT);
    glInterleavedArrays(GL_N3F_V3F, sizeof(LsgVLTME_Node), self->nodes);

    glDrawElements(
        GL_TRIANGLE_STRIP,
        self->mesh->count - 1, GL_UNSIGNED_INT,
        self->mesh->indices + 1
    );

    glPopClientAttrib();
}

static void LsgVLTME_destroy(LsgVLTME* self) {
    /* TODO: free nodes as needed */
    if (self->mesh)
        LsgVLTME_freeMesh(self->mesh);

    s_pclass->destroy((LsgObject*)self);
}

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

static void LsgVLTME_refine(
    LsgVLTME_Mesh* mesh,
    const LsgVLTME_MeshParams* params,
    const LsgVLTME_Node* nodes,
    unsigned int level,
    unsigned int apex,
    unsigned int base
) {
    const LsgVLTME_Node* node = &nodes[base];
    int recurse = (level != 0);

    /* view dependent error */
    if (recurse) {
        Vertex dist;
        float err_radius;

        err_radius = params->error_threshold * node->error + node->radius;
        err_radius *= err_radius;

        vertex_copy(dist, node->v);
        vertex_sub(dist, *params->eye);

        recurse = err_radius > vertex_dot(dist, dist);
    }

    /* visibility */
    if (recurse)
        recurse = LsgSphere_visible(node->v, node->radius, params->frustum);

    /* build mesh */
    if (recurse)
        LsgVLTME_refine(
            mesh, params, nodes,
            level - 1, base, QTREE_CHILD_L(apex, base)
        );

    LsgVLTME_appendMesh(mesh, apex, level & 0x01);

    if (recurse)
        LsgVLTME_refine(
            mesh, params, nodes,
            level - 1, base, QTREE_CHILD_R(apex, base)
        );
}

static void LsgVLTME_appendMesh(
    LsgVLTME_Mesh* mesh,
    unsigned int index,
    unsigned int parity
) {
    unsigned int tail     = mesh->indices[mesh->count - 1];
    unsigned int pre_tail = mesh->indices[mesh->count - 2];

    if ((index != tail) && (index != pre_tail)) {
        if (mesh->count > (mesh->size - 2)) {
            mesh->size *= 2;
            mesh->indices = realloc(
                mesh->indices, sizeof(unsigned int) * mesh->size
            );
        }

        if (parity == mesh->parity)
            mesh->indices[mesh->count++] = pre_tail;

        mesh->indices[mesh->count++] = index;
        mesh->parity = parity;
    }
}

static LsgVLTME_Node* LsgVLTME_convert(
    const LsgImage* img,
    const Matrix tm
) {
    unsigned int x, y, z, i;

    LsgVLTME_Node* nodes = (LsgVLTME_Node*)malloc(
        img->height * img->width * sizeof(LsgVLTME_Node)
    );

    if (nodes) {
        /* convert pixel -> vertex */
        for (y = 0; y < img->height; ++y) {
            for (x = 0; x < img->width; ++x) {
                for (z = 0, i = 0; i < img->bpp; ++i) 
                    z = (z << 8) | img->data[
                        (y * img->width + x) * img->bpp + i
                    ];

                vertex_assign(
                    nodes[y * img->width + x].v,
                    (float)x/(float)(img->width - 1),
                    (float)y/(float)(img->height - 1),
                    (float)z/(float)((1UL << (img->bpp * 8)) - 1)
                );

                matrix_apply(tm, nodes[y * img->width + x].v);

                nodes[y * img->width + x].error  = 0.0;
                nodes[y * img->width + x].radius = 0.0;
            }                    
        }

        /* compute normals */
        for (y = 0; y < img->height; ++y) {
            unsigned int idx_n = MAX(y, 1) - 1;
            unsigned int idx_s = MIN(y, img->height - 2) + 1;

            for (x = 0; x < img->width; ++x) {
                Vertex v1, v2;
                unsigned int idx_w = MAX(x, 1) - 1;
                unsigned int idx_e = MIN(x, img->width - 2) + 1;
                
                vertex_copy(v1, nodes[idx_s * img->width + idx_e].v);
                vertex_sub(v1, nodes[idx_n * img->width + idx_w].v);

                vertex_copy(v2, nodes[idx_s * img->width + idx_w].v);
                vertex_sub(v2, nodes[idx_n * img->width + idx_e].v);

                vertex_cross(v1, v2);
                vertex_normalize(v1);
                vertex_copy(nodes[y * img->width + x].n, v1);
            }
        }
    }

    return nodes;
}

static void LsgVLTME_computeErrors(
    LsgVLTME_Node* nodes,
    unsigned int resolution,
    unsigned int level
) {
    Vertex v;

    unsigned int dx = 1U << ((level + 2) / 2);
    unsigned int dy = 1U << ((level + 1) / 2);

    unsigned int x, y, i;
    unsigned int x0, y0;

    int pdx, pdy, pdb;
    int cdx, cdy, cdb;

    if (level)
        LsgVLTME_computeErrors(nodes, resolution, level - 1);

    /* parent and child vertex positions */
    if (level % 2) {
        y0  = dy / 2;

        pdx = dx / 2;
        pdy = dy / 2;

        cdx = dx / 2;
        cdy = 0;
    } else {
        y0  = 0;

        pdx = dx / 2;
        pdy = 0;

        cdx =
        cdy = dy / 2;
    }

    /* level 0 has no children, but we can use neighbouring vertices
     * to determine bounding sphere radius. */
    if (level == 0) {
        cdx = 1;
        cdy = 0;
    }

    for (y = y0; y < resolution; y += dy) {
        x0 = (y - y0) % dx ? 0 : dx / 2;
        for (x = x0; x < resolution; x += dx) {
            LsgVLTME_Node* node = &nodes[y * resolution + x];

            /* calculate per vertex error */
            vertex_copy(v, nodes[(y + pdy) * resolution + (x + pdx)].v);
            vertex_add(v, nodes[(y - pdy) * resolution + (x - pdx)].v);
            vertex_scale(v, 0.5);
            vertex_sub(v, node->v);

            node->error = vertex_length(v);

            /* calculate bounding sphere radius */
            node->radius = 0.0;
            for (i = 0; i < 4; ++i) {
                if (
                    ((x + cdx) >= 0) &&
                    ((x + cdx) < resolution) &&
                    ((y + cdy) >= 0) &&
                    ((y + cdy) < resolution)
                ) {
                    LsgVLTME_Node* cnode =
                        &nodes[(y + cdy) * resolution + (x + cdx)];
                    
                    float r;
                    
                    vertex_copy(v, cnode->v);
                    vertex_sub(v,  node->v);
                    r = vertex_length(v);

                    if (level) {
                        node->radius = MAX(node->radius, r + cnode->radius);
                        node->error = MAX(node->error, cnode->error);
                    } else {
                        node->radius = MAX(node->radius, r);
                    }
                }
                    
                cdb = cdy;
                cdy = cdx;
                cdx = -cdb;
            }

            pdx = -pdx;
        }

        pdb = pdy;
        pdy = pdx;
        pdx = -pdb;
    }
}

static void LsgVLTME_reindex(
    LsgVLTME_Node* qt_nodes,
    unsigned int qt_apex,
    unsigned int qt_base,
    const LsgVLTME_Node* lin_nodes,
    unsigned int lin_apex,
    unsigned int lin_v1,
    unsigned int lin_v2,
    unsigned int level
) {
    unsigned int lin_base = (lin_v1 + lin_v2) / 2;

    memcpy(&qt_nodes[qt_base], &lin_nodes[lin_base], sizeof(LsgVLTME_Node));

    if (level) {
        LsgVLTME_reindex(
            qt_nodes,
            qt_base,
            QTREE_CHILD_L(qt_apex, qt_base),
            lin_nodes,
            lin_base,
            lin_v1,
            lin_apex,
            level - 1
        );

        LsgVLTME_reindex(
            qt_nodes,
            qt_base,
            QTREE_CHILD_R(qt_apex, qt_base),
            lin_nodes,
            lin_base,
            lin_apex,
            lin_v2,
            level - 1
        );
    }
}

#define LIN_IDX(x, y) ((y) * resolution + (x))
LsgVLTME* LsgVLTME_createFromImage(
    const LsgImage* img,
    const Matrix transform
) {
    LsgVLTME_Node* qt_nodes;
    LsgVLTME_Node* lin_nodes;
    unsigned int levels;
    unsigned int resolution;

    /* compute number of levels */
    levels = 0;
    while (((0x01U << levels) + 1) < img->width)
        ++levels;

    resolution = (0x01 << levels) + 1;

    /* verify image resolution (2^k + 1) */
    if ((resolution != img->width) || (resolution != img->height)) {
        LsgError_report(
            __FILE__, "LsgVLTME_buildTerrain", __LINE__,
            "invalid image size"
        );
        return 0;
    }

    levels *= 2;

    /* build vertex data */
    lin_nodes = LsgVLTME_convert(img, transform);
    qt_nodes  = (LsgVLTME_Node*)malloc(
        QTREE_COUNT(levels) * sizeof(LsgVLTME_Node)
    );
    
    if (!qt_nodes || !lin_nodes) {
        LsgError_report(
            __FILE__, "LsgVLTME_buildTerrain", __LINE__,
            strerror(ENOMEM)
        );
        free(qt_nodes);
        free(lin_nodes);
        return 0;
    }

    /* compute static error bounds */
    LsgVLTME_computeErrors(lin_nodes, resolution, levels - 1);

    /* copy edge and center nodes */
    memcpy(&qt_nodes[IDX_SW], &lin_nodes[LIN_IDX(0,              resolution - 1)], sizeof(LsgVLTME_Node));
    memcpy(&qt_nodes[IDX_SE], &lin_nodes[LIN_IDX(resolution - 1, resolution - 1)], sizeof(LsgVLTME_Node));
    memcpy(&qt_nodes[IDX_NE], &lin_nodes[LIN_IDX(resolution - 1, 0)],              sizeof(LsgVLTME_Node));
    memcpy(&qt_nodes[IDX_NW], &lin_nodes[LIN_IDX(0,              0)],              sizeof(LsgVLTME_Node));
    memcpy(&qt_nodes[IDX_C],  &lin_nodes[LIN_IDX(resolution / 2, resolution / 2)], sizeof(LsgVLTME_Node));
    
    /* bring vertex data into qtree order */
    LsgVLTME_reindex(
        qt_nodes,
        IDX_C,
        IDX_S,
        lin_nodes,
        LIN_IDX(resolution / 2, resolution / 2),
        LIN_IDX(0,              resolution - 1),
        LIN_IDX(resolution - 1, resolution - 1),
        levels - 2
    );

    LsgVLTME_reindex(
        qt_nodes,
        IDX_C,
        IDX_E,
        lin_nodes,
        LIN_IDX(resolution / 2, resolution / 2),
        LIN_IDX(resolution - 1, resolution - 1),
        LIN_IDX(resolution - 1, 0),
        levels - 2
    );

    LsgVLTME_reindex(
        qt_nodes,
        IDX_C,
        IDX_N,
        lin_nodes,
        LIN_IDX(resolution / 2, resolution / 2),
        LIN_IDX(resolution - 1, 0),
        LIN_IDX(0,              0),
        levels - 2
    );

    LsgVLTME_reindex(
        qt_nodes,
        IDX_C,
        IDX_W,
        lin_nodes,
        LIN_IDX(resolution / 2, resolution / 2),
        LIN_IDX(0,              0),
        LIN_IDX(0,              resolution - 1),
        levels - 2
    );

    /* free linear indexed vertex data */
    free(lin_nodes);

    return LsgVLTME_create(
        qt_nodes,
        levels
    );
}
#undef LIN_IDX
