#include <lescegra/util/features.h>

#include <lescegra/base/error.h>

#define GL_GLEXT_PROTOTYPES
#include <GL/gl.h>
#ifdef HAVE_GL_GLEXT_H
# include <GL/glext.h>
#endif

#include <string.h>
#include <stdlib.h>

static int init = 1;

static const char* vendor;
static const char* version;
static const char* renderer;

static unsigned int gl_version;
    
static char** extensions;
static unsigned int ext_count;

static int num_texture_units;

static void LsgFeatures_init(void) {
    unsigned int ext_cap, i;
    char* c;

    init = 0;

    /* get description */
    vendor   = (const char*)glGetString(GL_VENDOR);
    version  = (const char*)glGetString(GL_VERSION);
    renderer = (const char*)glGetString(GL_RENDERER);

    /* parse gl version */
    gl_version = 0;
    c = (char*)version;
    for (i = 0; i < 3; ++i) {
        gl_version <<= 8;
        gl_version += strtol(c, &c, 10);
        ++c;
    }

    /* get extension string */
    c = malloc(strlen((char*)glGetString(GL_EXTENSIONS)) + 1);
    strcpy(c, (char*)glGetString(GL_EXTENSIONS));

    /* parse extension string */
    ext_cap    = 32;
    ext_count  = 0;
    extensions = malloc(sizeof(char*) * ext_cap);

    do {
        if (ext_count == ext_cap) {
            ext_cap *= 2;
            extensions = realloc(extensions, sizeof(char*) * ext_cap);
        }

        assert(extensions != NULL);
        extensions[ext_count++] = c;
        c = strchr(c, ' ');
        
        if (c)
            *(c++) = 0;
    } while (c != NULL);

    extensions = realloc(extensions, sizeof(char*) * ext_count);

    /* feature checks */
    
    /* multitexturing */
#ifdef GL_ARB_multitexture
    if (
        LsgFeatures_checkVersion(1, 3, 0) ||
        LsgFeatures_checkExtension("GL_ARB_multitexture")
    ) {
        glGetIntegerv(GL_MAX_TEXTURE_UNITS_ARB, &num_texture_units);
    } else
#endif
    {
        num_texture_units = 1;
    }
}

int LsgFeatures_checkVersion(
    int major,
    int minor,
    int patch
) {
    if (init)
        LsgFeatures_init();

    return gl_version >= ((major << 16) + (minor << 8) + patch);
}

int LsgFeatures_checkExtension(
    const char* extension
) {
    int i;

    if (init)
        LsgFeatures_init();

    for (i = 0; i < ext_count; ++i) {
        if (!strcmp(extensions[i], extension))
            return 1;
    }

    return 0;
}

int LsgFeatures_numTextureUnits(void) {
    if (init)
        LsgFeatures_init();

    return num_texture_units;
}
