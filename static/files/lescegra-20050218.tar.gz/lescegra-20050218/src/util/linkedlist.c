#include <lescegra/util/linkedlist.h>

#include <stdlib.h>

static int   LsgLinkedList_count(LsgLinkedList* self);
static int   LsgLinkedList_contains(LsgLinkedList* self, void* object);
static int   LsgLinkedList_index(LsgLinkedList* self, void* object);
static void  LsgLinkedList_append(LsgLinkedList* self, void* object);
static void  LsgLinkedList_insert(LsgLinkedList* self, int index, void* object);
static int   LsgLinkedList_remove(LsgLinkedList* self, void* object);
static void* LsgLinkedList_removeByIndex(LsgLinkedList* self, int index);
static void* LsgLinkedList_set(LsgLinkedList* self, int index, void* object);
static void* LsgLinkedList_get(LsgLinkedList* self, int index);
static void  LsgLinkedList_clear(LsgLinkedList* self);
static LsgLinkedListIterator* LsgLinkedList_iterator(LsgLinkedList* self);
static void  LsgLinkedList_destroy(LsgLinkedList* self);

static void LsgLinkedList_staticInit(LsgLinkedListClass* class, LsgLinkedList* instance) {
    ((LsgListClass*)class)->count         = (int   (*)(LsgList*))LsgLinkedList_count;
    ((LsgListClass*)class)->contains      = (int   (*)(LsgList*, void*))LsgLinkedList_contains;
    ((LsgListClass*)class)->index         = (int   (*)(LsgList*, void*))LsgLinkedList_index;
    ((LsgListClass*)class)->append        = (void  (*)(LsgList*, void*))LsgLinkedList_append;
    ((LsgListClass*)class)->insert        = (void  (*)(LsgList*, int, void*))LsgLinkedList_insert;
    ((LsgListClass*)class)->remove        = (int   (*)(LsgList*, void*))LsgLinkedList_remove;
    ((LsgListClass*)class)->removeByIndex = (void* (*)(LsgList*, int))LsgLinkedList_removeByIndex;
    ((LsgListClass*)class)->set           = (void* (*)(LsgList*, int, void*))LsgLinkedList_set;
    ((LsgListClass*)class)->get           = (void* (*)(LsgList*, int))LsgLinkedList_get;
    ((LsgListClass*)class)->clear         = (void  (*)(LsgList*))LsgLinkedList_clear;
    ((LsgListClass*)class)->iterator      = (LsgIterator* (*)(LsgList*))LsgLinkedList_iterator;

    ((LsgObjectClass*)class)->destroy = (void (*)(LsgObject*))LsgLinkedList_destroy;

    instance->first = NULL;
}

static LsgObjectClass* s_pclass = NULL;

LsgClassID LsgLinkedList_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgLinkedList",
            LsgList_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgLinkedListClass),
            sizeof(LsgLinkedList),
            (LsgClassStaticInitializer)LsgLinkedList_staticInit
        );

        s_pclass = LSG_OBJECT_CLASS(LsgClass_getParentClass(classid));
    }

    return classid;
}

static LsgLinkedListElement* LsgLinkedList_createElement(void* object) {
    LsgLinkedListElement* el;

    el = (LsgLinkedListElement*)malloc(sizeof(LsgLinkedListElement));
    if (el) {
        el->next = NULL;
        el->value = object;
    }

    return el;
}

LsgLinkedList* LsgLinkedList_create(void) {
    LsgLinkedList* self = (LsgLinkedList*)LsgClass_alloc(LsgLinkedList_classID());

    if (self)
        LsgLinkedList_init(self);

    return self;
}

void LsgLinkedList_init(LsgLinkedList* self) {
    LsgList_init(&self->parent);


    self->first = NULL;
}

static int LsgLinkedList_count(LsgLinkedList* self) {
    int count = 0;
    LsgLinkedListElement* elem;

    elem = self->first;
    while (elem) {
        ++count;
        elem = elem->next;
    }

    return count;
}

static int LsgLinkedList_contains(LsgLinkedList* self, void* object) {
    return LsgLinkedList_index(self, object) != -1;
}

static int LsgLinkedList_index(LsgLinkedList* self, void* object) {
    LsgLinkedListElement* el;
    int index = 0;

    el = self->first;
    while (el) {
        if (el->value == object) {
            return index;
        }
        el = el->next;
        ++index;
    }

    return -1;
}

static void LsgLinkedList_append(LsgLinkedList* self, void* object) {
    LsgLinkedListElement* el;
    LsgLinkedListElement* nel;

    nel = LsgLinkedList_createElement(object);

    if (self->first) {
        el = self->first;
        while (el->next) {
            el = el->next;
        }
        el->next = nel;
    } else {
        self->first = nel;
    }
}

static void LsgLinkedList_insert(LsgLinkedList* self, int index, void* object) {
    LsgLinkedListElement* el;
    LsgLinkedListElement* nel;
    int pos = 1;

    nel = LsgLinkedList_createElement(object);

    if ((index == 0) || (self->first == NULL)) {
        nel->next = self->first;
        self->first = nel;
    } else {
        el = self->first;
        while (el->next && (pos < index)) {
            ++pos;
            el = el->next;
        }

        nel->next = el->next;
        el->next = nel;
    }
}

static int LsgLinkedList_remove(LsgLinkedList* self, void* object) {
    LsgLinkedListElement* el;
    LsgLinkedListElement* prev = NULL;
    int pos = 0;

    el = self->first;
    while (el) {
        if (el->value == object) {
            if (prev) {
                prev->next = el->next;
            } else {
                self->first = el->next;
            }
            free(el);
            return pos;
        }

        prev = el;
        el = el->next;
        ++pos;
    }

    return pos;
}

static void* LsgLinkedList_removeByIndex(LsgLinkedList* self, int index) {
    LsgLinkedListElement* el;
    LsgLinkedListElement* prev = NULL;
    void* object = NULL;
    int pos = 0;

    el = self->first;
    while (el && (pos < index)) {
        ++pos;
        prev = el;
        el = el->next;
    }

    if (prev) {
        prev->next = el->next;
    } else {
        self->first = el->next;
    }

    object = el->value;
    free(el);

    return object;
}

static void* LsgLinkedList_set(LsgLinkedList* self, int index, void* object) {
    LsgLinkedListElement* el;
    void* old_object = NULL;
    int pos = 0;

    el = self->first;
    while (el && (pos < index)) {
        ++pos;
        el = el->next;
    }

    if (el) {
        old_object = el->value;
        el->value = object;
    }

    return old_object;
}

static void* LsgLinkedList_get(LsgLinkedList* self, int index) {
    LsgLinkedListElement* el;
    int pos = 0;

    el = self->first;
    while (el && (pos < index)) {
        ++pos;
        el = el->next;
    }

    if (el) {
        return el->value;
    } else {
        return NULL;
    }
}

static void LsgLinkedList_clear(LsgLinkedList* self) {
    LsgLinkedListElement* el;
    LsgLinkedListElement* next_el;

    el = self->first;
    while (el) {
        next_el = el->next;
        free(el);
        el = next_el;
    }
    self->first = NULL;
}

static LsgLinkedListIterator* LsgLinkedList_iterator(LsgLinkedList* self) {
    return LsgLinkedListIterator_create(self);
}

static void LsgLinkedList_destroy(LsgLinkedList* self) {
    LsgLinkedList_clear(self);

    s_pclass->destroy((LsgObject*)self);
}

/* LsgLinkedListIterator ***********************************************/

static int   LsgLinkedListIterator_hasNext(LsgLinkedListIterator* self);
static void* LsgLinkedListIterator_next(LsgLinkedListIterator* self);

static void LsgLinkedListIterator_staticInit(LsgLinkedListIteratorClass* class, LsgLinkedListIterator* instance) {
    ((LsgIteratorClass*)class)->hasNext = (int   (*)(LsgIterator*))LsgLinkedListIterator_hasNext;
    ((LsgIteratorClass*)class)->next    = (void* (*)(LsgIterator*))LsgLinkedListIterator_next;

    instance->element = NULL;
}

LsgClassID LsgLinkedListIterator_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgLinkedListIterator",
            LsgIterator_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgLinkedListIteratorClass),
            sizeof(LsgLinkedListIterator),
            (LsgClassStaticInitializer)LsgLinkedListIterator_staticInit
        );
    }

    return classid;
}

LsgLinkedListIterator* LsgLinkedListIterator_create(LsgLinkedList* list) {
    LsgLinkedListIterator* self = (LsgLinkedListIterator*)LsgClass_alloc(LsgLinkedListIterator_classID());

    if (self)
        LsgLinkedListIterator_init(self, list);

    return self;
}

void LsgLinkedListIterator_init(LsgLinkedListIterator* self, LsgLinkedList* list) {
    LsgIterator_init(&self->parent);

    self->element = list->first;
}

static int LsgLinkedListIterator_hasNext(LsgLinkedListIterator* self) {
    return self->element != NULL;
}

static void* LsgLinkedListIterator_next(LsgLinkedListIterator* self) {
    void* value;

    if (self->element) {
        value = self->element->value;
        self->element = self->element->next;
        return value;
    } else {
        return NULL;
    }
}
