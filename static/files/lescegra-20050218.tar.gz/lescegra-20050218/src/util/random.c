/* Copyright (C) 1997 - 2002, Makoto Matsumoto and Takuji Nishimura,
 * Copyright (C) 2003 - 2004, Enno Cramer
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   1. Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2. Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *
 *   3. The names of its contributors may not be used to endorse or promote
 *      products derived from this software without specific prior written
 *      permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Any feedback is very welcome.
 * http://www.math.keio.ac.jp/matumoto/emt.html
 * email: matumoto@math.keio.ac.jp
 */

#include <lescegra/util/random.h>

#include <stdlib.h>
#include <limits.h>

static void LsgRandom_staticInit(LsgRandomClass* class, LsgRandom* instance) {
    LsgRandom_seed(instance, 0);
}

LsgClassID LsgRandom_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgRandom",
            LsgObject_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgRandomClass),
            sizeof(LsgRandom),
            (LsgClassStaticInitializer)LsgRandom_staticInit
        );
    }

    return classid;
}

LsgRandom* LsgRandom_create(unsigned long int seed) {
    LsgRandom* self = (LsgRandom*)LsgClass_alloc(LsgRandom_classID());

    if (self)
        LsgRandom_init(self, seed);

    return self;
}

void LsgRandom_init(LsgRandom* self, unsigned long int seed) {
    LsgObject_init(&self->parent);

    LsgRandom_seed(self, seed);
}

void LsgRandom_seed(LsgRandom* self, unsigned long int seed) {
    int i;

    self->state[0] = seed & 0xffffffffUL;
    for (i = 1; i < LSG_RANDOM_STATE_SIZE; ++i)
        self->state[i] =
            (1812433253UL *
             (self->state[i-1] ^ (self->state[i-1] >> 30)) + i
            ) & 0xffffffffUL;

    self->index = 0;
}

#define M 397
#define MIX_BITS(a, b) (((a) & 0x80000000UL) | ((b) & 0x7fffffffUL))

static void LsgRandom_reload(LsgRandom* self) {
    static unsigned long mag01[2] = {0x0UL, 0x9908b0dfUL};
    unsigned long int temp;
    int i;

    for (i = 0; i < LSG_RANDOM_STATE_SIZE - M; ++i) {
        temp = MIX_BITS(self->state[i], self->state[i + 1]);
        self->state[i] =
            self->state[i + M] ^ (temp >> 1) ^ mag01[temp & 0x1UL];
    }

    for (; i < LSG_RANDOM_STATE_SIZE - 1; ++i) {
        temp = MIX_BITS(self->state[i], self->state[i + 1]);
        self->state[i] =
            self->state[i + (M - LSG_RANDOM_STATE_SIZE)] ^
            (temp >> 1) ^ mag01[temp & 0x1UL];
    }

    temp = MIX_BITS(self->state[LSG_RANDOM_STATE_SIZE - 1], self->state[0]);
    self->state[LSG_RANDOM_STATE_SIZE - 1] =
        self->state[M - 1] ^ (temp >> 1) ^ mag01[temp & 0x1UL];

    self->index = 0;
}

#undef MIX_BITS
#undef M

unsigned long int LsgRandom_generate(LsgRandom* self) {
    unsigned long int y;

    if (self->index >= LSG_RANDOM_STATE_SIZE) {
        LsgRandom_reload(self);
    }

    y = self->state[self->index++];

    /* Tempering */
    y ^= (y >> 11);
    y ^= (y << 7) & 0x9d2c5680UL;
    y ^= (y << 15) & 0xefc60000UL;
    y ^= (y >> 18);

    return y;
}

float LsgRandom_random(LsgRandom* self) {
    return (float)LsgRandom_generate(self) / (float)ULONG_MAX;
}

float LsgRandom_randomMax(LsgRandom* self, float limit) {
    return LsgRandom_random(self) * limit;
}

float LsgRandom_randomError(LsgRandom* self) {
    return 2.0 * LsgRandom_random(self) - 1.0;
}

float LsgRandom_randomRange(LsgRandom* self, float base, float error) {
    return base + 2.0 * error * LsgRandom_random(self) - error;
}
