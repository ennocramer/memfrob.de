#include <lescegra/util/arraylist.h>

#include <lescegra/base/error.h>

#include <stdlib.h>
#include <string.h>

#define LSG_ARRAYLIST_CAPACITY 256

static int   LsgArrayList_count(LsgArrayList* self);
static int   LsgArrayList_contains(LsgArrayList* self, void* object);
static int   LsgArrayList_index(LsgArrayList* self, void* object);
static void  LsgArrayList_append(LsgArrayList* self, void* object);
static void  LsgArrayList_insert(LsgArrayList* self, int index, void* object);
static int   LsgArrayList_remove(LsgArrayList* self, void* object);
static void* LsgArrayList_removeByIndex(LsgArrayList* self, int index);
static void* LsgArrayList_set(LsgArrayList* self, int index, void* object);
static void* LsgArrayList_get(LsgArrayList* self, int index);
static void  LsgArrayList_clear(LsgArrayList* self);
static LsgArrayListIterator* LsgArrayList_iterator(LsgArrayList* self);
static void  LsgArrayList_destroy(LsgArrayList* self);

static void LsgArrayList_staticInit(LsgArrayListClass* class, LsgArrayList* instance) {
    ((LsgListClass*)class)->count         = (int   (*)(LsgList*))LsgArrayList_count;
    ((LsgListClass*)class)->contains      = (int   (*)(LsgList*, void*))LsgArrayList_contains;
    ((LsgListClass*)class)->index         = (int   (*)(LsgList*, void*))LsgArrayList_index;
    ((LsgListClass*)class)->append        = (void  (*)(LsgList*, void*))LsgArrayList_append;
    ((LsgListClass*)class)->insert        = (void  (*)(LsgList*, int, void*))LsgArrayList_insert;
    ((LsgListClass*)class)->remove        = (int   (*)(LsgList*, void*))LsgArrayList_remove;
    ((LsgListClass*)class)->removeByIndex = (void* (*)(LsgList*, int))LsgArrayList_removeByIndex;
    ((LsgListClass*)class)->set           = (void* (*)(LsgList*, int, void*))LsgArrayList_set;
    ((LsgListClass*)class)->get           = (void* (*)(LsgList*, int))LsgArrayList_get;
    ((LsgListClass*)class)->clear         = (void  (*)(LsgList*))LsgArrayList_clear;
    ((LsgListClass*)class)->iterator      = (LsgIterator* (*)(LsgList*))LsgArrayList_iterator;

    ((LsgObjectClass*)class)->destroy = (void (*)(LsgObject*))LsgArrayList_destroy;

    instance->elements = NULL;
    instance->capacity = 0;
    instance->count    = 0;
}

static LsgListClass* s_pclass = NULL;

LsgClassID LsgArrayList_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgArrayList",
            LsgList_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgArrayListClass),
            sizeof(LsgArrayList),
            (LsgClassStaticInitializer)LsgArrayList_staticInit
        );

        s_pclass = LSG_LIST_CLASS(LsgClass_getParentClass(classid));
    }

    return classid;
}

LsgArrayList* LsgArrayList_create(void) {
    LsgArrayList* self = (LsgArrayList*)LsgClass_alloc(LsgArrayList_classID());

    if (self)
        LsgArrayList_init(self);

    return self;
}

void LsgArrayList_init(LsgArrayList* self) {
    LsgList_init(&self->parent);

    self->count = 0;
    self->capacity = LSG_ARRAYLIST_CAPACITY;
    self->elements = (void**)malloc(sizeof(void*) * LSG_ARRAYLIST_CAPACITY);

    assert(self->elements != NULL);
}

static void LsgArrayList_grow(LsgArrayList* self) {
    self->capacity *= 2;
    self->elements = realloc(self->elements, sizeof(void*) * self->capacity);

    assert(self->elements != NULL);
}

static void LsgArrayList_shrink(LsgArrayList* self) {
    self->capacity /= 2;
    self->elements = realloc(self->elements, sizeof(void*) * self->capacity);
}

static int LsgArrayList_count(LsgArrayList* self) {
    return self->count;
}

static int LsgArrayList_contains(LsgArrayList* self, void* object) {
    return LsgArrayList_index(self, object) != -1;
}

static int LsgArrayList_index(LsgArrayList* self, void* object) {
    int i;

    for (i = 0; i < self->count; ++i) {
        if (self->elements[i] == object) {
            return i;
        }
    }

    return -1;
}

static void LsgArrayList_append(LsgArrayList* self, void* object) {
    LsgArrayList_insert(self, LsgArrayList_count(self), object);
}

static void LsgArrayList_insert(LsgArrayList* self, int index, void* object) {
    if (self->count >= self->capacity) LsgArrayList_grow(self);

    if (index > self->count) index = self->count;

    memmove(self->elements + index + 1, self->elements + index, sizeof(void*) * (self->count - index));
    self->elements[index] = object;

    ++self->count;
}

static int LsgArrayList_remove(LsgArrayList* self, void* object) {
    int index = LsgArrayList_index(self, object);

    if (index != -1)
        LsgArrayList_removeByIndex(self, index);

    return index;
}

static void* LsgArrayList_removeByIndex(LsgArrayList* self, int index) {
    void* object = NULL;

    if (index >= self->count)
        return NULL;

    object = self->elements[index];

    memmove(
        self->elements + index,
        self->elements + index + 1,
        sizeof(void*) * (self->count - index - 1)
    );

    --self->count;

    if (
        (self->capacity > LSG_ARRAYLIST_CAPACITY) &&
        (self->capacity / self->count >= 2)
    )
        LsgArrayList_shrink(self);

    return object;
}

static void* LsgArrayList_set(LsgArrayList* self, int index, void* object) {
    void* old_object = NULL;

    if (index >= self->count)
        return NULL;

    old_object = self->elements[index];

    self->elements[index] = object;

    return old_object;
}

static void* LsgArrayList_get(LsgArrayList* self, int index) {
    if (index >= self->count) return NULL;

    return self->elements[index];
}

static void LsgArrayList_clear(LsgArrayList* self) {
    self->elements = realloc(self->elements, sizeof(void*) * LSG_ARRAYLIST_CAPACITY);
    self->capacity = LSG_ARRAYLIST_CAPACITY;
    self->count    = 0;
}

static LsgArrayListIterator* LsgArrayList_iterator(LsgArrayList* self) {
    return LsgArrayListIterator_create(self);
}

static void LsgArrayList_destroy(LsgArrayList* self) {
    LsgList_refElements((LsgList*)self, 0);
    free(self->elements);

    ((LsgObjectClass*)s_pclass)->destroy((LsgObject*)self);
}

/* LsgArrayListIterator ************************************************/

static int   LsgArrayListIterator_hasNext(LsgArrayListIterator* self);
static void* LsgArrayListIterator_next(LsgArrayListIterator* self);

static void LsgArrayListIterator_staticInit(LsgArrayListIteratorClass* class, LsgArrayListIterator* instance) {
    ((LsgIteratorClass*)class)->hasNext = (int   (*)(LsgIterator*))LsgArrayListIterator_hasNext;
    ((LsgIteratorClass*)class)->next    = (void* (*)(LsgIterator*))LsgArrayListIterator_next;

    instance->elements = NULL;
    instance->count    = 0;
    instance->index    = 0;
}

LsgClassID LsgArrayListIterator_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgArrayListIterator",
            LsgIterator_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgArrayListIteratorClass),
            sizeof(LsgArrayListIterator),
            (LsgClassStaticInitializer)LsgArrayListIterator_staticInit
        );
    }

    return classid;
}

LsgArrayListIterator* LsgArrayListIterator_create(LsgArrayList* list) {
    LsgArrayListIterator* self = (LsgArrayListIterator*)LsgClass_alloc(LsgArrayListIterator_classID());

    if (self)
        LsgArrayListIterator_init(self, list);

    return self;
}

void LsgArrayListIterator_init(LsgArrayListIterator* self, LsgArrayList* list) {
    LsgIterator_init(&self->parent);

    self->elements = list->elements;
    self->count    = list->count;
    self->index    = -1;
}

static int LsgArrayListIterator_hasNext(LsgArrayListIterator* self) {
    return self->index < (self->count - 1);
}

static void* LsgArrayListIterator_next(LsgArrayListIterator* self) {
    return self->elements[++self->index];
}
