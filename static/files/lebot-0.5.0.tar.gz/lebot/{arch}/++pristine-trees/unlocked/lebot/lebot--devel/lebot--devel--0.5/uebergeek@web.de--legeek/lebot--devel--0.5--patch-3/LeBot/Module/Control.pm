#!/usr/bin/perl
package LeBot::Module::Control;

use LeBot;
use LeBot::Module;

use LeBot::Module::Command;

use strict;
use vars qw(@ISA);

@ISA = qw(LeBot::Module);

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $bot = shift;
    my $name = shift;
    
    my $self = $proto->SUPER::new($bot, $name);
    
    $self->version('0.5.0');
    $self->author('Enno Cramer');
    $self->contact('uebergeek@web.de');
    $self->url('http://geeky.kicks-ass.org/');
    
    return $self;
}

sub init {
    my $self = shift;
    my $bot = $self->bot();
    
    $bot->add_dependency($self, 'Command');
    
    my $cmd_mod = $bot->module('Command');
    
    $cmd_mod->add_command('.nick',   $self, \&_cmd_nick,   [ 'msg' ]);
    $cmd_mod->add_command('.join',   $self, \&_cmd_join,   [ 'msg' ]);
    $cmd_mod->add_command('.part',   $self, \&_cmd_part,   [ 'msg' ]);
    $cmd_mod->add_command('.say',    $self, \&_cmd_say,    [ 'msg' ]);
    $cmd_mod->add_command('.notice', $self, \&_cmd_notice, [ 'msg' ]);
    $cmd_mod->add_command('.me',     $self, \&_cmd_me,     [ 'msg' ]);
    $cmd_mod->add_command('.mode',   $self, \&_cmd_mode,   [ 'msg' ]);
    $cmd_mod->add_command('.topic',  $self, \&_cmd_topic,  [ 'msg' ]);
    $cmd_mod->add_command('.invite', $self, \&_cmd_invite, [ 'msg' ]);
    $cmd_mod->add_command('.kick',   $self, \&_cmd_kick,   [ 'msg' ]);
    $cmd_mod->add_command('.op',     $self, \&_cmd_op,     [ 'msg' ]);
    $cmd_mod->add_command('.deop',   $self, \&_cmd_deop,   [ 'msg' ]);
    $cmd_mod->add_command('.quit',   $self, \&_cmd_quit,   [ 'msg' ]);
    
    return 1;
}

sub done {
    my $self = shift;
    my $bot = $self->bot();
    my $cmd_mod = $bot->module('Command');
    
    $cmd_mod->remove_command('.nick');
    $cmd_mod->remove_command('.join');
    $cmd_mod->remove_command('.part');
    $cmd_mod->remove_command('.say',);
    $cmd_mod->remove_command('.notice');
    $cmd_mod->remove_command('.me');
    $cmd_mod->remove_command('.mode');
    $cmd_mod->remove_command('.topic');
    $cmd_mod->remove_command('.invite');
    $cmd_mod->remove_command('.kick');
    $cmd_mod->remove_command('.op');
    $cmd_mod->remove_command('.deop');
    $cmd_mod->remove_command('.quit');
    
    $bot->remove_dependency($self, 'Command');
    
    return 1;
}

sub _cmd_nick {
    my ($self, $event) = @_;

    my @args = split /\s+/, $event->{'args'}->[0];
    $self->bot()->context()->nick($args[1]);    
}

sub _cmd_join {
    my ($self, $event) = @_;

    my @args = split /\s+/, $event->{'args'}->[0];
    $self->bot()->context()->join($args[1]);
}

sub _cmd_part {
    my ($self, $event) = @_;

    my @args = split /\s+/, $event->{'args'}->[0];
    $self->bot()->context()->part($args[1]);
}

sub _cmd_say {
    my ($self, $event) = @_;

    my ($cmd, $to, $text) = split /\s+/, $event->{'args'}->[0], 3;
    $self->bot()->context()->privmsg($to, $text);
}

sub _cmd_notice {
    my ($self, $event) = @_;

    my ($cmd, $to, $text) = split /\s+/, $event->{'args'}->[0], 3;
    $self->bot()->context()->notice($to, $text);
}

sub _cmd_me {
    my ($self, $event) = @_;

    my ($cmd, $to, $text) = split /\s+/, $event->{'args'}->[0], 3;
    $self->bot()->context()->me($to, $text);
}

sub _cmd_quit {
    my ($self, $event) = @_;

    $self->bot()->context()->quit;
}

sub _cmd_mode {
    my ($self, $event) = @_;

    my ($cmd, $target, $mode, @args) = split /\s+/, $event->{'args'}->[0];
    $self->bot()->context()->mode($target, $mode, @args);
}

sub _cmd_topic {
    my ($self, $event) = @_;

    my ($cmd, $channel, $topic) = split /\s+/, $event->{'args'}->[0], 3;
    $self->bot()->context()->topic($channel, $topic);
}

sub _cmd_invite {
    my ($self, $event) = @_;

    my ($cmd, $nick, $channel) = split /\s+/, $event->{'args'}->[0];
    $self->bot()->context()->invite($nick, $channel);
}

sub _cmd_kick {
    my ($self, $event) = @_;

    my ($cmd, $nick, $channel) = split /\s+/, $event->{'args'}->[0];
    $self->bot()->context()->kick($nick, $channel);
}

sub _cmd_op {
    my ($self, $event) = @_;

    my ($cmd, $channel, $nick) = split /\s+/, $event->{'args'}->[0], 3;
    $self->bot()->context()->mode($channel, '+o', $nick);
}

sub _cmd_deop {
    my ($self, $event) = @_;

    my ($cmd, $channel, $nick) = split /\s+/, $event->{'args'}->[0], 3;
    $self->bot()->context()->mode($channel, '-o', $nick);
}

1;

__END__
