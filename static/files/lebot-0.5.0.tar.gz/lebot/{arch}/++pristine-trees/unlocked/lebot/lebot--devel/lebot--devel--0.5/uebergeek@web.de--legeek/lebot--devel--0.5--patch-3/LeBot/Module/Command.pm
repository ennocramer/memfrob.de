#!/usr/bin/perl
package LeBot::Module::Command;

use LeBot;
use LeBot::Module;

use File::Spec;

use strict;
use vars qw(@ISA);

@ISA = qw(LeBot::Module);

#########################
# Module lifetime stuff #
#########################

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $bot = shift;
    my $name = shift;
    
    my $self = $proto->SUPER::new($bot, $name);
    
    $self->version('0.5.0');
    $self->author('Enno Cramer');
    $self->contact('uebergeek@web.de');
    $self->url('http://geeky.kicks-ass.org/');
    
    $self->{commands} = {};
    
    return $self;
}

sub init {
    my $self = shift;
    my $bot = $self->bot();

    $bot->log('Command', 'registering hooks');    
    $self->bot()->add_hook('msg',    $self, \&_hook_all);
    $self->bot()->add_hook('public', $self, \&_hook_all);
    $self->bot()->add_hook('notice', $self, \&_hook_all);

    return 1;
}

sub done {
    my $self = shift;
    my $bot = $self->bot();

    $bot->log('Command', 'removing hooks');    
    $self->bot()->remove_hook('msg',    $self);
    $self->bot()->remove_hook('public', $self);
    $self->bot()->remove_hook('notice', $self);

    return 1;
}

# Adds a subroutine reference to the command table.
#
# arg0: The command string the code ref should be associated with (like '!cmd')
# arg1: A code ref to be called when the command is triggered.
# arg2: array of event types to react on
sub add_command {
    my ($self, $command, $module, $method, $ev_types) = @_;
    my $desc = {'module' => $module, 'method' => $method, 'event_types' => {} };
    foreach (@$ev_types) {
        $desc->{event_types}->{$_} = 1;
    }
    
    $self->bot()->log('Command', "adding command: $command", 0);
    $self->{'commands'}->{$command} = $desc;
}

# Removes a command from the command table.
#
# arg0: The command to be removed.
sub remove_command {
    my ($self, $command) = @_;
    
    $self->bot()->log('Command', "removing command: $command", 0);
    delete $self->{'commands'}->{$command};
}

# Returns a hash of all registered commands and their properties
#
# no args
sub get_command_list {
    my $self = shift;
    
    return %{$self->{'commands'}};
}

# Checks if the incoming event triggers a command handler and calls it if
# necessary.
# This method is called by dispatch_event on any incoming private/public message
# (Specifically it is registered as a hook for msg and public events; therefore
# command processing can be deactivated by calling remove_hook for this method).
#
# arg0: An incoming event.
sub _hook_all {
    my ($self, $event) = @_;
    
    my $cmd_str = ($event->{'args'}->[0]);
    my ($cmd, $garbage) = split /\s+/, $cmd_str, 2;
    
    if (exists $self->{'commands'}->{$cmd}) {
        my $module = $self->{'commands'}->{$cmd}->{'module'};
        my $method = $self->{'commands'}->{$cmd}->{'method'};
        my $ev_types = $self->{'commands'}->{$cmd}->{'event_types'};

        if ($ev_types->{$event->{'type'}}) {
            eval {
                $module->$method($event);
            };
            if ($@) {
                $self->bot()->log('Command', "error in command handler for $cmd: $@");
            }
        }
        return 1;
    }
    return 0;
}
