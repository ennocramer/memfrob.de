#!/usr/bin/perl

################################################################################
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Library General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
################################################################################

# Copyright (c) 2001-2002
# Enno Cramer <uebergeek@web.de>

use File::Spec;
use Time::HiRes;
use Net::IRC;
use LeBot::ConfigFile;
use LeBot::Connection;

package LeBot;

use strict;
use vars qw($VERSION %LOGLEVELS $LOGLEVEL $MAIN_CONF_DEF);

$VERSION = "0.5.0";
%LOGLEVELS = (
    debug => 0,
    debug_short => 1,
    
    general => 10,
    general_short => 11,
    
    warning => 20,
    
    error => 30,
    
    critical => 40,
);
$LOGLEVEL = $LOGLEVELS{debug_short};
$MAIN_CONF_DEF = {
    networks => {
        type => 'HASH',
        keys => {
            '.+' => 'network',
        },
    },

    network => {
        type => 'HASH',
        keys => {
            servers => 'SCALAR_ARRAY',
            nicks => 'SCALAR_ARRAY',
            autoconnect => 'SCALAR',
        },
    },

    SCALAR_ARRAY => {
        type => 'ARRAY',
        values => 'SCALAR',
    },

    root => {
        type => 'HASH',
        keys => {
            networks => 'networks',
            modules => 'SCALAR_ARRAY',
        },
    },
};

# Creates a new Bot.
#
# arg0: The Bots base dir. This is where user data and config is stored.
sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    (my $basedir = shift) =~ s/\/$//;

    my $self = {
        '_basedir' => $basedir,  # directory to store configuration
        '_running' => 0,         # when set to 0, Bot::run will return
        '_time_step' => 0.1,
        '_irc' => undef,         # Net::IRC
        '_connections' => [],    # LeBot::Connection
        
        '_context' => undef,     # Calling context (connection, user)

        '_modules' => {},        # loaded modules
        '_depend' => {},
        '_hooks' => {},          # registered hooks in per signal arrays
        '_timer' => {},          # timer for executing functions after defined delays
    };
    
    bless $self, $class;
    
    $self->log('LeBot', 'creating LeBot instance');
    
    $self->log('LeBot', 'loading main config');
    my $config = $self->load_config('main', $MAIN_CONF_DEF);
    
    $self->log('LeBot', 'loading modules');
    foreach (@{$config->{'modules'}}) {
        $self->load_module($_);
    }
    
    $self->log('LeBot', 'creating Net::IRC object');
    $self->{'_irc'} = new Net::IRC;
    $self->{'_irc'}->timeout(0);
    
    $self->log('LeBot', 'creating connections');
    foreach (keys %{$config->{networks}}) {
        my $nw = $_;
        my $desc = $config->{networks}->{$nw};
        my $conn = LeBot::Connection->new($self, $nw, $desc->{servers}, $desc->{nicks});
        push @{$self->{_connections}}, $conn;
        $conn->connect() if ($desc->{autoconnect});
    }

    $self->log('LeBot', 'creating bot done');
    
    return $self;
}

sub basedir {
    my $self = shift;
    return $self->{_basedir};
}

sub context {
    my $self = shift;
    return $self->{_context};
}

# Destroys this Bot. First removes any loaded module, then unties the user
# hashes and closes the IRC connection.
# This method is called by quit
#
# arg0: Parting message.
sub done {
    my $self = shift;
    my $message = shift || 'exiting';
    $self->log('LeBot', "quit: $message");
    
    $self->{'_running'} = 0;
    
    # Quit connection before modules are unloaded so they can react
    # on leave and disconnect events.
    # ATTENTION: reconnect on disconnect may falsely react on disconnect
    # event if earlier leave event is not processed.
    foreach (@{$self->{_connections}}) {
        $_->quit($message);
    }
    
    Time::HiRes::usleep(500);
    my @mod_order = sort { $self->cmp_mod_unload($a, $b) } keys %{$self->{'_modules'}};
    foreach (@mod_order) {
        $self->unload_module($_, 1);
    }
}

sub cmp_mod_unload {
    my ($self, $a, $b) = @_;

#    print "cmp: $a - $b\n";
#    print "dep $a: ".join(", ", @{$self->{_depend}->{$a}})."\n";
#    print "dep $b: ".join(", ", @{$self->{_depend}->{$b}})."\n";

    if (grep {$_->name() eq $a} @{$self->{_depend}->{$b}}) {
#        print "$a depends on $b\n";
        return -1;
    } elsif (grep {$_->name() eq $b} @{$self->{_depend}->{$a}}) {
#        print "$b depends on $a\n";
        return 1;
    } else {
        return 0;
    }
}

sub run {
    my $self = shift;

    $self->{'_running'} = 1;
    while ($self->{'_running'}) {
        Time::HiRes::sleep($self->time_step());
        $self->loop_once;
    }
}

sub loop_once {
    my $self = shift;
    my $now = Time::HiRes::time();
    
    foreach(keys %{$self->{'_timer'}}) {
        my $key = $_;
        my $timer = $self->{'_timer'}->{$key};

        if ($timer->{'time'} <= $now) {
            eval {
                &{$timer->{'code'}}($self, $timer->{'data'})
            };
            if ($@) {
                $self->log('LeBot', "error in timer handler: $@");
            }

            if ($timer->{'repeat'}) {
                $timer->{'time'} += $timer->{'repeat'};
            } else {
                delete $self->{'_timer'}->{$key};
            }
        }
    }

    $self->{'_irc'}->do_one_loop();
    
    foreach (@{$self->{_connections}}) {
        my $conn = $_;
        if ($conn->want_connect() && !$conn->connected()) {
            $conn->try_to_connect();
        }
    }
}

sub stop {
    my $self = shift;
    
    $self->{_running} = 0;
}

sub time_step {
    my $self = shift;
    
    if (@_) {
        $self->{'_time_step'} = $_[0];
    }
    
    return $self->{'_time_step'};
}

###########
# Modules #
###########

# Loads a module
#
# arg0: The modules name.
sub load_module {
    my ($self, $name) = @_;
    
    if (! exists $self->{'_modules'}->{$name}) {
        my $fq_name = 'LeBot::Module::'.$name;
        my $symbol_table = $fq_name.'::';
#        my $package = File::Spec->catfile('LeBot', 'Module', $name.'.pm');
       
        $self->log('LeBot', "loading module $name");
        
        eval("local \$SIG{__DIE__} = 'DEFAULT'; require $fq_name;");
        if ($@) {
            $self->log('LeBot', "module load failed: $@");
            return 0;
        }
        
        my $mod = eval("$fq_name->new(\$self, \$name)");
        if ($@) {
            $self->log('LeBot', "module load failed: $@");
            &clear_symbol_table($symbol_table);
            return 0;
        }
        
        eval { $mod->init(); };
        if ($@) {
            $self->log('LeBot', "module load failed: $@");
            &clear_symbol_table($symbol_table);
            return 0;
        }
        
        $self->{_modules}->{$name} = $mod;
        $self->{_depend}->{$name} = [];
        
        return 1;
    } else {
        $self->log('LeBot', "module $name already loaded");
        return 1;
    }
}

# Unloads a module and clears its symbol table.
#
# arg0: The modules name.
sub unload_module {
    my ($self, $name, $force) = @_;
    if (! defined $force) {
        $force = 0;
    }
    
    if (exists $self->{'_modules'}->{$name}) {
        my $fq_name = 'LeBot::Module::'.$name;
#        my $symbol_table = 'LeBot::Module::'.$name.'::';
#        my $package = File::Spec->catfile('LeBot', 'Module', $name.'.pm');
   
        $self->log('LeBot', "unloading module $name");
        
        my $module = $self->{_modules}->{$name};
        eval { $module->done(); };
        if ($@) {
            $self->log('LeBot', "error in module unload: $@");
        }
        eval("no $fq_name;");
#        &clear_symbol_table($symbol_table);
#        delete $INC{$package};

        delete $self->{'_modules'}->{$name};
        delete $self->{'_depend'}->{$name};

        return 1;
    } else {
        $self->log('LeBot', "module $name is not loaded");
        return 1;
    }
}

sub module {
    my $self = shift;
    my $name = shift;
    
    return $self->{_modules}->{$name};
}

# Returns a hash of all loaded modules and their names
#
# no args
sub get_module_list {
    my $self = shift;

    return %{$self->{'_modules'}};
}

# Mark a module as dependency
# (This is only a counter at the moment)
#
# arg0: the module name
sub add_dependency {
    my ($self, $module, $dependency) = @_;
    
    if (exists $self->{_depend}->{$dependency}) {
        push @{$self->{_depend}->{$dependency}}, $module;
    } else {
        die "dependency problem, module $dependency not loaded";
    }
}

# Remove dependency mark from module
#
# arg0: the module name
sub remove_dependency {
    my ($self, $module, $dependency) = @_;
    
    if (exists $self->{_depend}->{$dependency}) {
        my $deplist = $self->{_depend}->{$dependency};
        for (my $i = 0; $i < scalar @{$deplist}; $i++) {
            if  ($deplist->[$i] == $module) {
                splice @{$deplist}, $i, 1;
            }
        }
    } else {
        $self->log("strange, trying to remove dependency to not existing module $dependency");
    }
}

#########
# Hooks #
#########

# Adds a hook to some type of event.
#
# arg0: The event type.
# arg1: The handler routine.
# arg2: Boolean if the hook should be placed at the beginning of the hooklist (replace)
#       default: false
sub add_hook {
    my $self = shift;
    my $event = shift;
    my $module = shift;
    my $method = shift;
    my $replace = shift;
    
#    my $found = 0;
#    my $i = 0;
#    while ((! $found) && ($i < scalar @EVENTS)) {
#        if ($EVENTS[$i++] eq $event) {
#            $found = 1;
#        }  
#    }
#    
#    if ($found) {
        $self->log('LeBot', "adding hook: $event", 0);

        my $hooklist = $self->{'_hooks'}->{$event};
        if (! defined $hooklist) {
            $hooklist = [];
            $self->{'_hooks'}->{$event} = $hooklist;
        }
        if ($replace) {
            unshift @{$hooklist}, [$module, $method];
        } else {
            push @{$hooklist}, [$module, $method];
        }
#    } else {
#        $self->log("trying to add unknown event $event");
#    }
}

# Removes a hook from the hooklist.
#
# arg0: The event type this routine is registered for.
# arg1: The handler reoutine to remove from the hook list.
sub remove_hook {
    my $self = shift;
    my $event = shift;
    my $module = shift;

    $self->log('LeBot', "removing hook: $event", 0);

    my $hooklist = $self->{'_hooks'}->{$event};
    if (defined $hooklist) {
        for (my $i = 0; $i < scalar @{$hooklist}; $i++) {
            if  ($hooklist->[$i]->[0] == $module) {
                splice @{$hooklist}, $i, 1;
            }
        }
    }
}

# Returns a list of all registered hooks for an event
#
# arg0: the event type
sub get_hook_list {
    my ($self, $event) = @_;
    
    return @{$self->{'_hooks'}->{$event}};
}

# Takes the incoming Net::IRC::Event object, converts it into plain
# hash and passes the hast to dispatch_event.
#
# arg0: The event
sub irc_event {
    my ($self, $conn, $event) = @_;
    
    my %event = ();
    while (my ($key, $value) = each %$event) {
#        if ((ref($value) eq 'ARRAY') && (scalar @$value == 1)) {
#            $value = $value->[0];
#        }
        
        $event{$key} = $value;
    }
    
    $self->{_context} = $conn;
    $self->dispatch_event(\%event);
}

# Takes an incoming event and dispatches it to all registered handler routines.
# This method is called on incoming IRC events but can also be called by
# modules to dispatch any event that is probably useful.
#
# arg0: The incoming event (hash-ref).
sub dispatch_event {
    my $self = shift;
    my $event = shift;

    my $type = $event->{'type'};

    $self->log('LeBot', "event: $type", 0);
    foreach (keys %$event) {
        if (($_ eq 'to') || ($_ eq 'args')) {
            $self->log('DBG', "ev '$_' => ('".CORE::join("', '", @{$event->{$_}})."')", $LOGLEVELS{debug});
        } else {
            $self->log('DBG', "ev '$_' => '".$event->{$_}."'", $LOGLEVELS{debug});
        }
    }
    
    my $hooklist = $self->{'_hooks'}->{$type};
    if (defined $hooklist) {
        foreach (@$hooklist) {
            my ($module, $coderef) = @$_;
            my $return = eval {
                $module->$coderef($event);
            };
            if ($@) {
                $self->log($type, "error in hook: $@");
                $self->log($type, "hook: $_\n");
#            } elsif ((defined $return) && $return) {
#                last;
            }
        }
    }
}

###########
# Context #
###########

sub find_connection {
    my $self = shift;
    my $net = shift;
    
    return (grep { $_->network() eq $net } @{$self->{_connections}})[0];
}

#########
# Timer #
#########

sub add_timer {
    my ($self, $name, $subref, $data, $time, $repeat) = @_;
    
    $self->{'_timer'}->{$name} = {
        'code' => $subref,
        'data' => $data,
        'time' => $time + Time::HiRes::time(),
        'repeat' => $repeat,
    };
}

sub remove_timer {
    my ($self, $name) = @_;
    
    delete $self->{'_timer'}->{$name};
}

sub get_timer_list {
    my $self = shift;
    
    return %{$self->{'_timer'}};
}

##########
# Config #
##########

# Read config file for module (~/.lebot/<module>.conf)
#
# arg0: config module name
sub load_config {
    my ($self, $module, $definition) = @_;
    my $file = File::Spec->catfile($self->basedir(), $module.'.conf');
    
    return undef unless (-f $file && -r $file);
    
    my $hash = eval {
        LeBot::ConfigFile::load_config($file);    
    };
    if ($@) {
        $self->log('LeBot', "error loading config file: $@");
    }
    
    if ($definition) {
        LeBot::ConfigFile::validate_config($hash, $definition, $module);
    }
    
    return $hash;
}

# Save module config to file (~/.lebot/<module>.conf)
#
# arg0: the module name
# arg1: config hash
sub save_config {
    my ($self, $module, $hash) = @_;
    my $file = File::Spec->catfile($self->basedir(), $module.'.conf');

    eval {
        LeBot::ConfigFile::save_config($file, $hash);
    };
    if ($@) {
        $self->log('LeBot', "error saving config file: $@");
        return 0;
    }
    
    return 1;
}

################
# Misc methods #
################

# Log a message.
#
# arg0: The message to log.
sub log {
    my ($self, $instance, $message, $loglevel) = @_;
    if (! defined $loglevel) { $loglevel = $LOGLEVELS{general}; }
    
    return unless ($loglevel >= $LOGLEVEL);
    
    if (ref($message) eq 'HASH') {
        foreach (sort keys %$message) {
            print STDOUT '                      \''.$_.'\' => \''.$message->{$_}."'\n";
        }
    } elsif (ref($message) eq 'ARRAY') {
        print STDOUT '                      (\''.CORE::join("', '", @$message)."')\n";
    } else {
        my ($ss, $mm, $hh, $DD, $MM, $YY, $dow, $doy, $isdst) = localtime();
        $YY += 1900;
        print STDOUT sprintf("[%02i/%02i/%04i %02i:%02i:%02i] %s: %s\n", $MM, $DD, $YY, $hh, $mm, $ss, $instance, $message);
    }
}

sub now {
    return Time::HiRes::time();
}

sub run_forked {
    my $self = shift;
    my $code = shift;
    
    my $pid = fork;
    if (! defined $pid) {
        die('could not fork');
    }
    
    if ($pid) {
        $SIG{CHLD} = sub { wait; };
    } else {
        &$code(@_);
        exit 0;
    }
}

sub irc_lcase {
    my $line = shift;
    # shamelessly copied out of perl scripting sample from xchat
    $line =~ tr(A-Z\133-\136)(a-z\173-\176);
    return $line;
}

sub irc_ucase {
    my $line = shift;
    # shamelessly copied out of perl scripting sample from xchat
    $line =~ tr(a-z\173-\176)(A-Z\133-\136);
    return $line;
}

sub mask_to_perlre {
    my ($self, $mask, $case) = @_;
    
    if (! defined $case) {
        $case = 0;
    }

    $mask =~ s/([.+|()\[\]\\\^])/\\$1/g;
    $mask =~ s/\*/.*/g;
    $mask =~ s/\?/./g;

    if ($case) {
        #'{}|~' eq lc '[]\^'
        $mask =~ s/(\\\[|{)/(\\[|{)/g;          # \133 \173
        $mask =~ s/(\\\\|\\\|)/(\\\\|\\|)/g;    # \134 \174
        $mask =~ s/(\\\]|})/(\\]|})/g;          # \135 \175
        $mask =~ s/(~|\\\^)|/(~|\\^)/g;         # \136 \176
    }
    
    return $mask;
}

sub irc_match {
    my ($self, $mask, $string, $case) = @_;

    if (! defined $case) {
        $case = 0;
    }
    
    my $re = $self->mask_to_perlre($mask, $case);
    
    if ($case) {
        return $string =~ /$re/i;
    } else {
        return $string =~ /$re/;
    }
}

sub clear_symbol_table {
    my $symbol_table = shift;

    no strict 'refs';
    foreach (keys %$symbol_table) {
        delete $symbol_table->{$_};
    }
    undef $$symbol_table;
    use strict 'refs';
}

sub generate_salt {
    return CORE::join '', ('.', '/', 0..9, 'A'..'Z', 'a'..'z')[rand 64, rand 64];
}

1;

__END__
