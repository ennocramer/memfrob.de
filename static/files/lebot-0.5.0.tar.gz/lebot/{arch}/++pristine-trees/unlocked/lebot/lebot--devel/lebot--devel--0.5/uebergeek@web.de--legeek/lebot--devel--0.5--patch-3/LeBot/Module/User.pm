#!/usr/bin/perl
package LeBot::Module::User;

use LeBot;
use LeBot::Module;

use LeBot::Module::Command;
use File::Spec;

use strict;
use vars qw(@ISA);

@ISA = qw(LeBot::Module);

#########################
# Module lifetime stuff #
#########################

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $bot = shift;
    my $name = shift;
    
    my $self = $proto->SUPER::new($bot, $name);
    
    $self->version('0.5.0');
    $self->author('Enno Cramer');
    $self->contact('uebergeek@web.de');
    $self->url('http://geeky.kicks-ass.org/');
    
    $self->{accounts} = {};
    $self->{logins} = {};
    
    return $self;
}

sub init {
    my $self = shift;
    my $bot = $self->bot();
    
    $bot->add_dependency($self, 'Command');
    
    $bot->log('User', 'loading accounts');
    $self->_load_accounts();
    
    $bot->module('Command')->add_command('.login',  $self, \&_cmd_login,  [ 'msg' ]);
    $bot->module('Command')->add_command('.logout', $self, \&_cmd_logout, [ 'msg' ]);
    $bot->module('Command')->add_command('.whoami', $self, \&_cmd_whoami, [ 'msg' ]);
    $bot->module('Command')->add_command('.passwd', $self, \&_cmd_passwd, [ 'msg' ]);
    $bot->add_hook('nick', $self, \&_hook_nick);
    $bot->add_hook('quit', $self, \&_hook_quit);

    return 1;
}

sub done {
    my $self = shift;
    my $bot = $self->bot();
    
    $bot->remove_hook('nick', $self);
    $bot->remove_hook('quit', $self);
    $bot->module('Command')->remove_command('.login');
    $bot->module('Command')->remove_command('.logout');
    $bot->module('Command')->remove_command('.whoami');
    $bot->module('Command')->remove_command('.passwd');

    $bot->log('User', 'saving accounts');    
    $self->_save_accounts();
    
    $bot->remove_dependency($self, 'Command');

    return 1;
}

#############################
# Methods for other Modules #
#############################

# Associates an IRC login (<nick>!<user>@<host>) with a Bots user account.
# If the supplied password matches the one saved in the account db the
# association is set up and 1 is returned. Otherwise 0 is returned to indicate
# that login failed.
#
# arg0: The IRC login.
# arg1: The user account someone wishes to login with.
# arg2: The password for that user account.
sub login_user {
    my ($self, $login, $user, $password) = @_;
    
    my $userdata = $self->get_user_data($user);
    if (defined $userdata) {
        if (crypt($password, $userdata->{'password'}) eq $userdata->{'password'}) {
            $self->{'_logins'}->{$login} = $user;
            return 1;
        }
    }
    
    return 0;
}

# Returns the user account some IRC login is associated with or undef if
# that IRC login is not authenticated yet.
#
# arg0: IRC login
sub get_user_name {
    my ($self, $login) = @_;
    
    return $self->{'_logins'}->{$login};
}

# Removes the association between an IRC login and a user account.
#
# arg0: IRC login
sub logout_user {
    my ($self, $login) = @_;
    
    if (exists $self->{'_logins'}->{$login}) {
        my $user = $self->{'_logins'}->{$login};
        delete $self->{'_logins'}->{$login};
    }
}

# Changes the IRC login for a user that is already logged in
#
# arg0: the old IRC login
# arg1: the new IRC login
sub change_user_login {
    my ($self, $old, $new) = @_;
    
    if ((exists $self->{'_logins'}->{$old}) && (not exists $self->{'_logins'}->{$new})) {
        $self->{'_logins'}->{$new} = $self->{'_logins'}->{$old};
        delete $self->{'_logins'}->{$old};
    }
}

# Checks if a specified IRC login is allowed to access functions that require
# a special right. This is done by first checking if the login is associated
# with the user account 'root' who has access to any function. The second step
# is to check if the field 'right_<right>' in the user account db is true.
# If the login is not associated with a user account or the field
# 'right_<right>' is false, this method return 0.
#
# arg0: The IRC login
# arg1: The right to check.
sub has_right {
    my ($self, $login, $right) = @_;

    my $user = $self->get_user_name($login);
    
    if (defined $user) {
        if ($user eq "root") {
            return 1;
        } elsif ($self->get_user_data($user)->{rights}->{$right}) {
            return 1;
        } else {   
            return 0;
        }
    } else {
        return 0;
    }
}

# Returns the user account data hash for a user.
#
# arg0: The user account.
sub get_user_data {
    my ($self, $user) = @_;
    
    return $self->{'_users'}->{$user};
}

# Returns the user account data hash for the account a login is
# associated with.
#
# arg0: An IRC login.
sub get_user_data_by_login {
    my ($self, $login) = @_;

    my $name = $self->get_user_name($login);    

    if (defined $name) {
        return $self->get_user_data($name);
    } else {
        return undef;
    }
}

# Saves any changes made to an user account data hash.
#
# arg0: The user account.
sub save_user_data {
    my ($self, $user) = @_;
    
    my $userdata =  $self->get_user_data($user);
    if (defined $userdata) {
        my $file = File::Spec->catfile($self->bot()->basedir(), 'users', $user.'.user');
        LeBot::ConfigFile::save_config($file, $userdata);
    }
}

# Adds a new user account if it does not yet exist.
#
# arg0: The name of the user account to add.
# arg1: The initial password for this user account.
sub add_user {
    my ($self, $user, $passwd) = @_;

    if (! exists $self->{'_users'}->{$user}) {
        my $hash = {
            password => crypt($passwd, $self->bot()->generate_salt()),
            rights => {},
        };
        $self->{'_users'}->{$user} = $hash;
    }
}

# Removes an existing user account.
#
# arg0: The user account to delete.
sub remove_user {
    my ($self, $user) = @_;
    
    if (exists $self->{'_users'}->{$user}) {
        delete $self->{'_users'}->{$user};
        unlink $self->{'_basedir'}."/users/$user.user";
    }
}

##################
# Internal stuff #
##################

sub _load_accounts {
    my $self = shift;
    
    my $dir = File::Spec->catdir($self->bot()->basedir(), 'users');
    if (-d $dir) {
        opendir(DIR, $dir);
        my @files = readdir(DIR);
        closedir(DIR);
        my @userfiles = grep /\.user$/, @files;
    
        foreach (@userfiles) {
            my $file = $_;
            (my $user = $file) =~ s/\.user$//;
            my $fullfile = File::Spec->catfile($dir, $file);
            $self->{'accounts'}->{$user} = LeBot::ConfigFile::load_config($fullfile);
        }
    } else {
        mkdir $dir;
    }
    
    if (! defined $self->get_user_data('root')) {
        $self->add_user('root', 'lebot');
    }
}

sub _save_accounts {
    my $self = shift;
    
    foreach (keys %{$self->{'accounts'}}) {
        $self->save_user_data($_);
    }
}

######################
# Hooks and commands #
######################

sub _cmd_login {
    my ($self, $event) = @_;

    my ($cmd, $user, $password) = split /\s+/, $event->{'args'}->[0];
    my $login = $event->{'from'};
    
    if ($self->login_user($login, $user, $password)) {
        $self->bot()->context()->privmsg($event->{'nick'}, "logged in as $user");
    } else {
        $self->bot()->context()->privmsg($event->{'nick'}, "login failed");
    }
}

sub _cmd_logout {
    my ($self, $event) = @_;

    my $login = $event->{'from'};
    $self->logout_user($login);
}

sub _cmd_whoami {
    my ($self, $event) = @_;
    
    my $user = $self->get_user_name($event->{'from'});
    
    if (defined $user) {
        $self->bot()->context()->privmsg($event->{'nick'}, "you are currently logged in as $user");
    } else {
        $self->bot()->context()->privmsg($event->{'nick'}, "you are not logged in");
    }
}


sub _cmd_passwd {
    my ($self, $event) = @_;
    
    my ($cmd, $newpasswd) = split /\s+/, $event->{'args'}->[0];

    my $login = $event->{'from'};
    my $user = $self->get_user_name($login);
    
    if (defined $user) {
        my $data = $self->get_user_data($user);
        $data->{'password'} = crypt($newpasswd, $self->bot()->generate_salt());
        $self->save_user_data($user);
        $self->bot()->context()->privmsg($event->{'nick'}, "password for $user changed to $newpasswd");
    } else {
        $self->bot()->context()->privmsg($event->{'nick'}, "login first");
    }
}

sub _hook_nick {
    my ($self, $event) = @_;
    
    my $old_from = $event->{'from'};
    my $new_from = $event->{'args'}->[0].'!'.$event->{'userhost'};
    
    if (defined $self->get_user_name($event->{'from'})) {
        $self->change_user_login($old_from, $new_from);
    }
}

sub _hook_quit {
    my ($self, $event) = @_;

    if (defined $self->get_user_name($event->{'from'})) {
        $self->logout_user($event->{'from'});
    }    
}

1;

__END__
