#!/usr/bin/perl
package LeBot::ConfigFile;

use strict;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $file = shift;
    my $mtime = 0;
    my $data = {};
    
    if (defined $file) {
        die('file not found: '.$file) unless (-f $file);
        die('cannot read file: '.$file) unless (-r $file);
        
        $data = &parse_config($file);
        $mtime = (stat($file))[9];
    }
    
    my $self = {
        _file => $file,
        _mtime => $mtime,
        _data => $data,
    };

    bless $self, $class;
    
    return $self;
}

sub load {
    return $_[0]->new($_[1]);
}

sub save {
  my $self = shift;
  
  die('no filename in ConfigFile::save') unless (defined $self->{_file});
  
  my $file = $self->{_file};
  
  open(FILE, '>'.$file) || die('error opening (w) file: '.$file);
  print FILE &print_config($self->{_data});
  close(FILE);
}

sub load_config {
    my $file = shift;

    open(FILE, $file) || die "could not open $file";
    my $input = join('', (<FILE>));
    close(FILE);
    
    my $ctx = {
        'file' => $file,
        'line' => 1,
        'column' => 1,
        'input' => $input,
    };
    
    return &parse_config($ctx);
}

sub save_config {
    my ($file, $cfg) = @_;
    
    open(FILE, '>'.$file) || die "could not open $file";
    print FILE &print_config($cfg);
    close(FILE);
}

### VALIDATING ###

sub validate_config {
    my ($config, $definition, $module) = @_;
    
    &validate_hash($definition, $config, 'root', $module);
}

sub validate_value {
    my ($definition, $value, $value_type, $value_name) = @_;
    
    if ($value_type eq 'SCALAR') {
        die("value $value_name should be a SCALAR") if (ref($value));
    } else {
        if (exists $definition->{$value_type}) {
            my $type = $definition->{$value_type}->{type};
            if ($type eq 'HASH') {
                &validate_hash($definition, $value, $value_type, $value_name);
            } elsif ($type eq 'ARRAY') {
                &validate_array($definition, $value, $value_type, $value_name);
            } else {
                die("error in type definition $value_type");
            }
        }
    }
}

sub validate_hash {
    my ($definition, $value, $value_type, $value_name) = @_;
    my $value_def = $definition->{$value_type};
    
    if (ref($value) ne 'HASH') {
        die("value $value_name should be a HASH");
    }
    
    foreach (keys %$value) {
        my $key = $_;
        
        foreach (keys %{$value_def->{keys}}) {
            if ($key =~ /^$_$/) {
                &validate_value($definition, $value->{$key}, $value_def->{keys}->{$_}, $value_name.'->{'.$key.'}');
                last;
            }
        }
    }
}

sub validate_array {
    my ($definition, $value, $value_type, $value_name) = @_;
    my $value_def = $definition->{$value_type};
    
    if (ref($value) ne 'ARRAY') {
        die("value $value_name should be an ARRAY");
    }
    
    if (exists $value_def->{values}) {
        for (my $i = 0; $i < scalar @$value; ++$i) {
            &validate_value($definition, $value->[$i], $value_def->{values}, $value_name.'->['.$i.']');
        }
    }
}

### PRINTING ###
sub print_config {
    my $cfg = shift;
    my $str = '';

    foreach (sort keys %$cfg) {
        my $key = $_;
        my $value = $cfg->{$key};
        
        $str .= &print_scalar($key);
        $str .= ' ';
        $str .= &print_value($value, 1);
        $str .= "\n";
    }
    
    return $str;
}

sub print_value {
    my ($value, $indent) = @_;
    
    if (ref($value) eq 'HASH') {
        return &print_hash($value, $indent);
    } elsif (ref($value) eq 'ARRAY') {
        return &print_array($value, $indent);
    } else {
        return &print_scalar($value);
    }
    
}

sub print_hash {
    my $hash = shift;
    my $indent = shift;
    my $str = "{\n";

    foreach (sort keys %$hash) {
        my $key = $_;
        my $value = $hash->{$key};

        $str .= '    ' x $indent;
        $str .= &print_scalar($key);
        $str .= ' => ';
        $str .= &print_value($value, $indent + 1);
        $str .= ",\n";
    }
    
    $str .= '    ' x $indent;
    $str .= '}';
    
    return $str;
}

sub print_array {
    my $array = shift;
    my $indent = shift;
    my $str = '( ';

    foreach (@$array) {
        my $value = $_;

        $str .= &print_value($value, $indent + 1);
        $str .= ', ';
    }
    
    $str .= ')';
    
    return $str;
}

sub print_scalar {
    my $value = shift;

    if ($value =~ /^[a-zA-Z0-9_]+$/) {
        return $value;
    } else {
        (my $str = $value) =~ s/("|\\)/\\$1/g;
        return '"'.$str.'"';
    }
}

### PARSING ###
sub parse_config {
    my $ctx = shift;
    my $cfg = {};
    
    &parser_match($ctx, '\s*');
    while(length($ctx->{'input'}) > 0) {
        my $key = &parse_scalar($ctx);
        &parser_match($ctx, '\s+');
        my $value = &parse_value($ctx);
        &parser_match($ctx, '\s+');
        
        $cfg->{$key} = $value;
    }
    
    return $cfg;
}

sub parse_value {
        my $ctx = shift;

        if (defined &parser_lookahead($ctx, '{')) {
            return &parse_hash($ctx);
        } elsif (defined &parser_lookahead($ctx, '\\(')) {
            return &parse_array($ctx);
        } else {
            return &parse_scalar($ctx);
        }
}

sub parse_scalar {
    my $ctx = shift;
    
    if (defined &parser_lookahead($ctx, '"|\'')) {
        return &parse_string_literal($ctx);
    } else {
        my $value = &parser_match($ctx, '[a-zA-Z0-9_]+');
        &parser_die($ctx, 'value expected') unless (defined $value);
        return $value;
    }
}

sub parse_string_literal {
    my $ctx = shift;
    my $lit = '';
    my $ch;

    &parser_die($ctx, 'string literal expected') unless (defined ($ch = &parser_match($ctx, '"|\'')));
    while (! defined &parser_lookahead($ctx, "$ch|\\n|\$")) {
        if (defined &parser_lookahead($ctx, '\\\\')) {
            &parser_match($ctx, '\\\\');
            my $ch = &parser_match($ctx, '.');
            my $out;
            if ($ch eq 'n') {
                $out = "\n";
            } elsif ($ch eq 't') {
                $out = "\t";
            } elsif ($ch eq "\n") {
                $out = '';
            } else {
                $out = $ch;
            }
            $lit .= $out;
        } else {
            $lit .= &parser_match($ctx, "([^$ch\\n\\\$\\\\]|&(?!{))+");
        }
    }
    &parser_die($ctx, 'runaway string literal') unless (defined &parser_match($ctx, $ch));
    
    return $lit;
}

sub parse_array {
    my $ctx = shift;
    my $array = [];

    &parser_die($ctx, '( expected') unless (&parser_match($ctx, '\\('));
    &parser_match($ctx, '\s*');
    while (! defined &parser_lookahead($ctx, '\\)')) {
        push @$array, &parse_scalar($ctx);
        &parser_match($ctx, '\s*,?\s*');
    }
    &parser_die($ctx, ') expected') unless (&parser_match($ctx, '\\)'));
    
    return $array;
}

sub parse_hash {
    my $ctx = shift;
    my $hash = {};

    &parser_die($ctx, '{ expected') unless (&parser_match($ctx, '\{'));
    &parser_match($ctx, '\s*');
    while (! defined &parser_lookahead($ctx, '}')) {
        my ($key, $value) = &parse_pair($ctx);
        $hash->{$key} = $value;
        &parser_match($ctx, '\s*,?\s*');
    }
    &parser_die($ctx, '} expected') unless (&parser_match($ctx, '\}'));
    
    return $hash;
}

sub parse_pair {
    my $ctx = shift;
    
    my $key = &parse_scalar($ctx);
    &parser_match($ctx, '\s*');
    &parser_die(', or => expected') unless (defined &parser_match($ctx, ',|=>'));
    &parser_match($ctx, '\s*');
    my $value = &parse_value($ctx);
    
    return ($key, $value);
}

sub parser_lookahead {
    my ($ctx, $re) = @_;
    
    if ($ctx->{'input'} =~ /^($re)/) {
        return $&;
    } else {
        return undef;
    }
}

sub parser_match {
    my ($ctx, $re) = @_;
    
    if ($ctx->{'input'} =~ s/^($re)//) {
        my $match = $&;

        (my $buffer = $&) =~ s/[^\n]+//g;
        my $lines = length($buffer);
        $ctx->{'line'} += $lines;
        
        if ($lines > 0) {
            ($buffer = $match) =~ s/^.*\n//;
            $ctx->{'column'} = length($buffer)+1;
        } else {
            $ctx->{'column'} += length($match);
        }

        return $match;
    } else {
        return undef;
    }
}

sub parser_die {
    my ($ctx, $msg) = @_;

    die $ctx->{'file'}.' ('.$ctx->{'line'}.', '.$ctx->{'column'}.'): '.$msg.'; error';
}

1;

__END__
