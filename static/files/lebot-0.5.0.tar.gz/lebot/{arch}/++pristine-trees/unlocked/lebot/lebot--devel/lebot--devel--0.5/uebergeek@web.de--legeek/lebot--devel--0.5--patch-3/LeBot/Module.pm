#!/usr/bin/perl

package LeBot::Module;

use strict;

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $bot = shift;
    my $name = shift;
    
    my $self = {
        bot => $bot,
        
        name => $name,
        version => undef,
        author => undef,
        contact => undef,
        url => undef,        
    };
    
    bless $self, $class;
    
    return $self;
}

sub init {
}

sub done {
}

sub name {
    my $self = shift;
    return $self->{name};
}

sub version {
    my ($self, $version) = @_;
    return $self->_property('version', $version);
}

sub author {
    my ($self, $author) = @_;
    return $self->_property('author', $author);
}

sub contact {
    my ($self, $contact) = @_;
    return $self->_property('contact', $contact);
}

sub url {
    my ($self, $url) = @_;
    return $self->_property('url', $url);
}

sub bot {
    my $self = shift;
    
    return $self->{bot};
}

sub _property {
    my $self = shift;
    my $name = shift;
    my $value = shift;
    
    if (defined $value) {
        $self->{$name} = $value;
    }
    
    return $self->{$name};
}

1;

__END__
