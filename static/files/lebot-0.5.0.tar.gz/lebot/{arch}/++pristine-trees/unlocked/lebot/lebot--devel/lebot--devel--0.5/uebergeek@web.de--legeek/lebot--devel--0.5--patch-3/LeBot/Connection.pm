#!/usr/bin/perl

################################################################################
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Library General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
################################################################################

# Copyright (c) 2002
# Enno Cramer <uebergeek@web.de>

package LeBot::Connection;

use strict;
use vars ('@EVENTS');

# fill @EVENTS with all non-numeric events (see doc Net::IRC::Event)
@EVENTS = (
    'nick',
    'quit',
    'join',
    'part',
    'mode',         
    'topic',
    'kick',
    'public',
    'msg',
    'notice',
#    'ping',    # adding a ping handler makes Net::IRC not respond to ping anymore ... very bad :>
    'other',
    'invite',
    'kill',
    'disconnect',
    'leaving',
    'umode',
    'error',
    'cping',
    'cversion',
    'csource',
    'ctime',
    'cdcc',
    'cuserinfo',
    'cclientinfo',
    'cerrmsg',
    'cfinger',
    'caction',
    'crping',
    'crversion',
    'crsource',
    'crtime',
    'cruserinfo',
    'crclientinfo',
    'crfinger',
    'dcc_open',
    'dcc_update',
    'dcc_close',
    'chat'
    );

# add all numeric events from Net::IRC::Event to @EVENTS
foreach (1 .. 513) {
    my $name = Net::IRC::Event::trans($_);
    push @EVENTS, $name if (defined $name);
}

BEGIN {
    # add control functions on the fly
    # dequote format handler
    foreach (qw(
admin away connected ctcp ctcp_reply ignore info invite ison
join kick links list lusers maxlinelen me mode motd names new_chat new_get
new_send notice oper part peer privmsg rehash restart sconnect 
sl squit stats summon time topic trace unignore userhost users version wallops
who whois whowas
)) {
        my $method = $_;
        eval <<EOF;
sub $method {
    my \$self = shift;
    \$self->{_bot}->log('LeBot::Connection', "$method(".(scalar \@_ > 0 ? '"'.CORE::join("', '",\@_).'"' : '').')', 0);
    \$self->{_connection}->$method(\@_);
}
EOF

        if ($@) {
            print STDERR "DEBUG: error adding control function: $@\n";
        }
        if ($!) {
            print STDERR "DEBUG: error adding control function: $!\n";
        }
    }
}

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    
    my $bot = shift;
    my $network = shift;
    my $servers = shift;
    my $nicks = shift;
    
    my $connection = $bot->{_irc}->newconn();
    $connection->debug(1);
    
    my $self = {
        _bot => $bot,
        _connection => $connection,
        _network => $network,
        _servers => [],
        _cur_serv => 0,
        _nicks => [],
        _cur_nick => 0,
        _want_connect => 0,
    };
    
    bless $self, $class;
    
    foreach (@$servers) {
        my ($serv, $port) = split /:/;
        push @{$self->{_servers}}, [$serv || 'irc.openprojects.net', $port || 6667];
    }
    
    foreach (@$nicks) {
        push @{$self->{_nicks}}, $_;
    }
    
    # destroy event from Net::IRC::Connection triggers error in gc ... $self->{_bot} already undefined
    $self->{_connection}->add_handler(\@EVENTS, sub { if (defined $self->{_bot}) { $self->{_bot}->irc_event($self, $_[1]); } });
    $self->{_connection}->add_handler('nicknameinuse', sub { $self->_nick_in_use(); });
    $self->{_connection}->verbose(1);

    return $self;
}

sub network {
    my $self = shift;
    
    return $self->{_network};
}

sub want_connect {
    my $self = shift;
    
    if (@_) {
        $self->{_want_connect} = $_[0];
    }
    
    return $self->{_want_connect};
}

sub connect {
    my $self = shift;
    
    if ($self->connected()) {
        $self->disconnect();
    }
    
    $self->{_cur_serv} = 0;
    $self->want_connect(1);
}

sub try_to_connect {
    my $self = shift;
    
    $self->{_cur_nick} = 0;
    $self->{_connection}->nick($self->{_nicks}->[0]);
    
    $self->{_connection}->server($self->{_servers}->[$self->{_cur_serv}]->[0]);
    $self->{_connection}->port($self->{_servers}->[$self->{_cur_serv}]->[1]);
    
    if (!$self->{_connection}->connect()) {
        $self->{_cur_serv} = ($self->{_cur_serv} + 1) % scalar @{$self->{_servers}};
    }
}

sub disconnect {
    my $self = shift;
    
    $self->want_connect(0);
    $self->{_connection}->disconnect($_[0]);
}

sub quit {
    my $self = shift;
    
    $self->want_connect(0);
    $self->{_connection}->quit(@_[0]);
}

sub _nick_in_use {
    my $self = shift;

    $self->{_cur_nick}++;
    
    if ($self->{_cur_nick} == scalar @{$self->{_nicks}}) {
    # generate nick
    } else {
        $self->{_connection}->nick($self->{_nicks}->[$self->{_cur_nick}]);
    }
}

1;
