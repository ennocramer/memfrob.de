#include <lescegra.h>
#include <GL/glu.h>
#include <GL/gl.h>
#include <SDL/SDL.h>

#include <stdlib.h>

static SDL_Surface* screen = NULL;

static LsgPerspectiveCam* camera = NULL;
static LsgCoords* scene = NULL;

static int quit = 0;

static void display(void) {
    LsgFrustum* vf;
    int error;

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    /* reset viewing matrizes */
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    vf = LsgFrustum_create(matrix_identity, matrix_identity);
    LsgCamera_display(LSG_CAMERA(camera), vf, LSG_NODE(scene));
    LsgObject_free(LSG_OBJECT(vf));

    /* force rendering of cached geometry */
    glFlush();

    if ((error = glGetError()) != GL_NO_ERROR)
        LsgError_reportFormat(__FILE__, "display", __LINE__, "OpenGL Error: %s", gluErrorString(error));

    SDL_GL_SwapBuffers();
}

static void event_keydown(SDL_KeyboardEvent event) {
    switch (event.keysym.sym) {
        case 'q':
        case 'Q':
        case SDLK_ESCAPE:
            quit = 1;
            break;
        default:
            break;
    }
}

static void event_loop(void) {
    SDL_Event event;

    while (!quit) {
        display();

        SDL_WaitEvent(&event);
        do {
            switch(event.type) {
                case SDL_KEYDOWN:
                    event_keydown(event.key);
                    break;
                case SDL_QUIT:
                    quit = 1;
                    break;
                default:
                    break;
            }
        } while (SDL_PollEvent(&event));
    }
}

int main(int argc, char* argv[]) {
    SDL_Init(SDL_INIT_VIDEO);

    /* configure OpenGL display buffer */
    SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 5);
    SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 5);
    SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 5);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 16);
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

    /* create a new window */
    screen = SDL_SetVideoMode(320, 240, 16, SDL_HWSURFACE | SDL_OPENGL);
    SDL_WM_SetCaption("lescegra tutorial - lesson 00", NULL);

    /* create a camera and a scene */
    camera = LsgPerspectiveCam_create();
    scene = LsgCoords_create(1.0);

    /* position camera */
    vertex_assign(camera->location, 1.0, 2.0, 1.0);
    vertex_assign(camera->lookat,   0.0, 0.0, 0.0);
    vertex_assign(camera->up,       0.0, 1.0, 0.0);
    camera->fovy = 45.0;
    camera->aspect = 320.0 / 240.0;
    camera->dmin = 0.1;
    camera->dmax = 5.0;

    /* render scene and handle user input */
    event_loop();

    /* free allocated objects */
    LsgObject_free(LSG_OBJECT(scene));
    LsgObject_free(LSG_OBJECT(camera));

    /* close window */
    SDL_FreeSurface(screen);
    SDL_Quit();

    return 0;
}
