/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_WINDOW_CAM_H
#define LSG_WINDOW_CAM_H 1

#include <lescegra/sg/camera.h>

#include <lescegra/base/vertex.h>

typedef struct LsgWindowCam LsgWindowCam;
typedef struct LsgWindowCamClass LsgWindowCamClass;

struct LsgWindowCam {
    LsgCamera parent;
    
    Vertex location, center;
    Vertex axes[3];
    float w, h;

    float dmin, dmax;
};

struct LsgWindowCamClass {
    LsgCameraClass parent;
};

LsgClassID LsgWindowCam_classID(void);

#define IS_LSG_WINDOW_CAM(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgWindowCam_classID())

#define LSG_WINDOW_CAM(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgWindowCam*, LsgWindowCam_classID(), (instance))

#define LSG_WINDOW_CAM_CLASS(class) \
    LSG_CLASS_CAST(LsgWindowCamClass*, LsgWindowCam_classID(), (class))

LsgWindowCam* LsgWindowCam_create(void);

void LsgWindowCam_init(LsgWindowCam* self);

void LsgWindowCam_setWindow(
    LsgWindowCam* self,
    const Vertex center,
    const Vertex base,
    const Vertex up,
    float dmin,
    float dmax
);

#endif
