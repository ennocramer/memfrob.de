/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_PERSPECTIVECAM_H
#define LSG_PERSPECTIVECAM_H 1

/**
 * \file  perspectivecam.h
 * \brief Perspective camera with location and lookat
 */

#include <lescegra/sg/camera.h>

#include <lescegra/base/vertex.h>

typedef struct LsgPerspectiveCam LsgPerspectiveCam;
typedef struct LsgPerspectiveCamClass LsgPerspectiveCamClass;

/**
 * \brief Perspective camera with location and lookat
 *
 * A perspective camera that is defined by the three vertices location, lookat
 * and up, the field-of-view and a minimal and maximal viewing distance.
 */
struct LsgPerspectiveCam {
    LsgCamera parent;

    Vertex location;
    Vertex lookat;
    Vertex up;
    float fovy;
    float aspect;
    float dmin;
    float dmax;
};

struct LsgPerspectiveCamClass {
    LsgCameraClass parent;
};

LsgClassID LsgPerspectiveCam_classID(void);

#define IS_LSG_PERSPECTIVE_CAM(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgPerspectiveCam_classID())

#define LSG_PERSPECTIVE_CAM(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgPerspectiveCam*, LsgPerspectiveCam_classID(), (instance))

#define LSG_PERSPECTIVE_CAM_CLASS(class) \
    LSG_CLASS_CAST(LsgPerspectiveCamClass*, LsgPerspectiveCam_classID(), (class))

/**
 * \relates LsgPerspectiveCam
 * Allocate and initialize a LsgPerspectiveCam.
 * @return A new LsgPerspectiveCam instance
 */
LsgPerspectiveCam* LsgPerspectiveCam_create(void);

/**
 * \relates LsgPerspectiveCam
 * Constructor method for LsgPerspectiveCam. Initialize the camera as looking from
 * {0, 0, -1} to the center of the coordinate system with the second (y) axis
 * being up. The initial field-of-view is 45 degrees in both directions.
 * @param self      The instance variable
 */
void LsgPerspectiveCam_init(LsgPerspectiveCam* self);

#endif
