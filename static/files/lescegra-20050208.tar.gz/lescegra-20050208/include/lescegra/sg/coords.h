/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_COORDS_H
#define LSG_COORDS_H 1

/**
 * \file  coords.h
 * \brief Colored coordinate system
 */

#include <lescegra/sg/node.h>

typedef struct LsgCoords LsgCoords;
typedef struct LsgCoordsClass LsgCoordsClass;

/**
 * \brief Colored coordinate system
 *
 * Display a red, green, blue colored coordinate system.
 */
struct LsgCoords {
    LsgNode parent;

    float size;
};

struct LsgCoordsClass {
    LsgNodeClass parent;
};

LsgClassID LsgCoords_classID(void);

#define IS_LSG_COORDS(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgCoords_classID())

#define LSG_COORDS(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgCoords*, LsgCoords_classID(), (instance))

#define LSG_COORDS_CLASS(class) \
    LSG_CLASS_CAST(LsgCoordsClass*, LsgCoords_classID(), (class))

/**
 * \relates LsgCoords
 * Allocate and initialize a new LsgCoords.
 * @param size      The axes length
 * @return A new LsgCoords instance
 */
LsgCoords* LsgCoords_create(float size);

/**
 * \relates LsgCoords
 * Constructor method for LsgCoords.
 * @param self      The instance variable
 * @param size      The axes length
 */
void LsgCoords_init(LsgCoords* self, float size);

#endif
