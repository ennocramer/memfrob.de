/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_LIGHT_H
#define LSG_LIGHT_H 1

/**
 * \file  light.h
 * \brief Directional or point light source
 */

#include <lescegra/sg/state.h>

#include <lescegra/base/vertex.h>

typedef struct LsgLight LsgLight;
typedef struct LsgLightClass LsgLightClass;

/**
 * \ingroup scene
 * \brief   Directional or point light source
 *
 * A Light source defining a location and a color.
 */
struct LsgLight {
    LsgState parent;

    float color[4];
    float location[4];
    int num;
};

struct LsgLightClass {
    LsgStateClass parent;
};

#define IS_LSG_LIGHT(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgLight_classID())

#define LSG_LIGHT(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgLight*, LsgLight_classID(), (instance))

#define LSG_LIGHT_CLASS(class) \
    LSG_CLASS_CAST(LsgLightClass*, LsgLight_classID(), (class))

LsgClassID LsgLight_classID(void);

LsgLight* LsgLight_create(int num);
void LsgLight_init(LsgLight* self, int num);

#endif
