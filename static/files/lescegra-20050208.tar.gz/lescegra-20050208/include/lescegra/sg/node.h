/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_NODE_H
#define LSG_NODE_H 1

/**
 * \file  node.h
 * \brief Scene graph hierarchy base class
 */

#include <lescegra/base/object.h>

#include <lescegra/coll/bvolume.h>
#include <lescegra/coll/frustum.h>

typedef struct LsgNode LsgNode;
typedef struct LsgNodeClass LsgNodeClass;

/**
 * \brief Scene graph hierarchy base class
 *
 * Abstract base class for the scene graph class hierarchy.
 */
struct LsgNode {
    LsgObject parent;

    LsgBVolume* bvolume;
    int updated;
    int dirty;
};

struct LsgNodeClass {
    LsgObjectClass parent;

    void (*clean)(LsgNode* self);
    void (*update)(LsgNode* self, float now);
    void (*display)(const LsgNode* self, const LsgFrustum* frustum);
};

LsgClassID LsgNode_classID(void);

#define IS_LSG_NODE(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgNode_classID())

#define LSG_NODE(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgNode*, LsgNode_classID(), (instance))

#define LSG_NODE_CLASS(class) \
    LSG_CLASS_CAST(LsgNodeClass*, LsgNode_classID(), (class))

/**
 * \relates LsgNode
 * Constructor for LsgNode. Initially clear the bounding box and set the dirty flag
 * to make the first call to update recompute the complete bounding box tree.
 * @param self      The instance variable
 */
void LsgNode_init(LsgNode* self);

/**
 * \relates LsgNode
 * Clean the node.
 * @param self      The instance variable
 */
void LsgNode_clean(LsgNode* self);

/**
 * \relates LsgNode
 * Update the node.
 * @param self      The instance variable
 * @param now       The new time value
 */
void LsgNode_update(LsgNode* self, float now);

/**
 * \relates LsgNode
 * Display the node.
 * @param self      The instance variable
 * @param frustum   The current view frustum
 */
void LsgNode_display(const LsgNode* self, const LsgFrustum* frustum);

#endif
