/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_PATH_H
#define LSG_PATH_H 1

#include <lescegra/base/object.h>

#include <lescegra/base/vertex.h>
#include <lescegra/util/list.h>

typedef enum {
    LSG_PATH_STEP,
    LSG_PATH_LINEAR,
    LSG_PATH_BEZIER,
    LSG_PATH_CATMULL_ROM
} LsgPath_Mode;

typedef struct {
    Vertex v;
    float time;
} LsgPath_Key;

typedef struct LsgPath LsgPath;
typedef struct LsgPathClass LsgPathClass;

struct LsgPath {
    LsgObject parent;

    LsgList* keys;
    LsgPath_Mode mode;
};

struct LsgPathClass {
    LsgObjectClass parent;
};

LsgClassID LsgPath_classID(void);

#define IS_LSG_PATH(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgPath_classID())

#define LSG_PATH(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgPath*, LsgPath_classID(), (instance))

#define LSG_PATH_CLASS(class) \
    LSG_CLASS_CAST(LsgPathClass*, LsgPath_classID(), (class))

LsgPath* LsgPath_create(LsgPath_Mode mode);
void LsgPath_init(LsgPath* self, LsgPath_Mode mode);

void LsgPath_interpolate(LsgPath* self, float time, Vertex v);
void LsgPath_addKey(LsgPath* self, Vertex v, float time);
void LsgPath_clear(LsgPath* self);

#endif
