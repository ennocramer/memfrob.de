/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_LINKEDLIST_H
#define LSG_LINKEDLIST_H 1

#include <lescegra/util/list.h>

/**
 * \file  linkedlist.h
 * \brief A single linked list
 */

typedef struct LsgLinkedListElement LsgLinkedListElement;
struct LsgLinkedListElement {
    void* value;
    LsgLinkedListElement* next;
};

typedef struct LsgLinkedList LsgLinkedList;
typedef struct LsgLinkedListClass LsgLinkedListClass;

/**
 * \ingroup util
 * \brief   Linked list
 *
 * A linked list
 */
struct LsgLinkedList {
    LsgList parent;
    
    LsgLinkedListElement* first;
};

struct LsgLinkedListClass {
    LsgListClass parent;
};

LsgClassID LsgLinkedList_classID(void);

#define IS_LSG_LINKED_LIST(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgLinkedList_classID())

#define LSG_LINKED_LIST(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgLinkedList*, LsgLinkedList_classID(), (instance))

#define LSG_LINKED_LIST_CLASS(class) \
    LSG_CLASS_CAST(LsgLinkedListClass*, LsgLinkedList_classID(), (class))

LsgLinkedList* LsgLinkedList_create(void);
void LsgLinkedList_init(LsgLinkedList* self);

/* LsgLinkedListIterator */

typedef struct LsgLinkedListIterator LsgLinkedListIterator;
typedef struct LsgLinkedListIteratorClass LsgLinkedListIteratorClass;

/**
 * \brief Iterator for LsgLinkedList
 *
 * An iterator for the LsgLinkedList
 */
struct LsgLinkedListIterator {
    LsgIterator parent;
    
    LsgLinkedListElement* element;
};

struct LsgLinkedListIteratorClass {
    LsgIteratorClass parent;
};

LsgClassID LsgLinkedListIterator_classID(void);

#define LSG_LINKED_LIST_ITERATOR(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgLinkedListIterator*, LsgLinkedListIterator_classID(), (instance))

#define LSG_LINKED_LIST_ITERATOR_CLASS(class) \
    LSG_CLASS_CAST(LsgLinkedListIteratorClass*, LsgLinkedListIterator_classID(), (class))

LsgLinkedListIterator* LsgLinkedListIterator_create(LsgLinkedList* list);
void LsgLinkedListIterator_init(LsgLinkedListIterator* self, LsgLinkedList* list);

#endif
