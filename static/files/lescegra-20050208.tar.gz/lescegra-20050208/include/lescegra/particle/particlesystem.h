/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_PARTICLESYSTEM_H
#define LSG_PARTICLESYSTEM_H 1

/**
 * \file  particlesystem.h
 * \brief Particle system container
 */

#include <lescegra/sg/group.h>

#include <lescegra/particle/particle.h>

#include <lescegra/util/list.h>

typedef struct LsgParticleSystem LsgParticleSystem;
typedef struct LsgParticleSystemClass LsgParticleSystemClass;

/**
 * \ingroup particle
 * \brief   Particle system container
 *
 * LsgGroup node to encapsulate all particles and modifiers that belong to one
 * particle system.
 */
struct LsgParticleSystem {
    LsgGroup parent;

    LsgList* modifiers;
};

struct LsgParticleSystemClass {
    LsgGroupClass parent;
};

LsgClassID LsgParticleSystem_classID(void);

#define IS_LSG_PARTICLE_SYSTEM(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgParticleSystem_classID())

#define LSG_PARTICLE_SYSTEM(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgParticleSystem*, LsgParticleSystem_classID(), (instance))

#define LSG_PARTICLE_SYSTEM_CLASS(class) \
    LSG_CLASS_CAST(LsgParticleSystemClass*, LsgParticleSystem_classID(), (class))

/**
 * \relates LsgParticleSystem
 * Allocate and initialize a new LsgParticleSystem instance.
 * @return a new LsgParticleSystem instance
 */
LsgParticleSystem* LsgParticleSystem_create(void);

/**
 * \relates LsgParticleSystem
 * Constructor for LsgParticleSystem. Create an initially empty particle system.
 * @param self      The instance variable
 */
void LsgParticleSystem_init(LsgParticleSystem* self);

#endif
