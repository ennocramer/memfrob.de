/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_ERROR_H
#define LSG_ERROR_H 1

/**
 * \file  error.h
 * \brief Error handling
 */

/**
 * \brief Error Message
 *
 * Encapsulate an error message and the location where it has been reported.
 */
typedef struct {
    const char* message;
    const char* file;
    const char* method;
    unsigned int line;
} LsgError;

typedef void (*LsgErrorHandler)(const LsgError* error);

void LsgError_registerHandler(LsgErrorHandler handler);

/**
 * \relates LsgError
 * Report an error condition using the currently registered error handler.
 * @param file      The source file from where the error is reported
 * @param method    The method reporting the error
 * @param line      The line of the source file where the error is reported
 * @param message   The error message
 */
void LsgError_report(const char* file, const char* method, unsigned int line, const char* message);

/**
 * \relates LsgError
 * Report an error condition with a formatted message using the currently
 * registered error handler.
 * @param file      The source file from where the error is reported
 * @param method    The method reporting the error
 * @param line      The line of the source file where the error is reported
 * @param format    The error message template
 */
void LsgError_reportFormat(const char* file, const char* method, unsigned int line, const char* format, ...);

/**
 * \relates LsgError
 * Report an error condition and abort the program.
 * @param file      The source file from where the error is reported
 * @param method    The method reporting the error
 * @param line      The line of the source where the error is reported
 * @param message   The error message
 */
void LsgError_abort(const char* file, const char* method, unsigned int line, const char* message);

/**
 * \relates LsgError
 * Report an error condition with a formatted message and abort the program.
 * @param file      The source file from where the error is reported
 * @param method    The method reporting the error
 * @param line      The line of the source where the error is reported
 * @param format    The error message template
 */
void LsgError_abortFormat(const char* file, const char* method, unsigned int line, const char* format, ...);

/**
 * \relates LsgError
 * Abort the program with an error message if a given assertion is not met.
 * @param assertion The assertion to be tested
 * @param message   The error message to show if the assertion is not met
 * @param file      The source file from where the error is reported
 * @param method    The method reporting the error
 * @param line      The line of the source where the error is reported
 */
void LsgError_assert(int assertion, const char* message, const char* file, const char* method, unsigned int line);

#ifdef __GNUC__
#define LSG_ERROR_CURRENT_FUNCTION __PRETTY_FUNCTION__
#else
#define LSG_ERROR_CURRENT_FUNCTION ((const char*)0)
#endif

#ifdef NDEBUG
# define assert_msg(expr, msg)
# define assert(expr)
#else
# define assert_msg(expr, msg) LsgError_assert((expr), (msg), __FILE__, LSG_ERROR_CURRENT_FUNCTION, __LINE__)
# define assert(expr)          assert_msg((expr), #expr)
#endif

#endif
