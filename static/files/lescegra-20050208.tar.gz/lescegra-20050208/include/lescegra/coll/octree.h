/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_OCTREE_H
#define LSG_OCTREE_H 1

#include <lescegra/base/object.h>

#include <lescegra/base/vertex.h>
#include <lescegra/util/list.h>
#include <lescegra/coll/frustum.h>

typedef struct LsgOctree LsgOctree;
typedef struct LsgOctreeClass LsgOctreeClass;

struct LsgOctree {
    LsgObject parent;

    Vertex min;
    Vertex max;
    Vertex sep;
    Vertex vmin;
    Vertex vmax;
    int divisions;

    LsgOctree* children[8];
    LsgList* data;
};

struct LsgOctreeClass {
    LsgObjectClass parent;
};

LsgClassID LsgOctree_classID(void);

#define IS_LSG_OCTREE(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgOctree_classID())

#define LSG_OCTREE(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgOctree*, LsgOctree_classID(), (instance))

#define LSG_OCTREE_CLASS(class) \
    LSG_CLASS_CAST(LsgOctreeClass*, LsgOctree_classID(), (class))

LsgOctree* LsgOctree_create(const Vertex min, const Vertex max, int div);
LsgOctree* LsgOctree_createOptimal(const Vertex min, const Vertex max, int count, int target_count);
void LsgOctree_init(LsgOctree* self, const Vertex min, const Vertex max, int div);
void LsgOctree_add(LsgOctree* self, const Vertex min, const Vertex max, void* data);
void LsgOctree_getVisible(const LsgOctree* self, const LsgFrustum* frustum, LsgList* target);
void LsgOctree_getCollideVertex(const LsgOctree* self, const Vertex v, LsgList* target);
void LsgOctree_getCollideRay(const LsgOctree* self, const Vertex from, const Vertex dir, LsgList* target);
void LsgOctree_getCollideSphere(const LsgOctree* self, const Vertex center, float radius, LsgList* target);

#endif
