/**
 * \page pg_class Custom Classes
 *
 * \section pg_class_struct Class Struct
 *
 * A class definition consists of two structures. The first structure
 * defines the object and its member variables, while the second
 * provides the classes virtual method table.
 *
 * To faciliate Class Inheritance, both structures must contain the
 * corresponding structure of their parent class as the first
 * structure member. For ... these members should be named \c parent.
 *
 * \b Example:
 * \dontinclude node.h
 * \skipline typedef
 * \skipline typedef
 * \skip struct
 * \until };
 * \until };
 *
 *
 *
 * \section pg_class_classid The Class ID
 *
 * Every class is identified by a numeric id, to faciliate (runtime)
 * checked casts and runtime type information. This id is acquired by
 * registering the class via the LsgClass_register method.
 *
 * To ensure that every class is registered exactly once, the call to
 * LsgClass_register should be encapsulated and managed within the
 * class code.
 *
 * The global class registry also manages the classes virtual method
 * table and an object prototype.
 *
 * \b Example:
 * \dontinclude node.c
 * \skip LsgNode_staticInit
 * \until }
 * \until }
 * \until }
 *
 *
 *
 * \section pg_class_constructor The Constructor
 *
 * The constructor for a scene graph class is divided into two
 * functions. The first is responsible for allocating memory for a new
 * class instance, the second for initializing the newly allocated
 * memory.
 *
 * This division is necessary to allow the initializer being reused in
 * descendant classes. Also it allows the creation of abstract classes
 * by omitting the memory allocating part of the constructor.
 *
 *
 * \subsection pg_class_create The Memory Allocator
 *
 * The memory allocator is quite trivial and looks almost the same for
 * every class. It does the following three steps:
 *
 * -# allocate memory for the new instance (using LsgClass_alloc
 *    to handle static initialization)
 * -# call the initializer passing the new instance and all parameters
 * -# return the new instance
 *
 * \note This method should return \c NULL if an error is encountered
 * while initializing the instance.
 *
 *
 * \subsection pg_class_init The Initializer
 *
 * The initializer is the part of the constructor that does the actual
 * work. It is responsible for correctly initializing the object
 * structure.
 *
 * \b Example:
 * \dontinclude group.c
 * \skipline LsgGroup_create
 * \until }
 * \until }
 *
 *
 *
 * \section pg_class_destroy The Destructor
 *
 * The virtual destructor method is called by \c LsgObject_free to
 * free any allocated resources prior to destroying an object
 * instance.
 *
 * \b Example:
 * \dontinclude group.c
 * \skip LsgGroup_create
 * \skip LsgGroup_destroy
 * \until }
 */
