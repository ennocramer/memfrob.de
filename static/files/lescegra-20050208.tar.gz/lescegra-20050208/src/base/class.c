#include <lescegra/base/class.h>

#include <lescegra/base/error.h>

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

typedef struct {
    const char*       name;
    LsgClassID        parent;
    unsigned int      flags;

    unsigned int      class_size;
    LsgClass*         class;

    unsigned int      instance_size;
    LsgClassInstance* instance;
} LsgClassInfo;

static LsgClassInfo*  classes       = NULL;
static unsigned int   classes_size  = 0;
static unsigned int   classes_count = 0;

LsgClassID LsgClass_register(
        const char*          name,
        LsgClassID           parent,
        unsigned int         flags,
        unsigned int         class_size,
        unsigned int         instance_size,
        LsgClassStaticInitializer static_init
) {
    LsgClassInfo* cinfo;

    if (classes_size == classes_count) {
        if (classes_size == 0)
            classes_size = 32;
        else
            classes_size *= 2;

        classes = realloc(classes, sizeof(LsgClassInfo) * classes_size);

        assert(classes != NULL);

        if (classes_count == 0) {
            classes[0].name          = "LsgClass";
            classes[0].parent        = LSG_CLASS_ID_NONE;
            classes[0].flags         = LSG_CLASS_FLAG_ABSTRACT;
            classes[0].class_size    = sizeof(LsgClass);
            classes[0].instance_size = sizeof(LsgClassInstance);
            classes[0].class         = (LsgClass*)malloc(sizeof(LsgClass));
            classes[0].instance      = (LsgClassInstance*)malloc(sizeof(LsgClassInstance));

            classes[0].class->id       = LSG_CLASS_ID_NONE;
            classes[0].instance->class = classes[0].class;

            classes_count = 1;
        }
    }

    assert_msg(
        parent < classes_count,
        "Parent class does not exists."
    );

    assert_msg(
        (classes[parent].flags & LSG_CLASS_FLAG_FINAL) == 0x00,
        "Parent class is declared final."
    );

    assert_msg(
        classes[parent].class_size <= class_size,
        "Invalid class size."
    );

    assert_msg(
        classes[parent].instance_size <= instance_size,
        "Invalid class instance size."
    );

    cinfo = classes + classes_count;
    cinfo->class    = (LsgClass*)malloc(class_size);
    cinfo->instance = (LsgClassInstance*)malloc(instance_size);

    assert(cinfo->class    != NULL);
    assert(cinfo->instance != NULL);

    cinfo->name   = name;
    cinfo->parent = parent;
    cinfo->flags  = flags;

    cinfo->class_size    = class_size;
    cinfo->instance_size = instance_size;

    memcpy(cinfo->class,    classes[parent].class,    classes[parent].class_size);
    memcpy(cinfo->instance, classes[parent].instance, classes[parent].instance_size);

    cinfo->class->id       = (LsgClassID)classes_count;
    cinfo->instance->class = cinfo->class;

    if (static_init)
        static_init(cinfo->class, cinfo->instance);

    return (LsgClassID)classes_count++;
}

const char* LsgClass_getClassName(LsgClassID classid) {
    assert_msg(
        classid < classes_count,
        "Class does not exist."
    );

    return classes[classid].name;
}

const LsgClass* LsgClass_getClass(LsgClassID classid) {
    assert_msg(
        classid < classes_count,
        "Class does not exist."
    );

    return classes[classid].class;
}

LsgClassID LsgClass_getParent(LsgClassID classid) {
    assert_msg(
        classid < classes_count,
        "Class does not exist."
    );

    return classes[classid].parent;
}

unsigned int LsgClass_getFlags(LsgClassID classid) {
    assert_msg(
        classid < classes_count,
        "Class does not exist."
    );

    return classes[classid].flags;
}

LsgClassInstance* LsgClass_alloc(LsgClassID classid) {
    LsgClassInstance* instance;

    assert_msg(
        classid < classes_count,
        "Class does not exist."
    );

    assert_msg(
        (classes[classid].flags & LSG_CLASS_FLAG_ABSTRACT) == 0,
        "Class is declared abstract."
    );

    instance = malloc(classes[classid].instance_size);

    assert(instance != NULL);

    memcpy(instance, classes[classid].instance, classes[classid].instance_size);

    return instance;
}

int LsgClass_isInstanceOf(const LsgClassInstance* instance, LsgClassID classid) {
    if (instance == NULL)
        return 1;
    else
        return LsgClass_isChildOf(instance->class, classid);
}

int LsgClass_isChildOf(const LsgClass* class, LsgClassID classid) {
    LsgClassID cid;

    if (class == NULL)
        return 0;

    cid = class->id;
    while ((cid != classid) && (cid != LSG_CLASS_ID_NONE))
        cid = classes[cid].parent;

    return cid == classid;
}

LsgClassInstance* LsgClass_assertInstanceCast(LsgClassInstance* instance, LsgClassID classid, const char* file, const char* method, unsigned int line) {
    if (!LsgClass_isInstanceOf(instance, classid)) {
        LsgError_abortFormat(file, method, line,
            "Illegal instance cast.\n"
            "Cannot cast object of type %s to type %s.",
            LsgClass_getClassName(instance->class->id),
            LsgClass_getClassName(classid)
        );
    }

    return instance;
}

LsgClass* LsgClass_assertClassCast(LsgClass* class, LsgClassID classid, const char* file, const char* method, unsigned int line) {
    if (!LsgClass_isChildOf(class, classid)) {
        LsgError_abortFormat(file, method, line,
            "Illegal class cast.\n"
            "Cannot cast class %s to class %s.",
            LsgClass_getClassName(class->id),
            LsgClass_getClassName(classid)
        );
    }

    return class;
}

LsgClassInstance* LsgClass_instanceCast(LsgClassInstance* instance, LsgClassID classid) {
    if (LsgClass_isInstanceOf(instance, classid)) {
        return instance;
    } else {
        return NULL;
    }
}

LsgClass* LsgClass_classCast(LsgClass* class, LsgClassID classid) {
    if (LsgClass_isChildOf(class, classid)) {
        return class;
    } else {
        return NULL;
    }
}

void LsgClass_abortAbstract(LsgClassInstance* instance, LsgClassID classid, const char* method) {
    LsgError_abortFormat(__FILE__, LSG_ERROR_CURRENT_FUNCTION, __LINE__,
        "Unimplemented method called.\n"
        "Method %s::%s is not implemented in class %s.",
        LsgClass_getClassName(classid),
        method,
        LsgClass_getClassName(instance->class->id)
    );
}
