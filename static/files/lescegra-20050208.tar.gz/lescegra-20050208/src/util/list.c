#include <lescegra/util/list.h>

#include <stddef.h>

static int   LsgIterator_hasNext_impl(LsgIterator* self);
static void* LsgIterator_next_impl(LsgIterator* self);

static void LsgIterator_staticInit(LsgIteratorClass* class, LsgIterator* instance) {
    class->hasNext = LsgIterator_hasNext_impl;
    class->next    = LsgIterator_next_impl;
}

LsgClassID LsgIterator_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgIterator",
            LsgObject_classID(),
            LSG_CLASS_FLAG_ABSTRACT,
            sizeof(LsgIteratorClass),
            sizeof(LsgIterator),
            (LsgClassStaticInitializer)LsgIterator_staticInit
        );
    }

    return classid;
}

void LsgIterator_init(LsgIterator* self) {
    LsgObject_init(&self->parent);
}

static int LsgIterator_hasNext_impl(LsgIterator* self) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgIterator_classID(), "hasNext");

    return 0;
}

int LsgIterator_hasNext(LsgIterator* self) {
    LsgIteratorClass* class = (LsgIteratorClass*)((LsgClassInstance*)self)->class;

    return class->hasNext(self);
}

static void* LsgIterator_next_impl(LsgIterator* self) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgIterator_classID(), "next");

    return NULL;
}

void* LsgIterator_next(LsgIterator* self) {
    LsgIteratorClass* class = (LsgIteratorClass*)((LsgClassInstance*)self)->class;

    return class->next(self);
}

/* LsgList *************************************************************/

static int   LsgList_count_impl(LsgList* self);
static int   LsgList_contains_impl(LsgList* self, void* object);
static int   LsgList_index_impl(LsgList* self, void* object);
static void  LsgList_append_impl(LsgList* self, void* object);
static void  LsgList_insert_impl(LsgList* self, int index, void* object);
static int    LsgList_remove_impl(LsgList* self, void* object);
static void* LsgList_removeByIndex_impl(LsgList* self, int index);
static void* LsgList_get_impl(LsgList* self, int index);
static void* LsgList_set_impl(LsgList* self, int index, void* object);
static void  LsgList_clear_impl(LsgList* self);
static LsgIterator* LsgList_iterator_impl(LsgList* self);

static void LsgList_staticInit(LsgListClass* class, LsgList* instance) {
    instance->ref_elements = 0;

    class->count         = LsgList_count_impl;
    class->contains      = LsgList_contains_impl;
    class->index         = LsgList_index_impl;
    class->append        = LsgList_append_impl;
    class->insert        = LsgList_insert_impl;
    class->remove        = LsgList_remove_impl;
    class->removeByIndex = LsgList_removeByIndex_impl;
    class->get           = LsgList_get_impl;
    class->set           = LsgList_set_impl;
    class->clear         = LsgList_clear_impl;
    class->iterator      = LsgList_iterator_impl;
}

LsgClassID LsgList_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgList",
            LsgObject_classID(),
            LSG_CLASS_FLAG_ABSTRACT,
            sizeof(LsgListClass),
            sizeof(LsgList),
            (LsgClassStaticInitializer)LsgList_staticInit
        );
    }

    return classid;
}

void LsgList_init(LsgList* self) {
    LsgObject_init(&self->parent);
}

void LsgList_refElements(LsgList* self, int ref) {
    if (!self->ref_elements != !ref) {
        LsgIterator* it = LsgList_iterator(self);
        while (LsgIterator_hasNext(it)) {
            void* object = LsgIterator_next(it);
            
            if (object) {
                if (ref)
                    LsgObject_ref(LSG_OBJECT(object));
                else
                    LsgObject_unref(LSG_OBJECT(object));
            }
        }
        LsgObject_free(LSG_OBJECT(it));
    }

    self->ref_elements = ref;
}

static int  LsgList_count_impl(LsgList* self) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgList_classID(), "count");

    return 0;
}

int LsgList_count(LsgList* self) {
    LsgListClass* class = (LsgListClass*)((LsgClassInstance*)self)->class;

    return class->count(self);
}

static int LsgList_contains_impl(LsgList* self, void* object) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgList_classID(), "contains");

    return 0;
}

int LsgList_contains(LsgList* self, void* object) {
    LsgListClass* class = (LsgListClass*)((LsgClassInstance*)self)->class;

    return class->contains(self, object);
}

static int LsgList_index_impl(LsgList* self, void* object) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgList_classID(), "index");

    return 0;
}

int LsgList_index(LsgList* self, void* object) {
    LsgListClass* class = (LsgListClass*)((LsgClassInstance*)self)->class;

    return class->index(self, object);
}

static void LsgList_append_impl(LsgList* self, void* object) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgList_classID(), "append");

    return;
}

void LsgList_append(LsgList* self, void* object) {
    LsgListClass* class = (LsgListClass*)((LsgClassInstance*)self)->class;

    if (self->ref_elements && object)
        LsgObject_ref(LSG_OBJECT(object));

    class->append(self, object);
}

static void LsgList_insert_impl(LsgList* self, int index, void* object) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgList_classID(), "insert");

    return;
}

void LsgList_insert(LsgList* self, int index, void* object) {
    LsgListClass* class = (LsgListClass*)((LsgClassInstance*)self)->class;

    if (self->ref_elements && object)
        LsgObject_ref(LSG_OBJECT(object));

    class->insert(self, index, object);
}

static int LsgList_remove_impl(LsgList* self, void* object) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgList_classID(), "remove");

    return 0;
}

int LsgList_remove(LsgList* self, void* object) {
    LsgListClass* class = (LsgListClass*)((LsgClassInstance*)self)->class;

    int index = class->remove(self, object);

    if (self->ref_elements && index && object)
        LsgObject_unref(LSG_OBJECT(object));

    return index;
}

static void* LsgList_removeByIndex_impl(LsgList* self, int index) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgList_classID(), "removeByIndex");

    return NULL;
}

void* LsgList_removeByIndex(LsgList* self, int index) {
    LsgListClass* class = (LsgListClass*)((LsgClassInstance*)self)->class;

    void* object = class->removeByIndex(self, index);

    if (self->ref_elements && object)
        LsgObject_unref(LSG_OBJECT(object));

    return object;
}

static void* LsgList_get_impl(LsgList* self, int index) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgList_classID(), "get");

    return NULL;
}

void* LsgList_get(LsgList* self, int index) {
    LsgListClass* class = (LsgListClass*)((LsgClassInstance*)self)->class;

    return class->get(self, index);
}

static void* LsgList_set_impl(LsgList* self, int index, void* object) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgList_classID(), "set");

    return NULL;
}

void* LsgList_set(LsgList* self, int index, void* object) {
    LsgListClass* class = (LsgListClass*)((LsgClassInstance*)self)->class;

    void* old_object = class->set(self, index, object);

    if (self->ref_elements && old_object)
        LsgObject_unref(LSG_OBJECT(old_object));

    return old_object;
}

static void LsgList_clear_impl(LsgList* self) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgList_classID(), "clear");

    return;
}

void LsgList_clear(LsgList* self) {
    LsgListClass* class = (LsgListClass*)((LsgClassInstance*)self)->class;

    if (self->ref_elements) {
        LsgIterator* it = LsgList_iterator(self);
        while (LsgIterator_hasNext(it)) {
            void* object = LsgIterator_next(it);
            
            if (object)
                LsgObject_unref(LSG_OBJECT(object));
        }
        LsgObject_free(LSG_OBJECT(it));
    }

    class->clear(self);
}

static LsgIterator* LsgList_iterator_impl(LsgList* self) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgList_classID(), "iterator");

    return NULL;
}

LsgIterator* LsgList_iterator(LsgList* self) {
    LsgListClass* class = (LsgListClass*)((LsgClassInstance*)self)->class;

    return class->iterator(self);
}
