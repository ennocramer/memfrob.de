#include <lescegra/coll/hterrainbvolume.h>

#include <lescegra/util/arraylist.h>
#include <lescegra/coll/helper.h>

#include <stddef.h>
#include <math.h>

#ifndef M_PI
#define M_PI		3.14159265358979323846
#endif

#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define FRAME_ELEMENT(self, x, y) ((self)->frame[(y) * (self)->resolution[0] + (x)])

static int LsgHTerrainBVolume_visible(const LsgHTerrainBVolume*, const LsgFrustum*);
static void LsgHTerrainBVolume_collideVertex(const LsgHTerrainBVolume*, const Vertex, LsgList*);
static void LsgHTerrainBVolume_collideRay(const LsgHTerrainBVolume*, const Vertex, const Vertex, LsgList*);
static void LsgHTerrainBVolume_collideSphere(const LsgHTerrainBVolume*, const Vertex, float, LsgList*);

static void LsgHTerrainBVolume_staticInit(LsgHTerrainBVolumeClass* class, LsgHTerrainBVolume* instance) {
    ((LsgBVolumeClass*)class)->visible       = (int  (*)(const LsgBVolume*, const LsgFrustum*))LsgHTerrainBVolume_visible;
    ((LsgBVolumeClass*)class)->collideVertex = (void (*)(const LsgBVolume*, const Vertex, LsgList*))LsgHTerrainBVolume_collideVertex;
    ((LsgBVolumeClass*)class)->collideRay    = (void (*)(const LsgBVolume*, const Vertex, const Vertex, LsgList*))LsgHTerrainBVolume_collideRay;
    ((LsgBVolumeClass*)class)->collideSphere = (void (*)(const LsgBVolume*, const Vertex, float, LsgList*))LsgHTerrainBVolume_collideSphere;

    instance->terrain = NULL;
}

LsgClassID LsgHTerrainBVolume_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgHTerrainBVolume",
            LsgBVolume_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgHTerrainBVolumeClass),
            sizeof(LsgHTerrainBVolume),
            (LsgClassStaticInitializer)LsgHTerrainBVolume_staticInit
        );
    }

    return classid;
}

LsgHTerrainBVolume* LsgHTerrainBVolume_create(LsgHTerrain* terrain) {
    LsgHTerrainBVolume* self = (LsgHTerrainBVolume*)LsgClass_alloc(LsgHTerrainBVolume_classID());

    if (self)
        LsgHTerrainBVolume_init(self, terrain);

    return self;
}

void LsgHTerrainBVolume_init(LsgHTerrainBVolume* self, LsgHTerrain* terrain) {
    LsgBVolume_init(&self->parent);

    self->terrain = terrain;
}

static int LsgHTerrainBVolume_visible(const LsgHTerrainBVolume* self, const LsgFrustum* frustum) {
    /* view frustum culling is done by via LsgOctree in LsgHTerrain_display */
    return 1;
}

static void LsgHTerrainBVolume_collideVertex(const LsgHTerrainBVolume* self, const Vertex v, LsgList* buffer) {
    /* this method is not very useful as we don't really define a volume but rather
     * a collision surface. */
}

static void LsgHTerrainBVolume_collideRay(const LsgHTerrainBVolume* self, const Vertex from, const Vertex dir, LsgList* buffer) {
    LsgList* list;
    LsgIterator* it;
    LsgHit* hit = NULL;

    list = (LsgList*)LsgArrayList_create();
    LsgOctree_getCollideRay(self->terrain->octree, from, dir, list);

    it = LsgList_iterator(list);
    while (LsgIterator_hasNext(it)) {
        int x_min, x, x_max, z_min, z, z_max;
        int idx = (int)LsgIterator_next(it);

        x_min = idx % self->terrain->resolution[0];
        x_max = x_min + self->terrain->chunk;
        x_max = MIN(x_max, self->terrain->resolution[0] - 1);
        z_min = idx / self->terrain->resolution[0];
        z_max = z_min + self->terrain->chunk;
        z_max = MIN(z_max, self->terrain->resolution[1] - 1);

        for (z = z_min; z < z_max; ++z) {
            for (x = x_min; x < x_max; ++x) {
                hit = LsgTriangle_collideRay(
                        FRAME_ELEMENT(self->terrain, x, z).point,
                        FRAME_ELEMENT(self->terrain, x, z + 1).point,
                        FRAME_ELEMENT(self->terrain, x + 1, z).point,
                        from, dir);
                if (hit) LsgList_append(buffer, hit);

                hit = LsgTriangle_collideRay(
                        FRAME_ELEMENT(self->terrain, x + 1, z + 1).point,
                        FRAME_ELEMENT(self->terrain, x + 1, z).point,
                        FRAME_ELEMENT(self->terrain, x, z + 1).point,
                        from, dir);
                if (hit) LsgList_append(buffer, hit);
            }
        }
    }
    LsgObject_free((LsgObject*)it);
}

static void LsgHTerrainBVolume_collideSphere(const LsgHTerrainBVolume* self, const Vertex center, float radius, LsgList* buffer) {
    LsgList* list;
    LsgIterator* it;
    LsgHit* hit = NULL;

    list = (LsgList*)LsgArrayList_create();
    LsgOctree_getCollideSphere(self->terrain->octree, center, radius, list);

    it = LsgList_iterator(list);
    while (LsgIterator_hasNext(it)) {
        int x_min, x, x_max, z_min, z, z_max;
        int idx = (int)LsgIterator_next(it);

        x_min = idx % self->terrain->resolution[0];
        x_max = x_min + self->terrain->chunk;
        x_max = MIN(x_max, self->terrain->resolution[0] - 1);
        z_min = idx / self->terrain->resolution[0];
        z_max = z_min + self->terrain->chunk;
        z_max = MIN(z_max, self->terrain->resolution[1] - 1);

        for (z = z_min; z < z_max; ++z) {
            for (x = x_min; x < x_max; ++x) {
                hit = LsgTriangle_collideSphere(
                        FRAME_ELEMENT(self->terrain, x, z).point,
                        FRAME_ELEMENT(self->terrain, x, z + 1).point,
                        FRAME_ELEMENT(self->terrain, x + 1, z).point,
                        center, radius);
                if (hit) LsgList_append(buffer, hit);

                hit = LsgTriangle_collideSphere(
                        FRAME_ELEMENT(self->terrain, x + 1, z + 1).point,
                        FRAME_ELEMENT(self->terrain, x + 1, z).point,
                        FRAME_ELEMENT(self->terrain, x, z + 1).point,
                        center, radius);
                if (hit) LsgList_append(buffer, hit);
            }
        }
    }
    LsgObject_free((LsgObject*)it);
}
