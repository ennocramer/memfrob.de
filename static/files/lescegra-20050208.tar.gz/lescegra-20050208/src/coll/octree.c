#include <lescegra/coll/octree.h>

#include <lescegra/util/arraylist.h>

#include <stdlib.h>
#include <math.h>

static void LsgOctree_destroy(LsgOctree* self);

static void LsgOctree_staticInit(LsgOctreeClass* class, LsgOctree* instance) {
    int i;

    ((LsgObjectClass*)class)->destroy = (void (*)(LsgObject*))LsgOctree_destroy;

    for (i = 0; i < 8; ++i)
        instance->children[i] = NULL;
    instance->data = NULL;
}

LsgClassID LsgOctree_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgOctree",
            LsgObject_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgOctreeClass),
            sizeof(LsgOctree),
            (LsgClassStaticInitializer)LsgOctree_staticInit
        );
    }

    return classid;
}

LsgOctree* LsgOctree_create(const Vertex min, const Vertex max, int div) {
    LsgOctree* self = (LsgOctree*)LsgClass_alloc(LsgOctree_classID());

    if (self)
        LsgOctree_init(self, min, max, div);

    return self;
}

#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define SQR(a) ((a) * (a))
LsgOctree* LsgOctree_createOptimal(const Vertex min, const Vertex max, int count, int target_count) {
    Vertex size;
    float side_count[3];
    int side_div[3];
    float target;
    int div, i;

    vertex_copy(size, max);
    vertex_sub(size, min);

    /* CONCEPT:
     * ASSUMPTION: All elements to be contained in this Octree are roughly
     * equally sized in ervery dimension and equally distributed in space.
     *
     * The number of elements N for any dimension is proportional to the
     * size S of the Octree in that dimension:
     *      N_i ~ S_i, with i in {x, y, z}
     * or:
     *      N_i / N_f = S_i / S_f, with i,f in {x, y, z}    (1)
     *
     * The total number of elements is the product of the number of elements
     * for all three dimensions:
     *      N = N_x * N_y * N_z                             (2)
     *
     * From (1) and (2) we get
     *      N_i = (N * S_x^2 / (S_y*S_z))^1/3    (permute x, y and z)
     *
     * For a total number of elements N and targetted number T of elements
     * per Octree leaf we get the number of Octree division d through:
     *      N / 8^d = T
     * or for a single dimension:
     *     N_i / 2^d = T^1/3
     *
     * Finally, we use the smallest number of divisions ...
     */

    target = exp(log(target_count)/3);
    for (i = 0; i < 3; ++i) {
        side_count[i] = (float)count * SQR(size[i]) / (size[(i + 1) % 3] * size[(i + 2) % 3]);
        side_count[i] = exp(log(side_count[i]) / 3);
        side_div[i]   = (int)log(sqrt(side_count[i] / target));
    }

    div = MIN(MIN(side_div[0], side_div[1]), side_div[2]);

    return LsgOctree_create(min, max, div);
}

void LsgOctree_init(LsgOctree* self, const Vertex min, const Vertex max, int div) {
    LsgObject_init(&self->parent);

    vertex_copy(self->min, min);
    vertex_copy(self->max, max);
    vertex_copy(self->vmin, max);
    vertex_copy(self->vmax, min);
    self->divisions = div;

    vertex_copy(self->sep, min);
    vertex_add(self->sep, max);
    vertex_scale(self->sep, 0.5);

    if (!div) {
        self->data = (LsgList*)LsgArrayList_create();
    }
}

void LsgOctree_add(LsgOctree* self, const Vertex min, const Vertex max, void* data) {
    Vertex cmin, cmax;
    int idx = 0;

    vertex_min(self->vmin, min);
    vertex_max(self->vmax, max);

    if (self->divisions) {
        if (min[0] > self->sep[0])
            idx |= 0x1;
        if (min[1] > self->sep[1])
            idx |= 0x2;
        if (min[2] > self->sep[2])
            idx |= 0x4;

        if (!self->children[idx]) {
            if (idx & 0x1) {
                cmin[0] = self->sep[0];
                cmax[0] = self->max[0];
            } else {
                cmin[0] = self->min[0];
                cmax[0] = self->sep[0];
            }
            if (idx & 0x2) {
                cmin[1] = self->sep[1];
                cmax[1] = self->max[1];
            } else {
                cmin[1] = self->min[1];
                cmax[1] = self->sep[1];
            }
            if (idx & 0x4) {
                cmin[2] = self->sep[2];
                cmax[2] = self->max[2];
            } else {
                cmin[2] = self->min[2];
                cmax[2] = self->sep[2];
            }
            self->children[idx] = LsgOctree_create(cmin, cmax, self->divisions - 1);
        }

        LsgOctree_add(self->children[idx], min, max, data);
    } else {
        LsgList_append(self->data, data);
    }
}

void LsgOctree_getVisible(const LsgOctree* self, const LsgFrustum* frustum, LsgList* target) {
    LsgIterator* it;
    int i;

    /* test visibility */
    for (i = 0; i < 6; ++i) {
        if (frustum->planes[i].normal[0] * self->vmin[0] +
            frustum->planes[i].normal[1] * self->vmin[1] +
            frustum->planes[i].normal[2] * self->vmin[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * self->vmin[0] +
            frustum->planes[i].normal[1] * self->vmin[1] +
            frustum->planes[i].normal[2] * self->vmax[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * self->vmin[0] +
            frustum->planes[i].normal[1] * self->vmax[1] +
            frustum->planes[i].normal[2] * self->vmin[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * self->vmin[0] +
            frustum->planes[i].normal[1] * self->vmax[1] +
            frustum->planes[i].normal[2] * self->vmax[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * self->vmax[0] +
            frustum->planes[i].normal[1] * self->vmin[1] +
            frustum->planes[i].normal[2] * self->vmin[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * self->vmax[0] +
            frustum->planes[i].normal[1] * self->vmin[1] +
            frustum->planes[i].normal[2] * self->vmax[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * self->vmax[0] +
            frustum->planes[i].normal[1] * self->vmax[1] +
            frustum->planes[i].normal[2] * self->vmin[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * self->vmax[0] +
            frustum->planes[i].normal[1] * self->vmax[1] +
            frustum->planes[i].normal[2] * self->vmax[2] +
            frustum->planes[i].distance > 0) continue;

        return;
    }

    /* collect data */
    if (self->divisions) {
        for (i = 0; i < 8; ++i) {
            if (self->children[i]) LsgOctree_getVisible(self->children[i], frustum, target);
        }
    } else {
        it = LsgList_iterator(self->data);
        while (LsgIterator_hasNext(it)) {
            LsgList_append(target, LsgIterator_next(it));
        }
        LsgObject_free((LsgObject*)it);
    }
}

void LsgOctree_getCollideVertex(const LsgOctree* self, const Vertex v, LsgList* target) {
    LsgIterator* it;
    int i;

    if ((v[0] < self->vmin[0]) || (v[0] > self->vmax[0]) ||
        (v[1] < self->vmin[1]) || (v[1] > self->vmax[1]) ||
        (v[2] < self->vmin[2]) || (v[2] > self->vmax[2])) return;

    if (self->divisions) {
        for (i = 0; i < 8; ++i) {
            if (self->children[i]) LsgOctree_getCollideVertex(self->children[i], v, target);
        }
    } else {
        it = LsgList_iterator(self->data);
        while (LsgIterator_hasNext(it)) {
            LsgList_append(target, LsgIterator_next(it));
        }
        LsgObject_free((LsgObject*)it);
    }
}

void LsgOctree_getCollideRay(const LsgOctree* self, const Vertex from, const Vertex dir, LsgList* target) {
    LsgIterator* it;
    Vertex v;
    float lambda, normal;
    int i, d, nd, nnd;

    for (i = 0; i < 6; ++i) {
        d   = (i + 0) % 3;
        nd  = (i + 1) % 3;
        nnd = (i + 2) % 3;

        if (i < 3) {
            lambda = (self->vmin[d] - from[d]) / dir[d];
            normal = -1.0;
        } else {
            lambda = (self->vmax[d] - from[d]) / dir[d];
            normal = 1.0;
        }

        /* plane behind from or not facing towards from */
        if ((lambda < 0.0) || ((normal * dir[d]) >= 0.0)) continue;

        vertex_copy(v, dir);
        vertex_scale(v, lambda);
        vertex_add(v, from);

        if ((v[nd]  >= self->vmin[nd])  && (v[nd]  <= self->vmax[nd]) &&
            (v[nnd] >= self->vmin[nnd]) && (v[nnd] <= self->vmax[nnd])) {
            if (self->divisions) {
                for (i = 0; i < 8; ++i) {
                    if (self->children[i])
                        LsgOctree_getCollideRay(self->children[i], from, dir, target);
                }
            } else {
                it = LsgList_iterator(self->data);
                while (LsgIterator_hasNext(it)) {
                    LsgList_append(target, LsgIterator_next(it));
                }
                LsgObject_free((LsgObject*)it);
            }
            return;
        }
    }
}

void LsgOctree_getCollideSphere(const LsgOctree* self, const Vertex center, float radius, LsgList* target) {
    LsgIterator* it;
    int i;

    /* trivial reject (distance to any plane larger than radius */
    if (   ((center[0] - self->vmax[0]) > radius)
        || ((center[1] - self->vmax[1]) > radius)
        || ((center[2] - self->vmax[2]) > radius)
        || ((self->vmin[0] - center[0]) > radius)
        || ((self->vmin[1] - center[1]) > radius)
        || ((self->vmin[2] - center[2]) > radius)) return;

    /* trivial accept (center in octree range) */
    i = (center[0] >= self->vmin[0]) && (center[0] <= self->vmax[0]) &&
        (center[1] >= self->vmin[1]) && (center[1] <= self->vmax[1]) &&
        (center[2] >= self->vmin[2]) && (center[2] <= self->vmax[2]);

    /* check real distance (skip if trivial accept succeeded) */
    if (!i) {
        Vertex n;

        /* calculate nearest point on octree boundaries */
        vertex_copy(n, center);
        vertex_min(n, self->vmax);
        vertex_max(n, self->vmin);

        /* calculate distance between octree boundary and sphere center */
        vertex_sub(n, center);
        if (vertex_length(n) > radius) return;
    }

    if (self->divisions) {
        for (i = 0; i < 8; ++i) {
            if (self->children[i]) LsgOctree_getCollideSphere(self->children[i], center, radius, target);
        }
    } else {
        it = LsgList_iterator(self->data);
        while (LsgIterator_hasNext(it)) {
            LsgList_append(target, LsgIterator_next(it));
        }
        LsgObject_free((LsgObject*)it);
    }
}

static void LsgOctree_destroy(LsgOctree* self) {
    LsgObjectClass* pclass = (LsgObjectClass*)LsgClass_getClass(LsgObject_classID());
    int i;

    if (self->divisions) {
        for (i = 0; i < 8; ++i) {
            if (self->children[i]) LsgObject_free((LsgObject*)self->children[i]);
        }
    } else {
        LsgObject_free((LsgObject*)self->data);
    }

    pclass->destroy((LsgObject*)self);
}
