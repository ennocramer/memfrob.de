#include <lescegra/coll/bvolume.h>

static void LsgGenericBVolume_include_impl(LsgGenericBVolume* self, const Vertex v);
static void LsgGenericBVolume_reset_impl(LsgGenericBVolume* self);

static void LsgGenericBVolume_staticInit(LsgGenericBVolumeClass* class, LsgGenericBVolume* instance) {
    class->include       = LsgGenericBVolume_include_impl;
    class->reset         = LsgGenericBVolume_reset_impl;
}

LsgClassID LsgGenericBVolume_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgGenericBVolume",
            LsgObject_classID(),
            LSG_CLASS_FLAG_ABSTRACT,
            sizeof(LsgGenericBVolumeClass),
            sizeof(LsgGenericBVolume),
            (LsgClassStaticInitializer)LsgGenericBVolume_staticInit
        );
    }

    return classid;
}

void LsgGenericBVolume_init(LsgGenericBVolume* self) {
    LsgBVolume_init(&self->parent);
}

static void LsgGenericBVolume_include_impl(LsgGenericBVolume* self, const Vertex v) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgIterator_classID(), "include");
}

void LsgGenericBVolume_include(LsgGenericBVolume* self, const Vertex v) {
    LsgGenericBVolumeClass* class = (LsgGenericBVolumeClass*)((LsgClassInstance*)self)->class;

    class->include(self, v);
}

void LsgGenericBVolume_reset_impl(LsgGenericBVolume* self) {
    ((LsgBVolume*)self)->valid = 0;
}

void LsgGenericBVolume_reset(LsgGenericBVolume* self) {
    LsgGenericBVolumeClass* class = (LsgGenericBVolumeClass*)((LsgClassInstance*)self)->class;

    class->reset(self);
}
