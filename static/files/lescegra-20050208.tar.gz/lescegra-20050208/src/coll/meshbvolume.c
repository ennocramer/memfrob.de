#include <lescegra/coll/meshbvolume.h>

#include <lescegra/util/arraylist.h>
#include <lescegra/coll/helper.h>

#include <stddef.h>

#include <math.h>
#ifndef M_PI
#define M_PI		3.14159265358979323846
#endif

static void LsgMeshBVolume_collideVertex(const LsgMeshBVolume*, const Vertex, LsgList*);
static void LsgMeshBVolume_collideRay(const LsgMeshBVolume*, const Vertex, const Vertex, LsgList*);
static void LsgMeshBVolume_collideSphere(const LsgMeshBVolume*, const Vertex, float, LsgList*);

static void LsgMeshBVolume_staticInit(LsgMeshBVolumeClass* class, LsgMeshBVolume* instance) {
    ((LsgBVolumeClass*)class)->collideVertex = (void (*)(const LsgBVolume*, const Vertex, LsgList*))LsgMeshBVolume_collideVertex;
    ((LsgBVolumeClass*)class)->collideRay    = (void (*)(const LsgBVolume*, const Vertex, const Vertex, LsgList*))LsgMeshBVolume_collideRay;
    ((LsgBVolumeClass*)class)->collideSphere = (void (*)(const LsgBVolume*, const Vertex, float, LsgList*))LsgMeshBVolume_collideSphere;

    instance->mesh = NULL;
}

LsgClassID LsgMeshBVolume_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgMeshBVolume",
            LsgBVolume_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgMeshBVolumeClass),
            sizeof(LsgMeshBVolume),
            (LsgClassStaticInitializer)LsgMeshBVolume_staticInit
        );
    }

    return classid;
}

LsgMeshBVolume* LsgMeshBVolume_create(LsgMesh* mesh) {
    LsgMeshBVolume* self = (LsgMeshBVolume*)LsgClass_alloc(LsgMeshBVolume_classID());

    if (self)
        LsgMeshBVolume_init(self, mesh);

    return self;
}

void LsgMeshBVolume_init(LsgMeshBVolume* self, LsgMesh* mesh) {
    LsgBVolume_init(&self->parent);

    self->mesh = mesh;
}

static void LsgMeshBVolume_collideVertex(const LsgMeshBVolume* self, const Vertex v, LsgList* hits) {
    if (self->mesh->octree) {
        if ((v[0] >= self->mesh->octree->vmin[0]) &&
            (v[0] <= self->mesh->octree->vmax[0]) &&
            (v[1] >= self->mesh->octree->vmin[1]) &&
            (v[1] <= self->mesh->octree->vmax[1]) &&
            (v[2] >= self->mesh->octree->vmin[2]) &&
            (v[2] <= self->mesh->octree->vmax[2])) {
            LsgHit* hit = LsgHit_create();
            vertex_copy(hit->intersection, v);
            LsgList_append(hits, hit);
        }
    }
}

static void LsgMeshBVolume_collideRay(const LsgMeshBVolume* self, const Vertex from, const Vertex dir, LsgList* hits) {
    if (self->mesh->octree) {
        LsgList* candidates;
        LsgIterator* it;

        candidates = (LsgList*)LsgArrayList_create();
        LsgOctree_getCollideRay(self->mesh->octree, from, dir, candidates);

        it = LsgList_iterator(candidates);
        while (LsgIterator_hasNext(it)) {
            LsgHit* hit;
            int triangle = (int)LsgIterator_next(it);

            hit = LsgTriangle_collideRay(
                self->mesh->vertices[self->mesh->triangles[triangle][0]],
                self->mesh->vertices[self->mesh->triangles[triangle][1]],
                self->mesh->vertices[self->mesh->triangles[triangle][2]],
                from, dir);

            if (hit) LsgList_append(hits, hit);
        }
        LsgObject_free((LsgObject*)it);

        LsgObject_free((LsgObject*)candidates);
    }
}

static void LsgMeshBVolume_collideSphere(const LsgMeshBVolume* self, const Vertex center, float radius, LsgList* hits) {
    if (self->mesh->octree) {
        LsgList* candidates;
        LsgIterator* it;

        candidates = (LsgList*)LsgArrayList_create();
        LsgOctree_getCollideSphere(self->mesh->octree, center, radius, candidates);

        it = LsgList_iterator(candidates);
        while (LsgIterator_hasNext(it)) {
            LsgHit* hit;
            int triangle = (int)LsgIterator_next(it);

            hit = LsgTriangle_collideSphere(
                self->mesh->vertices[self->mesh->triangles[triangle][0]],
                self->mesh->vertices[self->mesh->triangles[triangle][1]],
                self->mesh->vertices[self->mesh->triangles[triangle][2]],
                center, radius);

            if (hit) LsgList_append(hits, hit);
        }
        LsgObject_free((LsgObject*)it);

        LsgObject_free((LsgObject*)candidates);
    }
}
