#include <lescegra/coll/bbox.h>

#include <stdlib.h>

static int  LsgBBox_visible(const LsgBBox* self, const LsgFrustum* frustum);
static void LsgBBox_collideVertex(const LsgBBox* self, const Vertex v, LsgList* buffer);
static void LsgBBox_collideRay(const LsgBBox* self, const Vertex from, const Vertex dir, LsgList* buffer);
static void LsgBBox_collideSphere(const LsgBBox* self, const Vertex center, float radius, LsgList* buffer);
static void LsgBBox_include(LsgBBox* self, const Vertex v);
static void LsgBBox_merge(const LsgBBox* self, LsgGenericBVolume* target);

static void LsgBBox_staticInit(LsgBBoxClass* class, LsgBBox* instance) {
    ((LsgBVolumeClass*)class)->visible       = (int  (*)(const LsgBVolume*, const LsgFrustum*))LsgBBox_visible;
    ((LsgBVolumeClass*)class)->collideVertex = (void (*)(const LsgBVolume*, const Vertex, LsgList*))LsgBBox_collideVertex;
    ((LsgBVolumeClass*)class)->collideRay    = (void (*)(const LsgBVolume*, const Vertex, const Vertex, LsgList*))LsgBBox_collideRay;
    ((LsgBVolumeClass*)class)->collideSphere = (void (*)(const LsgBVolume*, const Vertex, float, LsgList*))LsgBBox_collideSphere;
    ((LsgBVolumeClass*)class)->merge         = (void (*)(const LsgBVolume*, LsgGenericBVolume*))LsgBBox_merge;

    ((LsgGenericBVolumeClass*)class)->include       = (void (*)(LsgGenericBVolume*, const Vertex))LsgBBox_include;

    vertex_assign(instance->min, 0.0, 0.0, 0.0);
    vertex_assign(instance->max, 0.0, 0.0, 0.0);
}

LsgClassID LsgBBox_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgBBox",
            LsgGenericBVolume_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgBBoxClass),
            sizeof(LsgBBox),
            (LsgClassStaticInitializer)LsgBBox_staticInit
        );
    }

    return classid;
}

LsgBBox* LsgBBox_create(void) {
    LsgBBox* self = (LsgBBox*)LsgClass_alloc(LsgBBox_classID());

    if (self)
        LsgBBox_init(self);

    return self;
}

void LsgBBox_init(LsgBBox* self) {
    LsgGenericBVolume_init(&self->parent);
}

int LsgBBox_visible(const LsgBBox* self, const LsgFrustum* frustum) {
    int p;

    if (!((LsgBVolume*)self)->valid) return 1;

    for (p = 0; p < 6; ++p) {
        if (frustum->planes[p].normal[0] * self->min[0] +
            frustum->planes[p].normal[1] * self->min[1] +
            frustum->planes[p].normal[2] * self->min[2] +
            frustum->planes[p].distance > 0) continue;
        if (frustum->planes[p].normal[0] * self->min[0] +
            frustum->planes[p].normal[1] * self->min[1] +
            frustum->planes[p].normal[2] * self->max[2] +
            frustum->planes[p].distance > 0) continue;
        if (frustum->planes[p].normal[0] * self->min[0] +
            frustum->planes[p].normal[1] * self->max[1] +
            frustum->planes[p].normal[2] * self->min[2] +
            frustum->planes[p].distance > 0) continue;
        if (frustum->planes[p].normal[0] * self->min[0] +
            frustum->planes[p].normal[1] * self->max[1] +
            frustum->planes[p].normal[2] * self->max[2] +
            frustum->planes[p].distance > 0) continue;
        if (frustum->planes[p].normal[0] * self->max[0] +
            frustum->planes[p].normal[1] * self->min[1] +
            frustum->planes[p].normal[2] * self->min[2] +
            frustum->planes[p].distance > 0) continue;
        if (frustum->planes[p].normal[0] * self->max[0] +
            frustum->planes[p].normal[1] * self->min[1] +
            frustum->planes[p].normal[2] * self->max[2] +
            frustum->planes[p].distance > 0) continue;
        if (frustum->planes[p].normal[0] * self->max[0] +
            frustum->planes[p].normal[1] * self->max[1] +
            frustum->planes[p].normal[2] * self->min[2] +
            frustum->planes[p].distance > 0) continue;
        if (frustum->planes[p].normal[0] * self->max[0] +
            frustum->planes[p].normal[1] * self->max[1] +
            frustum->planes[p].normal[2] * self->max[2] +
            frustum->planes[p].distance > 0) continue;

        return 0;
    }

    return 1;
}

void LsgBBox_collideVertex(const LsgBBox* self, const Vertex v, LsgList* buffer) {
    LsgHit* hit;
    Vertex dmin, dmax;

    if ((v[0] >= self->min[0]) && (v[0] <= self->max[0])
    &&  (v[1] >= self->min[1]) && (v[1] <= self->max[1])
    &&  (v[2] >= self->min[2]) && (v[2] <= self->max[2])) {
        hit = LsgHit_create();

        /* compute positive distance to all sides */
        vertex_copy(dmin, v);
        vertex_sub(dmin, self->min);
        vertex_copy(dmax, self->max);
        vertex_sub(dmax, v);

        /* find smallest distance */
        vertex_copy(hit->intersection, v);
        if ((dmax[0] < dmax[1]) && (dmax[0] < dmax[2]) &&
            (dmax[0] < dmin[0]) && (dmax[0] < dmin[1]) && (dmax[0] < dmin[2])) {
            hit->intersection[0] += dmax[0];
            hit->normal[0] = 1.0;
        } else if ((dmin[0] < dmin[1]) && (dmin[0] < dmin[2]) &&
            (dmin[0] < dmax[1]) && (dmin[0] < dmax[2])) {
            hit->intersection[0] -= dmin[0];
            hit->normal[0] = -1.0;
        } else if ((dmax[1] < dmax[2]) &&
            (dmax[1] < dmin[1]) && (dmax[1] < dmin[2])) {
            hit->intersection[1] += dmax[1];
            hit->normal[1] = 1.0;
        } else if ((dmin[1] < dmin[2]) &&
            (dmin[1] < dmax[2])) {
            hit->intersection[1] -= dmin[1];
            hit->normal[1] = -1.0;
        } else if (dmax[2] < dmin[2]) {
            hit->intersection[2] += dmax[2];
            hit->normal[2] = 1.0;
        } else {
            hit->intersection[2] -= dmin[2];
            hit->normal[2] = -1.0;
        }

        LsgList_append(buffer, hit);
    }
}

void LsgBBox_collideRay(const LsgBBox* self, const Vertex from, const Vertex dir, LsgList* buffer) {
    LsgHit* hit;
    Vertex v;
    float lambda, normal;
    int i, d, nd, nnd;

    for (i = 0; i < 6; ++i) {
        d   = (i + 0) % 3;
        nd  = (i + 1) % 3;
        nnd = (i + 2) % 3;

        if (i < 3) {
            lambda = (self->min[d] - from[d]) / dir[d];
            normal = -1.0;
        } else {
            lambda = (self->max[d] - from[d]) / dir[d];
            normal = 1.0;
        }

        /* plane behind from or not facing towards from */
        if ((lambda < 0.0) || ((normal * dir[d]) >= 0.0)) continue;

        vertex_copy(v, dir);
        vertex_scale(v, lambda);
        vertex_add(v, from);

        if ((v[nd]  >= self->min[nd])  && (v[nd]  <= self->max[nd]) &&
            (v[nnd] >= self->min[nnd]) && (v[nnd] <= self->max[nnd])) {
            hit = LsgHit_create();

            vertex_copy(hit->intersection, v);
            vertex_assign(hit->normal, 0.0, 0.0, 0.0);
            hit->normal[i] = normal;

            LsgList_append(buffer, hit);
            return;
        }
    }
}

void LsgBBox_collideSphere(const LsgBBox* self, const Vertex center, float radius, LsgList* buffer) {
    LsgHit* hit = NULL;
    Vertex p, n;
    int c;

    /* trivial accept/reject can save up to two sqrt calls (vertex_length) */

    /* trivial reject (distance to any plane larger than radius) */
    if ((center[0] - self->max[0] > radius)
    ||  (center[1] - self->max[1] > radius)
    ||  (center[2] - self->max[2] > radius)
    ||  (self->min[0] - center[0] > radius)
    ||  (self->min[1] - center[1] > radius)
    ||  (self->min[2] - center[2] > radius)) return;

    /* trivial accept (center in bbox) */
    /* TODO: use better detection than calling buffer->count twice */
    c = LsgList_count(buffer);
    LsgBBox_collideVertex(self, center, buffer);
    if (LsgList_count(buffer) != c) return;

    /* calculate nearest point on bbox */
    vertex_copy(p, center);
    vertex_min(p, self->max);
    vertex_max(p, self->min);

    /* calculate distance between bbox and center */
    vertex_copy(n, center);
    vertex_sub(n, p);

    /* create hit object and calculate normal from nearest point */
    if (vertex_length(n) <= radius) {
        hit = LsgHit_create();
        vertex_copy(hit->intersection, p);
        vertex_copy(hit->normal, n);
        vertex_normalize(hit->normal);
        LsgList_append(buffer, hit);
    }
}

void LsgBBox_include(LsgBBox* self, const Vertex v) {
    if (((LsgBVolume*)self)->valid) {
        vertex_min(self->min, v);
        vertex_max(self->max, v);
    } else {
        vertex_copy(self->min, v);
        vertex_copy(self->max, v);
        ((LsgBVolume*)self)->valid = 1;
    }
}

void LsgBBox_merge(const LsgBBox* self, LsgGenericBVolume* target) {
    Vertex v;

    vertex_assign(v, self->min[0], self->min[1], self->min[2]);
    LsgGenericBVolume_include(target, v);
    vertex_assign(v, self->min[0], self->min[1], self->max[2]);
    LsgGenericBVolume_include(target, v);
    vertex_assign(v, self->min[0], self->max[1], self->min[2]);
    LsgGenericBVolume_include(target, v);
    vertex_assign(v, self->min[0], self->max[1], self->max[2]);
    LsgGenericBVolume_include(target, v);
    vertex_assign(v, self->max[0], self->min[1], self->min[2]);
    LsgGenericBVolume_include(target, v);
    vertex_assign(v, self->max[0], self->min[1], self->max[2]);
    LsgGenericBVolume_include(target, v);
    vertex_assign(v, self->max[0], self->max[1], self->min[2]);
    LsgGenericBVolume_include(target, v);
    vertex_assign(v, self->max[0], self->max[1], self->max[2]);
    LsgGenericBVolume_include(target, v);
}
