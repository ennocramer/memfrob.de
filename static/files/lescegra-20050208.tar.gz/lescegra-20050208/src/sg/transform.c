#include <lescegra/sg/transform.h>

#include <lescegra/base/error.h>

#include <GL/gl.h>

#include <stdlib.h>

static void LsgTransform_update(LsgTransform*, float now);
static void LsgTransform_display(const LsgTransform*, const LsgFrustum*);

static void LsgTransform_staticInit(LsgTransformClass* class, LsgTransform* instance) {
    ((LsgNodeClass*)class)->update  = (void (*)(LsgNode*, float))LsgTransform_update;
    ((LsgNodeClass*)class)->display = (void (*)(const LsgNode*, const LsgFrustum*))LsgTransform_display;

    matrix_copy(instance->tm, matrix_identity);
}

LsgClassID LsgTransform_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgTransform",
            LsgGroup_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgTransformClass),
            sizeof(LsgTransform),
            (LsgClassStaticInitializer)LsgTransform_staticInit
        );
    }

    return classid;
}

LsgTransform* LsgTransform_create(void) {
    LsgTransform* self = (LsgTransform*)LsgClass_alloc(LsgTransform_classID());

    if (self)
        LsgTransform_init(self);

    return self;
}

void LsgTransform_init(LsgTransform* self) {
    LsgGroup_init(&self->parent);
}

static void LsgTransform_update(LsgTransform* self, float now) {
    LsgNodeClass* pclass = (LsgNodeClass*)LsgClass_getClass(LsgGroup_classID());

    pclass->update((LsgNode*)self, now);

    if (((LsgNode*)self)->dirty && ((LsgNode*)self)->bvolume) {
        LsgError_report(__FILE__, "LsgFormat_update", __LINE__, "Bounding volume transformation is not implemented yet.");
        /* transform bounding volume */
    }
}

static void LsgTransform_display(const LsgTransform* self, const LsgFrustum* frust) {
    LsgNodeClass* pclass = (LsgNodeClass*)LsgClass_getClass(LsgGroup_classID());

    LsgFrustum* nfrust;
    Matrix m;

    /* transform frustum */
    matrix_copy(m, frust->modelview);
    matrix_mult(m, self->tm);
    nfrust = LsgFrustum_create(frust->projection, m);

    /* transform opengl modelview matrix */
    glPushMatrix();
    glMultMatrixf(self->tm);

    /* display child nodes with transformed view frustum */
    pclass->display((LsgNode*)self, nfrust);

    /* restore opengl modelview matrix */
    glPopMatrix();

    LsgObject_free((LsgObject*)nfrust);
}
