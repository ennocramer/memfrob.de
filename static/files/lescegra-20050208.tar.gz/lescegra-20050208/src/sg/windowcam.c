#include <lescegra/sg/windowcam.h>

#include <lescegra/base/error.h>

#include <math.h>

static void LsgWindowCam_load(
    const LsgWindowCam* self,
    Matrix proj,
    Matrix mview
);

static void LsgWindowCam_destroy(
    LsgWindowCam* self
);

static void LsgWindowCam_staticInit(
    LsgWindowCamClass* class,
    LsgWindowCam* instance
) {
    ((LsgCameraClass*)class)->load =
        (void (*)(const LsgCamera*, Matrix, Matrix))LsgWindowCam_load;

    ((LsgObjectClass*)class)->destroy =
        (void (*)(LsgObject*))LsgWindowCam_destroy;

    vertex_assign(instance->location, 0.0, 0.0, -1.0);
    vertex_assign(instance->center, 0.0, 0.0, 0.0);
    vertex_assign(instance->axes[0], 1.0, 0.0, 0.0);
    vertex_assign(instance->axes[0], 0.0, 1.0, 0.0);
    vertex_assign(instance->axes[0], 0.0, 0.0, 1.0);

    instance->w    = 2.0;
    instance->h    = 2.0;
    instance->dmin = 0.1;
    instance->dmax = 10.0;
}

LsgClassID LsgWindowCam_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgWindowCam",
            LsgCamera_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgWindowCamClass),
            sizeof(LsgWindowCam),
            (LsgClassStaticInitializer)LsgWindowCam_staticInit
        );
    }

    return classid;
}

LsgWindowCam* LsgWindowCam_create(void) {
    LsgWindowCam* self = (LsgWindowCam*)LsgClass_alloc(LsgWindowCam_classID());

    if (self)
        LsgWindowCam_init(self);

    return self;
}

void LsgWindowCam_init(LsgWindowCam* self) {
    LsgCamera_init(&self->parent);
}

void LsgWindowCam_setWindow(
    LsgWindowCam* self,
    const Vertex center,
    const Vertex base,
    const Vertex up,
    float dmin,
    float dmax
) {
    vertex_copy(self->center, center);

    vertex_copy(self->axes[0], base);
    vertex_normalize(self->axes[0]);

    vertex_copy(self->axes[1], up);
    vertex_normalize(self->axes[1]);

    vertex_copy(self->axes[2], base);
    vertex_cross(self->axes[2], up);
    vertex_normalize(self->axes[2]);

    self->w = vertex_dot(self->axes[0], base); /* sqrt is evil :) */
    self->h = vertex_dot(self->axes[1], up);

    self->dmin = dmin;
    self->dmax = dmax;
}

static void LsgWindowCam_load(
    const LsgWindowCam* self,
    Matrix proj,
    Matrix mview
) {
    Vertex delta, lookat;

    register float zmin, zmax;
    register float sx, sy, sz;

    vertex_copy(delta, self->center);
    vertex_sub(delta, self->location);

    sx = vertex_dot(self->axes[0], delta);
    sy = vertex_dot(self->axes[1], delta);
    sz = vertex_dot(self->axes[2], delta);

    if (sz > 0)
        sx *= -1.0;

    zmin = self->dmin;
    zmax = self->dmax;

    /* modelview matrix */
    vertex_copy(lookat, self->axes[2]);
    vertex_scale(lookat, sz);
    vertex_add(lookat, self->location);

    matrix_load_lookat(
        mview,
        self->location,
        lookat,
        self->axes[1]
    );

    /* projection matrix */
    matrix_load(
        proj,
        2.0 * fabs(sz) / self->w, 0, 2.0 * sx / self->w, 0,
        0, 2.0 * fabs(sz) / self->h, 2.0 * sy / self->h, 0,
        0, 0, (zmin + zmax) / (zmin - zmax), 2.0 * zmin * zmax / (zmin - zmax),
        0, 0, -1.0, 0
    );
}

static void LsgWindowCam_destroy(LsgWindowCam* self) {
    LsgObjectClass* pclass = (LsgObjectClass*)LsgClass_getClass(LsgCamera_classID());

    pclass->destroy((LsgObject*)self);
}
