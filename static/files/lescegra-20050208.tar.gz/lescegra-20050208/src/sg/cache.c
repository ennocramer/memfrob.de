#include <lescegra/sg/cache.h>

#include <GL/gl.h>

#include <stdlib.h>

static void LsgCache_update(LsgCache* self, float now);
static void LsgCache_display(const LsgCache* self, const LsgFrustum* frustum);
static void LsgCache_destroy(LsgCache* self);

static void LsgCache_staticInit(LsgCacheClass* class, LsgCache* instance) {
    ((LsgNodeClass*)class)->update  = (void (*)(LsgNode*, float))LsgCache_update;
    ((LsgNodeClass*)class)->display = (void (*)(const LsgNode*, const LsgFrustum*))LsgCache_display;

    ((LsgObjectClass*)class)->destroy = (void (*)(LsgObject*))LsgCache_destroy;

    instance->list  = 0;
    instance->valid = 0;
}

LsgClassID LsgCache_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgCache",
            LsgGroup_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgCacheClass),
            sizeof(LsgCache),
            (LsgClassStaticInitializer)LsgCache_staticInit
        );
    }

    return classid;
}

LsgCache* LsgCache_create(void) {
    LsgCache* self = (LsgCache*)LsgClass_alloc(LsgCache_classID());

    if (self)
        LsgCache_init(self);

    return self;
}

void LsgCache_init(LsgCache* self) {
    LsgGroup_init(&self->parent);

    self->list = glGenLists(1);
    self->valid = 0;
}

static void LsgCache_update(LsgCache* self, float now) {
    LsgNodeClass* pclass = (LsgNodeClass*)LsgClass_getClass(LsgGroup_classID());

    pclass->update((LsgNode*)self, now);

    if (((LsgNode*)self)->dirty) self->valid = 0;
}

void LsgCache_display(const LsgCache* self, const LsgFrustum* frustum) {
    LsgNodeClass* pclass = (LsgNodeClass*)LsgClass_getClass(LsgGroup_classID());

    if (self->valid) {
        glCallList(self->list);
    } else {
        glNewList(self->list, GL_COMPILE_AND_EXECUTE);
        pclass->display((LsgNode*)self, frustum);
        glEndList();

        /* discard const qualifier */
        ((LsgCache*)self)->valid = 1;
    }
}

void LsgCache_destroy(LsgCache* self) {
    LsgObjectClass* pclass = (LsgObjectClass*)LsgClass_getClass(LsgGroup_classID());

    glDeleteLists(self->list, 1);

    pclass->destroy((LsgObject*)self);
}
