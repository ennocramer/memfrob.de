#include <lescegra/sg/environment.h>

#include <lescegra/sg/state.h>
#include <lescegra/util/arraylist.h>

#include <stdlib.h>

static void LsgEnvironment_display(const LsgEnvironment*, const LsgFrustum*);
static void LsgEnvironment_destroy(LsgEnvironment*);

static void LsgEnvironment_staticInit(LsgEnvironmentClass* class, LsgEnvironment* instance) {
    ((LsgNodeClass*)class)->display =
        (void (*)(const LsgNode*, const LsgFrustum*))LsgEnvironment_display;

    ((LsgObjectClass*)class)->destroy =
        (void (*)(LsgObject*))LsgEnvironment_destroy;
}

LsgClassID LsgEnvironment_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgEnvironment",
            LsgGroup_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgEnvironmentClass),
            sizeof(LsgEnvironment),
            (LsgClassStaticInitializer)LsgEnvironment_staticInit
        );
    }

    return classid;
}

LsgEnvironment* LsgEnvironment_create(void) {
    LsgEnvironment* self = (LsgEnvironment*)LsgClass_alloc(LsgEnvironment_classID());

    if (self)
        LsgEnvironment_init(self);

    return self;
}

void LsgEnvironment_init(LsgEnvironment* self) {
    LsgGroup_init(&self->parent);

    self->states = LSG_LIST(LsgArrayList_create());
}

static void LsgEnvironment_display(
    const LsgEnvironment* self,
    const LsgFrustum* frustum
) {
    LsgNodeClass* pclass =
        (LsgNodeClass*)LsgClass_getClass(LsgGroup_classID());
    int i;
    
    for (i = 0; i < LsgList_count(self->states); ++i)
        LsgState_apply(LSG_STATE(LsgList_get(self->states, i)));

    pclass->display(LSG_NODE(self), frustum);

    for (i = LsgList_count(self->states) - 1; i >= 0; --i)
        LsgState_restore(LSG_STATE(LsgList_get(self->states, i)));
}

void LsgEnvironment_destroy(LsgEnvironment* self) {
    LsgObjectClass* pclass =
        (LsgObjectClass*)LsgClass_getClass(LsgNode_classID());

    LsgObject_free(LSG_OBJECT(self->states));

    pclass->destroy(LSG_OBJECT(self));
}
