#include <lescegra/sg/material.h>

#include <lescegra/base/vertex.h>
#include <lescegra/util/arraylist.h>
#include <lescegra/util/features.h>
#include <lescegra/sg/texture.h>

#define GL_GLEXT_PROTOTYPES
#include <GL/gl.h>
#ifdef HAVE_GL_GLEXT_H
# include <GL/glext.h>
#endif

#include <stdlib.h>

static void LsgMaterial_display(const LsgMaterial*, const LsgFrustum*);

static void LsgMaterial_staticInit(LsgMaterialClass* class, LsgMaterial* instance) {
    ((LsgNodeClass*)class)->display =
        (void (*)(const LsgNode*, const LsgFrustum*))LsgMaterial_display;

    instance->textures = NULL;

    vertex_assign(instance->ambient, 0.2, 0.2, 0.2);
    instance->ambient[3] = 1.0;

    vertex_assign(instance->diffuse, 0.7, 0.7, 0.7);
    instance->ambient[3] = 1.0;
    
    vertex_assign(instance->specular, 0.3, 0.3, 0.3);
    instance->ambient[3] = 1.0;

    instance->shininess = 5.0;
}

LsgClassID LsgMaterial_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgMaterial",
            LsgGroup_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgMaterialClass),
            sizeof(LsgMaterial),
            (LsgClassStaticInitializer)LsgMaterial_staticInit
        );
    }

    return classid;
}

LsgMaterial* LsgMaterial_create(void) {
    LsgMaterial* self = (LsgMaterial*)LsgClass_alloc(LsgMaterial_classID());

    if (self)
        LsgMaterial_init(self);

    return self;
}

void LsgMaterial_init(LsgMaterial* self) {
    LsgGroup_init(&self->parent);

    self->textures = LSG_LIST(LsgArrayList_create());
    LsgList_refElements(self->textures, 1);
}

static void LsgMaterial_display(
    const LsgMaterial* self,
    const LsgFrustum* frustum
) {
    LsgNodeClass* pclass =
        (LsgNodeClass*)LsgClass_getClass(LsgGroup_classID());
    int i;

    glPushAttrib(GL_LIGHTING_BIT | GL_TEXTURE_BIT);

    glEnable(GL_LIGHTING);

    glMaterialfv(GL_FRONT, GL_AMBIENT, self->ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, self->diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, self->specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, &self->shininess);

#ifdef GL_ARB_multitexture
    if (LsgFeatures_numTextureUnits() > 1) {
        int max =
            LsgFeatures_numTextureUnits() < LsgList_count(self->textures)
            ? LsgFeatures_numTextureUnits()
            : LsgList_count(self->textures);
        
        for (i = 0; i < max; ++i) {
            LsgTexture* tex = LSG_TEXTURE(LsgList_get(self->textures, i));
            
            glActiveTexture(GL_TEXTURE0 + i);

            glEnable(GL_TEXTURE_2D);

            glBindTexture(GL_TEXTURE_2D, tex->id);
            glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, tex->mode);
        }

        pclass->display(LSG_NODE(self), frustum);
    } else
#endif
    {
        /* render with first texture */
        LsgTexture* tex = LSG_TEXTURE(LsgList_get(self->textures, 0));

        glEnable(GL_TEXTURE_2D);
            
        glBindTexture(GL_TEXTURE_2D, tex->id);
        glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, tex->mode);

        pclass->display(LSG_NODE(self), frustum);

        /* additional texture passes */
        if (LsgList_count(self->textures) > 1) {
            glPushAttrib(
                GL_CURRENT_BIT
                | GL_COLOR_BUFFER_BIT
                | GL_DEPTH_BUFFER_BIT
            );

            glDepthFunc(GL_EQUAL);
            glDepthMask(GL_FALSE);

            glColor4f(1.0, 1.0, 1.0, 1.0);

            glEnable(GL_BLEND);
            glDisable(GL_LIGHTING);

            for (i = 0; i < LsgList_count(self->textures); ++i) {
                tex = LSG_TEXTURE(LsgList_get(self->textures, i));

                switch (tex->mode) {
                    case GL_DECAL: /* blend by alpha */
                        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
                        break;

                    case GL_MODULATE: /* blend with color / luminance */
                        glBlendFunc(GL_ZERO, GL_SRC_COLOR);
                        break;

                    default: /* not supported, no blending */
                        glBlendFunc(GL_ONE, GL_ZERO);
                        break;
                }
            
                glBindTexture(GL_TEXTURE_2D, tex->id);
                glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
            }

            glPopAttrib();
        }
    }

    glPopAttrib();
}
