#include <lescegra/sg/fog.h>

#include <GL/gl.h>

#include <stdlib.h>

static void LsgFog_apply(const LsgFog*);
static void LsgFog_restore(const LsgFog*);

static void LsgFog_staticInit(LsgFogClass* class, LsgFog* instance) {
    ((LsgStateClass*)class)->apply =
        (void (*)(const LsgState*))LsgFog_apply;
    ((LsgStateClass*)class)->restore =
        (void (*)(const LsgState*))LsgFog_restore;

    instance->type = LSG_FOG_LINEAR;

    instance->color[0] = 0.0;
    instance->color[1] = 0.0;
    instance->color[2] = 0.0;
    instance->color[3] = 1.0;

    instance->start   = 0.0;
    instance->end     = 10.0;
    instance->density = 1.0;
}

LsgClassID LsgFog_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgFog",
            LsgState_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgFogClass),
            sizeof(LsgFog),
            (LsgClassStaticInitializer)LsgFog_staticInit
        );
    }

    return classid;
}

LsgFog* LsgFog_create(enum LsgFogType type) {
    LsgFog* self = (LsgFog*)LsgClass_alloc(LsgFog_classID());

    if (self)
        LsgFog_init(self, type);

    return self;
}

void LsgFog_init(LsgFog* self, enum LsgFogType type) {
    LsgState_init(&self->parent);

    self->type = type;
}

static void LsgFog_apply(const LsgFog* self) {
    glPushAttrib(GL_FOG_BIT);

    glEnable(GL_FOG);

    glFogfv(GL_FOG_COLOR, self->color);

    if (self->type == LSG_FOG_LINEAR) {
        glFogi(GL_FOG_MODE, GL_LINEAR);
        glFogf(GL_FOG_START, self->start);
        glFogf(GL_FOG_END, self->end);
    } else {
        glFogi(GL_FOG_MODE, self->type == LSG_FOG_EXP ? GL_EXP : GL_EXP2);
        glFogf(GL_FOG_DENSITY, self->density);
    }
}

static void LsgFog_restore(const LsgFog* self) {
    glPopAttrib();
}
