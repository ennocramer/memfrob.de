#include <lescegra/sg/camera.h>

#include <GL/gl.h>

static void LsgCamera_load_impl(const LsgCamera* self, Matrix proj, Matrix mview);

static void LsgCamera_staticInit(LsgCameraClass* class, LsgCamera* instance) {
    class->load = LsgCamera_load_impl;
}

LsgClassID LsgCamera_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgCamera",
            LsgObject_classID(),
            LSG_CLASS_FLAG_ABSTRACT,
            sizeof(LsgCameraClass),
            sizeof(LsgCamera),
            (LsgClassStaticInitializer)LsgCamera_staticInit
        );
    }

    return classid;
}

void LsgCamera_init(LsgCamera* self) {
    LsgObject_init(&self->parent);
}

static void LsgCamera_load_impl(const LsgCamera* self, Matrix proj, Matrix mview) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgCamera_classID(), "display");
}

void LsgCamera_load(const LsgCamera* self, Matrix proj, Matrix mview) {
    LsgCameraClass* class = (LsgCameraClass*)((LsgClassInstance*)self)->class;

    class->load(self, proj, mview);
}

void LsgCamera_display(
    const LsgCamera* self,
    const LsgFrustum* frustum,
    const LsgNode* node
) {
    LsgFrustum* nfrust;
    Matrix tp, tmv;

    LsgCamera_load(self, tp, tmv);

    /* transform opengl projection and modelview matrices */
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glMultMatrixf(tp);

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glMultMatrixf(tmv);

    /* calculate new view frustum */
    matrix_premult(tp, frustum->projection);
    matrix_premult(tmv, frustum->modelview);

    /* display node */
    nfrust = LsgFrustum_create(tp, tmv);
    LsgNode_display(node, nfrust);
    LsgObject_free((LsgObject*)nfrust);

    /* restore opengl projection and modelview matrices */
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();

    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
}
