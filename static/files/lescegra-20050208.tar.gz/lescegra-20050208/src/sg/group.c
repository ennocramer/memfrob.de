#include <lescegra/sg/group.h>

#include <lescegra/util/arraylist.h>

#include <stdlib.h>
#include <float.h>

static void LsgGroup_clean(LsgGroup* self);
static void LsgGroup_update(LsgGroup* self, float now);
static void LsgGroup_display(const LsgGroup* self, const LsgFrustum* frust);
static void LsgGroup_destroy(LsgGroup* self);

static void LsgGroup_staticInit(LsgGroupClass* class, LsgGroup* instance) {
    ((LsgNodeClass*)class)->clean   = (void (*)(LsgNode*))LsgGroup_clean;
    ((LsgNodeClass*)class)->update  = (void (*)(LsgNode*, float))LsgGroup_update;
    ((LsgNodeClass*)class)->display = (void (*)(const LsgNode*, const LsgFrustum*))LsgGroup_display;

    ((LsgObjectClass*)class)->destroy = (void (*)(LsgObject*))LsgGroup_destroy;

    instance->children = NULL;
}

LsgClassID LsgGroup_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgGroup",
            LsgNode_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgGroupClass),
            sizeof(LsgGroup),
            (LsgClassStaticInitializer)LsgGroup_staticInit
        );
    }

    return classid;
}

LsgGroup* LsgGroup_create(void) {
    LsgGroup* self = (LsgGroup*)LsgClass_alloc(LsgGroup_classID());

    if (self)
        LsgGroup_init(self);

    return self;
}

void LsgGroup_init(LsgGroup* self) {
    LsgNode_init(&self->parent);

    self->children = (LsgList*)LsgArrayList_create();
    LsgList_refElements(self->children, 1);
}

static void LsgGroup_clean(LsgGroup* self) {
    LsgNodeClass* pclass = (LsgNodeClass*)LsgClass_getClass(LsgNode_classID());
    LsgIterator* it;

    /* clean child nodes */
    it = LsgList_iterator(self->children);
    while (LsgIterator_hasNext(it)) {
        LsgNode* child = LSG_NODE(LsgIterator_next(it));
        if (child->updated || child->dirty) LsgNode_clean(child);
    }
    LsgObject_free((LsgObject*)it);

    pclass->clean((LsgNode*)self);
}

void LsgGroup_update(LsgGroup* self, float now) {
    LsgNodeClass* pclass = (LsgNodeClass*)LsgClass_getClass(LsgNode_classID());
    LsgIterator* it;

    /* update child nodes */
    it = LsgList_iterator(self->children);
    while (LsgIterator_hasNext(it)) {
        LsgNode* child = LSG_NODE(LsgIterator_next(it));
        if (!child->updated) LsgNode_update(child, now);

        /* propagate dirty flag */
        self->parent.dirty = self->parent.dirty || child->dirty;
    }
    LsgObject_free((LsgObject*)it);

    /* update group bounding volume */
    if (self->parent.dirty
        && self->parent.bvolume
        && LsgClass_isInstanceOf((LsgClassInstance*)self->parent.bvolume, LsgGenericBVolume_classID()))
    {
        LsgGenericBVolume* gbv = LSG_GENERIC_BVOLUME(self->parent.bvolume);
        LsgGenericBVolume_reset(gbv);

        if (LsgList_count(self->children) > 0) {
            it = LsgList_iterator(self->children);
            do {
                LsgNode* child = LSG_NODE(LsgIterator_next(it));
                if (child->bvolume && child->bvolume->valid) {
                    LsgBVolume_merge(child->bvolume, gbv);
                } else {
                    self->parent.bvolume->valid = 0;
                }
            } while (self->parent.bvolume->valid && LsgIterator_hasNext(it));
            LsgObject_free((LsgObject*)it);
        }
    }

    pclass->update((LsgNode*)self, now);
}

static void LsgGroup_display(const LsgGroup* self, const LsgFrustum* frust) {
    LsgIterator* it;

    it = LsgList_iterator(self->children);
    while (LsgIterator_hasNext(it)) {
        LsgNode* child = LSG_NODE(LsgIterator_next(it));
        if (!child->bvolume ||
            !child->bvolume->valid ||
            LsgBVolume_visible(child->bvolume, frust)) LsgNode_display(child, frust);
    }
    LsgObject_free((LsgObject*)it);
}

void LsgGroup_destroy(LsgGroup* self) {
    LsgObjectClass* pclass = (LsgObjectClass*)LsgClass_getClass(LsgNode_classID());

    LsgObject_free((LsgObject*)self->children);

    pclass->destroy((LsgObject*)self);
}
