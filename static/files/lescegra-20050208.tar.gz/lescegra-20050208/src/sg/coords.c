#include <lescegra/sg/coords.h>

#include <lescegra/coll/bbox.h>

#include <GL/gl.h>

#include <stdlib.h>

static void LsgCoords_display(const LsgCoords*, const LsgFrustum*);

static void LsgCoords_staticInit(LsgCoordsClass* class, LsgCoords* instance) {
    ((LsgNodeClass*)class)->display = (void (*)(const LsgNode*, const LsgFrustum*))LsgCoords_display;

    instance->size = 0.0;
}

LsgClassID LsgCoords_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgCoords",
            LsgNode_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgCoordsClass),
            sizeof(LsgCoords),
            (LsgClassStaticInitializer)LsgCoords_staticInit
        );
    }

    return classid;
}

LsgCoords* LsgCoords_create(float size){
    LsgCoords* self = (LsgCoords*)LsgClass_alloc(LsgCoords_classID());

    if (self)
        LsgCoords_init(self, size);

    return self;
}

void LsgCoords_init(LsgCoords* self, float size) {
    LsgNode_init(&self->parent);

    self->size = size;
}

static void LsgCoords_display(const LsgCoords* self, const LsgFrustum* frust) {
    glPushAttrib(GL_ENABLE_BIT);
    glDisable(GL_LIGHTING);
    glDisable(GL_NORMALIZE);
    glDisable(GL_TEXTURE_2D);

    glPushMatrix();
    glScalef(self->size, self->size, self->size);

    glBegin(GL_LINES);
        /* X-Axis (Red) */
        glColor3f(1.0, 0.0, 0.0);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(1.0, 0.0, 0.0);

        glVertex3f(0.9, 0.1, 0.0);
        glVertex3f(1.0, 0.0, 0.0);

        glVertex3f(0.9, 0.0, 0.1);
        glVertex3f(1.0, 0.0, 0.0);

        /* Y-Axis (Green) */
        glColor3f(0.0, 1.0, 0.0);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(0.0, 1.0, 0.0);

        glVertex3f(0.1, 0.9, 0.0);
        glVertex3f(0.0, 1.0, 0.0);

        glVertex3f(0.0, 0.9, 0.1);
        glVertex3f(0.0, 1.0, 0.0);

        /* Z-Axis (Blue) */
        glColor3f(0.0, 0.0, 1.0);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(0.0, 0.0, 1.0);

        glVertex3f(0.1, 0.0, 0.9);
        glVertex3f(0.0, 0.0, 1.0);

        glVertex3f(0.0, 0.1, 0.9);
        glVertex3f(0.0, 0.0, 1.0);
    glEnd();

    glPopMatrix();

    glPopAttrib();
}
