#include <lescegra/sg/node.h>

#include <stddef.h>

static void LsgNode_clean_impl(LsgNode* self);
static void LsgNode_update_impl(LsgNode* self, float now);
static void LsgNode_display_impl(const LsgNode* self, const LsgFrustum* frustum);
static void LsgNode_destroy(LsgNode* self);

static void LsgNode_staticInit(LsgNodeClass* class, LsgNode* instance) {
    class->clean   = LsgNode_clean_impl;
    class->update  = LsgNode_update_impl;
    class->display = LsgNode_display_impl;

    ((LsgObjectClass*)class)->destroy = (void (*)(LsgObject*))LsgNode_destroy;

    instance->bvolume = NULL;
    instance->updated = 0;
    instance->dirty   = 1;
}

LsgClassID LsgNode_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgNode",
            LsgObject_classID(),
            LSG_CLASS_FLAG_ABSTRACT,
            sizeof(LsgNodeClass),
            sizeof(LsgNode),
            (LsgClassStaticInitializer)LsgNode_staticInit
        );
    }

    return classid;
}

void LsgNode_init(LsgNode* self) {
    LsgObject_init(&self->parent);
}

static void LsgNode_clean_impl(LsgNode* self) {
    self->updated = 0;
    self->dirty   = 0;
}

void LsgNode_clean(LsgNode* self) {
    LsgNodeClass* class = (LsgNodeClass*)((LsgClassInstance*)self)->class;

    class->clean(self);
}

static void LsgNode_update_impl(LsgNode* self, float now) {
    self->updated = 1;
    /* don't change the dirty flag by default */
    /* self->dirty   = 1; */
}

void LsgNode_update(LsgNode* self, float now) {
    LsgNodeClass* class = (LsgNodeClass*)((LsgClassInstance*)self)->class;

    class->update(self, now);
}

static void LsgNode_display_impl(const LsgNode* self, const LsgFrustum* frustum) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgNode_classID(), "display");
}

void LsgNode_display(const LsgNode* self, const LsgFrustum* frustum) {
    LsgNodeClass* class = (LsgNodeClass*)((LsgClassInstance*)self)->class;

    class->display(self, frustum);
}

static void LsgNode_destroy(LsgNode* self) {
    LsgObjectClass* pclass = (LsgObjectClass*)LsgClass_getClass(LsgObject_classID());

    if (self->bvolume) LsgObject_free((LsgObject*)self->bvolume);

    pclass->destroy((LsgObject*)self);
}
