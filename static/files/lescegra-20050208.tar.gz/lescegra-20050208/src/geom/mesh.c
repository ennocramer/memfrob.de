#include <lescegra/geom/mesh.h>

#include <GL/gl.h>

#include <stdlib.h>

static void LsgMesh_display(const LsgMesh*, const LsgFrustum*);

static void LsgMesh_staticInit(LsgMeshClass* class, LsgMesh* instance) {
    ((LsgNodeClass*)class)->display = (void (*)(const LsgNode*, const LsgFrustum*))LsgMesh_display;

    instance->triangles     = NULL;
    instance->texCoords     = NULL;
    instance->colors        = NULL;
    instance->normals       = NULL;
    instance->vertices      = NULL;

    instance->triangleCount = 0;

    instance->octree        = NULL;
}

LsgClassID LsgMesh_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgMesh",
            LsgNode_classID(),
            LSG_CLASS_FLAG_ABSTRACT,
            sizeof(LsgMeshClass),
            sizeof(LsgMesh),
            (LsgClassStaticInitializer)LsgMesh_staticInit
        );
    }

    return classid;
}

void LsgMesh_init(LsgMesh* self) {
    LsgNode_init(&self->parent);
}

static void LsgMesh_display(const LsgMesh* self, const LsgFrustum* frustum) {
    /* this should really be assert(...) */
    if (!(self->triangleCount && self->triangles && self->vertices)) return;

    glPushClientAttrib(GL_CLIENT_VERTEX_ARRAY_BIT);

    if (self->normals) {
        glEnableClientState(GL_NORMAL_ARRAY);
        glNormalPointer(GL_FLOAT, 0, self->normals);
    } else {
        glDisableClientState(GL_NORMAL_ARRAY);
    }

    if (self->colors) {
        glEnableClientState(GL_COLOR_ARRAY);
        glColorPointer(4, GL_FLOAT, 0, self->colors);
    } else {
        glDisableClientState(GL_COLOR_ARRAY);
    }

    if (self->texCoords) {
        glEnableClientState(GL_TEXTURE_COORD_ARRAY);
        glTexCoordPointer(2, GL_FLOAT, 0, self->texCoords);
    } else {
        glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    }

    glEnable(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0, self->vertices);

    glDrawElements(GL_TRIANGLES, self->triangleCount * 3, GL_UNSIGNED_INT, self->triangles);

    glPopClientAttrib();
}
