#include <lescegra/geom/md2model.h>

#include <lescegra/base/endian.h>
#include <lescegra/base/error.h>
#include <lescegra/util/image.h>
#include <lescegra/coll/bbox.h>

#include <GL/gl.h>

#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

typedef struct {
    int magic;
    int version;
    int skin_width;
    int skin_height;
    int frame_size;

    int skin_count;
    int vertex_count;
    int tex_coord_count;
    int triangle_count;
    int glcommand_count;
    int frame_count;

    int skin_offset;
    int tex_coord_offset;
    int triangle_offset;
    int frame_offset;
    int glcommand_offset;
    int filesize;
} MD2FileHeader;

typedef char MD2FileSkin[64];

typedef struct {
    short int s;
    short int t;
} MD2FileTexCoord;

typedef struct {
    short int vertices[3];
    short int tex_coords[3];
} MD2FileTriangle;

typedef struct {
    float scale[3];
    float translate[3];
    char  name[16];
} MD2FileFrameHeader;

typedef struct {
    unsigned char v[3];
    unsigned char n;
} MD2FileVertex;

/*
 * quake ii model normals
 * taken from utils3/qdata/anorms.h (q2source_12_11.zip from id software ftp server)
 * y and z values have been swapped to make models conform to right hand
 * coordinate system with y = up
 */
static Vertex q2_normals[256] = {
    {-0.525731, 0.850651, 0.000000},
    {-0.442863, 0.864188, 0.238856},
    {-0.295242, 0.955423, 0.000000},
    {-0.309017, 0.809017, 0.500000},
    {-0.162460, 0.951056, 0.262866},
    {0.000000, 1.000000, 0.000000},
    {0.000000, 0.525731, 0.850651},
    {-0.147621, 0.681718, 0.716567},
    {0.147621, 0.681718, 0.716567},
    {0.000000, 0.850651, 0.525731},
    {0.309017, 0.809017, 0.500000},
    {0.525731, 0.850651, 0.000000},
    {0.295242, 0.955423, 0.000000},
    {0.442863, 0.864188, 0.238856},
    {0.162460, 0.951056, 0.262866},
    {-0.681718, 0.716567, 0.147621},
    {-0.809017, 0.500000, 0.309017},
    {-0.587785, 0.688191, 0.425325},
    {-0.850651, 0.000000, 0.525731},
    {-0.864188, 0.238856, 0.442863},
    {-0.716567, 0.147621, 0.681718},
    {-0.688191, 0.425325, 0.587785},
    {-0.500000, 0.309017, 0.809017},
    {-0.238856, 0.442863, 0.864188},
    {-0.425325, 0.587785, 0.688191},
    {-0.716567, -0.147621, 0.681718},
    {-0.500000, -0.309017, 0.809017},
    {-0.525731, 0.000000, 0.850651},
    {0.000000, -0.525731, 0.850651},
    {-0.238856, -0.442863, 0.864188},
    {0.000000, -0.295242, 0.955423},
    {-0.262866, -0.162460, 0.951056},
    {0.000000, 0.000000, 1.000000},
    {0.000000, 0.295242, 0.955423},
    {-0.262866, 0.162460, 0.951056},
    {0.238856, 0.442863, 0.864188},
    {0.262866, 0.162460, 0.951056},
    {0.500000, 0.309017, 0.809017},
    {0.238856, -0.442863, 0.864188},
    {0.262866, -0.162460, 0.951056},
    {0.500000, -0.309017, 0.809017},
    {0.850651, 0.000000, 0.525731},
    {0.716567, 0.147621, 0.681718},
    {0.716567, -0.147621, 0.681718},
    {0.525731, 0.000000, 0.850651},
    {0.425325, 0.587785, 0.688191},
    {0.864188, 0.238856, 0.442863},
    {0.688191, 0.425325, 0.587785},
    {0.809017, 0.500000, 0.309017},
    {0.681718, 0.716567, 0.147621},
    {0.587785, 0.688191, 0.425325},
    {0.955423, 0.000000, 0.295242},
    {1.000000, 0.000000, 0.000000},
    {0.951056, 0.262866, 0.162460},
    {0.850651, 0.000000, -0.525731},
    {0.955423, 0.000000, -0.295242},
    {0.864188, 0.238856, -0.442863},
    {0.951056, 0.262866, -0.162460},
    {0.809017, 0.500000, -0.309017},
    {0.681718, 0.716567, -0.147621},
    {0.850651, 0.525731, 0.000000},
    {0.864188, -0.238856, 0.442863},
    {0.809017, -0.500000, 0.309017},
    {0.951056, -0.262866, 0.162460},
    {0.525731, -0.850651, 0.000000},
    {0.681718, -0.716567, 0.147621},
    {0.681718, -0.716567, -0.147621},
    {0.850651, -0.525731, 0.000000},
    {0.809017, -0.500000, -0.309017},
    {0.864188, -0.238856, -0.442863},
    {0.951056, -0.262866, -0.162460},
    {0.147621, -0.681718, 0.716567},
    {0.309017, -0.809017, 0.500000},
    {0.425325, -0.587785, 0.688191},
    {0.442863, -0.864188, 0.238856},
    {0.587785, -0.688191, 0.425325},
    {0.688191, -0.425325, 0.587785},
    {-0.147621, -0.681718, 0.716567},
    {-0.309017, -0.809017, 0.500000},
    {0.000000, -0.850651, 0.525731},
    {-0.525731, -0.850651, 0.000000},
    {-0.442863, -0.864188, 0.238856},
    {-0.295242, -0.955423, 0.000000},
    {-0.162460, -0.951056, 0.262866},
    {0.000000, -1.000000, 0.000000},
    {0.295242, -0.955423, 0.000000},
    {0.162460, -0.951056, 0.262866},
    {-0.442863, -0.864188, -0.238856},
    {-0.309017, -0.809017, -0.500000},
    {-0.162460, -0.951056, -0.262866},
    {0.000000, -0.525731, -0.850651},
    {-0.147621, -0.681718, -0.716567},
    {0.147621, -0.681718, -0.716567},
    {0.000000, -0.850651, -0.525731},
    {0.309017, -0.809017, -0.500000},
    {0.442863, -0.864188, -0.238856},
    {0.162460, -0.951056, -0.262866},
    {0.238856, -0.442863, -0.864188},
    {0.500000, -0.309017, -0.809017},
    {0.425325, -0.587785, -0.688191},
    {0.716567, -0.147621, -0.681718},
    {0.688191, -0.425325, -0.587785},
    {0.587785, -0.688191, -0.425325},
    {0.000000, -0.295242, -0.955423},
    {0.000000, 0.000000, -1.000000},
    {0.262866, -0.162460, -0.951056},
    {0.000000, 0.525731, -0.850651},
    {0.000000, 0.295242, -0.955423},
    {0.238856, 0.442863, -0.864188},
    {0.262866, 0.162460, -0.951056},
    {0.500000, 0.309017, -0.809017},
    {0.716567, 0.147621, -0.681718},
    {0.525731, 0.000000, -0.850651},
    {-0.238856, -0.442863, -0.864188},
    {-0.500000, -0.309017, -0.809017},
    {-0.262866, -0.162460, -0.951056},
    {-0.850651, 0.000000, -0.525731},
    {-0.716567, -0.147621, -0.681718},
    {-0.716567, 0.147621, -0.681718},
    {-0.525731, 0.000000, -0.850651},
    {-0.500000, 0.309017, -0.809017},
    {-0.238856, 0.442863, -0.864188},
    {-0.262866, 0.162460, -0.951056},
    {-0.864188, 0.238856, -0.442863},
    {-0.809017, 0.500000, -0.309017},
    {-0.688191, 0.425325, -0.587785},
    {-0.681718, 0.716567, -0.147621},
    {-0.442863, 0.864188, -0.238856},
    {-0.587785, 0.688191, -0.425325},
    {-0.309017, 0.809017, -0.500000},
    {-0.147621, 0.681718, -0.716567},
    {-0.425325, 0.587785, -0.688191},
    {-0.162460, 0.951056, -0.262866},
    {0.442863, 0.864188, -0.238856},
    {0.162460, 0.951056, -0.262866},
    {0.309017, 0.809017, -0.500000},
    {0.147621, 0.681718, -0.716567},
    {0.000000, 0.850651, -0.525731},
    {0.425325, 0.587785, -0.688191},
    {0.587785, 0.688191, -0.425325},
    {0.688191, 0.425325, -0.587785},
    {-0.955423, 0.000000, 0.295242},
    {-0.951056, 0.262866, 0.162460},
    {-1.000000, 0.000000, 0.000000},
    {-0.850651, 0.525731, 0.000000},
    {-0.955423, 0.000000, -0.295242},
    {-0.951056, 0.262866, -0.162460},
    {-0.864188, -0.238856, 0.442863},
    {-0.951056, -0.262866, 0.162460},
    {-0.809017, -0.500000, 0.309017},
    {-0.864188, -0.238856, -0.442863},
    {-0.951056, -0.262866, -0.162460},
    {-0.809017, -0.500000, -0.309017},
    {-0.681718, -0.716567, 0.147621},
    {-0.681718, -0.716567, -0.147621},
    {-0.850651, -0.525731, 0.000000},
    {-0.688191, -0.425325, 0.587785},
    {-0.587785, -0.688191, 0.425325},
    {-0.425325, -0.587785, 0.688191},
    {-0.425325, -0.587785, -0.688191},
    {-0.587785, -0.688191, -0.425325},
    {-0.688191, -0.425325, -0.587785}
};

static void LsgMD2Model_destroy(LsgMD2Model*);

static void LsgMD2Model_staticInit(LsgMD2ModelClass* class, LsgMD2Model* instance) {
    ((LsgObjectClass*)class)->destroy = (void (*)(LsgObject*))LsgMD2Model_destroy;

    instance->triangles  = NULL;
    instance->tex_coords = NULL;
    instance->normals    = NULL;
    instance->vertices   = NULL;

    instance->octrees    = NULL;
}

LsgClassID LsgMD2Model_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgMD2Model",
            LsgMesh_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgMD2ModelClass),
            sizeof(LsgMD2Model),
            (LsgClassStaticInitializer)LsgMD2Model_staticInit
        );
    }

    return classid;
}

LsgMD2Model* LsgMD2Model_create(const char* filename) {
    LsgMD2Model* self = (LsgMD2Model*)LsgClass_alloc(LsgMD2Model_classID());

    if (self) {
        if (!LsgMD2Model_init(self, filename)) {
            LsgMD2Model_destroy(self);
            self = NULL;
        }
    }

    return self;
}

static int LsgMD2Model_load(LsgMD2Model* self, const char* filename);
int LsgMD2Model_init(LsgMD2Model* self, const char* filename) {
    LsgMesh_init(&self->parent);

    return LsgMD2Model_load(self, filename);
}

void LsgMD2Model_frame(LsgMD2Model* self, int frame) {
    self->frame = frame % self->frame_count;

    /* only vertices can be animated */
    ((LsgMesh*)self)->normals  = self->normals  + self->frame * self->vertex_count;
    ((LsgMesh*)self)->vertices = self->vertices + self->frame * self->vertex_count;
}

static void LsgMD2Model_destroy(LsgMD2Model* self) {
    LsgObjectClass* pclass = (LsgObjectClass*)LsgClass_getClass(LsgMesh_classID());
    int i;

    if (self->octrees) {
        for (i = 0; i < self->frame_count; ++i) {
            if (self->octrees[i]) LsgObject_free((LsgObject*)self->octrees[i]);
        }

        free(self->octrees);
    }

    if (self->triangles)  free(self->triangles);
    if (self->tex_coords) free(self->tex_coords);
    if (self->normals)    free(self->normals);
    if (self->vertices)   free(self->vertices);

    pclass->destroy((LsgObject*)self);
}

static int LsgMD2Model_loadHeader(FILE* file, MD2FileHeader* header);
static int LsgMD2Model_loadTexCoords(FILE* file, MD2FileHeader* header, LsgTexCoord* coords);
static int LsgMD2Model_loadTriangles(FILE* file, MD2FileHeader* header, LsgTriangle* triangles, LsgTriangle* coord_refs);
static int LsgMD2Model_loadFrames(FILE* file, MD2FileHeader* header, Vertex* vertices, Vertex* normals);

static int LsgMD2Model_load(LsgMD2Model* self, const char* filename) {
#define ERROR(msg) LsgError_reportFormat(__FILE__, "LsgMD2Model_load", __LINE__, "%s: %s", filename, (msg))
#define FERROR(msg) ERROR(ferror(file) ? strerror(errno) : (msg))
    MD2FileHeader header;
    LsgTexCoord* coord_buffer = NULL;
    LsgTriangle* coord_refs = NULL;
    FILE* file = NULL;
    int i;
    int ret = 1;

    /* open file */
    if (!(file = fopen(filename, "r"))) {
        ERROR(strerror(errno));
        ret = 0;
    }

    /* load file header */
    if (ret) {
        ret = ret && LsgMD2Model_loadHeader(file, &header);

        if (!ret)
            FERROR("Premature end of file");
    }

    /* check md2 file header */
    if (ret) {
        if ((header.magic != 0x32504449) || (header.version != 8)) {
            ERROR("Invalid MD2 file header");
            ret = 0;
        }
    }

    /* allocate memory */
    if (ret) {
        coord_buffer     = (LsgTexCoord*)malloc(sizeof(LsgTexCoord) * header.tex_coord_count);
        coord_refs       = (LsgTriangle*)malloc(sizeof(LsgTriangle) * header.triangle_count);

        self->triangles  = (LsgTriangle*)malloc(sizeof(LsgTriangle) * header.triangle_count);
        self->tex_coords = (LsgTexCoord*)malloc(sizeof(LsgTexCoord) * header.vertex_count);
        self->normals    = (Vertex*)malloc(sizeof(Vertex) * header.frame_count * header.vertex_count);
        self->vertices   = (Vertex*)malloc(sizeof(Vertex) * header.frame_count * header.vertex_count);

        self->octrees    = (LsgOctree**)calloc(header.frame_count, sizeof(LsgOctree*));

        ret  = coord_buffer
            && coord_refs
            && self->triangles
            && self->tex_coords
            && self->normals
            && self->vertices
            && self->octrees;

        if (!ret)
            ERROR(strerror(ENOMEM));
    }

    /* load geometry */
    if (ret) {
        ret = ret && LsgMD2Model_loadTexCoords(file, &header, coord_buffer);
        ret = ret && LsgMD2Model_loadTriangles(file, &header, self->triangles, coord_refs);
        ret = ret && LsgMD2Model_loadFrames(file, &header, self->vertices, self->normals);

        if (!ret)
            FERROR("Premature end of file");
    }

    /* fixup texture coordinates and set missing model parameter */
    if (ret) {
        for (i = 0; i < header.triangle_count; ++i) {
            self->tex_coords[self->triangles[i][0]][0] = coord_buffer[coord_refs[i][0]][0];
            self->tex_coords[self->triangles[i][0]][1] = coord_buffer[coord_refs[i][0]][1];

            self->tex_coords[self->triangles[i][1]][0] = coord_buffer[coord_refs[i][1]][0];
            self->tex_coords[self->triangles[i][1]][1] = coord_buffer[coord_refs[i][1]][1];

            self->tex_coords[self->triangles[i][2]][0] = coord_buffer[coord_refs[i][2]][0];
            self->tex_coords[self->triangles[i][2]][1] = coord_buffer[coord_refs[i][2]][1];
        }

        self->frame_count    = header.frame_count;
        self->vertex_count   = header.vertex_count;

        /* LsgMesh members */
        ((LsgMesh*)self)->triangleCount = header.triangle_count;

        /* static arrays */
        ((LsgMesh*)self)->triangles = self->triangles;
        ((LsgMesh*)self)->texCoords = self->tex_coords;
        ((LsgMesh*)self)->colors    = NULL;

        /* dynamic arrays (animation) */
        LsgMD2Model_frame(self, 0);
    }

    /* create octrees */
    if (ret) {
        Vertex min, max;
        int frame, triag;

        frame = 0;
        while (ret && (frame < header.frame_count)) {
            /* calculate model frame size */
            vertex_copy(min, self->vertices[frame * self->vertex_count]);
            vertex_copy(max, self->vertices[frame * self->vertex_count]);
            for (i = 1; i < self->vertex_count; ++i) {
                vertex_min(min, self->vertices[frame * self->vertex_count + i]);
                vertex_max(max, self->vertices[frame * self->vertex_count + i]);
            }

            /* create optimal octree */
            self->octrees[frame] = LsgOctree_createOptimal(min, max, header.triangle_count, 4);
            ret = ret && self->octrees[frame];

            /* add triangles */
            if (ret) {
                for (triag = 0; triag < header.triangle_count; ++triag) {
                    vertex_copy(min, self->vertices[frame * header.vertex_count + self->triangles[triag][0]]);
                    vertex_copy(max, self->vertices[frame * header.vertex_count + self->triangles[triag][0]]);
                    vertex_min(min,  self->vertices[frame * header.vertex_count + self->triangles[triag][1]]);
                    vertex_max(max,  self->vertices[frame * header.vertex_count + self->triangles[triag][1]]);
                    vertex_min(min,  self->vertices[frame * header.vertex_count + self->triangles[triag][2]]);
                    vertex_max(max,  self->vertices[frame * header.vertex_count + self->triangles[triag][2]]);

                    LsgOctree_add(self->octrees[frame], min, max, (void*)&self->triangles[triag]);
                }
            }

            ++frame;
        }
    }


    /* free resources */
    if (coord_refs) free(coord_refs);
    if (coord_buffer) free(coord_buffer);
    if (file) fclose(file);

    return ret;
#undef FERROR
#undef ERROR
}

static int LsgMD2Model_loadHeader(FILE* file, MD2FileHeader* header) {
    int ret = 1;

    /* seek to beginning of file */
    ret = ret && !fseek(file, 0, SEEK_SET);

    /* read file header */
    ret = ret && fread(header, sizeof(MD2FileHeader), 1, file);

    /* fix header for big endian machines */
    if (ret && (LsgEndian_endianess() == LSG_ENDIAN_BIG))
        LsgEndian_swapArray((char*)header, sizeof(int), 17);

    return ret;
}

static int LsgMD2Model_loadTexCoords(FILE* file, MD2FileHeader* header, LsgTexCoord* coords) {
    MD2FileTexCoord buffer;
    int i;
    int ret = 1;

    ret = ret && !fseek(file, header->tex_coord_offset, SEEK_SET);

    i = 0;
    while (ret && (i < header->tex_coord_count)) {
        ret = ret && fread(&buffer, sizeof(MD2FileTexCoord), 1, file);

        if (LsgEndian_endianess() == LSG_ENDIAN_BIG)
            LsgEndian_swapArray((char*)&buffer, sizeof(short int), 2);

        coords[i][0] = (float)buffer.s / header->skin_width;
        coords[i][1] = (float)buffer.t / header->skin_height;

        ++i;
    }

    return ret;
}

static int LsgMD2Model_loadTriangles(FILE* file, MD2FileHeader* header, LsgTriangle* triangles, LsgTriangle* coord_refs) {
    MD2FileTriangle buffer;
    int i;
    int ret = 1;

    ret = ret && !fseek(file, header->triangle_offset, SEEK_SET);

    i = 0;
    while (ret && (i < header->triangle_count)) {
        ret = ret && fread(&buffer, sizeof(buffer), 1, file);

        if (LsgEndian_endianess() == LSG_ENDIAN_BIG)
            LsgEndian_swapArray((char*)&buffer, sizeof(short int), 6);

        triangles[i][0] = (int)buffer.vertices[0];
        triangles[i][1] = (int)buffer.vertices[1];
        triangles[i][2] = (int)buffer.vertices[2];

        coord_refs[i][0] = (int)buffer.tex_coords[0];
        coord_refs[i][1] = (int)buffer.tex_coords[1];
        coord_refs[i][2] = (int)buffer.tex_coords[2];

        ++i;
    }

    return ret;
}

static int LsgMD2Model_loadFrames(FILE* file, MD2FileHeader* header, Vertex* vertices, Vertex* normals) {
    MD2FileFrameHeader buffer_fh;
    MD2FileVertex buffer_v;
    int i, f;
    int ret = 1;

    ret = ret && !fseek(file, header->frame_offset, SEEK_SET);

    i = 0;
    while (ret && (i < header->frame_count)) {
        ret = ret && fread(&buffer_fh, sizeof(MD2FileFrameHeader), 1, file);

        if (LsgEndian_endianess() == LSG_ENDIAN_BIG)
            LsgEndian_swapArray((char*)&buffer_fh, sizeof(float), 6);

        f = 0;
        while (ret && (f < header->vertex_count)) {
            ret = ret && fread(&buffer_v, sizeof(MD2FileVertex), 1, file);

            /* no endianess conversion necessary */

            vertices[i * header->vertex_count + f][0] = (float)buffer_v.v[0] * buffer_fh.scale[0] + buffer_fh.translate[0];
            vertices[i * header->vertex_count + f][2] = (float)buffer_v.v[1] * buffer_fh.scale[1] + buffer_fh.translate[1];
            vertices[i * header->vertex_count + f][1] = (float)buffer_v.v[2] * buffer_fh.scale[2] + buffer_fh.translate[2];

            vertex_copy(normals[i * header->vertex_count + f], q2_normals[buffer_v.n]);

            ++f;
        }

        ++i;
    }

    return ret;
}
