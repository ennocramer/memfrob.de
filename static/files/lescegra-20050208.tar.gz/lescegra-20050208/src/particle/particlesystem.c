#include <lescegra/particle/particlesystem.h>

#include <lescegra/util/linkedlist.h>
#include <lescegra/particle/particlemodifier.h>

#include <stdlib.h>

static void LsgParticleSystem_update(LsgParticleSystem*, float);
static void LsgParticleSystem_destroy(LsgParticleSystem*);

static void LsgParticleSystem_staticInit(LsgParticleSystemClass* class, LsgParticleSystem* instance) {
    ((LsgNodeClass*)class)->update = (void (*)(LsgNode*, float))LsgParticleSystem_update;

    ((LsgObjectClass*)class)->destroy = (void (*)(LsgObject*))LsgParticleSystem_destroy;

    instance->modifiers = NULL;
}

LsgClassID LsgParticleSystem_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgParticleSystem",
            LsgGroup_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgParticleSystemClass),
            sizeof(LsgParticleSystem),
            (LsgClassStaticInitializer)LsgParticleSystem_staticInit
        );
    }

    return classid;
}

LsgParticleSystem* LsgParticleSystem_create(void) {
    LsgParticleSystem* self = (LsgParticleSystem*)LsgClass_alloc(LsgParticleSystem_classID());

    if (self)
        LsgParticleSystem_init(self);

    return self;
}

void LsgParticleSystem_init(LsgParticleSystem* self) {
    LsgGroup_init(&self->parent);

    self->modifiers = (LsgList*)LsgLinkedList_create();
}

static void LsgParticleSystem_update(LsgParticleSystem* self, float now) {
    LsgNodeClass* pclass = (LsgNodeClass*)LsgClass_getClass(LsgGroup_classID());
    LsgIterator* it;

    it = LsgList_iterator(self->modifiers);
    while (LsgIterator_hasNext(it)) {
        LsgParticleModifier* pm = (LsgParticleModifier*)LsgIterator_next(it);
        LsgParticleModifier_update(pm, self->parent.children, now);
    }
    LsgObject_free((LsgObject*)it);

    pclass->update((LsgNode*)self, now);
}

static void LsgParticleSystem_destroy(LsgParticleSystem* self) {
    LsgObjectClass* pclass = (LsgObjectClass*)LsgClass_getClass(LsgGroup_classID());

    LsgObject_free((LsgObject*)self->modifiers);

    pclass->destroy((LsgObject*)self);
}
