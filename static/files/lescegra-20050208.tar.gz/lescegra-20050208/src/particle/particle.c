#include <lescegra/particle/particle.h>

#include <GL/gl.h>

#include <stdlib.h>

static void LsgParticle_update(LsgParticle*, float);

static void LsgParticle_staticInit(LsgParticleClass* class, LsgParticle* instance) {
    ((LsgNodeClass*)class)->update = (void (*)(LsgNode*, float))LsgParticle_update;

    vertex_assign(instance->location, 0.0, 0.0, 0.0);
    vertex_assign(instance->speed,    0.0, 0.0, 0.0);
    instance->birth       = 0.0;
    instance->last_update = 0.0;
}

LsgClassID LsgParticle_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgParticle",
            LsgNode_classID(),
            LSG_CLASS_FLAG_ABSTRACT,
            sizeof(LsgParticleClass),
            sizeof(LsgParticle),
            (LsgClassStaticInitializer)LsgParticle_staticInit
        );
    }

    return classid;
}

void LsgParticle_init(LsgParticle* self, const Vertex location, const Vertex speed, float now) {
    LsgNode_init(&self->parent);

    vertex_copy(self->location, location);
    vertex_copy(self->speed, speed);
    self->birth       = now;
    self->last_update = now;
}

static void LsgParticle_update(LsgParticle* self, float now) {
    LsgNodeClass* pclass = (LsgNodeClass*)LsgClass_getClass(LsgNode_classID());
    Vertex move;

    vertex_copy(move, self->speed);
    vertex_scale(move, now - self->last_update);
    vertex_add(self->location, move);

    self->last_update = now;

    pclass->update((LsgNode*)self, now);
}
