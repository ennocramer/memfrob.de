#include <lescegra/particle/particlemodifier.h>

#include <stdlib.h>

static void LsgParticleModifier_update_impl(LsgParticleModifier* self, LsgList* particles, float now);

static void LsgParticleModifier_staticInit(LsgParticleModifierClass* class, LsgParticleModifier* instance) {
    class->update = LsgParticleModifier_update_impl;
}

LsgClassID LsgParticleModifier_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgParticleModifier",
            LsgObject_classID(),
            LSG_CLASS_FLAG_ABSTRACT,
            sizeof(LsgParticleModifierClass),
            sizeof(LsgParticleModifier),
            (LsgClassStaticInitializer)LsgParticleModifier_staticInit
        );
    }

    return classid;
}

void LsgParticleModifier_init(LsgParticleModifier* self) {
    LsgObject_init(&self->parent);
}

void LsgParticleModifier_update(LsgParticleModifier* self, LsgList* particles, float now) {
    LsgParticleModifierClass* class = (LsgParticleModifierClass*)((LsgClassInstance*)self)->class;

    class->update(self, particles, now);
}

static void LsgParticleModifier_update_impl(LsgParticleModifier* self, LsgList* particles, float now) {
    LsgClass_abortAbstract((LsgClassInstance*)self, LsgParticleModifier_classID(), "update");
}
