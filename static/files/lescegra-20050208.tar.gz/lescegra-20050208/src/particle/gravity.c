#include <lescegra/particle/gravity.h>

#include <lescegra/particle/particle.h>

#include <stdlib.h>

static void LsgGravity_update(LsgGravity*, LsgList*, float);

static void LsgGravity_staticInit(LsgGravityClass* class, LsgGravity* instance) {
    ((LsgParticleModifierClass*)class)->update = (void (*)(LsgParticleModifier*, LsgList*, float))LsgGravity_update;

    vertex_assign(instance->location, 0.0, 0.0, 0.0);
    instance->mass = 1.0;
    instance->time = 0.0;
}

LsgClassID LsgGravity_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgGravity",
            LsgParticleModifier_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgGravityClass),
            sizeof(LsgGravity),
            (LsgClassStaticInitializer)LsgGravity_staticInit
        );
    }

    return classid;
}

LsgGravity* LsgGravity_create(float now) {
    LsgGravity* self = (LsgGravity*)LsgClass_alloc(LsgGravity_classID());

    if (self)
        LsgGravity_init(self, now);

    return self;
}

void LsgGravity_init(LsgGravity* self, float now) {
    LsgParticleModifier_init(&self->parent);

    self->time = now;
}

static void LsgGravity_update(LsgGravity* self, LsgList* particles, float now) {
    Vertex diff;
    float dist;
    LsgIterator* it;

    it = LsgList_iterator(particles);
    while (LsgIterator_hasNext(it)) {
        LsgParticle* p = LSG_PARTICLE(LsgIterator_next(it));

        vertex_copy(diff, self->location);
        vertex_sub(diff, p->location);

        dist = vertex_length(diff);
        vertex_scale(diff, self->mass / (dist * dist * dist));

        vertex_add(p->speed, diff);
    }
    LsgObject_free((LsgObject*)it);
}
