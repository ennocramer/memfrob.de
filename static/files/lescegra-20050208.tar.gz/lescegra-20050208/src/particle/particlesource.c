#include <lescegra/particle/particlesource.h>

#include <lescegra/util/random.h>

#include <stdlib.h>

static LsgRandom* rng = NULL;

static void LsgParticleSource_update(LsgParticleSource*, LsgList*, float);

static void LsgParticleSource_staticInit(LsgParticleSourceClass* class, LsgParticleSource* instance) {
    ((LsgParticleModifierClass*)class)->update = (void (*)(LsgParticleModifier*, LsgList*, float))LsgParticleSource_update;

    instance->generator = NULL;
    vertex_assign(instance->location, 0.0, 0.0, 0.0);
    vertex_assign(instance->location_error, 0.0, 0.0, 0.0);
    vertex_assign(instance->speed, 0.0, 0.0, 0.0);
    vertex_assign(instance->speed_error, 0.0, 0.0, 0.0);
    instance->birth_rate = 10.0;
    instance->birth_rate_error = 0.0;
    instance->lifetime = 1.0;
    instance->lifetime_error = 0.0;
    instance->time = 0.0;
}

LsgClassID LsgParticleSource_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgParticleSource",
            LsgParticleModifier_classID(),
            LSG_CLASS_FLAG_NONE,
            sizeof(LsgParticleSourceClass),
            sizeof(LsgParticleSource),
            (LsgClassStaticInitializer)LsgParticleSource_staticInit
        );

        rng = LsgRandom_create(0);
    }

    return classid;
}

LsgParticleSource* LsgParticleSource_create(LsgParticleGenerator generator, float now) {
    LsgParticleSource* self = (LsgParticleSource*)LsgClass_alloc(LsgParticleSource_classID());

    if (self)
        LsgParticleSource_init(self, generator, now);

    return self;
}

void LsgParticleSource_init(LsgParticleSource* self, LsgParticleGenerator generator, float now) {
    LsgParticleModifier_init(&self->parent);

    self->generator = generator;
    self->time      = now;
}

static void LsgParticleSource_update(LsgParticleSource* self, LsgList* particles, float now) {
    Vertex error;
    float dt, lifetime, birth;
    int i;

    for (i = 0; i < LsgList_count(particles); ) {
        LsgParticle* p = LSG_PARTICLE(LsgList_get(particles, i));
        lifetime = LsgRandom_randomRange(rng, self->lifetime, self->lifetime_error);
        if ((now - p->birth) > lifetime) {
            LsgObject_free((LsgObject*)LsgList_get(particles, i));
            LsgList_removeByIndex(particles, i);
        } else {
            ++i;
        }
    }

    dt = now - self->time;

    if (self->generator) {
        birth = LsgRandom_randomRange(rng, self->birth_rate, self->birth_rate_error) * dt;
        while (birth > 0.0) {
            LsgParticle* p = self->generator(now);

            vertex_assign(
                error,
                LsgRandom_randomError(rng),
                LsgRandom_randomError(rng),
                LsgRandom_randomError(rng)
            );
            vertex_mul(error, self->location_error);
            vertex_add(p->location, error);

            vertex_assign(
                error,
                LsgRandom_randomError(rng),
                LsgRandom_randomError(rng),
                LsgRandom_randomError(rng)
            );
            vertex_mul(error, self->speed_error);
            vertex_add(p->speed, error);

            LsgList_append(particles, p);
            birth -= 1.0;
        }
    }

    self->time = now;
}
