/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_RAY_H
#define LSG_RAY_H 1

#include <lescegra/sg/node.h>

#include <lescegra/util/random.h>

typedef struct {
    Vertex position;
    float age;
} LsgRay_Element;

typedef struct LsgRay LsgRay;
typedef struct LsgRayClass LsgRayClass;

struct LsgRay {
    LsgNode parent;

    LsgRandom* rng;
    Vertex* camera;

    LsgRay_Element* elements;
    int count;

    Matrix transform;
    Vertex direction;
    float width;
    int sdiv;
    float max_alpha;

    float max_age;
    float time;
};

struct LsgRayClass {
    LsgNodeClass parent;
};

LsgClassID LsgRay_classID(void);

#define IS_LSG_RAY(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgRay_classID())

#define LSG_RAY(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgRay*, LsgRay_classID(), (instance))

#define LSG_RAY_CLASS(class) \
    LSG_CLASS_CAST(LsgRayClass*, LsgRay_classID(), (class))

LsgRay* LsgRay_create(int count);
void LsgRay_init(
    LsgRay* self,
    int count
);

void LsgRay_reset(LsgRay* self, float now);

#endif
