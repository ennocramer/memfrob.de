#include "dtrack.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>

#include <errno.h>
#include <string.h>
#include <stdio.h>

#define LIM_BUF_SIZE    (4 * 1024)
#define LIM_6D_COUNT    (8)
#define LIM_3D_COUNT    (8)

typedef struct {
    unsigned long int frame;
    float timestamp;

    unsigned int count_6d;
    dtrack_body_6d obj_6d[LIM_6D_COUNT];

    unsigned int count_3d;
    dtrack_body_3d obj_3d[LIM_3D_COUNT];
} dtrack_frame;

static dtrack_frame frame;

static char sock_buffer[LIM_BUF_SIZE];
static int sock = -1;

int dtrack_init(unsigned short int port) {
    struct sockaddr_in addr;

    int ret;
    
    addr.sin_family      = AF_INET;
    addr.sin_port        = htons(port);
    addr.sin_addr.s_addr = INADDR_ANY;

    sock = socket(PF_INET, SOCK_DGRAM, 0);
    ret =
        (sock != -1) &&
        (bind(sock, (struct sockaddr*)&addr, sizeof(addr)) != -1);

    return ret;
}

static int dtrack_parse_ascii(const char* buffer, int bsize) {
    static char identifier[6];
    int count;

    while (bsize > 0) {
        if (sscanf(buffer, "%5s %n", identifier, &count) != 1)
            break;
        buffer += count;
        bsize  -= count;

        /* frame counter */
        if (!strcmp(identifier, "fr")) {
            if (sscanf(buffer, "%lu %n", &frame.frame, &count) != 1)
                break;
            buffer += count;
            bsize  -= count;

        /* timestamp */
        } else if (!strcmp(identifier, "ts")) {
            if (sscanf(buffer, "%f %n", &frame.timestamp, &count) != 1)
                break;
            buffer += count;
            bsize  -= count;

        /* 6 dof objects */
        } else if (!strcmp(identifier, "6d")) {
            dtrack_body_6d* elem;
            int i;

            if (sscanf(buffer, "%u %n", &frame.count_6d, &count) != 1)
                break;
            buffer += count;
            bsize  -= count;

            if (frame.count_6d > LIM_6D_COUNT)
                break;

            for (i = 0; i < frame.count_6d; ++i) {
                elem = &frame.obj_6d[i];

                if (
                    sscanf(
                        buffer,
                        "[%lu %f] "
                        "[%f %f %f %f %f %f] "
                        "[%f %f %f %f %f %f %f %f %f] "
                        "%n",
                        &elem->id, &elem->qual,
                        &elem->loc[0], &elem->loc[1], &elem->loc[2],
                        &elem->ang[0], &elem->ang[1], &elem->ang[2],
                        &elem->rot[0], &elem->rot[1], &elem->rot[2],
                        &elem->rot[3], &elem->rot[4], &elem->rot[5],
                        &elem->rot[6], &elem->rot[7], &elem->rot[8],
                        &count
                    ) != 17
                )
                    break;
                buffer += count;
                bsize  -= count;
            }

        /* 3 dof objects */
        } else if (!strcmp(identifier, "3d")) {
            dtrack_body_3d* elem;
            int i;

            if (sscanf(buffer, "%u %n", &frame.count_3d, &count) != 1)
                break;
            buffer += count;
            bsize  -= count;

            if (frame.count_3d > LIM_3D_COUNT)
                break;

            for (i = 0; i < frame.count_3d; ++i) {
                elem = &frame.obj_3d[i];

                if (
                    sscanf(
                        buffer,
                        "[%lu %f] "
                        "[%f %f %f] "
                        "%n",
                        &elem->id, &elem->qual,
                        &elem->loc[0], &elem->loc[1], &elem->loc[2],
                        &count
                    ) != 5
                )
                    break;
                buffer += count;
                bsize  -= count;
            }

        /* everything else */
        } else {
            count = strcspn(buffer, "\0xd\0x0a");
            buffer += count;
            bsize  -= count;
        }
    }

    return bsize == 0 ? 1 : -1;
}

int dtrack_next_frame(int block) {
    ssize_t read;

    read = recvfrom(
        sock,
        sock_buffer, sizeof(sock_buffer) - 1,
        MSG_TRUNC | (block ? 0 : MSG_DONTWAIT),
        NULL, 0
    );

    /* indicate read error */
    if (read == -1) {
        if (errno == EAGAIN)
            return 0;
        else
            return -1;
    }

    /* skip truncated packets */
    if (read >= LIM_BUF_SIZE)
        return -1;

    sock_buffer[read] = 0;
    return dtrack_parse_ascii(sock_buffer, read);
}

unsigned long int dtrack_get_frame(void) {
    return frame.frame;
}

float dtrack_get_timestamp(void) {
    return frame.timestamp;
}

unsigned int dtrack_get_6d_count(void) {
    return frame.count_6d;
}

const dtrack_body_6d* dtrack_get_6d(unsigned int index) {
    if (index < frame.count_6d)
        return &frame.obj_6d[index];

    return 0;
}

const dtrack_body_6d* dtrack_get_6d_by_id(unsigned long int id) {
    int i;

    for (i = 0; i < frame.count_6d; ++i) {
        if (frame.obj_6d[i].id == id)
            return &frame.obj_6d[i];
    }

    return NULL;
}

unsigned int dtrack_get_3d_count(void) {
    return frame.count_3d;
}

const dtrack_body_3d* dtrack_get_3d(unsigned int index) {
    if (index < frame.count_3d)
        return &frame.obj_3d[index];

    return NULL;
}

const dtrack_body_3d* dtrack_get_3d_by_id(unsigned long int id) {
    int i;

    for (i = 0; i < frame.count_3d; ++i) {
        if (frame.obj_3d[i].id == id)
            return &frame.obj_3d[i];
    }

    return NULL;
}

int dtrack_quit() {
    return close(sock) != -1;
}
