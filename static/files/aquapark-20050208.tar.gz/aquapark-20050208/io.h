#ifndef IO_H
#define IO_H 1

#define IO_FULLSCREEN 0x01
#define IO_STEREO     0x02
#define IO_CAVE       0x04

int io_init(int flags);
void io_run(void);
void io_quit(void);

#endif

