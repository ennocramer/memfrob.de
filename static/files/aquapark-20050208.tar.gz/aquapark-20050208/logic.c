#include "logic.h"

#include <lescegra.h>

#include <SDL/SDL.h>
#include <SDL/SDL_thread.h>

#include "dtrack.h"
#include "submarine.h"
#include "scene.h"

static int dtrack = 0;
static int quit   = 0;

static SDL_Thread* thread  = NULL;
static SDL_sem* sem_render = NULL;
static SDL_sem* sem_update = NULL;
static SDL_sem* sem_avail  = NULL;

static LsgVLTME_Mesh* back_mesh = NULL;
static Matrix proj, mview;
static Vertex camera;
static float error_threshold;

static void logic_track_head(void) {
    static Matrix dtrack_transform = {
        1.0/1200.0, 0.0,        0.0,      0.0,
        0.0,        1.0/1200.0, 0.0,      0.0,
        0.0,        0.0,        1.0/1200, 0.0,
        -0.09,      -0.03,      -1.1,     1.0
    };

    const dtrack_body_6d* body;
    int result;

    if ((result = dtrack_next_frame(0)) != 0) {
        /* skip queued packets */
        while (result == 1)
            result = dtrack_next_frame(0);

        /* disable tracking on io error */
        if (result == -1) {
            dtrack = 0;
            return;
        }

        /* track first 6 dof body if available */
        if ((body = dtrack_get_6d(0))) {
            vertex_copy(head, body->loc);
            matrix_apply(dtrack_transform, head);
        }
    }
}

static void logic_track_submarine(float now) {
    submarine_update(now);

    { /* fix scene graph */
        static Vertex up = {0.0, 0.0, 1.0};

        Matrix m;
        Vertex x, y, z;

        vertex_copy(y, submarine_lookat);
        vertex_sub(y, submarine);
        vertex_normalize(y);

        vertex_copy(x, y);
        vertex_cross(x, up);
        vertex_normalize(x);

        vertex_copy(z, x);
        vertex_cross(z, y);

        matrix_load(
            inv_sub_pos->tm,
            x[0], x[1], x[2], 0,
            y[0], y[1], y[2], 0,
            z[0], z[1], z[2], 0,
            0,    0,    0,    1
        );

        matrix_load_translate(m, -submarine[0], -submarine[1], -submarine[2]);

        matrix_mult(inv_sub_pos->tm, m);
    }
}

static void logic_thread_copy_data(void) {
    LsgCamera_load(LSG_CAMERA(pcam), proj, mview);
    matrix_mult(mview, inv_sub_pos->tm);

    vertex_copy(camera, submarine);
    vertex_add(camera, head);

    error_threshold = terrain->error_threshold;
}

static int logic_thread(void* arg) {
    while (!(volatile int)quit) {
        {
            LsgVLTME_MeshParams params;
            LsgFrustum* frust;

            frust = LsgFrustum_create(proj, mview);

            params.eye             = &camera;
            params.frustum         = frust;
            params.error_threshold = error_threshold;

            LsgVLTME_buildMesh(
                back_mesh,
                &params,
                terrain->nodes,
                terrain->levels
            );
        }

        /* signal new update */
        if (SDL_SemValue(sem_avail) == 0)
            SDL_SemPost(sem_avail);

        /* and wait for render thread to come by */
        SDL_SemWait(sem_update);

        {
            LsgVLTME_Mesh* b;

            /* exchange terrain mesh */
            b = terrain->mesh;
            terrain->mesh = back_mesh;
            back_mesh = b;

            /* copy data from main thread */
            logic_thread_copy_data();
        }

        /* tell render thread to continue rendering */
        SDL_SemPost(sem_render);
    }

    return 0;
}

static unsigned long int time_start;

int logic_init(void) {
    /* initialize logic "subsystems" */
    dtrack = dtrack_init(10000);
    submarine_init();

    back_mesh = LsgVLTME_createMesh();

    sem_render = SDL_CreateSemaphore(0);
    sem_update = SDL_CreateSemaphore(0);
    sem_avail  = SDL_CreateSemaphore(1);

    if (sem_render && sem_update && sem_avail)
        thread = SDL_CreateThread(logic_thread, NULL);

    time_start = SDL_GetTicks();

    return (thread != NULL);
}

void logic_update(void) {
    unsigned long int now = SDL_GetTicks() - time_start;

    if (dtrack)
        logic_track_head();

    logic_track_submarine(now * 0.001);

    if (caustics)
        LsgCaustics_update(caustics, now * 0.001);
    LsgNode_update(scene, now * 0.001);
    LsgNode_clean(scene);

    /* check update availability */
    if (SDL_SemTryWait(sem_avail) == 0) {
        /* grant sg access to update thread */
        SDL_SemPost(sem_update);
        /* and wait for update thread to finish */
        SDL_SemWait(sem_render);
    }
}

void logic_quit(void) {
    quit = 1;

    if (thread) {
        SDL_SemPost(sem_update);
        SDL_WaitThread(thread, NULL);
    }

    if (sem_render)
        SDL_DestroySemaphore(sem_render);

    if (sem_update)
        SDL_DestroySemaphore(sem_update);

    if (sem_avail)
        SDL_DestroySemaphore(sem_avail);

    LsgVLTME_freeMesh(back_mesh);

    submarine_quit();
    dtrack_quit();
}
