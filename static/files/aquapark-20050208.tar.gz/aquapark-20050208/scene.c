#include "scene.h"

#include <lescegra.h>

#include "ray.h"

#include <GL/gl.h>

#include <stdlib.h>

Vertex submarine_lookat = { 0.0, 1.0, 80.0 };
Vertex submarine = { 0.0, 0.0, 80.0 };
Vertex head      = { 0.0, 0.0,  0.0 };
Vertex eyes      = { 0.03, 0.0, 0.0 };

LsgNode* scene = NULL;

LsgTransform* inv_sub_pos = NULL;
LsgCaustics* caustics     = NULL;
LsgVLTME* terrain         = NULL;

LsgWindowCam* wcam[2]   = { NULL, NULL };
LsgPerspectiveCam* pcam = NULL;

static Vertex windows[2][3] = {
    {
        { 0.0, 1.0, 0.0 },
        { 2.0, 0.0, 0.0 },
        { 0.0, 0.0, 2.0 }
    },
    {
        { 0.0, 0.0, -1.0 },
        { -2.0, 0.0, 0.0 },
        { 0.0, -2.0, 0.0 }
    }
};

int scene_init(void) {
    LsgGroup* root;
    LsgGroup* inside;
    LsgGroup* outside;
    LsgGroup* world;

    { /* inside submarine */
    }

    { /* outside submarine */
        inv_sub_pos = LsgTransform_create();

        outside = LSG_GROUP(inv_sub_pos);
        root = outside; /* just for now */

        { /* env: fog */
            LsgEnvironment* env = LsgEnvironment_create();
            LsgFog* fog;

            /* fog */
            fog = LsgFog_create(LSG_FOG_LINEAR);
            vertex_assign(fog->color, 0.2, 0.3, 0.3);
            fog->start = 20.0;
            fog->end   = 100.0;

            /* append states */
            LsgList_append(env->states, fog);

            LsgList_append(outside->children, env);

            { /* env: light and caustics */
                LsgEnvironment* env2 = LsgEnvironment_create();
                LsgLight* light;

                /* light */
                light = LsgLight_create(0);
                vertex_assign(light->color, 1.0, 1.0, 1.0);
                vertex_assign(light->location, 1.0, 1.0, 1.0);
                light->location[3] = 0.0;

                /* append states */
                LsgList_append(env2->states, light);

#ifdef GL_ARB_multitexture
                { /* caustics */
                    caustics = LsgCaustics_create(
                        "data/textures/caust%02i.png", 32
                    );
                
                    vertex_assign(caustics->map_s, 0.02, 0.0, 0.0);
                    vertex_assign(caustics->map_t, 0.0, 0.02, 0.0);
                    
                    caustics->speed = 32.0 / 2.0;

                    LsgList_append(env2->states, caustics);
                }
#endif

                LsgList_append(LSG_GROUP(env)->children, env2);

                world = LSG_GROUP(env2);

                { /* terrain with texture */
                    LsgMaterial* mat = LsgMaterial_create();
                    LsgTexture* tex;
                    LsgImage* img;

                    vertex_assign(mat->ambient,  0.3, 0.3, 0.3);
                    vertex_assign(mat->diffuse,  0.8, 0.8, 0.8);
                    vertex_assign(mat->specular, 0.0, 0.0, 0.0);

                    img = LsgImage_load("data/textures/sand.png");

                    if (img) {
                        tex = LsgTexture_create(img, GL_RGB, GL_MODULATE);
                        LsgList_append(mat->textures, tex);
                    }

                    LsgObject_free(LSG_OBJECT(img));
                    
                    LsgList_append(world->children, mat);
                    
                    {
                        Matrix tm, m;
                        LsgImage* img;

                        matrix_load_translate(tm, -500.0, -500.0, 0.0);
                        matrix_load_scale(m, 1000.0, 1000.0, 200.0);
                        matrix_mult(tm, m);

                        img = LsgImage_load("data/terrain.png");
                        
                        if (!img) {
                            fprintf(
                                stderr,
                                "CRITICAL: missing terrain data, aborting\n"
                            );
                            exit(EXIT_FAILURE);
                        }

                        terrain = LsgVLTME_createFromImage(
                            img, tm
                        );

                        terrain->error_threshold = 300.0;
                        LsgList_append(LSG_GROUP(mat)->children, terrain);
                        
                        LsgObject_free(LSG_OBJECT(img));
                    }
                }
            }

            { /* rays */
                LsgRay* rays = LsgRay_create(200);
            
                matrix_load(
                    rays->transform,
                    1000.0,    0.0, 0.0, -500.0,
                       0.0, 1000.0, 0.0, -500.0,
                       0.0,    0.0, 0.0,  350.0,
                       0.0,    0.0, 0.0,    1.0
                );
                vertex_assign(rays->direction, -80.0, -80.0, -350.0);
                rays->width = 5.0;
                rays->sdiv = 10;
                rays->max_alpha = 0.3;

                rays->camera = &submarine;
                
                LsgRay_reset(rays, 0.0);
                
                LsgList_append(LSG_GROUP(env)->children, rays);
            }
        }
    }

    { /* cameras */
        wcam[0] = LsgWindowCam_create();
        LsgWindowCam_setWindow(
            wcam[0],
            windows[0][0], windows[0][1], windows[0][2],
            0.1,
            100.0
        );

        wcam[1] = LsgWindowCam_create();
        LsgWindowCam_setWindow(
            wcam[1],
            windows[1][0], windows[1][1], windows[1][2],
            0.1,
            100.0
        );

        pcam = LsgPerspectiveCam_create();
        vertex_assign(pcam->lookat, 0.0, 1.0, 0.0);
        vertex_assign(pcam->up,     0.0, 0.0, 1.0);
        pcam->fovy   = 90.0;
        pcam->aspect = 1.0;
        pcam->dmin   = 0.1;
        pcam->dmax   = 101.0;
    }

    scene = LSG_NODE(root);
    LsgObject_ref(LSG_OBJECT(scene));

    return 1;
}

void scene_quit(void) {
    LsgObject_free(LSG_OBJECT(pcam));
    LsgObject_free(LSG_OBJECT(wcam[0]));
    LsgObject_free(LSG_OBJECT(wcam[1]));

    if (terrain && IS_LSG_VLTME(terrain))
        free((void*)LSG_VLTME(terrain)->nodes);

    if (scene)
        LsgObject_unref(LSG_OBJECT(scene));
}
