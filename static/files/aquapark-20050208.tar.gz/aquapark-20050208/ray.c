#include "ray.h"

#include <GL/gl.h>

#include <stdlib.h>

static void LsgRay_update(LsgRay* self, float now);
static void LsgRay_display(const LsgRay* self, const LsgFrustum* frust);
static void LsgRay_destroy(LsgRay* self);

static void LsgRay_staticInit(LsgRayClass* class, LsgRay* instance) {
    ((LsgNodeClass*)class)->update  =
        (void (*)(LsgNode*, float))LsgRay_update;
    ((LsgNodeClass*)class)->display =
        (void (*)(const LsgNode*, const LsgFrustum*))LsgRay_display;

    ((LsgObjectClass*)class)->destroy =
        (void (*)(LsgObject*))LsgRay_destroy;

    instance->rng = NULL;
    instance->camera = NULL;
    instance->elements = NULL;
    instance->count = 0;

    matrix_load_identity(instance->transform);
    vertex_assign(instance->direction, 0.0, 0.0, 1.0);
    instance->width = 1.0;
    instance->sdiv = 4;
    instance->max_alpha = 0.4;

    instance->max_age = 1.0;
    instance->time = 0.0;
}

LsgClassID LsgRay_classID(void) {
    static LsgClassID classid = LSG_CLASS_ID_NONE;

    if (classid == LSG_CLASS_ID_NONE) {
        classid = LsgClass_register(
            "LsgRay",
            LsgNode_classID(),
            LSG_CLASS_FLAG_FINAL,
            sizeof(LsgRayClass),
            sizeof(LsgRay),
            (LsgClassStaticInitializer)LsgRay_staticInit
        );
    }

    return classid;
}

LsgRay* LsgRay_create(int count) {
    LsgRay* self = (LsgRay*)LsgClass_alloc(LsgRay_classID());

    if (self)
        LsgRay_init(self, count);

    return self;
}

void LsgRay_init(
    LsgRay* self,
    int count
) {
    int i;

    self->rng = LsgRandom_create(0);
    self->elements = malloc(count * sizeof(LsgRay_Element));
    self->count = count;

    for (i = 0; i < count; ++i)
        self->elements[i].age = 1.0 / 0.0;
}

void LsgRay_reset(LsgRay* self, float now) {
    int i;

    for (i = 0; i < self->count; ++i) {
        LsgRay_Element* elem = self->elements + i;

        elem->age = LsgRandom_randomMax(self->rng, self->max_age);
        vertex_assign(
            elem->position,
            LsgRandom_random(self->rng),
            LsgRandom_random(self->rng),
            LsgRandom_random(self->rng)
        );
        matrix_apply(self->transform, elem->position);
    }

    self->time = now;
}

static void LsgRay_update(LsgRay* self, float now) {
    float dt = now - self->time;
    int i;

    for (i = 0; i < self->count; ++i) {
        LsgRay_Element* elem = self->elements + i;

        elem->age += dt;
        if (elem->age > self->max_age) {
            elem->age = LsgRandom_randomMax(self->rng, dt);
            vertex_assign(
                elem->position,
                LsgRandom_random(self->rng),
                LsgRandom_random(self->rng),
                LsgRandom_random(self->rng)
            );
            matrix_apply(self->transform, elem->position);
        }
    }

    self->time = now;
}

static void LsgRay_display(const LsgRay* self, const LsgFrustum* frust) {
    Vertex dx, v;
    int i, s;

    if (!self->camera)
        return;

    glPushAttrib(
        GL_CURRENT_BIT
        | GL_ENABLE_BIT
        | GL_COLOR_BUFFER_BIT
        | GL_DEPTH_BUFFER_BIT
    );

    glDepthMask(GL_FALSE);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    for (i = 0; i < self->count; ++i) {
        LsgRay_Element* elem = self->elements + i;

        float max_alpha = 2.0 * elem->age / self->max_age - 1.0;
        max_alpha = (1.0 - max_alpha * max_alpha) * self->max_alpha;

        vertex_copy(v, elem->position);
        vertex_sub(v, *self->camera);

        vertex_copy(dx, self->direction);
        vertex_cross(dx, v);
        vertex_scale(dx, self->width / vertex_length(dx) / (float)self->sdiv);

        glBegin(GL_TRIANGLE_STRIP);

        for (s = 0; s <= self->sdiv; ++s) {
            float alpha = 2.0 * (float)s / (float)self->sdiv - 1.0;
            alpha = (1.0 - alpha * alpha) * max_alpha;

            glColor4f(1.0, 1.0, 1.0, alpha);

            vertex_copy(v, dx);
            vertex_scale(v, s);
            vertex_add(v, elem->position);

            glVertex3fv(v);
            vertex_add(v, self->direction);
            glVertex3fv(v);
        }

        glEnd();
    }

    glPopAttrib();
}

static void LsgRay_destroy(LsgRay* self) {
    LsgObjectClass* pclass =
        (LsgObjectClass*)LsgClass_getClass(LsgNode_classID());

    LsgObject_free(LSG_OBJECT(self->rng));
    free(self->elements);

    pclass->destroy(LSG_OBJECT(self));
}

