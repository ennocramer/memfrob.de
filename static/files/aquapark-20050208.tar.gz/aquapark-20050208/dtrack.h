#ifndef DTRACK_H
#define DTRACK_H 1

typedef struct {
    unsigned long int id;
    float qual;
    float loc[3];
    float ang[3];
    float rot[9];
} dtrack_body_6d;

typedef struct {
    unsigned long int id;
    float qual;
    float loc[3];
} dtrack_body_3d;

/* TODO: fix types */
int dtrack_init(unsigned short int port);
int dtrack_next_frame(int block);

unsigned long int dtrack_get_frame(void);
float dtrack_get_timestamp(void);

unsigned int dtrack_get_6d_count(void);
const dtrack_body_6d* dtrack_get_6d(unsigned int index);
const dtrack_body_6d* dtrack_get_6d_by_id(unsigned long int id);

unsigned int dtrack_get_3d_count(void);
const dtrack_body_3d* dtrack_get_3d(unsigned int index);

int dtrack_quit();

#endif
