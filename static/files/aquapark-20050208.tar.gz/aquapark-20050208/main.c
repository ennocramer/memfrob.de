#include "io.h"
#include "logic.h"
#include "scene.h"

#include <stdlib.h>
#include <string.h>

static int opt_flags = 0;
static int opt_help  = 0;

static void main_syntax(const char* prog) {
    fprintf(stderr, "syntax: %s [OPTIONS]\n", prog);
    fprintf(stderr, "  Options: -f  --fullscreen\n");
    fprintf(stderr, "           -s  --stereo    \n");
    fprintf(stderr, "           -c  --cave      \n");
}

static int main_cmdline(int argc, char* argv[]) {
    int error = 0;
    int i = 1;

    while (i < argc) {
        if (!strcmp(argv[i], "-f") || !strcmp(argv[i], "--fullscreen")) {
            opt_flags |= IO_FULLSCREEN;

        } else if (!strcmp(argv[i], "-s") || !strcmp(argv[i], "--stereo")) {
            opt_flags |= IO_STEREO;

        } else if (!strcmp(argv[i], "-c") || !strcmp(argv[i], "--cave")) {
            opt_flags |= IO_CAVE;

        } else if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) {
            opt_help = 1;

        } else {
            error = 1;
            fprintf(stderr, "invalid parameter: %s\n", argv[i]);
        }

        ++i;
    }

    return !error;
}

int main(int argc, char* argv[]) {
    int ok = 1;

    ok = main_cmdline(argc, argv);

    if (!ok || opt_help) {
        main_syntax(argv[0]);
        return ok ? EXIT_SUCCESS : EXIT_FAILURE;
    }
    
    if ((ok = io_init(opt_flags))) {
        if ((ok = scene_init())) {
            if ((ok = logic_init())) {
                io_run();
            }

            logic_quit();
        }

        scene_quit();
    }

    io_quit();

    return ok ? EXIT_SUCCESS : EXIT_FAILURE;
}
