#ifndef LOGIC_H
#define LOGIC_H 1

int logic_init(int);
void logic_update(void);
void logic_quit(void);

#endif
