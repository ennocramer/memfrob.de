#include "submarine.h"

#include <lescegra.h>

#include "scene.h"

#include <math.h>

/* submarine speed in units / second */
#define SUB_SPEED 10.0

/* max turn speed in radian per second */
#define SUB_FLUTTER 0.2

/* submarine elevation over ground */
#define SUB_ELEVATION 20.0

/* distance between path control points in seconds */
#define PATH_RESOLUTION 5.0

static LsgRandom* rng = NULL;
static LsgPath* path  = NULL;

static Vertex position = { 0.0, 0.0, 0.0 };
static Vertex direction = { 1.0, 0.0, 0.0 };

#define IDX_C  4

#define IDX_S  5
#define IDX_E  6
#define IDX_N  7
#define IDX_W  8

#define QTREE_CHILD_L(apex, base) \
    (4*(apex)-7 + ((2*(apex)+(base)+2) & 3))
#define QTREE_CHILD_R(apex, base) \
    (4*(apex)-7 + ((2*(apex)+(base)+3) & 3))

static void submarine_get_height_rec(
    Vertex v,
    const LsgVLTME_Node* nodes,
    unsigned int level,
    unsigned int apex,
    unsigned int base
) {
    const LsgVLTME_Node* node = nodes + apex;
    float dsqr;

    dsqr =
        (v[0] - node->v[0]) * (v[0] - node->v[0]) +
        (v[1] - node->v[1]) * (v[1] - node->v[1]);

    if (dsqr < node->radius * node->radius) {
        if (level == 0) {
            if (v[2] < node->v[2])
                v[2] = node->v[2];
            
        } else {
            submarine_get_height_rec(
                v, nodes, level - 1,
                base, QTREE_CHILD_L(apex, base)
            );
            submarine_get_height_rec(
                v, nodes, level - 1,
                base, QTREE_CHILD_R(apex, base)
            );
        }
    }
}

static void submarine_elevate(Vertex v) {
    v[2] = 0.0;

    submarine_get_height_rec(
        v, terrain->nodes, terrain->levels - 1,
        IDX_C, IDX_S
    );
    submarine_get_height_rec(
        v, terrain->nodes, terrain->levels - 1,
        IDX_C, IDX_E
    );
    submarine_get_height_rec(
        v, terrain->nodes, terrain->levels - 1,
        IDX_C, IDX_N
    );
    submarine_get_height_rec(
        v, terrain->nodes, terrain->levels - 1,
        IDX_C, IDX_W
    );

    v[2] += SUB_ELEVATION;
}

static void submarine_flutter(float time) {
    Matrix m;

    matrix_load_rotate(
        m,
        0.0,
        0.0,
        LsgRandom_randomError(rng) * SUB_FLUTTER * time
    );

    matrix_apply(m, direction);
}

#define dump_vertex(v) (printf("%s = (%.2f, %.2f, %.2f)\n", #v, v[0], v[1], v[2]))

static void submarine_step(float time) {
    Vertex v;

    submarine_flutter(PATH_RESOLUTION);
    vertex_copy(v, direction);
    vertex_scale(v, SUB_SPEED * PATH_RESOLUTION);
    vertex_add(position, v);

    if (fabs(position[0]) > 400.0) {
        direction[0] *= -1.0;
        position[0] -= 2.0 * v[0];
    }

    if (fabs(position[1]) > 400.0) {
        direction[1] *= -1.0;
        position[1] -= 2.0 * v[1];
    }

    submarine_elevate(position);
}

void submarine_init(void) {
    int i;

    rng = LsgRandom_create(0);
    path = LsgPath_create(LSG_PATH_BEZIER);

    for (i = 0; i < 5; ++i) {
        submarine_step(PATH_RESOLUTION);
        LsgPath_addKey(path, position, (i-1) * PATH_RESOLUTION);
    }
}

void submarine_update(float now) {
    while (((LsgPath_Key*)LsgList_get(path->keys, 2))->time < now) {
        LsgPath_Key* key = LsgList_removeByIndex(path->keys, 0);
        LsgPath_Key* last = LsgList_get(path->keys, LsgList_count(path->keys) - 1);

        submarine_step(PATH_RESOLUTION);

        key->time = last->time + PATH_RESOLUTION;
        vertex_copy(key->v, position);

        LsgList_append(path->keys, key);
    }

    LsgPath_interpolate(path, now, submarine);
    LsgPath_interpolate(path, now + 1.0, submarine_lookat);
}

void submarine_quit(void) {
    LsgObject_free(LSG_OBJECT(path));
    LsgObject_free(LSG_OBJECT(rng));
}

