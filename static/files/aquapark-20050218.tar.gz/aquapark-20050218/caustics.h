/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003-2004 by Enno Cramer <uebergeek@web.de>              *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_CAUSTICS_H
#define LSG_CAUSTICS_H 1

#include <lescegra/sg/state.h>

#include <lescegra/util/list.h>

typedef struct LsgCaustics LsgCaustics;
typedef struct LsgCausticsClass LsgCausticsClass;

struct LsgCaustics {
    LsgState parent;

    LsgList* textures;

    float map_s[4];
    float map_t[4];

    int unit;

    float speed;
    int current;
};

struct LsgCausticsClass {
    LsgStateClass parent;
};

LsgClassID LsgCaustics_classID(void);

#define IS_LSG_CAUSTICS(instance) \
    LSG_CLASS_INSTANCE_OF((instance), LsgCaustics_classID())

#define LSG_CAUSTICS(instance) \
    LSG_CLASS_INSTANCE_CAST(LsgCaustics*, LsgCaustics_classID(), (instance))

#define LSG_CAUSTICS_CLASS(class) \
    LSG_CLASS_CAST(LsgCausticsClass*, LsgCaustics_classID(), (class))

LsgCaustics* LsgCaustics_create(const char* format, int count);
void LsgCaustics_init(
    LsgCaustics* self,
    const char* format,
    int count
);

void LsgCaustics_update(LsgCaustics* self, float now);

#endif
