#include <lescegra/sg/hterrain.h>

#include <lescegra/util/bbox.h>

#include <GL/gl.h>

#include <stdlib.h>
#include <float.h>

LsgHTerrain* LsgHTerrain_create(LsgHTerrainData* data, int min_x, int min_z, int max_x, int max_z) {
    LsgHTerrain* self = (LsgHTerrain*)malloc(sizeof(LsgHTerrain));
    
    LsgHTerrain_init(self, data, min_x, min_z, max_x, max_z);
    
    return self;
}

#define ELEMENT(data, x, z) ((data)->elements[(data)->width * (z) + (x)])

void LsgHTerrain_init(LsgHTerrain* self, LsgHTerrainData* data, int min_x, int min_z, int max_x, int max_z) {
    int x, z;
    
    LsgNode_init(&self->super);
    
    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))LsgHTerrain_display;
    ((LsgNode*)self)->collide = (int  (*)(LsgNode*, Vertex, Vertex))LsgHTerrain_collide;
    
    self->data = data;
    self->min_x = min_x;
    self->min_z = min_z;
    self->max_x = max_x;
    self->max_z = max_z;
    
    for (z = self->min_z; z <= self->max_z; ++z) {
        for (x = self->min_x; x <= self->max_x; ++x) {
            LsgBBox_include(((LsgNode*)self)->bbox, ELEMENT(self->data, x, z).v);
        }
    }
}

void LsgHTerrain_display(LsgHTerrain* self, LsgFrustum* frust) {
/* use vertex array functions? */
#if 0
    int x, z;
    
    for (z = self->min_z; z < self->max_z; ++z) {
        glBegin(GL_TRIANGLE_STRIP);
        for (x = self->min_x; x <= self->max_x; ++x) {
            glNormal3fv(ELEMENT(self->data, x, z).n);
            glVertex3fv(ELEMENT(self->data, x, z).v);
            glNormal3fv(ELEMENT(self->data, x, z + 1).n);
            glVertex3fv(ELEMENT(self->data, x, z + 1).v);
        }
        glEnd();
    }
#else
    int x, z;

    glInterleavedArrays(GL_N3F_V3F, 0, self->data->elements);
    for (z = self->min_z; z < self->max_z; ++z) {
        glBegin(GL_TRIANGLE_STRIP);
        for (x = self->min_x; x <= self->max_x; ++x) {
            glArrayElement(z * self->data->width + x);
            glArrayElement((z+1) * self->data->width + x);
        }
        glEnd();
    }
#endif
    
    LsgNode_display(&self->super, frust);
}

#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))

/* the easy way :) */
int LsgHTerrain_collide(LsgHTerrain* self, Vertex v, Vertex nearest) {
    float fx, fz;
    Vertex n, tmp;
    int x, z;
    
    fx = (v[0] - ELEMENT(self->data, self->min_x, self->min_z).v[0])
            / (ELEMENT(self->data, self->max_x, self->min_z).v[0] 
                - ELEMENT(self->data, self->min_x, self->min_z).v[0]);
    fz = (v[2] - ELEMENT(self->data, self->min_x, self->min_z).v[2])
            / (ELEMENT(self->data, self->min_x, self->max_z).v[2] 
                - ELEMENT(self->data, self->min_x, self->min_z).v[2]);
    
    fx = MIN(MAX(fx, 0.0), 1.0);
    fz = MIN(MAX(fz, 0.0), 1.0);
    
    fx *= (float)(self->max_x - self->min_x);
    fz *= (float)(self->max_z - self->min_z);

    x = (int)(fx) + self->min_x;
    z = (int)(fz) + self->min_z;
    
    fx = fx - (float)(int)fx;
    fz = fz - (float)(int)fz;

    vertex_copy(n, ELEMENT(self->data, x, z).v);
    
    if (fx > FLT_EPSILON) {
        vertex_copy(tmp, ELEMENT(self->data, x+1, z).v);
        vertex_sub(tmp, ELEMENT(self->data, x, z).v);
        vertex_scale(tmp, fx);
        vertex_add(n, tmp);
    }
    
    if (fz > FLT_EPSILON) {
        vertex_copy(tmp, ELEMENT(self->data, x, z+1).v);
        vertex_sub(tmp, ELEMENT(self->data, x, z).v);
        vertex_scale(tmp, fz);
        vertex_add(n, tmp);
    }
    
    if (nearest) {
        vertex_copy(nearest, n);
    }
    
    return v[1] <= n[1];
}

/* LsgHTerrainLsgGroup */

LsgHTerrainLsgGroup* LsgHTerrainLsgGroup_create(float min_x, float min_z, float width, float height, int div_x, int div_z) {
    LsgHTerrainLsgGroup* self = (LsgHTerrainLsgGroup*)malloc(sizeof(LsgHTerrainLsgGroup));
    
    LsgHTerrainLsgGroup_init(self, min_x, min_z, width, height, div_x, div_z);
    
    return self;
}

void LsgHTerrainLsgGroup_init(LsgHTerrainLsgGroup* self, float min_x, float min_z, float width, float height, int div_x, int div_z) {
    LsgGroup_init(&self->super);
    
    ((LsgNode*)self)->collide = (int (*)(LsgNode*, Vertex, Vertex))LsgHTerrainLsgGroup_collide;

    self->min_x = min_x;
    self->min_z = min_z;
    self->div_x = div_x;
    self->div_z = div_z;    
    self->width = width;
    self->depth = height;
}

int LsgHTerrainLsgGroup_collide(LsgHTerrainLsgGroup* self, Vertex v, Vertex nearest) {
    LsgNode* node;
    int x, z;
    
    x = (int)((v[0] - self->min_x) * (float)self->div_x / self->width);
    z = (int)((v[2] - self->min_z) * (float)self->div_z / self->depth);
    
    x = MIN(MAX(x, 0), self->div_x - 1);
    z = MIN(MAX(z, 0), self->div_z - 1);
    
    node = (LsgNode*)LsgList_get(self->super.children, z * self->div_x + x);
    return node->collide(node, v, nearest);
}

/* the real constructor */

#define NEXT(val, mod) (((val) + 1) % (mod))
#define PREV(val, mod) (((val) + (mod) - 1) % (mod))

LsgNode* divide_and_conquer(LsgHTerrainData* data, int offs_x, int offs_z, int width, int depth, int div);

LsgNode* LsgHTerrain_createHierarchy(LsgImage* img, int size, Vertex dimension) {
    LsgHTerrainData* data;
    Vertex scale;
    int x, y, z, i;
    int idx_src, idx_dst;
    int width, height;
    float dx, dz;
    
    width = img->width + 1;
    height = img->height + 1;
    
    data = (LsgHTerrainData*)malloc(width * height * sizeof(LsgHTerrainDataElement) + sizeof(LsgHTerrainData));
    data->width = width;
    data->depth = height;
    
    scale[0] = dimension[0] / (float)img->width;
    scale[2] = dimension[2] / (float)img->height;
    for (scale[1] = dimension[1], i = 0; i < img->bpp; ++i) {
        scale[1] /= 256.0;
    }

    idx_src = idx_dst = -1;
    for (z = 0; z < img->height; ++z) {
        for (x = 0; x < img->width; ++x) {
            for (y = 0, i = 0; i < img->bpp; ++i) {
                y <<= 8;
                y += img->data[++idx_src];
            }

            ++idx_dst;
            vertex_assign(data->elements[idx_dst].v, (float)x, (float)y, (float)z);
            vertex_mul(data->elements[idx_dst].v, scale);
        }
        ++idx_dst;
        data->elements[idx_dst].v[0] = (float)x * scale[0];
        data->elements[idx_dst].v[1] = data->elements[idx_dst - width + 1].v[1];
        data->elements[idx_dst].v[2] = (float)z * scale[2];
    }
    for ( x = 0; x < width; ++x) {
        ++idx_dst;
        vertex_copy(data->elements[idx_dst].v, ELEMENT(data, x, 0).v);
        data->elements[idx_dst].v[2] += dimension[2];
    }
    
    /* calculate normals */
    dx = dimension[0] / (float)width;
    dz = dimension[2] / (float)height;
    
    for (z = 0; z < height; ++z) {
        for (x = 0; x < width; ++x) {
            vertex_assign(ELEMENT(data, x, z).n, 
                    -dz * (ELEMENT(data, NEXT(x, width), z).v[1] - ELEMENT(data, PREV(x, width), z).v[1]),
                    dx * dz,
                    -dx * (ELEMENT(data, x, NEXT(z, height)).v[1] - ELEMENT(data, x, PREV(z, height)).v[1]));
            vertex_normalize(data->elements[idx_dst].n);
        }
    }

    return divide_and_conquer(data, 0, 0, width, height, size);
}

LsgNode* divide_and_conquer(LsgHTerrainData* data, int offs_x, int offs_z, int width, int depth, int div) {
    /* width/height are number of vertices; number of triangles are width/height - 1 */
    if (MAX(width, depth) < div * div + 1) {
        return (LsgNode*)LsgHTerrain_create(data, offs_x, offs_z, offs_x + width - 1, offs_z + depth - 1);
    } else {
        LsgGroup* group;
        float min_x, min_z, dist_x, dist_z;
        int div_x, div_z;
        int step_x, step_z, x, z;
        
        /* number of triangles per subnode */
        step_x = (width  - 1) / div;
        step_z = (depth - 1) / div;
        if (step_x < div) step_x = width - 1;
        if (step_z < div) step_z = depth - 1;

        min_x = ELEMENT(data, offs_x, offs_z).v[0];
        min_z = ELEMENT(data, offs_x, offs_z).v[2];
        
        dist_x = ELEMENT(data, offs_x + width - 1, offs_z).v[0] - min_x;
        dist_z = ELEMENT(data, offs_x, offs_z + depth - 1).v[2] - min_z;
        
        div_x = width / step_x;
        div_z = width / step_z;
        
        group = (LsgGroup*)LsgHTerrainLsgGroup_create(min_x, min_z, dist_x, dist_z, div_x, div_z);
        for (z = 0; z < depth - 1; z += step_z) {
            for (x = 0; x < width - 1; x += step_x) {
                LsgList_append(group->children, divide_and_conquer(data,
                        offs_x + x, offs_z + z,
                        MIN(step_x + 1, width - x),
                        MIN(step_z + 1, depth - z),
                        div));
            }
        }
        return (LsgNode*)group;
    }
}
