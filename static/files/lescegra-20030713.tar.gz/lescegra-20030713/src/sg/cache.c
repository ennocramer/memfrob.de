#include <lescegra/sg/cache.h>

#include <GL/gl.h>

#include <stdlib.h>

LsgCache* LsgCache_create(void) {
    LsgCache* self = (LsgCache*)malloc(sizeof(LsgCache));
    
    LsgCache_init(self);
    
    return self;
}

void LsgCache_init(LsgCache* self) {
    LsgGroup_init(&self->super);
    
    ((LsgObject*)self)->destroy = (void (*)(LsgObject*))LsgCache_destroy;
    ((LsgNode*)self)->update    = (void (*)(LsgNode*, float))LsgCache_update;
    ((LsgNode*)self)->display   = (void (*)(LsgNode*, LsgFrustum*))LsgCache_display;
    
    self->list = glGenLists(1);
    self->valid = 0;
}

void LsgCache_update(LsgCache* self, float now) {
    LsgGroup_update(&self->super, now);
    
    if (((LsgNode*)self)->dirty) self->valid = 0;
}

void LsgCache_display(LsgCache* self, LsgFrustum* frustum) {
    if (self->valid) {
        glCallList(self->list);
    } else {
        glNewList(self->list, GL_COMPILE_AND_EXECUTE);
        LsgGroup_display(&self->super, frustum);
        glEndList();
        
        self->valid = 1;
    }
}

void LsgCache_destroy(LsgCache* self) {
    glDeleteLists(self->list, 1);
    
    LsgGroup_destroy(&self->super);
}
