#include <lescegra/sg/transform.h>

#include <GL/gl.h>

#include <stdlib.h>

LsgTransform* LsgTransform_create(void) {
    LsgTransform* self = (LsgTransform*)malloc(sizeof(LsgTransform));
    
    LsgTransform_init(self);
    
    return self;
}

void LsgTransform_init(LsgTransform* self) {
    LsgGroup_init(&self->super);
    
    ((LsgNode*)self)->update  = (void (*)(LsgNode*, float))LsgTransform_update;
    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))LsgTransform_display;
    ((LsgNode*)self)->collide = (int  (*)(LsgNode*, Vertex, Vertex))LsgTransform_collide;
    
    matrix_load_identity(self->tm);
}

void LsgTransform_update(LsgTransform* self, float now) {
    LsgGroup_update(&self->super, now);
    
    if (((LsgNode*)self)->dirty && ((LsgNode*)self)->bbox->valid)
        LsgBBox_transform(((LsgNode*)self)->bbox, self->tm);
}

void LsgTransform_display(LsgTransform* self, LsgFrustum* frust) {
    LsgIterator* it;
    LsgFrustum nfrust;
    Matrix m;
    
    /* transform frustum */
    matrix_copy(m, frust->modelview);
    matrix_mult(m, self->tm);
    LsgFrustum_init(&nfrust, frust->projection, m);
    
    /* transform opengl modelview matrix */
    glPushMatrix();
    glMultMatrixf(self->tm);
    
    it = LsgIterator_create(self->super.children);
    while (LsgIterator_hasNext(it)) {
        LsgNode* child = (LsgNode*)LsgIterator_next(it);
        if (LsgBBox_visible(child->bbox, &nfrust)) child->display(child, &nfrust);
    }
    LsgObject_free((LsgObject*)it);
    
    /* restore opengl modelview matrix */
    glPopMatrix();
    
    /* skip LsgGroup_display; call LsgNode_display with original frustum */
    LsgNode_display(&self->super.super, frust);
}

int  LsgTransform_collide(LsgTransform* self, Vertex v, Vertex nearest) {
    Matrix tm_inv;
    Vertex v_copy;
    int ret;
    
    matrix_copy(tm_inv, self->tm);
    matrix_invert(tm_inv);
    
    vertex_copy(v_copy, v);
    matrix_apply(tm_inv, v_copy);
    
    ret = LsgGroup_collide(&self->super, v_copy, nearest);
    
    if (nearest) {
        matrix_apply(self->tm, nearest);
    }
    
    return ret;
}
