#include <lescegra/sg/material.h>

#include <GL/gl.h>

#include <stdlib.h>

LsgMaterial* LsgMaterial_create(void) {
    LsgMaterial* self = (LsgMaterial*)malloc(sizeof(LsgMaterial));
    
    LsgMaterial_init(self);
    
    return self;
}

void LsgMaterial_init(LsgMaterial* self) {
    LsgGroup_init(&self->super);
    
    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))LsgMaterial_display;
    
    vertex_assign(self->ambient, 0.2, 0.2, 0.2); self->ambient[3] = 1.0;
    vertex_assign(self->diffuse, 0.7, 0.7, 0.7); self->ambient[3] = 1.0;
    vertex_assign(self->specular, 0.3, 0.3, 0.3); self->ambient[3] = 1.0;
    self->shininess = 5.0;
}

void LsgMaterial_display(LsgMaterial* self, LsgFrustum* frustum) {
    glPushAttrib(GL_LIGHTING_BIT);
    
    glMaterialfv(GL_FRONT, GL_AMBIENT, self->ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, self->diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, self->specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, &self->shininess);
    
    LsgGroup_display(&self->super, frustum);
    
    glPopAttrib();
}
