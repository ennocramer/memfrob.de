#include <lescegra/util/bbox.h>

#include <stdlib.h>

LsgBBox* LsgBBox_create(void) {
    LsgBBox* self = (LsgBBox*)malloc(sizeof(LsgBBox));
    
    LsgBBox_init(self);
    
    return self;
}

void LsgBBox_init(LsgBBox* self) {
    LsgObject_init(&self->super);

    LsgBBox_clear(self);
}

void LsgBBox_clear(LsgBBox* self) {
    self->valid = 0;
}

/* NaN test */
#include <assert.h>
int isnan(double);

void LsgBBox_combine(LsgBBox* self, const LsgBBox* box) {
    if (box->valid) {
        assert(!isnan(box->min[0]) && !isnan(box->min[1]) && !isnan(box->min[2])
            && !isnan(box->max[0]) && !isnan(box->max[1]) && !isnan(box->max[2]));
    
        if (self->valid) {
            vertex_min(self->min, box->min);
            vertex_max(self->max, box->max);
        } else {
            vertex_copy(self->min, box->min);
            vertex_copy(self->max, box->max);
            self->valid = 1;
        }
    } else {
        self->valid = 0;
    }
}

void LsgBBox_include(LsgBBox* self, Vertex v) {
    if (self->valid) {
        vertex_min(self->min, v);
        vertex_max(self->max, v);
    } else {
        vertex_copy(self->min, v);
        vertex_copy(self->max, v);
        self->valid = 1;
    }
}

void LsgBBox_transform(LsgBBox* self, Matrix tm) {
    Vertex v[8];
    int i;
    
    /* all 8 corners */    
    vertex_assign(v[0], self->min[0], self->min[1], self->min[2]);
    vertex_assign(v[1], self->min[0], self->min[1], self->max[2]);
    vertex_assign(v[2], self->min[0], self->max[1], self->min[2]);
    vertex_assign(v[3], self->min[0], self->max[1], self->max[2]);
    vertex_assign(v[4], self->max[0], self->min[1], self->min[2]);
    vertex_assign(v[5], self->max[0], self->min[1], self->max[2]);
    vertex_assign(v[6], self->max[0], self->max[1], self->min[2]);
    vertex_assign(v[7], self->max[0], self->max[1], self->max[2]);
    
    /* transform */
    for (i = 0; i < 8; ++i) {
        matrix_apply(tm, v[i]);
    }
    
    /* collapse */
    vertex_copy(self->min, v[0]);
    vertex_copy(self->max, v[0]);
    for (i = 1; i < 8; ++i) {
        vertex_min(self->min, v[i]);
        vertex_max(self->max, v[i]);
    }
}

int LsgBBox_contains(LsgBBox* self, Vertex v) {
    return (v[0] >= self->min[0]) && (v[0] <= self->max[0])
        && (v[1] >= self->min[1]) && (v[1] <= self->max[1])
        && (v[2] >= self->min[2]) && (v[2] <= self->max[2]);
}

int LsgBBox_visible(LsgBBox* self, LsgFrustum* frustum) {
/* transforming the bbox to the frustrum and testing in NDC sometimes 
 * removes visible bboxes */
#if 1
    int p;
    
    if (!self->valid) return 1;
    
    for (p = 0; p < 6; ++p) {
        if (frustum->planes[p].normal[0] * self->min[0] + 
            frustum->planes[p].normal[1] * self->min[1] +
            frustum->planes[p].normal[2] * self->min[2] +
            frustum->planes[p].distance > 0) continue;
        if (frustum->planes[p].normal[0] * self->min[0] + 
            frustum->planes[p].normal[1] * self->min[1] +
            frustum->planes[p].normal[2] * self->max[2] +
            frustum->planes[p].distance > 0) continue;
        if (frustum->planes[p].normal[0] * self->min[0] + 
            frustum->planes[p].normal[1] * self->max[1] +
            frustum->planes[p].normal[2] * self->min[2] +
            frustum->planes[p].distance > 0) continue;
        if (frustum->planes[p].normal[0] * self->min[0] + 
            frustum->planes[p].normal[1] * self->max[1] +
            frustum->planes[p].normal[2] * self->max[2] +
            frustum->planes[p].distance > 0) continue;
        if (frustum->planes[p].normal[0] * self->max[0] + 
            frustum->planes[p].normal[1] * self->min[1] +
            frustum->planes[p].normal[2] * self->min[2] +
            frustum->planes[p].distance > 0) continue;
        if (frustum->planes[p].normal[0] * self->max[0] + 
            frustum->planes[p].normal[1] * self->min[1] +
            frustum->planes[p].normal[2] * self->max[2] +
            frustum->planes[p].distance > 0) continue;
        if (frustum->planes[p].normal[0] * self->max[0] + 
            frustum->planes[p].normal[1] * self->max[1] +
            frustum->planes[p].normal[2] * self->min[2] +
            frustum->planes[p].distance > 0) continue;
        if (frustum->planes[p].normal[0] * self->max[0] + 
            frustum->planes[p].normal[1] * self->max[1] +
            frustum->planes[p].normal[2] * self->max[2] +
            frustum->planes[p].distance > 0) continue;
        
        return 0;
    }
    
    return 1;
#else
    LsgBBox transformed;
    
    if (!self->valid) return 1;
    
    LsgBBox_init(&transformed);
    LsgBBox_combine(&transformed, self);
    LsgBBox_transform(&transformed, frustum->matrix);
    
    return transformed.min[0] <= 1.0
        && transformed.min[1] <= 1.0
        && transformed.min[2] <= 1.0
        && transformed.max[0] >= -1.0
        && transformed.max[1] >= -1.0
        && transformed.max[2] >= -1.0;
#endif
}

void LsgBBox_nearest(LsgBBox* self, Vertex v, Vertex n) {
    vertex_copy(n, v);
    vertex_min(n, self->max);
    vertex_max(n, self->min);
}
