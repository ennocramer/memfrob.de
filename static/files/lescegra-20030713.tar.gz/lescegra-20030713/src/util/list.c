#include <lescegra/util/list.h>

#include <stdlib.h>

LsgListElement* LsgList_element_alloc(void* data) {
    LsgListElement* el;

    el = (LsgListElement*)malloc(sizeof(LsgListElement));
    if (el) {
        el->next = NULL;
        el->value = data;
    }

    return el;
}

LsgList* LsgList_create(void) {
    LsgList* self = (LsgList*)malloc(sizeof(LsgList));

    LsgList_init(self);

    return self;
}

void LsgList_init(LsgList* self) {
    LsgObject_init(&self->super);
    
    ((LsgObject*)self)->destroy = (void (*)(LsgObject*))LsgList_destroy;
    
    self->first = NULL;
}

void LsgList_destroy(LsgList* self) {
    LsgList_empty(self);
}

unsigned int LsgList_count(const LsgList* self) {
    unsigned int count = 0;
    LsgListElement* elem;

    elem = self->first;
    while (elem) {
        ++count;
        elem = elem->next;
    }

    return count;
}

void LsgList_append(LsgList* self, void* data) {
    LsgListElement* el;
    LsgListElement* nel;

    nel = LsgList_element_alloc(data);
    if (nel) {
        if (self->first) {
            el = self->first;
            while (el->next) {
                el = el->next;
            }
            el->next = nel;
        } else {
            self->first = nel;
        }
    }
}

void LsgList_insert(LsgList* self, unsigned int index, void* data) {
    LsgListElement* el;
    LsgListElement* nel;
    unsigned int pos = 1;

    nel = LsgList_element_alloc(data);
    if (nel) {
        if ((pos == 0) || (self->first == NULL)) {
            nel->next = self->first;
            self->first = nel;
        } else {
            el = self->first;
            while (el->next && (pos < index)) {
                ++pos;
                el = el->next;
            }

            nel->next = el->next;
            el->next = nel;
        }
    }
}

void LsgList_remove(LsgList* self, unsigned int index) {
    LsgListElement* el;
    LsgListElement* prev = NULL;
    unsigned int pos = 0;

    el = self->first;
    while (el && (pos < index)) {
        ++pos;
        prev = el;
        el = el->next;
    }

    if (prev) {
        prev->next = el->next;
    } else {
        self->first = el->next;
    }

    free(el);
}

void LsgList_remove_object(LsgList* self, void* data) {
    LsgListElement* el;
    LsgListElement* prev = NULL;

    el = self->first;
    while (el) {
        if (el->value == data) {
            if (prev) {
                prev->next = el->next;
            } else {
                self->first = el->next;
            }
            free(el);
            return;
        }
        prev = el;
        el = el->next;
    }
}

void LsgList_empty(LsgList* self) {
    LsgListElement* el;
    LsgListElement* next_el;

    el = self->first;
    while (el) {
        next_el = el->next;
        free(el);
        el = next_el;
    }
    self->first = NULL;
}

void* LsgList_set(LsgList* self, unsigned int index, void* data) {
    LsgListElement* el;
    unsigned int pos = 0;
    void* old;

    el = self->first;
    while (el && (pos < index)) {
        ++pos;
        el = el->next;
    }

    if (el) {
        old = el->value;
        el->value = data;
        return old;
    } else {
        return NULL;
    }
}

void* LsgList_get(const LsgList* self, unsigned int index) {
    LsgListElement* el;
    unsigned int pos = 0;

    el = self->first;
    while (el && (pos < index)) {
        ++pos;
        el = el->next;
    }

    if (el) {
        return el->value;
    } else {
        return NULL;
    }
}

/* LsgIterator ***********************************************************/

LsgIterator* LsgIterator_create(const LsgList* list) {
    LsgIterator* self = (LsgIterator*)malloc(sizeof(LsgIterator));

    LsgIterator_init(self, list);

    return self;
}

void LsgIterator_init(LsgIterator* self, const LsgList* list) {
    LsgObject_init(&self->super);
    
    self->index = -1;
    self->element = list->first;
}

int LsgIterator_hasNext(const LsgIterator* self) {
    return self->element != NULL;
}

void* LsgIterator_next(LsgIterator* it) {
    void* value;

    if (it->element) {
        value = it->element->value;
        it->element = it->element->next;
        ++(it->index);
        return value;
    } else {
        return NULL;
    }
}

int LsgIterator_index(const LsgIterator* it) {
    return it->index;
}

