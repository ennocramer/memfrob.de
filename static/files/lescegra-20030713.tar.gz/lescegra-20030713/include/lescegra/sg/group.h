/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_GROUP_H
#define LSG_GROUP_H 1

/**
 * \file  group.h
 * \brief Basic grouping node
 */

#include <lescegra/sg/node.h>

#include <lescegra/util/list.h>
#include <lescegra/util/vertex.h>
#include <lescegra/util/frustum.h>

/**
 * \ingroup scene
 * \brief   Basic grouping node
 *
 * The junction base class for the scene graph. Allows grouping of nodes and
 * thereby hierarchical view frustum culling and collision detection.
 */
typedef struct {
    LsgNode super;
    LsgList* children;
} LsgGroup;

/**
 * \relates LsgGroup
 * Allocate and initialize a new LsgGroup.
 * @return A new LsgGroup instance
 */
LsgGroup* LsgGroup_create(void);

/**
 * \relates LsgGroup
 * Constructor method for LsgGroup.
 * @param self          The instance variable
 */
void LsgGroup_init(LsgGroup* self);

/**
 * \relates LsgGroup
 * Clean all children.
 * @param self      The instance variable
 */
void LsgGroup_clean(LsgGroup* self);

/**
 * \relates LsgGroup
 * Update all children.
 * @param self      The instance variable
 * @param now       The current time
 */
void LsgGroup_update(LsgGroup* self, float time);

/**
 * \relates LsgGroup
 * Display all subnodes if they are visible within the current view frustum.
 * @param self      The instance variable
 * @param frustum   The current view frustum
 */
void LsgGroup_display(LsgGroup* self, LsgFrustum* frustum);

/**
 * \relates LsgGroup
 * Check for collision with all children.
 * @param self      The instance variable
 * @param v         Some vertex
 * @param nearest   A buffer to store the nearest vertex to v that would collide
 *                  with any child
 * @return 1 if v collides with at least one child, 0 otherwise
 */
int  LsgGroup_collide(LsgGroup* self, Vertex v, Vertex nearest);

/**
 * \relates LsgGroup
 * Destructor method for LsgGroup.
 * @param self      The instance variable
 */
void LsgGroup_destroy(LsgGroup* self);

#endif
