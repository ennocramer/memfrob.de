/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_HTERRAIN_H
#define LSG_HTERRAIN_H 1

/**
 * \file  hterrain.h
 * \brief Hierarchical subdivided terrain
 */

#include <lescegra/sg/node.h>

#include <lescegra/util/vertex.h>
#include <lescegra/util/image.h>

typedef struct {
    Vertex n;
    Vertex v;
} LsgHTerrainDataElement;

typedef struct {
    int width;
    int depth;
    LsgHTerrainDataElement elements[1];
} LsgHTerrainData;

/**
 * \ingroup geometry
 * \brief   Hierarchical subdivided terrain
 *
 * A hierarchical subdivided terrain node to allow swift rendering of
 * static terrain with up to several million vertices.
 */
typedef struct {
    LsgNode super;
    LsgHTerrainData* data;
    int min_x;
    int min_z;
    int max_x;
    int max_z;
} LsgHTerrain;

LsgHTerrain* LsgHTerrain_create(LsgHTerrainData* data, int min_x, int min_z, int max_x, int max_z);
void LsgHTerrain_init(LsgHTerrain* self, LsgHTerrainData* data, int min_x, int min_z, int max_x, int max_z);
void LsgHTerrain_display(LsgHTerrain* self, LsgFrustum* frust);
int  LsgHTerrain_collide(LsgHTerrain* self, Vertex v, Vertex nearest);

#define LsgHTerrain_clean(self)       LsgNode_clean(&(self)->super)
#define LsgHTerrain_update(self, now) LsgNode_update(&(self)->super, now)
#define LsgHTerrain_destroy(self)     LsgNode_destroy(&(self)->super)

/* LsgHTerrainLsgGroup */

#include <lescegra/sg/group.h>

typedef struct {
    LsgGroup super;
    int div_x;
    int div_z;
    float min_x;
    float min_z;
    float width;
    float depth;
} LsgHTerrainLsgGroup;

LsgHTerrainLsgGroup* LsgHTerrainLsgGroup_create(float min_x, float min_z, float width, float depth, int div_x, int div_z);
void LsgHTerrainLsgGroup_init(LsgHTerrainLsgGroup* self, float min_x, float min_z, float width, float depth, int div_x, int div_z);
int LsgHTerrainLsgGroup_collide(LsgHTerrainLsgGroup* self, Vertex v, Vertex nearest);

#define LsgHTerrainLsgGroup_clean(self)          LsgGroup_clean(&(self)->super)
#define LsgHTerrainLsgGroup_update(self, now)    LsgGroup_update(&(self)->super, now)
#define LsgHTerrainLsgGroup_display(self, frust) LsgGroup_display(&(self)->super, frust)
#define LsgHTerrainLsgGroup_destroy(self)        LsgGroup_destroy(&(self)->super)

/* something else :) */

LsgNode* LsgHTerrain_createHierarchy(LsgImage* img, int size, Vertex dimension);

#endif
