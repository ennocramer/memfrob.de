/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_TRANSFORM_H
#define LSG_TRANSFORM_H 1

/**
 * \file  transform.h
 * \brief Geometry transformation node
 */

#include <lescegra/sg/group.h>

#include <lescegra/util/vertex.h>
#include <lescegra/util/matrix.h>
#include <lescegra/util/frustum.h>

/**
 * \ingroup scene
 * \brief   Geometry transformation node
 *
 * Apply a transformation matrix to all subnodes.
 */
typedef struct {
    LsgGroup super;
    Matrix tm;
} LsgTransform;

/**
 * \relates LsgTransform
 * Allocate and initialize a transformation node.
 * @return a new LsgTransform instance
 */
LsgTransform* LsgTransform_create(void);

/**
 * \relates LsgTransform
 * Constructor method for LsgTransform. Initialize the transformation to identity.
 * @param self      The instance variable
 */
void LsgTransform_init(LsgTransform* self);

/**
 * \relates LsgTransform
 * Update all children and recompute the bounding box.
 * @param self      The instance variable
 * @param now       The current time
 */
void LsgTransform_update(LsgTransform* self, float now);

/**
 * \relates LsgTransform
 * Display all children with a transformed view frustum and changed OpenGL
 * modelview matrix.
 * @param self      The instance variable
 * @param frustum   The view frustum
 */
void LsgTransform_display(LsgTransform* self, LsgFrustum* frustum);

/**
 * \relates LsgTransform
 * Compute collision with transformed children.
 * @param self      The instance variable
 * @param v         Some vertex
 * @param nearest   A buffer to store the nearest vertex to v that would collide
 *                  with any child
 * @return 1 if v after being transformed collides with at least one child,
 *         0 otherwise
 */
int  LsgTransform_collide(LsgTransform* self, Vertex v, Vertex nearest);

/**
 * Clean all children. Reuse parent implementation.
 */
#define LsgTransform_clean(self)       LsgGroup_clean(&(self)->super)

/**
 * Destructor method for LsgTransform. Reuse parent implementation.
 */
#define LsgTransform_destroy(self)     LsgGroup_destroy(&(self)->super)

#endif
