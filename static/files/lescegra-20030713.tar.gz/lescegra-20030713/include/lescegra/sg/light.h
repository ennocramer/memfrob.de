/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_LIGHT_H
#define LSG_LIGHT_H 1

/**
 * \file  light.h
 * \brief Directional or point light source
 */

#include <lescegra/sg/node.h>

#include <lescegra/util/vertex.h>

/**
 * \ingroup scene
 * \brief   Directional or point light source
 *
 * A Light source defining a location and a color.
 */
typedef struct {
    LsgNode super;
    int num;
    float color[4];
    float location[4];
} LsgLight;

LsgLight* LsgLight_create(int num);
void LsgLight_init(LsgLight* self, int num);
void LsgLight_display(LsgLight* self, LsgFrustum* frust);

void LsgLight_enable(LsgLight* self);
void LsgLight_disable(LsgLight* self);

#define LsgLight_update(self, now) LsgNode_update(&(self)->super, now)
#define LsgLight_clean(self)       LsgNode_clean(&(self)->super)
#define LsgLight_destroy(self)     LsgNode_destroy(&(self)->super)

#endif
