/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_NODE_H
#define LSG_NODE_H 1

/**
 * \file  node.h
 * \brief Scene graph hierarchy base class
 */

#include <lescegra/util/object.h>

#include <lescegra/util/vertex.h>
#include <lescegra/util/frustum.h>
#include <lescegra/util/bbox.h>

typedef struct LsgNode LsgNode;

/**
 * \brief Scene graph hierarchy base class
 *
 * Abstract base class for the scene graph class hierarchy.
 */
struct LsgNode {
    LsgObject super;
    LsgBBox* bbox;
    /**
     * Flag to indicate a changed boundig box. Parents should check this flag
     * after calling update and update their own bounding boxes if necessary.
     */
    int dirty;
    /**
     * Mark this node as having any changes processed. Call after running
     * update to ensure later calls to update don't have process to reevaluate
     * unchanged nodes.
     * @param self      The instance variable
     */
    void (*clean)(LsgNode* self);
    /**
     * Update this node to accommodate to passingtime.
     * @param self      The instance variable
     * @param now       The current time
     */
    void (*update)(LsgNode* self, float now);
    /**
     * Display this node.
     * @param self      The instance variable
     * @param frustum   The viewing frustum transformed to the local
     *                  coordinate system
     */
    void (*display)(LsgNode* self, LsgFrustum* frustum);
    /**
     * Check for collision and calculate nearest vertex if asked for.
     * @param self      The instance variable
     * @param v         Some vertex
     * @param nearest   The buffer to store the vertex nearest to v that would
     *                  cause a collision. May be NULL to indicate that the
     *                  computation is not neccessary.
     * @return 1 if the vertex v collides with the node, 0 otherwise
     */
    int  (*collide)(LsgNode* self, Vertex v, Vertex nearest);
};

/**
 * \relates LsgNode
 * Constructor for LsgNode. Initially clear the bounding box and set the dirty flag
 * to make the first call to update recompute the complete bounding box tree.
 * @param self      The instance variable
 */
void LsgNode_init(LsgNode* self);

/**
 * \relates LsgNode
 * Clean the node by unsetting the dirty flag.
 * @param self      The instance variable
 */
void LsgNode_clean(LsgNode* self);

/**
 * \relates LsgNode
 * Update the node. Does nothing at all.
 * @param self      The instance variable
 */
void LsgNode_update(LsgNode* self, float now);

/**
 * \relates LsgNode
 * Display this node. Does nothing at all.
 * @param self      The instance variable
 * @param frustum   The view frustum transformed to the local coordinat system
 */
void LsgNode_display(LsgNode* self, LsgFrustum* frustum);

/**
 * \relates LsgNode
 * Check collision with this node. Delegate collision detection to bounding box
 * if it is valid. Otherwise always return 0. The value of nearest is not defined
 * if the bounding box is not valid.
 * @param self      The instance variable
 * @param v         Some vertex
 * @param nearest   The buffer to store the vertex nearest to v that would
 *                  cause a collision. May be NULL to indicate that the
 *                  computation is not neccessary.
 * @return 0 if bounding box is not valid, otherwise the return value of
 *         bbox_collide with the same vertex.
 */
int  LsgNode_collide(LsgNode* self, Vertex v, Vertex nearest);

/**
 * \relates LsgNode
 * Destructor for LsgNode. Destroy the bounding box.
 * @param self      The instance variable
 */
void LsgNode_destroy(LsgNode* self);

#endif
