/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_CACHE_H
#define LSG_CACHE_H 1

/**
 * \file  cache.h
 * \brief Render cache
 */
 
#include <lescegra/sg/group.h>

/**
 * \brief Render cache
 *
 * Cache sub nodes in an OpenGL list for faster rendering. The dirty flag
 * is used to force an update of the cache.
 */
typedef struct {
    LsgGroup super;
    int list;
    int valid;
} LsgCache;

LsgCache* LsgCache_create(void);
void LsgCache_init(LsgCache* self);
void LsgCache_update(LsgCache* self, float now);
void LsgCache_display(LsgCache* self, LsgFrustum* frustum);
void LsgCache_destroy(LsgCache* self);

#define LsgCache_clean(self) LsgGroup_clean(&(self)->super)

#endif
