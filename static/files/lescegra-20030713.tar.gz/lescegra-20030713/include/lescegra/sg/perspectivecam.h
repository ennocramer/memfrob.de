/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_PERSPECTIVECAM_H
#define LSG_PERSPECTIVECAM_H 1

/**
 * \file  perspectivecam.h
 * \brief Perspective camera with location and lookat
 */

#include <lescegra/sg/camera.h>

#include <lescegra/util/vertex.h>

/**
 * \brief Perspective camera with location and lookat
 *
 * A perspective camera that is defined by the three vertices location, lookat
 * and up, the field-of-view and a minimal and maximal viewing distance.
 */
typedef struct {
    LsgCamera super;
    Vertex location;
    Vertex lookat;
    Vertex up;
    float fovy;
    float aspect;
    float dmin;
    float dmax;
} LsgPerspectiveCam;


/**
 * \relates LsgPerspectiveCam
 * Allocate and initialize a LsgPerspectiveCam.
 * @return A new LsgPerspectiveCam instance
 */
LsgPerspectiveCam* LsgPerspectiveCam_create(void);

/**
 * \relates LsgPerspectiveCam
 * Constructor method for LsgPerspectiveCam. Initialize the camera as looking from
 * {0, 0, -1} to the center of the coordinate system with the second (y) axis
 * being up. The initial field-of-view is 45 degrees in both directions.
 * @param self      The instance variable
 */
void LsgPerspectiveCam_init(LsgPerspectiveCam* self);

/**
 * \relates LsgPerspectiveCam
 * Display a node as seen using this camera.
 * @param self      The instance variable
 * @param frustum   The initial view frustum
 * @param node      The node to display
 */
void LsgPerspectiveCam_display(LsgPerspectiveCam* self, LsgFrustum* frust, LsgNode* node);

/**
 * Destructor method for LsgPerspectiveCam. Reuse parent implementation.
 */
#define LsgPerspectiveCam_destroy(self) LsgCamera_destroy(&(self)->super)

#endif
