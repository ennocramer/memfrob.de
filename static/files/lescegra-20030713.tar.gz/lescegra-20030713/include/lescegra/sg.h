/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#include <lescegra/sg/node.h>
#include <lescegra/sg/group.h>
#include <lescegra/sg/transform.h>
#include <lescegra/sg/material.h>
#include <lescegra/sg/texture.h>
#include <lescegra/sg/cache.h>

#include <lescegra/sg/camera.h>
#include <lescegra/sg/perspectivecam.h>
#include <lescegra/sg/observercam.h>
#include <lescegra/sg/orthocam.h>

#include <lescegra/sg/light.h>
#include <lescegra/sg/fog.h>

#include <lescegra/sg/name.h>

#include <lescegra/sg/gllist.h>
#include <lescegra/sg/coords.h>
#include <lescegra/sg/md2model.h>
#include <lescegra/sg/terrain.h>
#include <lescegra/sg/hterrain.h>

#ifdef USE_DEPRECATED
#include <lescegra/sg/sine_anim.h>
#include <lescegra/sg/interpolator.h>
#endif
