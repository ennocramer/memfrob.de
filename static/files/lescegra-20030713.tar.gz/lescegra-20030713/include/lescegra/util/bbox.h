/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_BBOX_H
#define LSG_BBOX_H 1

/**
 * \file  bbox.h
 * \brief Axis Aligned Bounding Box
 */

#include <lescegra/util/object.h>

#include <lescegra/util/vertex.h>
#include <lescegra/util/matrix.h>
#include <lescegra/util/frustum.h>

/**
 * \brief Axis Aligned Bounding Box
 *
 * An axis aligned bounding box
 */
typedef struct {
    LsgObject super;
    Vertex min;
    Vertex max;
    int valid;
} LsgBBox;

/**
 * \relates LsgBBox
 * Allocate and initialize a bounding box.
 */
LsgBBox* LsgBBox_create(void);

/**
 * \relates LsgBBox
 * Constructor method for LsgBBox.
 * Initially set the bounding box state to invalid.
 * @param self  The instance variable
 */
void LsgBBox_init(LsgBBox* self);

/**
 * \relates LsgBBox
 * Clear the bounding box volume.
 * Set the bounding box state to invalid. Min and max are undefined.
 * @param self  The instance variable
 */
void LsgBBox_clear(LsgBBox* self);

/**
 * \relates LsgBBox
 * Include another bounding box in the bounded volume.
 * @param self  The instance variable
 * @param box   The other bounding box
 */
void LsgBBox_combine(LsgBBox* self, const LsgBBox* box);

/**
 * \relates LsgBBox
 * Add a vertex to the bounded volume.
 * @param self  The instance variable
 * @param v     The vertex to add to the bounded volume
 */
void LsgBBox_include(LsgBBox* self, Vertex v);

/**
 * \relates LsgBBox
 * Transform the bounding box with a matrix.
 * @param self  The instance variable
 * @param tm    The transformation matrix
 */
void LsgBBox_transform(LsgBBox* self, Matrix tm);

/**
 * \relates LsgBBox
 * Check if the bounding box contains a vertex.
 * @param self  The instance variable
 * @param v     The vertex to check
 * @return 1 if the vertex v is contained in the volume bound by self,
 *         0 otherwise
 */
int LsgBBox_contains(LsgBBox* self, Vertex v);

/**
 * \relates LsgBBox
 * Check if any part of the bounding box is inside a given view frustum.
 * @param self      The instance variable
 * @param frustum   The view frustum
 * @return 1 if any part of the volume bound by self intersects with the view
 *         frustum, 0 otherwise
 */
int LsgBBox_visible(LsgBBox* self, LsgFrustum* frustum);

/**
 * \relates LsgBBox
 * Compute the point nearest to a given vertex that is still inside the
 * bounded volume.
 * @param self  The instance variable
 * @param v     Some vertex
 * @param n     The buffer to hold the vertex nearest to v but still inside
 *              the bounded volume
 */
void LsgBBox_nearest(LsgBBox* self, Vertex v, Vertex n);

#endif
