/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

/**
 * \file  coll.h
 * \brief Collision Detection and Visibility Determination
 */

/**
 * \defgroup coll       Collision Detection
 */
 
/**
 * \page collision                      Collision Detection
 *
 * Every node can define an appropriate bounding volume to be used for
 * visibility determination and collision detection. A reference to the bounding
 * volume has to be provided in the \c bvolume member of LsgNode.
 *
 * A node without a bounding volume is considered to have no extent and will be
 * rendered whenever its parent is rendered. A node with an invalid bounding 
 * volume (the valid member of LsgBVolume is not set) is considered to have an
 * unknown extent and thereby forces its parent bounding box to be invalid also.
 * Nodes with invalid bounding volumes are always rendered.
 *
 * \section collision_api               Interface
 *  The bounding volume base class is LsgBVolume. It defines a set of virtual
 *  methods for visibility determination and collision detection.
 *
 * \subsection collision_api_frustum    View Frustum Culling
 * \code
 * int (*visible)(LsgBVolume* self, LsgFrustum* vf);
 * \endcode
 * \param self      The instance variable
 * \param vf        The view frustum in local coordinates
 * \return 0 if the bounding volume is completely outside of the view frustum
 *
 * Check if the bounding volume is visible.
 * 
 * \subsection collision_api_vertex     Vertex Collision
 * \code
 * void (*collideVertex)(LsgBVolume* self, Vertex v, LsgList* hits);
 * \endcode
 * \param self      The instance variable
 * \param v         The vertex
 * \param hits      A list to store eventual collision hits
 *
 * Check if a given vertex collides with the bounding volume.
 * 
 * \subsection collision_api_ray        Ray Collision
 * \code
 * void (*collideRay)(LsgBVolume* self, Vertex from, Vertex direction, LsgList* hits);
 * \endcode
 * \param self      The instance variable
 * \param from      The ray starting point
 * \param direction The ray direction
 * \param hits      A List to store eventual collision hits
 *
 * Check if a given ray collides with the bounding volume.
 * 
 * \subsection collision_api_sphere     Sphere Collision
 * \code
 * void (*collideSphere)(LsgBVolume* self, Vertex center, float radius, LsgList* hits);
 * \endcode
 * \param self      The instance variable
 * \param center    The sphere center
 * \param radius    The sphere radius
 * \param hits      A List to store eventual collision hits
 *
 * Check if a given sphere collides with the bounding volume.
 * 
 * \section collision_gp                General Purpose Bounding Volumes
 * Often, especially for visibility determination, it is not necessary to
 * implement a specific bounding volume for geometry nodes. A generic bounding
 * volume, like a box or sphere, is in many cases already sufficient.
 *
 * Therefore Lescegra provides a set of generic bounding volumes that can be
 * used directly with any geometry.
 *
 * \subsection collision_gp_sphere      Bounding Sphere
 * The class LsgBSphere defines a generic Bounding Sphere specified by its
 * center and radius.
 *
 * \note This class is not implemented yet.
 *
 * \subsection collision_gp_box         Bounding Box
 * The class LsgBBox defines a generic Axis Aligned Bounding Box (AABB)
 * specified by its near lower left corner and far upper right corner.
 *
 * \section collision_custom            Customized Bounding Volumes
 * Sometimes a generic bounding volume is just not sufficient and you have
 * to implement a customized bounding volume for a node class. Reasons may be
 * to provide a more precise collision detection or to adapt to transformations
 * the node applies onto its children. In this case you to pay attention to two
 * additional methods defined by LsgBVolume.
 *
 * \see LsgHTerrain, LsgHTerrainBVolume, LsgGroup, LsgGroupBBox, LsgTransform, LsgTransformBBox
 *
 * \subsection collision_custom_include Merging a Vertex into a Bounding Volume
 * \code
 * void (*include)(LsgBVolume* self, Vertex v);
 * \endcode
 * \param self      The instance variable
 * \param v         The vertex
 *
 * Extend the bounding volume to include a given vertex.
 * 
 * \note This method is only relevant for bounding volumes for nodes that
 * contain children with arbitrary bounding volumes.
 *
 * \subsection collision_custom_merge   Merging Two Bounding Volumes
 * \code
 * void (*merge)(LsgBVolume* self, LsgBVolume* target);
 * \endcode
 * \param self      The instance variable
 * \param target    The target bounding volume
 *
 * Merge the bounding volume into another bounding volume. This is achieved by
 * including a list of vertices that form a convex volume including this
 * bounding volume. 
 */

#include <lescegra/coll/hit.h>
#include <lescegra/coll/frustum.h>
#include <lescegra/coll/octree.h>

#include <lescegra/coll/bvolume.h>

#include <lescegra/coll/bbox.h>
