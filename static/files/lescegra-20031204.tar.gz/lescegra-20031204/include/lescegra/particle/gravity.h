/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_GRAVITY_H
#define LSG_GRAVITY_H 1

/**
 * \file  gravity.h
 * \brief Gravitational force attracting particles
 */

#include <lescegra/particle/particlemodifier.h>

#include <lescegra/util/vertex.h>

/**
 * \ingroup particle
 * \brief   Gravitational force attracting particles
 *
 * Attract particles with gravitational force (a = mass * 1 / dist ^ 2)
 */
typedef struct {
    LsgParticleModifier super;
    Vertex location;
    float mass;
    float time;
} LsgGravity;

LsgGravity* LsgGravity_create(float now);
void LsgGravity_init(LsgGravity* self, float now);
void LsgGravity_update(LsgGravity* self, LsgList* particles, float now);

#define LsgGravity_destroy(self) LsgParticleModifier_destry(&(self)->super)

#endif
