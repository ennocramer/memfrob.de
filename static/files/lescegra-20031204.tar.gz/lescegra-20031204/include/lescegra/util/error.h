/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_ERROR_H
#define LSH_ERROR_H 1

/**
 * \file  error.h
 * \brief Error handling
 */

#include <lescegra/util/object.h>

/**
 * \brief Error Message
 *
 * Encapsulate an error message and the location where it has been reported.
 */
typedef struct {
    LsgObject super;
    char* message;
    char* file;
    char* method;
    int line;
} LsgError;

typedef void (*LsgErrorHandler)(LsgError* error);

/**
 * \relates LsgError
 * Allocate and initialize a new LsgError instance.
 * \note Use the macros \c __FILE__ and \c __LINE__ for \a file and \a line
 * respectively.
 * @param message   The error message
 * @param file      The source file from where the error is reported
 * @param method    The method reporting the error
 * @param line      The line of the source file where the error is reported
 */
LsgError* LsgError_create(const char* message, const char* file, const char* method, int line);

/**
 * \relates LsgError
 * Constructor for LsgError.
 * @param self      The instance variable
 * @param message   The error message
 * @param file      The source file from where the error is reported
 * @param method    The method reporting the error
 * @param line      The line of the source file where the error is reported
 */
void LsgError_init(LsgError* self, const char* message, const char* file, const char* method, int line);

/**
 * \relates LsgError
 * Convert the error message to a simple string.
 * \note The generated string has to be free'd by the caller.
 * @param self      The instance variable
 * @return a newly allocated string containing the complete error message and
 * the location of the error report
 */
char* LsgError_toString(LsgError* self);

/**
 * \relates LsgError
 * Destructor for LsgError.
 * @param self      The instance variable
 */
void LsgError_destroy(LsgError* self);

void LsgError_registerHandler(LsgErrorHandler handler);

/**
 * \relates LsgError
 * Report an error condition.
 * @param file      The source file from where the error is reported
 * @param method    The method reporting the error
 * @param line      The line of the source file where the error is reported
 * @param message   The error message
 */
void LsgError_report(const char* file, const char* method, int line, const char* message);

/**
 * \relates LsgError
 * Report an error condition with a formatted message.
 * @param file      The source file from where the error is reported
 * @param method    The method reporting the error
 * @param line      The line of the source file where the error is reported
 * @param format    The error message template
 */
void LsgError_reportFormat(const char* file, const char* method, int line, const char* format, ...);

void LsgError_abortAbstract(const char* class, const char* method, LsgObject* obj);

#endif
