/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_MESH_H
#define LSG_MESH_H 1

#include <lescegra/sg/node.h>

#include <lescegra/util/types.h>
#include <lescegra/util/vertex.h>
#include <lescegra/coll/octree.h>

typedef struct {
    LsgNode      super;
    LsgTriangle* triangles;
    LsgTexCoord* texCoords;
    LsgColor*    colors;
    Vertex*      normals;
    Vertex*      vertices;
    
    int          triangleCount;
    
    LsgOctree*   octree;
} LsgMesh;

void LsgMesh_init(LsgMesh* self);
void LsgMesh_display(LsgMesh* self, LsgFrustum* frustum);

#define LsgMesh_clean(self)       LsgNode_clean(&(self)->super)
#define LsgMesh_update(self, now) LsgNode_update(&(self)->super, now)
#define LsgMesh_destroy(self)     LsgNode_destroy(&(self)->super)

/******************************************************************************/

#include <lescegra/coll/bbox.h>

typedef struct {
    LsgBBox super;
    LsgMesh* mesh;
} LsgMeshBVolume;

LsgMeshBVolume* LsgMeshBVolume_create(LsgMesh* mesh);
void LsgMeshBVolume_init(LsgMeshBVolume* self, LsgMesh* mesh);
void LsgMeshBVolume_collideVertex(LsgMeshBVolume* self, Vertex v, LsgList* hits);
void LsgMeshBVolume_collideRay(LsgMeshBVolume* self, Vertex from, Vertex dir, LsgList* hits);
void LsgMeshBVolume_collideSphere(LsgMeshBVolume* self, Vertex center, float radius, LsgList* hits);

#define LsgMeshBVolume_visible(self, frustum) LsgBBox_visible(&(self)->super, frustum)
#define LsgMeshBVolume_destroy(self)          LsgBBox_destroy(&(self)->super)

#endif
