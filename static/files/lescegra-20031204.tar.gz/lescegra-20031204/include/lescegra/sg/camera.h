/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_CAMERA_H
#define LSG_CAMERA_H 1

/**
 * \file  camera.h
 * \brief Abstract camera interface
 */

#include <lescegra/util/object.h>

#include <lescegra/coll/frustum.h>
#include <lescegra/sg/node.h>

typedef struct LsgCamera LsgCamera;

/**
 * \brief Abstract camera interface
 */
struct LsgCamera {
    LsgObject super;
    /**
     * Display a node as seen by the camera.
     * @param self      The instance variable
     * @param frust     The initial view frustum
     * @param node      The node to display
     */
    void (*display)(LsgCamera* self, LsgFrustum* frust, LsgNode* node);
};

/**
 * \relates LsgCamera
 * Constructor method for LsgCamera. Does nearly nothing.
 * @param self      The instance variable
 */
void LsgCamera_init(LsgCamera* self);

/**
 * Destructor method for LsgCamera. Reuse parent implementation.
 * @param self      The instance variable
 */
#define LsgCamera_destroy(self)     LsgObject_destroy(&(self)->super)

#endif
