/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_TEXTURE_H
#define LSG_TEXTURE_H 1

/**
 * \file  texture.h
 * \brief Texture properties
 */

#include <lescegra/sg/state.h>

#include <lescegra/util/image.h>

/**
 * \ingroup scene
 * \brief   Texture properties
 *
 * Apply a texture properties to all children.
 */
typedef struct {
    LsgState super;
    unsigned int id;
    unsigned int mode;
    unsigned int unit;
} LsgTexture;

/**
 * \relates LsgTexture
 * Allocate and initialize a texture node.
 * @param data      The texture color data
 * @param type      The texture type
 * @param mode      The texture environment mode
 * @param unit      The texture unit (0 for no multitexturing)
 * @return A new texture node
 */
LsgTexture* LsgTexture_create(LsgImage* data, int type, unsigned int mode, unsigned int unit);

/**
 * \relates LsgTexture
 * Constructor method for LsgTexture. Create a new texture object of a given type
 * with the provided pixel data.
 * @param self      The instance variable
 * @param data      The texture color data
 * @param type      The texture type
 * @param mode      The texture environment mode
 * @param unit      The texture unit (0 for no multitexturing)
 */
void LsgTexture_init(LsgTexture* self, LsgImage* data, int type, unsigned int mode, unsigned int unit);

void LsgTexture_save(LsgTexture* self);
void LsgTexture_apply(LsgTexture* self);
void LsgTexture_restore(LsgTexture* self);

/**
 * \relates LsgTexture
 * Destructor method for LsgTexture. Delete the texture object and the list of 
 * child nodes.
 * @param self      The instance variable
 */
void LsgTexture_destroy(LsgTexture* self);

#endif
