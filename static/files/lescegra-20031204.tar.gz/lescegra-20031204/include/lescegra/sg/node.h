/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_NODE_H
#define LSG_NODE_H 1

/**
 * \file  node.h
 * \brief Scene graph hierarchy base class
 */

#include <lescegra/util/object.h>

#include <lescegra/coll/bvolume.h>
#include <lescegra/coll/frustum.h>

typedef struct LsgNode LsgNode;

/**
 * \brief Scene graph hierarchy base class
 *
 * Abstract base class for the scene graph class hierarchy.
 */
struct LsgNode {
    LsgObject super;
    /**
     * Mark this node as being unchanged. Call after running update to ensure
     * later calls to update don't have to re-process unchanged nodes.
     * @param self      The instance variable
     */
    void (*clean)(LsgNode* self);
    /**
     * Update this node to accommodate to passing time.
     * @param self      The instance variable
     * @param now       The current time
     */
    void (*update)(LsgNode* self, float now);
    /**
     * Display this node.
     * @param self      The instance variable
     * @param frustum   The viewing frustum transformed to the local
     *                  coordinate system
     */
    void (*display)(LsgNode* self, LsgFrustum* frustum);
    /**
     * Bounding Volume for this node.
     */
    LsgBVolume* bvolume;
    /**
     * Flag indicating if the node has been updated
     */
    int updated;
    /**
     * Flag indicating a changed object state that has to propagate up the
     * scene graph structure (e.g. changed bounding volume)
     */
    int dirty;
};

/**
 * \relates LsgNode
 * Constructor for LsgNode. Initially clear the bounding box and set the dirty flag
 * to make the first call to update recompute the complete bounding box tree.
 * @param self      The instance variable
 */
void LsgNode_init(LsgNode* self);

/**
 * \relates LsgNode
 * Clean the node by unsetting the dirty flag.
 * @param self      The instance variable
 */
void LsgNode_clean(LsgNode* self);

/**
 * \relates LsgNode
 * Update the node. Does nothing at all.
 * @param self      The instance variable
 */
void LsgNode_update(LsgNode* self, float now);

/**
 * \relates LsgNode
 * Destructor for LsgNode. Destroy the bounding box.
 * @param self      The instance variable
 */
void LsgNode_destroy(LsgNode* self);

#endif
