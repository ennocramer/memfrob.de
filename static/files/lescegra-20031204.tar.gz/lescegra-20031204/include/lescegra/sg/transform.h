/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_TRANSFORM_H
#define LSG_TRANSFORM_H 1

/**
 * \file  transform.h
 * \brief Geometry transformation node
 */

#include <lescegra/sg/group.h>

#include <lescegra/util/matrix.h>
#include <lescegra/coll/frustum.h>

/**
 * \ingroup scene
 * \brief   Geometry transformation node
 *
 * Apply a transformation matrix to all subnodes.
 */
typedef struct {
    LsgGroup super;
    Matrix tm;
} LsgTransform;

/**
 * \relates LsgTransform
 * Allocate and initialize a transformation node.
 * @return a new LsgTransform instance
 */
LsgTransform* LsgTransform_create(void);

/**
 * \relates LsgTransform
 * Constructor method for LsgTransform. Initialize the transformation to identity.
 * @param self      The instance variable
 */
void LsgTransform_init(LsgTransform* self);

/**
 * \relates LsgTransform
 * Display all children with a transformed view frustum and changed OpenGL
 * modelview matrix.
 * @param self      The instance variable
 * @param frustum   The view frustum
 */
void LsgTransform_display(LsgTransform* self, LsgFrustum* frustum);

/**
 * Update all children. Reuse parent implementation.
 */
#define LsgTransform_update(self, now) LsgGroup_update(&(self)->super, now)

/**
 * Clean all children. Reuse parent implementation.
 */
#define LsgTransform_clean(self)       LsgGroup_clean(&(self)->super)

/**
 * Destructor method for LsgTransform. Reuse parent implementation.
 */
#define LsgTransform_destroy(self)     LsgGroup_destroy(&(self)->super)

/******************************************************************************/

typedef struct {
    LsgGroupBBox super;
} LsgTransformBBox;

LsgTransformBBox* LsgTransformBBox_create(LsgTransform* tfm);
void LsgTransformBBox_init(LsgTransformBBox* self, LsgTransform* tfm);
int LsgTransformBBox_visible(LsgTransformBBox* self, LsgFrustum* vf);
void LsgTransformBBox_collideVertex(LsgTransformBBox* self, Vertex v, LsgList* buffer);
void LsgTransformBBox_collideRay(LsgTransformBBox* self, Vertex from, Vertex dir, LsgList* buffer);
void LsgTransformBBox_collideSphere(LsgTransformBBox* self, Vertex center, float radius, LsgList* buffer);
void LsgTransfromBBox_merge(LsgTransformBBox* self, LsgBVolume* target);

#define LsgTransformBBox_destroy(self)          LsgGroupBBox_destroy(&(self)->super)

#endif
