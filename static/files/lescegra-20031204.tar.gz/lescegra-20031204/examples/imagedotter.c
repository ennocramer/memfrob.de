#include <lescegra.h>

#include <GL/glut.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#ifndef M_PI
# define M_PI		3.14159265358979323846	/* pi */
#endif

#define PICTURE_SIZE 50.0

LsgGroup* scene;
LsgPerspectiveCam* camera;
LsgGLList* picture;

static float cam_rot = M_PI * 0.5;
static float cam_dist = 70.0;

static int mouse_x = 0;
static int mouse_y = 0;

void display(void) {
    LsgFrustum viewfrustum;
    int error;
    
    LsgFrustum_init(&viewfrustum, matrix_identity, matrix_identity);
    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    /* reset viewing matrizes */
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    /* display the scene */
    camera->super.display((LsgCamera*)camera, &viewfrustum, (LsgNode*)scene);

    /* force rendering of cached geometry */
    glFlush();
    glutSwapBuffers();

    if ((error = glGetError()) != GL_NO_ERROR) {
        printf("%s\n", gluErrorString(error));
    }
}

void reshape(int w, int h) {
    float aspect = (float)w / (float)h;

    camera->aspect = aspect;
    glViewport(0, 0, w, h);
}

void animate(int time) {
    float now = (float)time / 1000.0;

    scene->super.update((LsgNode*)scene, now);

    glutTimerFunc(1000 / 25, animate, time + 1000 / 25);
    glutPostRedisplay();
}

void mouse_drag(int x, int y) {
    int dx = x - mouse_x;

    cam_rot += dx * M_PI / 500.0;
    vertex_assign(camera->location, cam_dist * cos(cam_rot), 0.0, cam_dist * sin(cam_rot));

    mouse_x = x;
    mouse_y = y;
}

void mouse_down(int button, int state, int x, int y) {
    mouse_x = x;
    mouse_y = y;
}

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case  27:
        case 'q':
        case 'Q':
            exit(0);
    }
}

void init_video(void) {
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutCreateWindow("lescegra example: picture viewer");

    glClearColor(0.0, 0.0, 0.0, 0.0);
    
    glEnable(GL_BLEND);

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMotionFunc(mouse_drag);
    glutMouseFunc(mouse_down);

    glutTimerFunc(0, animate, 0);

    glutKeyboardFunc(keyboard);
}

void init_scene(const char* file) {
    LsgImage* img;
    int x, y;

    /* create the camera */
    camera = LsgPerspectiveCam_create();
    vertex_assign(camera->location, 0.0, 0.0, cam_dist);
    vertex_assign(camera->lookat,   0.0, 0.0, 0.0);
    vertex_assign(camera->up,       0.0, 1.0, 0.0);
    camera->dmin   =  20.0;
    camera->dmax   = 180.0;
    camera->fovy   =  50.0;
    camera->aspect =   1.0;

    /* create the scene container */
    scene = LsgGroup_create();

    picture = LsgGLList_create();
    img = LsgImage_load(file);
    
    if (!img) {
        LsgError_report(__FILE__, "init_scene", __LINE__, "no image loaded");
        exit(1);
    }

    glNewList(picture->list, GL_COMPILE);
    glBegin(GL_POINTS);
    for (y = 0; y < img->height; ++y) {
        for (x = 0; x < img->width; ++x) {
            int idx = (y * img->width + x) * img->bpp;
            if (img->bpp == 4)
                glColor4ubv(img->data + idx);
            else
                glColor3ubv(img->data + idx);
            glVertex3f((float)x / (float)img->width * PICTURE_SIZE - 0.5 * PICTURE_SIZE, (float)-y / (float)img->height * PICTURE_SIZE + 0.5 * PICTURE_SIZE, 0.0);
        }
    }
    glEnd();
    glEndList();
    
    LsgList_append(scene->children, picture);
    LsgList_append(scene->children, LsgCoords_create(20.0));
    free(img);
}

int main(int argc, char* argv[]) {
    if ((argc < 2) || (argc > 3) || !strcmp("--help", argv[1]) || !strcmp("-h", argv[1])) {
        fprintf(stderr, "usage: %s <model> [<texture>]\n\n", argv[0]);
        fprintf(stderr, "control:\n");
        fprintf(stderr, "  w     - toggle wireframe mode\n");
        fprintf(stderr, "  q     - exit\n");
        return 1;
    }

    glutInit(&argc, argv);

    init_video();
    init_scene(argv[1]);

    glutMainLoop();

    return 0;
}
