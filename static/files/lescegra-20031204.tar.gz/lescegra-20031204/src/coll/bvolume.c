#include <lescegra/coll/bvolume.h>

#include <lescegra/util/error.h>

#include <stdlib.h>
#include <stdio.h>

static int  LsgBVolume_visible(LsgBVolume* self, LsgFrustum* frustum);
static void LsgBVolume_collideVertex(LsgBVolume* self, Vertex v, LsgList* b);
static void LsgBVolume_collideRay(LsgBVolume* self, Vertex v, Vertex d, LsgList* b);
static void LsgBVolume_collideSphere(LsgBVolume* self, Vertex c, float r, LsgList* b);
static void LsgBVolume_include(LsgBVolume* self, Vertex v);
static void LsgBVolume_merge(LsgBVolume* self, LsgBVolume* target);

void LsgBVolume_init(LsgBVolume* self) {
    LsgObject_init(&self->super);
    
    self->visible       = LsgBVolume_visible;
    self->collideVertex = LsgBVolume_collideVertex;
    self->collideRay    = LsgBVolume_collideRay;
    self->collideSphere = LsgBVolume_collideSphere;
    self->include       = LsgBVolume_include;
    self->merge         = LsgBVolume_merge;
    self->reset         = LsgBVolume_reset;
    self->valid         = 0;
}

void LsgBVolume_reset(LsgBVolume* self) {
    self->valid = 0;
}

static int LsgBVolume_visible(LsgBVolume* self, LsgFrustum* frustum) {
    LsgError_abortAbstract("LsgBVolume", "visible", (LsgObject*)self);
    return 0;
}

static void LsgBVolume_collideVertex(LsgBVolume* self, Vertex v, LsgList* b) {
    LsgError_abortAbstract("LsgBVolume", "collideVertex", (LsgObject*)self);
}

static void LsgBVolume_collideRay(LsgBVolume* self, Vertex v, Vertex d, LsgList* b) {
    LsgError_abortAbstract("LsgBVolume", "collideRay", (LsgObject*)self);
}

static void LsgBVolume_collideSphere(LsgBVolume* self, Vertex c, float r, LsgList* b) {
    LsgError_abortAbstract("LsgBVolume", "collideSphere", (LsgObject*)self);
}

static void LsgBVolume_include(LsgBVolume* self, Vertex v) {
    LsgError_abortAbstract("LsgBVolume", "include", (LsgObject*)self);
}

static void LsgBVolume_merge(LsgBVolume* self, LsgBVolume* target) {
    LsgError_abortAbstract("LsgBVolume", "merge", (LsgObject*)self);
}
