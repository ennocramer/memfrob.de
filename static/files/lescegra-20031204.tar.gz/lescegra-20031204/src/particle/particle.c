#include <lescegra/particle/particle.h>

#include <GL/gl.h>

#include <stdlib.h>

void LsgParticle_init(LsgParticle* self, Vertex location, Vertex speed, float now) {
    LsgNode_init(&self->super);
    
    ((LsgNode*)self)->update = (void (*)(LsgNode*, float))LsgParticle_update;
    
    self->birth = now;
    self->time = now;
    vertex_copy(self->location, location);
    vertex_copy(self->speed, speed);
}

void LsgParticle_update(LsgParticle* self, float now) {
    Vertex move;
    
    vertex_copy(move, self->speed);
    vertex_scale(move, now - self->time);
    vertex_add(self->location, move);
    
    self->time = now;
    
    LsgNode_update(&self->super, now);
}
