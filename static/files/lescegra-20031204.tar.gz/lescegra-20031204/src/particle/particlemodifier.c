#include <lescegra/particle/particlemodifier.h>

#include <lescegra/util/error.h>

#include <stdlib.h>

static void LsgParticleModifier_update(LsgParticleModifier* self, LsgList* particles, float now);

void LsgParticleModifier_init(LsgParticleModifier* self) {
    LsgObject_init(&self->super);
    
    self->update = LsgParticleModifier_update;
}

static void LsgParticleModifier_update(LsgParticleModifier* self, LsgList* particles, float now) {
    LsgError_abortAbstract("LsgParticleModifier", "update", (LsgObject*)self);
}
