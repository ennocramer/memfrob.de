#include <lescegra/sg/node.h>

#include <lescegra/util/error.h>

#include <stddef.h>

static void LsgNode_display(LsgNode* self, LsgFrustum* frustum);

void LsgNode_init(LsgNode* self) {
    LsgObject_init(&self->super);
    
    self->super.destroy = (void (*)(LsgObject*))LsgNode_destroy;
    
    self->clean   = LsgNode_clean;
    self->update  = LsgNode_update;
    self->display = LsgNode_display;
    
    self->bvolume = NULL;
    self->updated = 0;
    self->dirty   = 1;
}

void LsgNode_clean(LsgNode* self) {
    self->updated = 0;
    self->dirty   = 0;
}

void LsgNode_update(LsgNode* self, float now) {
    self->updated = 1;
    /* don't change the dirty flag by default */
    /* self->dirty   = 1; */
}

static void LsgNode_display(LsgNode* self, LsgFrustum* frustum) {
    LsgError_abortAbstract("LsgNode", "display", (LsgObject*)self);
}

void LsgNode_destroy(LsgNode* self) {
    if (self->bvolume) LsgObject_free((LsgObject*)self->bvolume);
    
    LsgObject_destroy(&self->super);
}
