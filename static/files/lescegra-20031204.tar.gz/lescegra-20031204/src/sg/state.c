#include <lescegra/sg/state.h>

#include <lescegra/util/error.h>

static void LsgState_save(LsgState* self);
static void LsgState_apply(LsgState* self);
static void LsgState_restore(LsgState* self);

void LsgState_init(LsgState* self) {
    LsgObject_init(&self->super);
    
    self->save    = LsgState_save;
    self->apply   = LsgState_apply;
    self->restore = LsgState_restore;
}

static void LsgState_save(LsgState* self) {
    LsgError_abortAbstract("LsgState", "save", (LsgObject*)self);
}

static void LsgState_apply(LsgState* self) {
    LsgError_abortAbstract("LsgState", "apply", (LsgObject*)self);
}

static void LsgState_restore(LsgState* self) {
    LsgError_abortAbstract("LsgState", "restore", (LsgObject*)self);
}
