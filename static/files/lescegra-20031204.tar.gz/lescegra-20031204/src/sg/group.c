#include <lescegra/sg/group.h>

#include <lescegra/util/linkedlist.h>

#include <stdlib.h>
#include <float.h>

LsgGroup* LsgGroup_create(void) {
    LsgGroup* self = (LsgGroup*)malloc(sizeof(LsgGroup));

    LsgGroup_init(self);

    return self;
}

void LsgGroup_init(LsgGroup* self) {
    LsgGroup_initWithBounds(self, (LsgBVolume*)LsgGroupBBox_create(self));
}

void LsgGroup_initWithBounds(LsgGroup* self, LsgBVolume* bvolume) {
    LsgNode_init(&self->super);

    ((LsgObject*)self)->destroy = (void (*)(LsgObject*))LsgGroup_destroy;

    ((LsgNode*)self)->clean   = (void (*)(LsgNode*))LsgGroup_clean;
    ((LsgNode*)self)->update  = (void (*)(LsgNode*, float))LsgGroup_update;
    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))LsgGroup_display;

    ((LsgNode*)self)->bvolume = bvolume;
    self->children = (LsgList*)LsgLinkedList_create();
}

void LsgGroup_clean(LsgGroup* self) {
    LsgIterator* it;

    /* clean child nodes */
    it = self->children->iterator(self->children);
    while (it->hasNext(it)) {
        LsgNode* child = (LsgNode*)it->next(it);
        if (child->updated || child->dirty) child->clean(child);
    }
    LsgObject_free((LsgObject*)it);

    LsgNode_clean(&self->super);
}

void LsgGroup_update(LsgGroup* self, float now) {
    LsgIterator* it;

    /* update child nodes */
    it = self->children->iterator(self->children);
    while (it->hasNext(it)) {
        LsgNode* child = (LsgNode*)it->next(it);
        if (!child->updated) child->update(child, now);

        /* propagate dirty flag */
        self->super.dirty = self->super.dirty || child->dirty;
    }
    LsgObject_free((LsgObject*)it);

    /* update group bounding volume */
    if (self->super.dirty) {
        self->super.bvolume->reset(self->super.bvolume);

        if (self->children->count(self->children) > 0) {
            it = self->children->iterator(self->children);
            do {
                LsgNode* child = (LsgNode*)it->next(it);
                if (child->bvolume) {
                    if (child->bvolume->valid) child->bvolume->merge(child->bvolume, self->super.bvolume);
                } else {
                    self->super.bvolume->valid = 0;
                }
            } while (self->super.bvolume->valid && it->hasNext(it));
            LsgObject_free((LsgObject*)it);
        }
    }

    LsgNode_update(&self->super, now);
}

void LsgGroup_display(LsgGroup* self, LsgFrustum* frust) {
    LsgIterator* it = self->children->iterator(self->children);
    while (it->hasNext(it)) {
        LsgNode* child = (LsgNode*)it->next(it);
        if (!child->bvolume ||
            !child->bvolume->valid ||
            child->bvolume->visible(child->bvolume, frust)) child->display(child, frust);
    }
    LsgObject_free((LsgObject*)it);
}

void LsgGroup_destroy(LsgGroup* self) {
    LsgObject_free((LsgObject*)self->children);

    LsgNode_destroy(&self->super);
}

/******************************************************************************/

LsgGroupBBox* LsgGroupBBox_create(LsgGroup* group) {
    LsgGroupBBox* self = (LsgGroupBBox*)malloc(sizeof(LsgGroupBBox));
    
    LsgGroupBBox_init(self, group);
    
    return self;
}

void LsgGroupBBox_init(LsgGroupBBox* self, LsgGroup* group) {
    LsgBBox_init(&self->super);
    
    ((LsgBVolume*)self)->collideVertex = (void (*)(LsgBVolume*, Vertex, LsgList*))LsgGroupBBox_collideVertex;
    ((LsgBVolume*)self)->collideRay    = (void (*)(LsgBVolume*, Vertex, Vertex, LsgList*))LsgGroupBBox_collideRay;
    ((LsgBVolume*)self)->collideSphere = (void (*)(LsgBVolume*, Vertex, float, LsgList*))LsgGroupBBox_collideSphere;
    
    self->group = group;
}

void LsgGroupBBox_collideVertex(LsgGroupBBox* self, Vertex v, LsgList* buffer) {
    LsgIterator* it;
    
    if ((v[0] >= ((LsgBBox*)self)->min[0]) && (v[0] <= ((LsgBBox*)self)->max[0])
    &&  (v[1] >= ((LsgBBox*)self)->min[1]) && (v[1] <= ((LsgBBox*)self)->max[1])
    &&  (v[2] >= ((LsgBBox*)self)->min[2]) && (v[2] <= ((LsgBBox*)self)->max[2])) {
        it = self->group->children->iterator(self->group->children);
        while (it->hasNext(it)) {
            LsgNode* child = (LsgNode*)it->next(it);
            if (child->bvolume) child->bvolume->collideVertex(child->bvolume, v, buffer);
        }
        LsgObject_free((LsgObject*)it);
    }
}

void LsgGroupBBox_collideRay(LsgGroupBBox* self, Vertex from, Vertex dir, LsgList* buffer) {
    LsgIterator* it;
    Vertex v;
    float lambda, normal;
    int i, d, nd, nnd;
   
    for (i = 0; i < 6; ++i) {
        d   = (i + 0) % 3;
        nd  = (i + 1) % 3;
        nnd = (i + 2) % 3;

        if (i < 3) {
            lambda = (((LsgBBox*)self)->min[d] - from[d]) / dir[d];
            normal = -1.0;
        } else {
            lambda = (((LsgBBox*)self)->max[d] - from[d]) / dir[d];
            normal = 1.0;
        }            
        
        /* plane behind from or not facing towards from */
        if ((lambda < 0.0) || ((normal * dir[d]) >= 0.0)) continue;
        
        vertex_copy(v, dir);
        vertex_scale(v, lambda);
        vertex_add(v, from);

        /* intersection point not on bbox surface */
        if ((v[nd]  < ((LsgBBox*)self)->min[nd])  || (v[nd]  > ((LsgBBox*)self)->max[nd]) ||
            (v[nnd] < ((LsgBBox*)self)->min[nnd]) || (v[nnd] > ((LsgBBox*)self)->max[nnd])) continue;
        
        it = self->group->children->iterator(self->group->children);
        while (it->hasNext(it)) {
            LsgNode* child = (LsgNode*)it->next(it);
            if (child->bvolume) child->bvolume->collideRay(child->bvolume, from, dir, buffer);
        }
        LsgObject_free((LsgObject*)it);
        
        return;
    }
}

void LsgGroupBBox_collideSphere(LsgGroupBBox* self, Vertex center, float radius, LsgList* buffer) {
    LsgIterator* it;
    int accept;
    
    /* trivial reject (distance to any plane larger than radius) */
    if ((center[0] - ((LsgBBox*)self)->max[0] > radius)
    ||  (center[1] - ((LsgBBox*)self)->max[1] > radius)
    ||  (center[2] - ((LsgBBox*)self)->max[2] > radius)
    ||  (((LsgBBox*)self)->min[0] - center[0] > radius)
    ||  (((LsgBBox*)self)->min[1] - center[1] > radius)
    ||  (((LsgBBox*)self)->min[2] - center[2] > radius)) return;
    
    /* trivial accept (center in octree range) */
    accept = (center[0] >= ((LsgBBox*)self)->min[0]) && (center[0] <= ((LsgBBox*)self)->max[0]) &&
             (center[1] >= ((LsgBBox*)self)->min[1]) && (center[1] <= ((LsgBBox*)self)->max[1]) &&
             (center[2] >= ((LsgBBox*)self)->min[2]) && (center[2] <= ((LsgBBox*)self)->max[2]);
    
    /* check real distance (skip if trivial accept succeeded) */
    if (!accept) {
        Vertex n;
        
        /* calculate nearest point on octree boundaries */
        vertex_copy(n, center);
        vertex_min(n, ((LsgBBox*)self)->max);
        vertex_max(n, ((LsgBBox*)self)->min);
        
        /* calculate distance between octree boundary and sphere center */
        vertex_sub(n, center);
        if (vertex_length(n) > radius) return;
    }
    
    it = self->group->children->iterator(self->group->children);
    while (it->hasNext(it)) {
        LsgNode* child = (LsgNode*)it->next(it);
        if (child->bvolume) child->bvolume->collideSphere(child->bvolume, center, radius, buffer);
    }
    LsgObject_free((LsgObject*)it);
}
