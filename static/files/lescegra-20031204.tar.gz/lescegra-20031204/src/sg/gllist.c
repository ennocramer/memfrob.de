#include <lescegra/sg/gllist.h>

#include <GL/gl.h>

#include <stdlib.h>
#include <math.h>

LsgGLList* LsgGLList_create(void) {
    LsgGLList* self = (LsgGLList*)malloc(sizeof(LsgGLList));
    
    LsgGLList_init(self);

    return self;
}

void LsgGLList_init(LsgGLList* self) {
    LsgNode_init(&self->super);
    
    ((LsgObject*)self)->destroy = (void (*)(LsgObject*))LsgGLList_destroy;
    
    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))LsgGLList_display;
    
    self->list = glGenLists(1);
}

void LsgGLList_display(LsgGLList* self, LsgFrustum* frust) {
    glCallList(self->list);
}

void LsgGLList_destroy(LsgGLList* self) {
    glDeleteLists(self->list, 1);
    
    LsgNode_destroy(&self->super);
}
