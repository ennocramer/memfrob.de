#include <lescegra/sg/material.h>

#include <lescegra/util/vertex.h>

#include <GL/gl.h>

#include <stdlib.h>

LsgMaterial* LsgMaterial_create(void) {
    LsgMaterial* self = (LsgMaterial*)malloc(sizeof(LsgMaterial));
    
    LsgMaterial_init(self);
    
    return self;
}

void LsgMaterial_init(LsgMaterial* self) {
    LsgState_init(&self->super);
    
    ((LsgState*)self)->save    = (void (*)(LsgState*))LsgMaterial_save;
    ((LsgState*)self)->apply   = (void (*)(LsgState*))LsgMaterial_apply;
    ((LsgState*)self)->restore = (void (*)(LsgState*))LsgMaterial_restore;
    
    vertex_assign(self->ambient, 0.2, 0.2, 0.2); self->ambient[3] = 1.0;
    vertex_assign(self->diffuse, 0.7, 0.7, 0.7); self->ambient[3] = 1.0;
    vertex_assign(self->specular, 0.3, 0.3, 0.3); self->ambient[3] = 1.0;
    self->shininess = 5.0;
}

void LsgMaterial_save(LsgMaterial* self) {
    glPushAttrib(GL_LIGHTING_BIT);
}

void LsgMaterial_apply(LsgMaterial* self) {
    glMaterialfv(GL_FRONT, GL_AMBIENT, self->ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, self->diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, self->specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, &self->shininess);
}

void LsgMaterial_restore(LsgMaterial* self) {
    glPopAttrib();
}
