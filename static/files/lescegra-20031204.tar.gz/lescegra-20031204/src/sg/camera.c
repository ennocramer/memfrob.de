#include <lescegra/sg/camera.h>

#include <lescegra/util/error.h>

#include <stdlib.h>

static void LsgCamera_display(LsgCamera* self, LsgFrustum* frustum, LsgNode* node);

void LsgCamera_init(LsgCamera* self) {
    LsgObject_init(&self->super);
    
    self->display = LsgCamera_display;
}

static void LsgCamera_display(LsgCamera* self, LsgFrustum* frustum, LsgNode* node) {
    LsgError_abortAbstract("LsgCamera", "display", (LsgObject*)self);
}
