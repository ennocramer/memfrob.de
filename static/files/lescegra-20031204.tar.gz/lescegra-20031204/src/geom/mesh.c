#include <lescegra/geom/mesh.h>

#include <GL/gl.h>

#include <stdlib.h>

void LsgMesh_init(LsgMesh* self) {
    LsgNode_init(&self->super);
    
    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))LsgMesh_display;
    
    self->triangles     = NULL;
    self->texCoords     = NULL;
    self->colors        = NULL;
    self->normals       = NULL;
    self->vertices      = NULL;

    self->triangleCount = 0;
    
    self->octree        = NULL;
}

void LsgMesh_display(LsgMesh* self, LsgFrustum* frustum) {
    /* this should really be assert(...) */
    if (!(self->triangleCount && self->triangles && self->vertices)) return;
    
    glPushClientAttrib(GL_CLIENT_VERTEX_ARRAY_BIT);
    
    if (self->normals) {
        glEnableClientState(GL_NORMAL_ARRAY);
        glNormalPointer(GL_FLOAT, 0, self->normals);
    } else {
        glDisableClientState(GL_NORMAL_ARRAY);
    }
    
    if (self->colors) {
        glEnableClientState(GL_COLOR_ARRAY);
        glColorPointer(4, GL_FLOAT, 0, self->colors);
    } else {
        glDisableClientState(GL_COLOR_ARRAY);
    }
    
    if (self->texCoords) {
        glEnableClientState(GL_TEXTURE_COORD_ARRAY);
        glTexCoordPointer(2, GL_FLOAT, 0, self->texCoords);
    } else {
        glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    }
    
    glEnable(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0, self->vertices);

    glDrawElements(GL_TRIANGLES, self->triangleCount * 3, GL_UNSIGNED_INT, self->triangles);
    
    glPopClientAttrib();    
}

/******************************************************************************/

#include <lescegra/util/arraylist.h>

#include <math.h>
#ifndef M_PI
#define M_PI		3.14159265358979323846
#endif

LsgMeshBVolume* LsgMeshBVolume_create(LsgMesh* mesh) {
    LsgMeshBVolume* self = (LsgMeshBVolume*)malloc(sizeof(LsgMeshBVolume));
    
    LsgMeshBVolume_init(self, mesh);
    
    return self;
}

void LsgMeshBVolume_init(LsgMeshBVolume* self, LsgMesh* mesh) {
    LsgBBox_init(&(self)->super);
    
    ((LsgBVolume*)self)->collideVertex = (void (*)(LsgBVolume*, Vertex, LsgList*))LsgMeshBVolume_collideVertex;
    ((LsgBVolume*)self)->collideRay    = (void (*)(LsgBVolume*, Vertex, Vertex, LsgList*))LsgMeshBVolume_collideRay;
    ((LsgBVolume*)self)->collideSphere = (void (*)(LsgBVolume*, Vertex, float, LsgList*))LsgMeshBVolume_collideSphere;
    
    self->mesh = mesh;
}

void LsgMeshBVolume_collideVertex(LsgMeshBVolume* self, Vertex v, LsgList* hits) {
    if (!(self->mesh->octree && self->mesh->triangleCount && self->mesh->triangles && self->mesh->vertices))
        LsgBBox_collideVertex(&self->super, v, hits);
}

static LsgHit* LsgMeshBVolume_collideRayTriangle(const Vertex v1, const Vertex v2, const Vertex v3, const Vertex from, const Vertex direction) {
    LsgHit* hit;
    Vertex edge[3];
    Vertex p[3];
    Vertex intersection, n;
    float d;

    /* build triangle edge vectors */
    vertex_copy(edge[0], v2);
    vertex_sub(edge[0], v1);
    vertex_normalize(edge[0]);
    vertex_copy(edge[1], v3);
    vertex_sub(edge[1], v2);
    vertex_normalize(edge[0]);
    vertex_copy(edge[2], v1);
    vertex_sub(edge[2], v3);
    vertex_normalize(edge[0]);

    /* calculate plane normal */
    vertex_copy(n, edge[0]);
    vertex_cross(n, edge[1]);
    vertex_normalize(n);
    
    d = 1.0  / vertex_dot(n, direction);
    
    /* if the ray and the plane are collinear, we get 1.0 / 0.0 --> NaN
     * which you can check by inequality to itself. we assume no collision
     * in the case of collinear ray and plane. */
    if (d != d) return NULL;
    
    /* calculate ray - plane intersection */
    vertex_copy(intersection, v1);
    vertex_sub(intersection, from);
    d *= vertex_dot(intersection, n);
    
    if (d < 0.0) return NULL; /* ray going away from plane */
    
    vertex_copy(intersection, direction);
    vertex_scale(intersection, d);
    vertex_add(intersection, from);
    
    /* compute direction vertex from each triangle corner to intersection point */
    vertex_copy(p[0], intersection);
    vertex_sub(p[0], v1);
    vertex_normalize(p[0]);
    vertex_copy(p[1], intersection);
    vertex_sub(p[1], v2);
    vertex_normalize(p[1]);
    vertex_copy(p[2], intersection);
    vertex_sub(p[2], v3);
    vertex_normalize(p[2]);

    /* check if the intersection is inside the triangle */
    if (acos(vertex_dot(p[0], p[2])) +
        acos(vertex_dot(p[1], p[0])) +
        acos(vertex_dot(p[2], p[1])) >= 1.99 * M_PI) {

        hit = LsgHit_create();
        vertex_copy(hit->normal, n);
        vertex_copy(hit->intersection, intersection);

        return hit;
    }
    
    return NULL;
}

void LsgMeshBVolume_collideRay(LsgMeshBVolume* self, Vertex from, Vertex dir, LsgList* hits) {
    LsgList* candidates;
    LsgIterator* it;
    
    if (!(self->mesh->octree && self->mesh->triangleCount && self->mesh->triangles && self->mesh->vertices)) {
        LsgBBox_collideRay(&self->super, from, dir, hits);
        return;
    }
    
    candidates = (LsgList*)LsgArrayList_create();
    LsgOctree_getCollideRay(self->mesh->octree, from, dir, candidates);
    
    it = candidates->iterator(candidates);
    while (it->hasNext(it)) {
        LsgHit* hit;
        int triangle = (int)it->next(it);
        
        hit = LsgMeshBVolume_collideRayTriangle(
                self->mesh->vertices[self->mesh->triangles[triangle][0]],
                self->mesh->vertices[self->mesh->triangles[triangle][1]],
                self->mesh->vertices[self->mesh->triangles[triangle][2]],
                from, dir);
        
        if (hit) hits->append(hits, hit);
    }
    LsgObject_free((LsgObject*)it);
    
    LsgObject_free((LsgObject*)candidates);
}

static LsgHit* LsgMeshBVolume_collideSphereTriangle(const Vertex v1, const Vertex v2, const Vertex v3, const Vertex center, float radius) {
    LsgHit* hit;
    Vertex edge[3];
    Vertex p[3];
    Vertex ctr_proj, n, ep, ed;
    float d;

    /* build triangle edge vectors */
    vertex_copy(edge[0], v2);
    vertex_sub(edge[0], v1);
    vertex_normalize(edge[0]);
    vertex_copy(edge[1], v3);
    vertex_sub(edge[1], v2);
    vertex_normalize(edge[0]);
    vertex_copy(edge[2], v1);
    vertex_sub(edge[2], v3);
    vertex_normalize(edge[0]);

    /* calculate plane normal */
    vertex_copy(n, edge[0]);
    vertex_cross(n, edge[1]);
    vertex_normalize(n);

    /* calculate sphere center relative to first plane corner */
    vertex_copy(ctr_proj, center);
    vertex_sub(ctr_proj, v1);

    /* trivial reject (distance to triangle plane greater than sphere radius) */
    if (fabs(d = vertex_dot(ctr_proj, n)) > radius) return NULL;

    /* project sphere center onto triangle plane */
    vertex_copy(ctr_proj, n);
    vertex_scale(ctr_proj, -d);
    vertex_add(ctr_proj, center);

    /* compute direction vertex from each triangle corner to projected sphere center */
    vertex_copy(p[0], ctr_proj);
    vertex_sub(p[0], v1);
    vertex_copy(p[1], ctr_proj);
    vertex_sub(p[1], v2);
    vertex_copy(p[2], ctr_proj);
    vertex_sub(p[2], v3);

    /* check if the projected sphere center is inside the triangle */
    if (acos(vertex_dot(p[0], p[2]) / (vertex_length(p[0]) * vertex_length(p[2]))) +
        acos(vertex_dot(p[1], p[0]) / (vertex_length(p[1]) * vertex_length(p[0]))) +
        acos(vertex_dot(p[2], p[1]) / (vertex_length(p[2]) * vertex_length(p[1]))) >= 1.99 * M_PI) {

        hit = LsgHit_create();
        vertex_copy(hit->normal, n);
        vertex_copy(hit->intersection, ctr_proj);

        return hit;
    }

    /* sphere edge intersection test */
    /* edge v1 -> v2 */
    vertex_copy(ep, edge[0]);
    vertex_scale(ep, vertex_dot(ep, p[0]));
    vertex_add(ep, v1);

    vertex_copy(ed, center);
    vertex_sub(ed, ep);
    if (vertex_length(ed) <= radius) {
        hit = LsgHit_create();

        vertex_copy(hit->normal, n);
        vertex_copy(hit->intersection, ep);

        return hit;
    }

    /* edge v2 -> 32 */
    vertex_copy(ep, edge[1]);
    vertex_scale(ep, vertex_dot(ep, p[1]));
    vertex_add(ep, v2);

    vertex_copy(ed, center);
    vertex_sub(ed, ep);
    if (vertex_length(ed) <= radius) {
        hit = LsgHit_create();

        vertex_copy(hit->normal, n);
        vertex_copy(hit->intersection, ep);

        return hit;
    }

    /* edge v3 -> v1 */
    vertex_copy(ep, edge[2]);
    vertex_scale(ep, vertex_dot(ep, p[2]));
    vertex_add(ep, v3);

    vertex_copy(ed, center);
    vertex_sub(ed, ep);
    if (vertex_length(ed) <= radius) {
        hit = LsgHit_create();

        vertex_copy(hit->normal, n);
        vertex_copy(hit->intersection, ep);

        return hit;
    }

    return NULL;
}

void LsgMeshBVolume_collideSphere(LsgMeshBVolume* self, Vertex center, float radius, LsgList* hits) {
    LsgList* candidates;
    LsgIterator* it;
    
    if (!(self->mesh->octree && self->mesh->triangleCount && self->mesh->triangles && self->mesh->vertices)) {
        LsgBBox_collideSphere(&self->super, center, radius, hits);
        return;
    }
    
    candidates = (LsgList*)LsgArrayList_create();
    LsgOctree_getCollideSphere(self->mesh->octree, center, radius, candidates);
    
    it = candidates->iterator(candidates);
    while (it->hasNext(it)) {
        LsgHit* hit;
        int triangle = (int)it->next(it);
        
        hit = LsgMeshBVolume_collideSphereTriangle(
                self->mesh->vertices[self->mesh->triangles[triangle][0]],
                self->mesh->vertices[self->mesh->triangles[triangle][1]],
                self->mesh->vertices[self->mesh->triangles[triangle][2]],
                center, radius);
        
        if (hit) hits->append(hits, hit);
    }
    LsgObject_free((LsgObject*)it);
    
    LsgObject_free((LsgObject*)candidates);
}
