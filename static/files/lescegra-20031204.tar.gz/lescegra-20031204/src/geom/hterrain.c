#include <lescegra/geom/hterrain.h>

#include <lescegra/util/arraylist.h>
#include <lescegra/coll/bbox.h>

#include <GL/gl.h>

#include <stdlib.h>
#include <float.h>

LsgHTerrain* LsgHTerrain_create(LsgImage* img, int divisions, Vertex dimension, int chunk) {
    LsgHTerrain* self = (LsgHTerrain*)malloc(sizeof(LsgHTerrain));

    LsgHTerrain_init(self, img, divisions, dimension, chunk);

    return self;
}

#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define FRAME_ELEMENT(self, x, y) ((self)->frame[(y) * (self)->resolution[0] + (x)])

static void LsgHTerrain_buildFrame(LsgHTerrain* self, LsgImage* img, Vertex dimension);

void LsgHTerrain_init(LsgHTerrain* self, LsgImage* img, int divisions, Vertex dimension, int chunk) {
    Vertex min, max;
    int x_min, x_max, z_min, z_max, z, x;

    LsgNode_init(&self->super);

    ((LsgObject*)self)->destroy = (void (*)(LsgObject*))LsgHTerrain_destroy;

    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))LsgHTerrain_display;

    self->resolution[0] = img->width;
    self->resolution[1] = img->height;
    self->frame   = (LsgHTerrainFrame*)malloc(sizeof(LsgHTerrainFrame) * self->resolution[0] * self->resolution[1]);

    vertex_assign(min, 0.0, 0.0, 0.0);
    self->octree = LsgOctree_create(min, dimension, divisions);
    self->chunk = chunk;

    /* create a bounding volume */
    ((LsgNode*)self)->bvolume = (LsgBVolume*)LsgHTerrainBVolume_create(self);
    ((LsgNode*)self)->bvolume->include(((LsgNode*)self)->bvolume, min);
    ((LsgNode*)self)->bvolume->include(((LsgNode*)self)->bvolume, dimension);

    /* build frame and surface */
    LsgHTerrain_buildFrame(self, img, dimension);

    /* fill octree */
    for (z_min = 0; z_min < self->resolution[1] - 1; z_min += chunk) {
        z_max = MIN(z_min + chunk, self->resolution[1] - 1);
        for (x_min = 0; x_min < self->resolution[0] - 1; x_min += chunk) {
            x_max = MIN(x_min + chunk, self->resolution[0] - 1);

            min[0] = FRAME_ELEMENT(self, x_min, z_min).point[0];
            max[0] = FRAME_ELEMENT(self, x_max, z_min).point[0];
            min[2] = FRAME_ELEMENT(self, x_min, z_min).point[2];
            max[2] = FRAME_ELEMENT(self, x_min, z_max).point[2];

            min[1] = FRAME_ELEMENT(self, x_min, z_min).point[1];
            max[1] = FRAME_ELEMENT(self, x_min, z_min).point[1];

            for (z = z_min; z <= z_max; ++z) {
                for (x = x_min; x <= x_max; ++x) {
                    max[1] = MAX(FRAME_ELEMENT(self, x, z).point[1], max[1]);
                    min[1] = MIN(FRAME_ELEMENT(self, x, z).point[1], min[1]);
                }
            }

            /* yeah ... this is evil :)
             * we do not store a pointer in the octree but the array index for the upper left corner of this chunk.
             * assumption: a cast from int to void* and back does not discard any information
             */
            LsgOctree_add(self->octree, min, max, (void*)(z_min * self->resolution[0] + x_min));
        }
    }
}

static void LsgHTerrain_buildFrame(LsgHTerrain* self, LsgImage* img, Vertex dimension) {
    Vertex scale;
    int x, y, z, i;
    int xn, xp, zn, zp;
    int idx_src, idx_dst;
    float dx, dz;

    scale[0] = dimension[0] / (float)(img->width - 1);
    scale[2] = dimension[2] / (float)(img->height - 1);
    for (scale[1] = dimension[1], i = 0; i < img->bpp; ++i) {
        scale[1] /= 256.0;
    }

    /* calculate points */
    idx_src = idx_dst = -1;
    for (z = 0; z < img->height; ++z) {
        for (x = 0; x < img->width; ++x) {
            for (y = 0, i = 0; i < img->bpp; ++i) {
                y <<= 8;
                y += img->data[++idx_src];
            }

            ++idx_dst;
            vertex_assign(self->frame[idx_dst].point, (float)x, (float)y, (float)z);
            vertex_mul(self->frame[idx_dst].point, scale);
        }
    }

    /* calculate normals (dy/dx + dy/dz) */
    dx = dimension[0] / (float)(self->resolution[0] - 1);
    dz = dimension[2] / (float)(self->resolution[1] - 1);

    for (z = 0; z < self->resolution[1]; ++z) {
        zn = MIN(z + 1, self->resolution[1] - 1);
        zp = MAX(z - 1, 0);
        for (x = 0; x < self->resolution[0]; ++x) {
            xn = MIN(x + 1, self->resolution[0] - 1);
            xp = MAX(x - 1, 0);

            vertex_assign(FRAME_ELEMENT(self, x, z).normal,
                    -dz * (FRAME_ELEMENT(self, xn, z).point[1] - FRAME_ELEMENT(self, xp, z).point[1]),
                    dx * dz,
                    -dx * (FRAME_ELEMENT(self, x, zn).point[1] - FRAME_ELEMENT(self, x, zp).point[1]));
            vertex_normalize(FRAME_ELEMENT(self, x, z).normal);
        }
    }
}

static void LsgHTerrain_displayOctree(LsgOctree* octree, LsgFrustum* frustum) {
    int i;

    /* test visibility */
    for (i = 0; i < 6; ++i) {
        if (frustum->planes[i].normal[0] * octree->vmin[0] +
            frustum->planes[i].normal[1] * octree->vmin[1] +
            frustum->planes[i].normal[2] * octree->vmin[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * octree->vmin[0] +
            frustum->planes[i].normal[1] * octree->vmin[1] +
            frustum->planes[i].normal[2] * octree->vmax[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * octree->vmin[0] +
            frustum->planes[i].normal[1] * octree->vmax[1] +
            frustum->planes[i].normal[2] * octree->vmin[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * octree->vmin[0] +
            frustum->planes[i].normal[1] * octree->vmax[1] +
            frustum->planes[i].normal[2] * octree->vmax[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * octree->vmax[0] +
            frustum->planes[i].normal[1] * octree->vmin[1] +
            frustum->planes[i].normal[2] * octree->vmin[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * octree->vmax[0] +
            frustum->planes[i].normal[1] * octree->vmin[1] +
            frustum->planes[i].normal[2] * octree->vmax[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * octree->vmax[0] +
            frustum->planes[i].normal[1] * octree->vmax[1] +
            frustum->planes[i].normal[2] * octree->vmin[2] +
            frustum->planes[i].distance > 0) continue;
        if (frustum->planes[i].normal[0] * octree->vmax[0] +
            frustum->planes[i].normal[1] * octree->vmax[1] +
            frustum->planes[i].normal[2] * octree->vmax[2] +
            frustum->planes[i].distance > 0) continue;

        return;
    }

    glBegin(GL_LINES);
    glVertex3f(octree->vmin[0], octree->vmin[1], octree->vmin[2]);
    glVertex3f(octree->vmin[0], octree->vmin[1], octree->vmax[2]);

    glVertex3f(octree->vmin[0], octree->vmin[1], octree->vmin[2]);
    glVertex3f(octree->vmin[0], octree->vmax[1], octree->vmin[2]);

    glVertex3f(octree->vmin[0], octree->vmin[1], octree->vmin[2]);
    glVertex3f(octree->vmax[0], octree->vmin[1], octree->vmin[2]);


    glVertex3f(octree->vmin[0], octree->vmin[1], octree->vmax[2]);
    glVertex3f(octree->vmin[0], octree->vmax[1], octree->vmax[2]);

    glVertex3f(octree->vmin[0], octree->vmin[1], octree->vmax[2]);
    glVertex3f(octree->vmax[0], octree->vmin[1], octree->vmax[2]);


    glVertex3f(octree->vmin[0], octree->vmax[1], octree->vmin[2]);
    glVertex3f(octree->vmin[0], octree->vmax[1], octree->vmax[2]);

    glVertex3f(octree->vmin[0], octree->vmax[1], octree->vmin[2]);
    glVertex3f(octree->vmax[0], octree->vmax[1], octree->vmin[2]);


    glVertex3f(octree->vmax[0], octree->vmin[1], octree->vmin[2]);
    glVertex3f(octree->vmax[0], octree->vmin[1], octree->vmax[2]);

    glVertex3f(octree->vmax[0], octree->vmin[1], octree->vmin[2]);
    glVertex3f(octree->vmax[0], octree->vmax[1], octree->vmin[2]);


    glVertex3f(octree->vmin[0], octree->vmax[1], octree->vmax[2]);
    glVertex3f(octree->vmax[0], octree->vmax[1], octree->vmax[2]);


    glVertex3f(octree->vmax[0], octree->vmin[1], octree->vmax[2]);
    glVertex3f(octree->vmax[0], octree->vmax[1], octree->vmax[2]);


    glVertex3f(octree->vmax[0], octree->vmax[1], octree->vmin[2]);
    glVertex3f(octree->vmax[0], octree->vmax[1], octree->vmax[2]);
    glEnd();

    if (octree->divisions) {
        for (i = 0; i < 8; ++i) {
            if (octree->children[i]) LsgHTerrain_displayOctree(octree->children[i], frustum);
        }
    }
}

void LsgHTerrain_display(LsgHTerrain* self, LsgFrustum* frust) {
    LsgList* list;
    LsgIterator* it;
    int idx, x, z, x_max, x_min, z_max, z_min;

    list = (LsgList*)LsgArrayList_create();
    LsgOctree_getVisible(self->octree, frust, list);

    if (list->count(list)) {
        glInterleavedArrays(GL_N3F_V3F, 0, self->frame);

        it = list->iterator(list);
        while (it->hasNext(it)) {
            idx = (int)it->next(it);

            x_min = idx % self->resolution[0];
            x_max = x_min + self->chunk + 1;
            x_max = MIN(x_max, self->resolution[0]);
            z_min = idx / self->resolution[0];
            z_max = z_min + self->chunk;
            z_max = MIN(z_max, self->resolution[1] - 1);

            for (z = z_min; z < z_max; ++z) {
                glBegin(GL_TRIANGLE_STRIP);
                for (x = x_min; x < x_max; ++x) {
                    glArrayElement( z      * self->resolution[0] + x);
                    glArrayElement((z + 1) * self->resolution[0] + x);
                }
                glEnd();
            }
        }
        LsgObject_free((LsgObject*)it);
    }

    LsgObject_free((LsgObject*)list);
}

void LsgHTerrain_destroy(LsgHTerrain* self) {
    LsgObject_free((LsgObject*)self->octree);

    free(self->frame);

    LsgNode_destroy(&self->super);
}

/******************************************************************************/

#include <math.h>

#ifndef M_PI
#define M_PI		3.14159265358979323846
#endif

LsgHTerrainBVolume* LsgHTerrainBVolume_create(LsgHTerrain* terrain) {
    LsgHTerrainBVolume* self = (LsgHTerrainBVolume*)malloc(sizeof(LsgHTerrainBVolume));

    LsgHTerrainBVolume_init(self, terrain);

    return self;
}

void LsgHTerrainBVolume_init(LsgHTerrainBVolume* self, LsgHTerrain* terrain) {
    LsgBBox_init(&self->super);

    ((LsgBVolume*)self)->visible = (int (*)(LsgBVolume*, LsgFrustum*))LsgHTerrainBVolume_visible;
    ((LsgBVolume*)self)->collideVertex = (void (*)(LsgBVolume*, Vertex, LsgList*))LsgHTerrainBVolume_collideVertex;
    ((LsgBVolume*)self)->collideRay    = (void (*)(LsgBVolume*, Vertex, Vertex, LsgList*))LsgHTerrainBVolume_collideRay;
    ((LsgBVolume*)self)->collideSphere = (void (*)(LsgBVolume*, Vertex, float, LsgList*))LsgHTerrainBVolume_collideSphere;

    self->terrain = terrain;
}

int LsgHTerrainBVolume_visible(LsgHTerrainBVolume* self, LsgFrustum* frustum) {
    /* view frustum culling is done by via LsgOctree in LsgHTerrain_display */
    return 1;
}

void LsgHTerrainBVolume_collideVertex(LsgHTerrainBVolume* self, Vertex v, LsgList* buffer) {
    /* this method is not very usefule as we don't really define a volume but rather
     * a collision surface. */
}

static LsgHit* LsgHTerrainBVolume_collideRayPlane(const Vertex v1, const Vertex v2, const Vertex v3, const Vertex from, const Vertex direction) {
    LsgHit* hit;
    Vertex edge[3];
    Vertex p[3];
    Vertex intersection, n;
    float d;

    /* build triangle edge vectors */
    vertex_copy(edge[0], v2);
    vertex_sub(edge[0], v1);
    vertex_normalize(edge[0]);
    vertex_copy(edge[1], v3);
    vertex_sub(edge[1], v2);
    vertex_normalize(edge[0]);
    vertex_copy(edge[2], v1);
    vertex_sub(edge[2], v3);
    vertex_normalize(edge[0]);

    /* calculate plane normal */
    vertex_copy(n, edge[0]);
    vertex_cross(n, edge[1]);
    vertex_normalize(n);
    
    d = 1.0  / vertex_dot(n, direction);
    
    /* if the ray and the plane are collinear, we get 1.0 / 0.0 --> NaN
     * which you can check by inequality to itself. we assume no collision
     * in the case of collinear ray and plane. */
    if (d != d) return NULL;
    
    /* calculate ray - plane intersection */
    vertex_copy(intersection, v1);
    vertex_sub(intersection, from);
    d *= vertex_dot(intersection, n);
    
    if (d < 0.0) return NULL; /* ray going away from plane */
    
    vertex_copy(intersection, direction);
    vertex_scale(intersection, d);
    vertex_add(intersection, from);
    
    /* compute direction vertex from each triangle corner to intersection point */
    vertex_copy(p[0], intersection);
    vertex_sub(p[0], v1);
    vertex_normalize(p[0]);
    vertex_copy(p[1], intersection);
    vertex_sub(p[1], v2);
    vertex_normalize(p[1]);
    vertex_copy(p[2], intersection);
    vertex_sub(p[2], v3);
    vertex_normalize(p[2]);

    /* check if the intersection is inside the triangle */
    if (acos(vertex_dot(p[0], p[2])) +
        acos(vertex_dot(p[1], p[0])) +
        acos(vertex_dot(p[2], p[1])) >= 1.99 * M_PI) {

        hit = LsgHit_create();
        vertex_copy(hit->normal, n);
        vertex_copy(hit->intersection, intersection);

        return hit;
    }
    
    return NULL;
}

void LsgHTerrainBVolume_collideRay(LsgHTerrainBVolume* self, Vertex from, Vertex dir, LsgList* buffer) {
    LsgList* list;
    LsgIterator* it;
    LsgHit* hit = NULL;

    list = (LsgList*)LsgArrayList_create();
    LsgOctree_getCollideRay(self->terrain->octree, from, dir, list);

    it = list->iterator(list);
    while (it->hasNext(it)) {
        int x_min, x, x_max, z_min, z, z_max;
        int idx = (int)it->next(it);

        x_min = idx % self->terrain->resolution[0];
        x_max = x_min + self->terrain->chunk;
        x_max = MIN(x_max, self->terrain->resolution[0] - 1);
        z_min = idx / self->terrain->resolution[0];
        z_max = z_min + self->terrain->chunk;
        z_max = MIN(z_max, self->terrain->resolution[1] - 1);

        for (z = z_min; z < z_max; ++z) {
            for (x = x_min; x < x_max; ++x) {
                hit = LsgHTerrainBVolume_collideRayPlane(
                        FRAME_ELEMENT(self->terrain, x, z).point,
                        FRAME_ELEMENT(self->terrain, x, z + 1).point,
                        FRAME_ELEMENT(self->terrain, x + 1, z).point,
                        from, dir);
                if (hit) buffer->append(buffer, hit);

                hit = LsgHTerrainBVolume_collideRayPlane(
                        FRAME_ELEMENT(self->terrain, x + 1, z + 1).point,
                        FRAME_ELEMENT(self->terrain, x + 1, z).point,
                        FRAME_ELEMENT(self->terrain, x, z + 1).point,
                        from, dir);
                if (hit) buffer->append(buffer, hit);
            }
        }
    }
    LsgObject_free((LsgObject*)it);
}

static LsgHit* LsgHTerrainBVolume_collideSpherePlane(const Vertex v1, const Vertex v2, const Vertex v3, const Vertex center, float radius) {
    LsgHit* hit;
    Vertex edge[3];
    Vertex p[3];
    Vertex ctr_proj, n, ep, ed;
    float d;

    /* build triangle edge vectors */
    vertex_copy(edge[0], v2);
    vertex_sub(edge[0], v1);
    vertex_normalize(edge[0]);
    vertex_copy(edge[1], v3);
    vertex_sub(edge[1], v2);
    vertex_normalize(edge[0]);
    vertex_copy(edge[2], v1);
    vertex_sub(edge[2], v3);
    vertex_normalize(edge[0]);

    /* calculate plane normal */
    vertex_copy(n, edge[0]);
    vertex_cross(n, edge[1]);
    vertex_normalize(n);

    /* calculate sphere center relative to first plane corner */
    vertex_copy(ctr_proj, center);
    vertex_sub(ctr_proj, v1);

    /* trivial reject (distance to triangle plane greater than sphere radius) */
    if (fabs(d = vertex_dot(ctr_proj, n)) > radius) return NULL;

    /* project sphere center onto triangle plane */
    vertex_copy(ctr_proj, n);
    vertex_scale(ctr_proj, -d);
    vertex_add(ctr_proj, center);

    /* compute direction vertex from each triangle corner to projected sphere center */
    vertex_copy(p[0], ctr_proj);
    vertex_sub(p[0], v1);
    vertex_copy(p[1], ctr_proj);
    vertex_sub(p[1], v2);
    vertex_copy(p[2], ctr_proj);
    vertex_sub(p[2], v3);

    /* check if the projected sphere center is inside the triangle */
    if (acos(vertex_dot(p[0], p[2]) / (vertex_length(p[0]) * vertex_length(p[2]))) +
        acos(vertex_dot(p[1], p[0]) / (vertex_length(p[1]) * vertex_length(p[0]))) +
        acos(vertex_dot(p[2], p[1]) / (vertex_length(p[2]) * vertex_length(p[1]))) >= 1.99 * M_PI) {

        hit = LsgHit_create();
        vertex_copy(hit->normal, n);
        vertex_copy(hit->intersection, ctr_proj);

        return hit;
    }

    /* sphere edge intersection test */
    /* edge v1 -> v2 */
    vertex_copy(ep, edge[0]);
    vertex_scale(ep, vertex_dot(ep, p[0]));
    vertex_add(ep, v1);

    vertex_copy(ed, center);
    vertex_sub(ed, ep);
    if (vertex_length(ed) <= radius) {
        hit = LsgHit_create();

        vertex_copy(hit->normal, n);
        vertex_copy(hit->intersection, ep);

        return hit;
    }

    /* edge v2 -> 32 */
    vertex_copy(ep, edge[1]);
    vertex_scale(ep, vertex_dot(ep, p[1]));
    vertex_add(ep, v2);

    vertex_copy(ed, center);
    vertex_sub(ed, ep);
    if (vertex_length(ed) <= radius) {
        hit = LsgHit_create();

        vertex_copy(hit->normal, n);
        vertex_copy(hit->intersection, ep);

        return hit;
    }

    /* edge v3 -> v1 */
    vertex_copy(ep, edge[2]);
    vertex_scale(ep, vertex_dot(ep, p[2]));
    vertex_add(ep, v3);

    vertex_copy(ed, center);
    vertex_sub(ed, ep);
    if (vertex_length(ed) <= radius) {
        hit = LsgHit_create();

        vertex_copy(hit->normal, n);
        vertex_copy(hit->intersection, ep);

        return hit;
    }

    return NULL;
}

void LsgHTerrainBVolume_collideSphere(LsgHTerrainBVolume* self, Vertex center, float radius, LsgList* buffer) {
    LsgList* list;
    LsgIterator* it;
    LsgHit* hit = NULL;

    list = (LsgList*)LsgArrayList_create();
    LsgOctree_getCollideSphere(self->terrain->octree, center, radius, list);

    it = list->iterator(list);
    while (it->hasNext(it)) {
        int x_min, x, x_max, z_min, z, z_max;
        int idx = (int)it->next(it);

        x_min = idx % self->terrain->resolution[0];
        x_max = x_min + self->terrain->chunk;
        x_max = MIN(x_max, self->terrain->resolution[0] - 1);
        z_min = idx / self->terrain->resolution[0];
        z_max = z_min + self->terrain->chunk;
        z_max = MIN(z_max, self->terrain->resolution[1] - 1);

        for (z = z_min; z < z_max; ++z) {
            for (x = x_min; x < x_max; ++x) {
                hit = LsgHTerrainBVolume_collideSpherePlane(
                        FRAME_ELEMENT(self->terrain, x, z).point,
                        FRAME_ELEMENT(self->terrain, x, z + 1).point,
                        FRAME_ELEMENT(self->terrain, x + 1, z).point,
                        center, radius);
                if (hit) buffer->append(buffer, hit);

                hit = LsgHTerrainBVolume_collideSpherePlane(
                        FRAME_ELEMENT(self->terrain, x + 1, z + 1).point,
                        FRAME_ELEMENT(self->terrain, x + 1, z).point,
                        FRAME_ELEMENT(self->terrain, x, z + 1).point,
                        center, radius);
                if (hit) buffer->append(buffer, hit);
            }
        }
    }
    LsgObject_free((LsgObject*)it);
}
