#include <lescegra/util/image.h>

#include <lescegra/util/error.h>

#include <stdlib.h>
#include <string.h>

LsgImage* LsgImage_create(int width, int height, int bpp) {
    LsgImage* self = (LsgImage*)malloc(sizeof(LsgImage));
    
    LsgImage_init(self, width, height, bpp);
    
    return self;
}

void LsgImage_init(LsgImage* self, int width, int height, int bpp) {
    LsgObject_init(&self->super);
    
    ((LsgObject*)self)->destroy = (void (*)(LsgObject*))LsgImage_destroy;

    self->width = width;
    self->height = height;
    self->bpp = bpp;
    
    self->data = (unsigned char*)malloc(sizeof(unsigned char) * width * height * bpp);
}

void LsgImage_copy(LsgImage* self, int x, int y, int w, int h, LsgImage* dst, int dst_x, int dst_y) {
    int bpp;
    int r, c, b;
    
    if ((x >= self->width) || (y >= self->height) 
    || (dst_x >= dst->width) || (dst_y >= dst->height)
    || (w < 1) || (h < 1)) return;
    
    /* clip on source image */
    if (x < 0) {
        w     += x;
        dst_x -= x;
        x      = 0;
    }
    
    if (y < 0) {
        h     += y;
        dst_y -= y;
        y      = 0;
    }
    
    if ((x + w) > self->width)
        w = self->width - x;
    
    if ((y + h) > self->height)
        h = self->height - y;
    
    /* clip on destination image */
    if (dst_x < 0) {
        x     -= dst_x;
        w     += dst_x;
        dst_x  = 0;
    }
    
    if (dst_y < 0) {
        y     -= dst_y;
        w     += dst_y;
        dst_y  = 0;
    }
    
    if ((dst_x + w) >= dst->width)
        w = dst->width - dst_x;
    
    if ((dst_y + h) >= dst->height)
        h = dst->height - dst_y;

    /* copy that data */
    bpp = self->bpp < dst->bpp ? self->bpp : dst->bpp;
    
    for (r = 0; r < h; ++r) {
        for (c = 0; c < w; ++c) {
            for (b = 0; b < bpp; ++b) {
                dst->data[((dst_y + r) * dst->width + (dst_x + c)) * dst->bpp + b] =
                        self->data[((y + r) * self->width + (x + c)) * self->bpp + b];
            }
        }
    }
}

void LsgImage_destroy(LsgImage* self) {
    if (self->data) free(self->data);
    
    LsgObject_destroy(&self->super);
}

void LsgImage_mirrorX(LsgImage* self) {
    unsigned char* tmp;
    int x, y;
    
    tmp = (unsigned char*)malloc(sizeof(unsigned char) * self->bpp);
    
    for (y = 0; y < self->height; ++y) {
        for (x = 0; x < self->width / 2; ++x) {
            memcpy(tmp, self->data + (y * self->width + x) * self->bpp, sizeof(unsigned char) * self->bpp);
            memcpy(self->data + (y * self->width + x) * self->bpp, self->data + (y * self->width + (self->width - x - 1)) * self->bpp, sizeof(unsigned char) * self->bpp);
            memcpy(self->data + (y * self->width + (self->width - x - 1)) * self->bpp, tmp, sizeof(unsigned char) * self->bpp);
        }
    }
}

void LsgImage_mirrorY(LsgImage* self) {
    unsigned char* tmp;
    int tmp_size;
    int y;
    
    tmp_size = self->width * self->bpp;
    tmp = (unsigned char*)malloc(sizeof(unsigned char) * tmp_size);
    
    for (y = 0; y < self->height / 2; ++y) {
        memcpy(tmp, self->data + y * tmp_size, sizeof(unsigned char) * tmp_size);
        memcpy(self->data + y * tmp_size, self->data + (self->height - y - 1) * tmp_size, sizeof(unsigned char) * tmp_size);
        memcpy(self->data + (self->height - y - 1) * tmp_size, tmp, sizeof(unsigned char) * tmp_size);
    }
    
    free(tmp);
}

LsgImage* LsgImage_load(const char* filename) {
    int len = strlen(filename);
    
    if (!strcmp(filename + len - 4, ".pcx")) {
        return LsgImage_loadPCX(filename);
        
    } else if (!strcmp(filename + len - 4, ".tga")) {
        return LsgImage_loadTGA(filename);
        
    } else if (!strcmp(filename + len - 4, ".png")) {
        return LsgImage_loadPNG(filename);
        
    } else {
        LsgError_reportFormat(__FILE__, "LsgImage_load", __LINE__, "%s: Unknown image format", filename);
        return NULL;
    }
}
