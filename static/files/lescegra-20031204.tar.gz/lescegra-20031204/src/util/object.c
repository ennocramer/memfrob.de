#include <lescegra/util/object.h>

#include <stdlib.h>

void LsgObject_init(LsgObject* self) {
    self->destroy = LsgObject_destroy;
}

void LsgObject_destroy(LsgObject* self) {
    /* nada */
}

void LsgObject_free(LsgObject* obj) {
    if (obj)
        obj->destroy(obj);
    free(obj);
}
