#include <lescegra/util/list.h>

#include <lescegra/util/error.h>

#include <stddef.h>

static int LsgIterator_hasNext(LsgIterator* self);
static void* LsgIterator_next(LsgIterator* self);
static int LsgIterator_index(LsgIterator* self);

void LsgIterator_init(LsgIterator* self) {
    LsgObject_init(&self->super);
    
    self->hasNext = LsgIterator_hasNext;
    self->next    = LsgIterator_next;
    self->index   = LsgIterator_index;
}

static int LsgIterator_hasNext(LsgIterator* self) {
    LsgError_abortAbstract("LsgIterator", "hasNext", (LsgObject*)self);
    return 0;
}

static void* LsgIterator_next(LsgIterator* self) {
    LsgError_abortAbstract("LsgIterator", "hasNext", (LsgObject*)self);
    return NULL;
}
static int LsgIterator_index(LsgIterator* self) {
    LsgError_abortAbstract("LsgIterator", "hasNext", (LsgObject*)self);
    return 0;
}

static int   LsgList_count(LsgList* self);
static int   LsgList_index(LsgList* self, void* object);
static void  LsgList_insert(LsgList* self, int index, void* object);
static void  LsgList_removeByIndex(LsgList* self, int index);
static void* LsgList_get(LsgList* self, int index);
static void  LsgList_set(LsgList* self, int index, void* object);
static void  LsgList_clear(LsgList* self);
static LsgIterator* LsgList_iterator(LsgList* self);

void LsgList_init(LsgList* self) {
    LsgObject_init(&self->super);
    
    self->count         = LsgList_count;
    self->contains      = LsgList_contains;
    self->index         = LsgList_index;
    self->append        = LsgList_append;
    self->insert        = LsgList_insert;
    self->remove        = LsgList_remove;
    self->removeByIndex = LsgList_removeByIndex;
    self->get           = LsgList_get;
    self->set           = LsgList_set;
    self->clear         = LsgList_clear;
    self->iterator      = LsgList_iterator;
}

static int LsgList_count(LsgList* self) {
    LsgError_abortAbstract("LsgList", "count", (LsgObject*)self);
    return 0;
}

int LsgList_contains(LsgList* self, void* object) {
    return self->index(self, object) != -1;
}

static int LsgList_index(LsgList* self, void* object) {
    LsgError_abortAbstract("LsgList", "index", (LsgObject*)self);
    return 0;
}

void LsgList_append(LsgList* self, void* object) {
    self->insert(self, self->count(self), object);
}

static void LsgList_insert(LsgList* self, int index, void* object) {
    LsgError_abortAbstract("LsgList", "insert", (LsgObject*)self);
}

void LsgList_remove(LsgList* self, void* object) {
    int idx;
    
    idx = self->index(self, object);
    if (idx != -1) self->removeByIndex(self, idx);
}

static void LsgList_removeByIndex(LsgList* self, int index) {
    LsgError_abortAbstract("LsgList", "removeByIndex", (LsgObject*)self);
}

static void* LsgList_get(LsgList* self, int index) {
    LsgError_abortAbstract("LsgList", "get", (LsgObject*)self);
    return NULL;
}

static void LsgList_set(LsgList* self, int index, void* object) {
    LsgError_abortAbstract("LsgList", "set", (LsgObject*)self);
}

static void LsgList_clear(LsgList* self) {
    LsgError_abortAbstract("LsgList", "clear", (LsgObject*)self);
}

static LsgIterator* LsgList_iterator(LsgList* self) {
    LsgError_abortAbstract("LsgList", "iterator", (LsgObject*)self);
    return NULL;
}

