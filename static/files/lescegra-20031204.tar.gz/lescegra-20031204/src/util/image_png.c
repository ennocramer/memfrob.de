#include <lescegra/util/image.h>

#include <lescegra/util/error.h>
#include <lescegra/util/endian.h>

#include <zlib.h>

#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define PNG_MAGIC "\211PNG\r\n\032\n"

typedef struct {
    int chunk_number;
    long int chunk_size;
    long int chunk_type;
    int done;
} PNGDecoderState;

typedef struct {
    long int width;
    long int height;
    char bit_depth;
    char color_type;
    char compression;
    char filter;
    char interlace;
} PNGHeader;

typedef struct {
    unsigned char* buffer_in;
    unsigned char* buffer_out;
    unsigned char* buffer_backup;

    z_stream zlib;
    
    int sample_size;
    int pixel_size;
    int scanline_size;
    int buffer_size;

    int scanline;    
    
    int plane_count;
    int sample_mask;
} PNGDataDecoderState;

#define MIN(a, b) ((a) < (b) ? (a) : (b))

LsgImage* LsgImage_loadPNG(const char* filename) {
#define ERROR(msg) LsgError_reportFormat(__FILE__, "LsgImage_loadPNG", __LINE__, "%s: %s", filename, (msg))
#define FERROR(msg) ERROR(ferror(file) ? strerror(errno) : (msg))
    LsgImage* image = NULL;
    
    FILE* file = NULL;
    
    PNGDecoderState state;
    PNGHeader header;
    PNGDataDecoderState data_decoder;
    
    char magic[8];
    
    memset(&state, 0, sizeof(PNGDecoderState));
    memset(&data_decoder, 0, sizeof(PNGDataDecoderState));
    
    /* open file */
    if (!(file = fopen(filename, "r"))) {
        ERROR(strerror(errno));
        goto loadPNG_error;
    }

    /* read png file magic */
    if (fread(magic, sizeof(char), 8, file) != 8) {
        FERROR("Premature end of file");
        goto loadPNG_error;
    }

    /* check file magic */
    if (strncmp(magic, PNG_MAGIC, 8)) {
        ERROR("Invalid file format");
        goto loadPNG_error;
    }
    
    /* read png chunks */
    while (!state.done && !feof(file)) {
        /* read chunk header */
        if ((fread(&state.chunk_size, sizeof(long int), 1, file) != 1) ||
            (fread(&state.chunk_type, sizeof(long int), 1, file) != 1)) {
            FERROR("Premature end of file");
            goto loadPNG_error;
        }

        /* png uses network byte order (big endian) */
        if (LsgEndian_endianess() != LsgEndian_BIG) {
            LsgEndian_swapLong(&state.chunk_size);
            LsgEndian_swapLong(&state.chunk_type);
        }

        /* first chunk must be IHDR */
        if ((state.chunk_number == 0) && (state.chunk_type != 0x49484452)) {
            ERROR("First chunk must be IHDR");
            goto loadPNG_error;
        }

        /* IHDR */
        if (state.chunk_type == 0x49484452) {
            if (state.chunk_number != 0) {
                ERROR("Repeated IHDR chunk found");
                goto loadPNG_error;
            }

            if (state.chunk_size != 13) {
                ERROR("Invalid IHDR chunk size");
                goto loadPNG_error;
            }
            
            if ((fread(&header.width, sizeof(long int), 2, file) != 2) ||
                (fread(&header.bit_depth, sizeof(char), 5, file) != 5)) {
                FERROR("Premature end of file");
                goto loadPNG_error;
            }
            
            if (LsgEndian_endianess() != LsgEndian_BIG) {
                LsgEndian_swapArray((char*)&header.width, sizeof(long int), 2);
                LsgEndian_swapArray((char*)&header.bit_depth, sizeof(char), 5);
            }
            
            if (header.compression != 0) {
                ERROR("Compression method not supported");
                goto loadPNG_error;
            }
            
            if (header.filter != 0) {
                ERROR("Filter method not supported");
                goto loadPNG_error;
            }
            
            if (header.interlace != 0) {
                ERROR("Interlace method not supported");
                goto loadPNG_error;
            }
            
            if (header.color_type & ~0x07) {
                ERROR("Sample type not supported");
                goto loadPNG_error;
            }
            
            if (header.color_type & 0x01) {
                ERROR("Palette images not supported");
                goto loadPNG_error;
            }
            
            data_decoder.plane_count   = (header.color_type & 0x02 ? 3 : 1) + (header.color_type & 0x04 ? 1 : 0);
            data_decoder.sample_mask   = ~(0xffffffff << header.bit_depth);
            
            data_decoder.sample_size   = (header.bit_depth + 7) / 8;
            data_decoder.pixel_size    = (header.bit_depth * data_decoder.plane_count + 7) / 8;
            data_decoder.scanline_size = (header.bit_depth * data_decoder.plane_count * header.width + 7) / 8;
            
            if (!(image = LsgImage_create(header.width, header.height, data_decoder.plane_count))) {
                ERROR(strerror(ENOMEM));
                goto loadPNG_error;
            }
            
            /* initialize the zlib inflate stream */
            data_decoder.buffer_size    = data_decoder.scanline_size + 1;
            data_decoder.buffer_in     = (unsigned char*)malloc(data_decoder.buffer_size);
            data_decoder.buffer_out    = (unsigned char*)malloc(data_decoder.buffer_size);
            data_decoder.buffer_backup = (unsigned char*)malloc(data_decoder.buffer_size);
            
            data_decoder.zlib.zalloc = (alloc_func)Z_NULL;
            data_decoder.zlib.zfree  = (free_func)Z_NULL;
            data_decoder.zlib.opaque = (voidpf)Z_NULL;

            data_decoder.zlib.next_in   = data_decoder.buffer_in;
            data_decoder.zlib.avail_in  = 0;
            data_decoder.zlib.next_out  = data_decoder.buffer_out;
            data_decoder.zlib.avail_out = data_decoder.buffer_size;

            if (inflateInit(&data_decoder.zlib) != Z_OK) {
                ERROR(data_decoder.zlib.msg);
                goto loadPNG_error;
            }

        /* IEND */
        } else if (state.chunk_type == 0x49454e44) {
            state.done = 1;
        
        /* IDAT */
        } else if (state.chunk_type == 0x49444154) {
            int data_left = state.chunk_size;
            
            while ((data_left > 0) || (data_decoder.zlib.avail_in)) {
                int read_count = MIN(data_decoder.buffer_size - data_decoder.zlib.avail_in, data_left);
                
                if (data_decoder.scanline >= image->height) {
                    ERROR("Too many pixels");
                    goto loadPNG_error;
                }
                
                if (read_count > 0) {
                    if (fread(data_decoder.buffer_in + data_decoder.zlib.avail_in, sizeof(unsigned char), read_count, file) != read_count) {
                        FERROR("Premature end of file");
                        goto loadPNG_error;
                    }

                    data_left                  -= read_count;
                    data_decoder.zlib.avail_in += read_count;
                }
                
                if ((data_decoder.zlib.avail_in > 0) && (data_decoder.zlib.avail_out > 0)) {
                    if (inflate(&data_decoder.zlib, Z_NO_FLUSH) < 0) {
                        ERROR(data_decoder.zlib.msg);
                        goto loadPNG_error;
                    }
                
                    memmove(data_decoder.buffer_in, data_decoder.zlib.next_in, data_decoder.zlib.avail_in);
                    data_decoder.zlib.next_in = data_decoder.buffer_in;
                }
                
                /* process inflated data */
                if (data_decoder.zlib.avail_out == 0) {
                    unsigned char* ptr = data_decoder.buffer_out;
                    unsigned char filter = *ptr++;
                    int pixel, byte, bit_shift;
                    
                    if (filter > 4) {
                        ERROR("Invalid scanline filter");
                        goto loadPNG_error;
                    }
                    
                    /* filter scanline */
                    if ((filter == 1) || ((filter == 3) && (data_decoder.scanline == 0))) {
                        for (byte = data_decoder.pixel_size + 1; byte < data_decoder.buffer_size; ++byte)
                            data_decoder.buffer_out[byte] += data_decoder.buffer_out[byte - data_decoder.pixel_size];
                        
                    } else if ((filter == 2) && (data_decoder.scanline != 0)) {
                        for (byte = 1; byte < data_decoder.buffer_size; ++byte)
                            data_decoder.buffer_out[byte] += data_decoder.buffer_backup[byte];
                        
                    } else if ((filter == 3) && (data_decoder.scanline != 0)) {
                        for (byte = 1; byte < 1 + data_decoder.pixel_size; ++byte)
                            data_decoder.buffer_out[byte] += data_decoder.buffer_backup[byte] / 2;
                        for (        ; byte < data_decoder.buffer_size; ++byte)
                            data_decoder.buffer_out[byte] += ((int)(data_decoder.buffer_out[byte - data_decoder.pixel_size]) + (int)(data_decoder.buffer_backup[byte])) >> 1;
                        
                    } else if (filter == 4) {
                        unsigned char a, b, c, out;
                        int p, pa, pb, pc;
                        for (byte = 1; byte < data_decoder.buffer_size; ++byte) {
                            a = (byte > data_decoder.pixel_size)                                ? data_decoder.buffer_out   [byte - data_decoder.pixel_size] : 0;
                            b =                                     (data_decoder.scanline > 0) ? data_decoder.buffer_backup[byte                          ] : 0;
                            c = (byte > data_decoder.pixel_size) && (data_decoder.scanline > 0) ? data_decoder.buffer_backup[byte - data_decoder.pixel_size] : 0;
                            
                            p  = a + b - c;
                            pa = abs(p - a);
                            pb = abs(p - b);
                            pc = abs(p - c);
                            
                            if ((pa <= pb) && (pa <= pc))
                                out = a;
                            else if (pb <= pc)
                                out = b;
                            else
                                out = c;
                            
                            data_decoder.buffer_out[byte] += out;
                        }
                            
                    }
                    
                    /* decode scanline */
                    bit_shift = 8 * data_decoder.sample_size - header.bit_depth;
                    for (pixel = 0; pixel < header.width; ++pixel) {
                        int sample, plane;
                    
                        for (plane = 0; plane < data_decoder.plane_count; ++plane) {
                            int i;

                            /* read all bytes that contain sample data */
                            for (sample = 0, i = 0; i < data_decoder.sample_size; ++i)
                                sample = (sample << 8) | ptr[i];
                            
                            /* extract sample data */
                            sample = (sample >> bit_shift) & data_decoder.sample_mask;
                            
                            /* scale sample to 8 bit color depth */
                            sample = (sample * 255 + 1) / data_decoder.sample_mask;
                                
                            image->data[(data_decoder.scanline * image->width + pixel) * image->bpp + plane] = (unsigned char)sample;

                            bit_shift -= header.bit_depth;
                            if (bit_shift < 0) {
                                ptr       +=     data_decoder.sample_size;
                                bit_shift += 8 * data_decoder.sample_size;
                            }
                        }
                    }
                    
                    /* exchange buffers */
                    ptr = data_decoder.buffer_backup;
                    data_decoder.buffer_backup = data_decoder.buffer_out;
                    data_decoder.buffer_out    = ptr;
                    
                    data_decoder.zlib.next_out  = data_decoder.buffer_out;
                    data_decoder.zlib.avail_out = data_decoder.buffer_size;
                    
                    ++data_decoder.scanline;
                }
            }
            
        /* unknown chunks */
        } else {
            if (((state.chunk_type >> 24) & 0x20) == 0) {
                ERROR("Unknown critical chunk found");
                goto loadPNG_error;
            }
            
            if (((state.chunk_type >>  8) & 0x20) != 0) {
                ERROR("Invalid chunk found (reserved bit set)");
                goto loadPNG_error;
            }
            
            fseek(file, state.chunk_size, SEEK_CUR);
        }
        
        /* skip chunk crc*/
        fseek(file, 4, SEEK_CUR);
        
        ++state.chunk_number;
    }

    /* no IEND chunk found? */
    if (!state.done) {
        ERROR("File truncated");
        goto loadPNG_error;
    }
    
    if (data_decoder.scanline < image->height) {
        ERROR("Too few pixels");
        goto loadPNG_error;
    }

    goto loadPNG_end;

    loadPNG_error:
        LsgObject_free((LsgObject*)image);
        image = NULL;

    loadPNG_end:
        deflateEnd(&data_decoder.zlib);
        free(data_decoder.buffer_in);
        free(data_decoder.buffer_out);
        free(data_decoder.buffer_backup);
        if (file) fclose(file);
        return image;
#undef FERROR
#undef ERROR
}
