#include <lescegra.h>

#include <GL/glut.h>

#include <stdlib.h>
#include <stdio.h>

#ifndef M_PI
# define M_PI		3.14159265358979323846	/* pi */
#endif

/* AnimatedRotate
 *****************************************************************************/
typedef struct AnimatedRotate_s AnimatedRotate;

struct AnimatedRotate_s {
    LsgGroup super;
    Vertex axis;
    float omega;
    float phi;
    float alpha;
};

AnimatedRotate* AnimatedRotate_create(Vertex axis, float omega, float phi);
void AnimatedRotate_init(AnimatedRotate* self, Vertex axis, float omega, float phi);
void AnimatedRotate_display(AnimatedRotate* self, LsgFrustum* frust);
void AnimatedRotate_update(AnimatedRotate* self, float now);

AnimatedRotate* AnimatedRotate_create(Vertex axis, float omega, float phi) {
    AnimatedRotate* self = (AnimatedRotate*)malloc(sizeof(AnimatedRotate));
    
    AnimatedRotate_init(self, axis, omega, phi);
    
    return self;
}

void AnimatedRotate_init(AnimatedRotate* self, Vertex axis, float omega, float phi) {
    LsgGroup_init(&self->super);
    self->super.super.display = (void (*)(LsgNode*, LsgFrustum*))AnimatedRotate_display;
    self->super.super.update  = (void (*)(LsgNode*, float))AnimatedRotate_update;
    
    vertex_copy(self->axis, axis);
    self->omega = omega;
    self->phi = phi;
    self->alpha = phi  * 180.0 / M_PI;
}

void AnimatedRotate_display(AnimatedRotate* self, LsgFrustum* frust) {
    glPushMatrix();
    
    glRotatef(self->alpha, self->axis[0], self->axis[1], self->axis[2]);
    
    LsgGroup_display(&self->super, frust);
    
    glPopMatrix();
}

void AnimatedRotate_update(AnimatedRotate* self, float now) {
    self->alpha = (self->omega * now + self->phi) * 180.0 / M_PI;
}

/* MAIN
 *****************************************************************************/

typedef struct {
    float radius;
    float orbit;
    float orbit_period;
} Body;

#define PLANET_COUNT 10
Body planets[PLANET_COUNT] = {
    /* 10^3km    10^9km 10^3 days */
    { 695.000, 0.000000,  0.00000}, /* sun */
    {   2.440, 0.057910,  0.08797}, /* mercury */
    {   6.052, 0.108200,  0.22470}, /* venus */
    {   6.378, 0.149600,  0.36526}, /* earth */
    {   3.397, 0.227940,  0.68698}, /* mars */
    {  71.492, 0.778330,  4.33271}, /* jupiter */
    {  60.268, 1.429400, 10.75950}, /* saturn */
    {  25.559, 2.870990, 30.68500}, /* uranus*/
    {  24.766, 4.504300, 60.19000}, /* neptune */
    {   1.150, 5.913520, 90.55000}  /* pluto */
};

LsgGroup* scene;
LsgPerspectiveCam* camera;

void display(void) {
    LsgFrustum viewfrustum;
    int error;
    
    LsgFrustum_init(&viewfrustum, matrix_identity, matrix_identity);
    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    /* reset viewing matrizes */
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    /* display the scene */
    camera->super.display((LsgCamera*)camera, &viewfrustum, (LsgNode*)scene);
    
    /* force rendering of cached geometry */
    glFlush();
    glutSwapBuffers();
    
    if ((error = glGetError()) != GL_NO_ERROR) {
        printf("%s\n", gluErrorString(error));
    }
}

void reshape(int w, int h) {
    float aspect = (float)w / (float)h;
    
    camera->aspect = aspect;
    glViewport(0, 0, w, h);
}

void animate(int time) {
    float now = (float)time / 1000.0;
    
    scene->super.update((LsgNode*)scene, now);
    scene->super.clean((LsgNode*)scene);
    
    glutTimerFunc(1000 / 25, animate, time + 1000 / 25);
    glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case  27:
        case 'q':
        case 'Q':
            exit(0);
    }
}

float color_diff[4] = {0.4, 0.4, 0.4, 1.0};
float color_spec[4] = {0.7, 0.7, 0.7, 1.0};
float color_shine   = 50;

void init_video(void) {
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutCreateWindow("lescegra example: solar system");
    
    glClearColor(0.0, 0.0, 0.0, 0.0);
    
    glEnable(GL_DEPTH_TEST);
    
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);

    glutTimerFunc(0, animate, 0);
    
    glutKeyboardFunc(keyboard);
}

Vertex axis_y = {0.0, 1.0, 0.0};

#define SCALE_TIME   0.365 / 5.0
#define SCALE_ORBIT  1.0
#define SCALE_RADIUS 0.001

void init_scene(void) {
    LsgGLList* sphere;
    AnimatedRotate* rot;
    LsgTransform* mov;
    
    int planet;
  
    /* create the camera */
    camera = LsgPerspectiveCam_create();
    vertex_assign(camera->location, 3.0, 30.0, 5.0);
    vertex_assign(camera->lookat,   0.0, 0.0, 0.0);
    vertex_assign(camera->up,       0.0, 1.0, 0.0);
    camera->dmin   =   1.0;
    camera->dmax   = 100.0;
    camera->fovy   =  30.0;
    camera->aspect =   1.0;

    /* create the scene container */
    scene = LsgGroup_create();
    
    /* sphere */
    sphere = LsgGLList_create();
    glNewList(sphere->list, GL_COMPILE);
    glBegin(GL_POINTS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex3f(0.0, 0.0, 0.0);
    glEnd();
    glEndList();

    for (planet = 1; planet < PLANET_COUNT; ++planet) {
        mov = LsgTransform_create();
        matrix_load_translate(mov->tm, planets[planet].orbit * SCALE_ORBIT, 0.0, 0.0);
        LsgList_append(mov->super.children, sphere);

        rot = AnimatedRotate_create(axis_y, 2.0 * M_PI / (planets[planet].orbit_period / SCALE_TIME), 0.0);
        LsgList_append(rot->super.children, mov);

        LsgList_append(scene->children, rot);
    }
}

int main(int argc, char* argv[]) {
    glutInit(&argc, argv);
    
    init_video();

    init_scene();
    
    glutMainLoop();
    
    return 0;
}
