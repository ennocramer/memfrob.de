#include <lescegra/util/image.h>

#include <stdlib.h>
#include <stdio.h>

#define PCX_MAGIC 10
#define PCX_ENCODING_RUNLENGTH 1

typedef struct {
    unsigned char manufacturer; /* magic: 10 */
    unsigned char version;
    unsigned char encoding;     /* const 1, pcq run length encoding */
    unsigned char bpp;
    unsigned short int dimension[4];
    unsigned short int dpi[2];
    unsigned char colormap[48];
    unsigned char reserved;     /* should be 0 */
    unsigned char planes;       /* number of color planes */
    unsigned short int bpl;     /* buffersize needed to store one scanline colorplane */
    unsigned short int palette;
    unsigned short int screen_size[2];
    unsigned char filler[54];
} PCXHeader;

LsgImage* LsgImage_loadPCX(const char* filename) {
    FILE* file;
    
    PCXHeader header;
    unsigned char* palette = NULL;
    int w, h, i;
    int count;
    int buffer;
    
    LsgImage* image;
    
    /* open file */
    if (!(file = fopen(filename, "r"))) {
        fprintf(stderr, "%s: Could not open file\n", filename);
        return NULL;
    }
    
    /* read header */
    if (fread(&header, sizeof(PCXHeader), 1, file) != 1) {
        fprintf(stderr, "%s: Could not read PCX Header\n", filename);
        fclose(file);
        return NULL;
    }
    
    /* check magic & version */
    if ((header.manufacturer != PCX_MAGIC) || (header.version != 5) || (header.bpp != 8)) {
        fprintf(stderr, "%s: Invalid/Unsupported file format\n", filename);
        fclose(file);
        return NULL;
    }
    
    /* read color palette */
    if ((header.version == 5) && (header.planes == 1)) {
        fseek(file, -769, SEEK_END);
        if (fgetc(file) == 12) {
            if (!(palette = (unsigned char*)malloc(sizeof(unsigned char) * 256 * 3))) {
                fprintf(stderr, "%s: Out of memory\n", filename);
                fclose(file);
                return NULL;
            }
            if (fread(palette, sizeof(unsigned char), 256 * 3, file) != 256 * 3) {
                fprintf(stderr, "%s: Error reading palette\n", filename);
                free(palette);
                fclose(file);
                return NULL;
            }
        }
    }
    
    w = header.dimension[2] - header.dimension[0] + 1;
    h = header.dimension[3] - header.dimension[1] + 1;
    
    /* read and convert image data */
    fseek(file, sizeof(PCXHeader), SEEK_SET);
    
    /* 256 color palette image */
    if ((header.planes == 1) && palette) {
        if (!(image = LsgImage_create(w, h, IMAGE_RGB))) {
            fprintf(stderr, "%s: Out of memory\n", filename);
            if (palette) free(palette);
            fclose(file);
            return NULL;
        }
        i = 0;
        while(i < w * h * 3) {
            count = 1;
            buffer = fgetc(file);
            if ((buffer & 192) == 192) {
                count = buffer & ~192;
                buffer = fgetc(file);
            }
            while (count-- > 0) {
                image->data[i++] = palette[buffer * 3 + 0];
                image->data[i++] = palette[buffer * 3 + 1];
                image->data[i++] = palette[buffer * 3 + 2];
            }
        }
        
    /* 8bit color planes */
    } else if (header.bpp == 8) {
        if (!(image = LsgImage_create(w, h, header.planes))) {
            fprintf(stderr, "%s: Out of memory\n", filename);
            if (palette) free(palette);
            fclose(file);
            return NULL;
        }
        for (h = 0; h < image->height; ++h) {       /* lines */
            for (i = 0; i < header.planes; ++i) {   /* planes */
                w = 0;
                while (w < image->width) {          /* pixel color plane */
                    count = 1;
                    buffer = fgetc(file);
                    if ((buffer & 192) == 192) {
                        count = buffer & ~192;
                        buffer = fgetc(file);
                    }
                    while (count-- > 0) {
                        image->data[(h * image->width + w++) * header.planes + i] = buffer;
                    }
                }
            }
        }

    /* uhhhh */
    } else {
        fprintf(stderr, "%s: Usupported image format\n", filename);
        if (palette) free(palette);
        fclose(file);
        return NULL;
    }
    
    if (palette) free(palette);
    fclose(file);
    
    return image;
}
