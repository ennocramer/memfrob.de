#include <lescegra/util/frustum.h>

#include <stdlib.h>
#include <math.h>

LsgFrustum* LsgFrustum_create(const Matrix projection, const Matrix modelview) {
    LsgFrustum* self = (LsgFrustum*)malloc(sizeof(LsgFrustum));
    
    LsgFrustum_init(self, projection, modelview);
    
    return self;
}

void LsgFrustum_init(LsgFrustum* self, const Matrix projection, const Matrix modelview) {
    LsgObject_init(&self->super);
    
    matrix_copy(self->projection, projection);
    matrix_copy(self->modelview, modelview);
    
    LsgFrustum_updatePlanes(self);
}

void LsgFrustum_transform(LsgFrustum* self, const Matrix projection, const Matrix modelview) {
    matrix_mult(self->projection, projection);
    matrix_mult(self->modelview, modelview);
    
    LsgFrustum_updatePlanes(self);
}

static void normalize_plane(LsgPlane* p);

void LsgFrustum_updatePlanes(LsgFrustum* self) {
    Matrix m;
    
    matrix_copy(m, self->projection);
    matrix_mult(m, self->modelview);
    
	self->planes[0].normal[0] = m[ 3] - m[ 0];
	self->planes[0].normal[1] = m[ 7] - m[ 4];
	self->planes[0].normal[2] = m[11] - m[ 8];
	self->planes[0].distance  = m[15] - m[12];
	normalize_plane(&self->planes[0]);

    self->planes[1].normal[0] = m[ 3] + m[ 0];
	self->planes[1].normal[1] = m[ 7] + m[ 4];
	self->planes[1].normal[2] = m[11] + m[ 8];
	self->planes[1].distance  = m[15] + m[12];
    normalize_plane(&self->planes[1]);

	self->planes[2].normal[0] = m[ 3] + m[ 1];
	self->planes[2].normal[1] = m[ 7] + m[ 5];
	self->planes[2].normal[2] = m[11] + m[ 9];
	self->planes[2].distance  = m[15] + m[13];
	normalize_plane(&self->planes[2]);

	self->planes[3].normal[0] = m[ 3] - m[ 1];
	self->planes[3].normal[1] = m[ 7] - m[ 5];
	self->planes[3].normal[2] = m[11] - m[ 9];
	self->planes[3].distance  = m[15] - m[13];
	normalize_plane(&self->planes[3]);

	self->planes[4].normal[0] = m[ 3] - m[ 2];
	self->planes[4].normal[1] = m[ 7] - m[ 6];
	self->planes[4].normal[2] = m[11] - m[10];
	self->planes[4].distance  = m[15] - m[14];
	normalize_plane(&self->planes[4]);

	self->planes[5].normal[0] = m[ 3] + m[ 2];
	self->planes[5].normal[1] = m[ 7] + m[ 6];
	self->planes[5].normal[2] = m[11] + m[10];
	self->planes[5].distance  = m[15] + m[14];
	normalize_plane(&self->planes[5]);
}

static void normalize_plane(LsgPlane* p) {
    float scale = 1.0 / vertex_length(p->normal);
    
    vertex_scale(p->normal, scale);
    p->distance *= scale;
}
