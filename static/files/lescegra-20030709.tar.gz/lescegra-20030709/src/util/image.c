#include <lescegra/util/image.h>

#include <stdlib.h>

LsgImage* LsgImage_create(int width, int height, int bpp) {
    LsgImage* self = (LsgImage*)malloc(sizeof(LsgImage));
    
    LsgImage_init(self, width, height, bpp);
    
    return self;
}

void LsgImage_init(LsgImage* self, int width, int height, int bpp) {
    LsgObject_init(&self->super);
    
    ((LsgObject*)self)->destroy = (void (*)(LsgObject*))LsgImage_destroy;

    self->width = width;
    self->height = height;
    self->bpp = bpp;
    
    self->data = (unsigned char*)malloc(sizeof(unsigned char) * width * height * bpp);
}

void LsgImage_destroy(LsgImage* self) {
    free(self->data);
    
    LsgObject_destroy(&self->super);
}
