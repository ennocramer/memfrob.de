#include <lescegra/particle/gravity.h>

#include <lescegra/particle/particle.h>

#include <stdlib.h>

LsgGravity* LsgGravity_create(float now) {
    LsgGravity* self = (LsgGravity*)malloc(sizeof(LsgGravity));
    
    LsgGravity_init(self, now);
    
    return self;
}

void LsgGravity_init(LsgGravity* self, float now) {
    LsgParticleModifier_init(&self->super);
    
    ((LsgParticleModifier*)self)->update = (void (*)(LsgParticleModifier*, LsgList*, float))LsgGravity_update;
    
    vertex_assign(self->location, 0.0, 0.0, 0.0);
    self->mass = 1.0;
    self->time = now;
}

void LsgGravity_update(LsgGravity* self, LsgList* particles, float now) {
    Vertex diff;
    float dist;
    LsgIterator* it;
    
    it = LsgIterator_create(particles);
    while (LsgIterator_hasNext(it)) {
        LsgParticle* p = (LsgParticle*)LsgIterator_next(it);
        
        vertex_copy(diff, self->location);
        vertex_sub(diff, p->location);
        
        dist = vertex_length(diff);
        vertex_scale(diff, self->mass / (dist * dist * dist));
        
        vertex_add(p->speed, diff);
    }
    LsgObject_free((LsgObject*)it);
}
