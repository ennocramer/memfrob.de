#include <lescegra/particle/particlemodifier.h>

#include <stdlib.h>

void LsgParticleModifier_init(LsgParticleModifier* self) {
    LsgObject_init(&self->super);
    
    self->update = NULL;
}
