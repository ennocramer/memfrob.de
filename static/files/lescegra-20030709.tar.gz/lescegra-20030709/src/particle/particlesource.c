#include <lescegra/particle/particlesource.h>

#include <lescegra/util/random.h>

#include <stdlib.h>

LsgParticleSource* LsgParticleSource_create(LsgParticleGenerator generator, float now) {
    LsgParticleSource* self = (LsgParticleSource*)malloc(sizeof(LsgParticleSource));
    
    LsgParticleSource_init(self, generator, now);
    
    return self;
}

void LsgParticleSource_init(LsgParticleSource* self, LsgParticleGenerator generator, float now) {
    LsgParticleModifier_init(&self->super);
    
    ((LsgParticleModifier*)self)->update = (void (*)(LsgParticleModifier*, LsgList*, float))LsgParticleSource_update;
    
    self->generator = generator;
    vertex_assign(self->location, 0.0, 0.0, 0.0);
    vertex_assign(self->location_error, 0.0, 0.0, 0.0);
    vertex_assign(self->speed, 0.0, 0.0, 0.0);
    vertex_assign(self->speed_error, 0.0, 0.0, 0.0);
    self->birth_rate = 10.0;
    self->birth_rate_error = 0.0;
    self->lifetime = 1.0;
    self->lifetime_error = 0.0;
    self->time = now;
}

void LsgParticleSource_update(LsgParticleSource* self, LsgList* particles, float now) {
    Vertex error;
    float dt, lifetime, birth;
    int i;

    for (i = 0; i < LsgList_count(particles); ) {
        LsgParticle* p = (LsgParticle*)LsgList_get(particles, i);
        lifetime = random_range(self->lifetime, self->lifetime_error);
        if ((now - p->birth) > lifetime) {
            LsgList_remove(particles, i);
        } else {
            ++i;
        }
    }
    
    dt = now - self->time;
    
    if (self->generator) {
        birth = random_range(self->birth_rate, self->birth_rate_error) * dt;
        while (random() < birth) {
            LsgParticle* p = self->generator(now);
            vertex_assign(error, random_error(), random_error(), random_error());
            vertex_mul(error, self->location_error);
            vertex_add(p->location, error);

            vertex_assign(error, random_error(), random_error(), random_error());
            vertex_mul(error, self->speed_error);
            vertex_add(p->speed, error);

            LsgList_append(particles, p);
            birth -= 1.0;
        }
    }
    
    self->time = now;
}
