#include <lescegra/sg/terrain.h>

#include <GL/gl.h>

#include <stdlib.h>

LsgTerrain* LsgTerrain_create(LsgImage* hf, Vertex dim) {
    LsgTerrain* self = (LsgTerrain*)malloc(sizeof(LsgTerrain));

    LsgTerrain_init(self, hf, dim);

    return self;
}

#define NEXT(val, mod) (((val) + 1) % (mod))
#define PREV(val, mod) (((val) + (mod) - 1) % (mod))

void LsgTerrain_init(LsgTerrain* self, LsgImage* hf, Vertex dim) {
    Vertex* precalc;
    Vertex scale, offset;
    Vertex n;
    float dx, dz;
    int x, y, z, i;
    int idx_src, idx_dst;

    LsgGLList_init(&self->super);

    /* precalculate image -> float array */
    /* TODO: maybe combine scale/offset into a transformation matrix
     *       or do the offset in integer domain using height/width div 2 */
    precalc = (Vertex*)malloc(sizeof(Vertex) * hf->width * hf->height);

    scale[0] = dim[0] / (float)hf->width;
    scale[2] = dim[2] / (float)hf->height;
    for (scale[1] = dim[1], i = 0; i < hf->bpp; ++i) {
        scale[1] /= 256.0;
    }

    vertex_copy(offset, dim);
    vertex_scale(offset, -0.5);

    idx_src = idx_dst = -1;
    for (z = 0; z < hf->height; ++z) {
        for (x = 0; x < hf->width; ++x) {
            for (y = 0, i = 0; i < hf->bpp; ++i) {
                y <<= 8;
                y += hf->data[++idx_src];
            }

            ++idx_dst;
            vertex_assign(precalc[idx_dst], (float)x, (float)y, (float)z);
            vertex_mul(precalc[idx_dst], scale);
            vertex_add(precalc[idx_dst], offset);
        }
    }

    /* convert float array -> gllist */
    dx = dim[0] / (float)hf->width;
    dz = dim[2] / (float)hf->height;
    
    glNewList(self->super.list, GL_COMPILE);
    for (z = 0; z < hf->height - 1; ++z) {
        glBegin(GL_TRIANGLE_STRIP);
        for (x = 0; x < hf->width; ++x) {
            for (i = 0; i < 2; ++i) {
                vertex_assign(n, 
                        -dz * (precalc[(z+i) * hf->width + NEXT(x, hf->width)][1] - precalc[(z+i) * hf->width + PREV(x, hf->width)][1]),
                        dx * dz,
                        -dx * (precalc[NEXT(z+i, hf->height) * hf->width + x][1] - precalc[PREV(z+i, hf->height) * hf->width + x][1]));
                vertex_normalize(n);

                glNormal3fv(n);
                glVertex3fv(precalc[(z+i) * hf->width + x]);
            }
        }
        glEnd();
    }

    glEndList();

    free(precalc);
}
