#include <lescegra/sg/group.h>

#include <stdlib.h>
#include <float.h>

LsgGroup* LsgGroup_create(void) {
    LsgGroup* self = (LsgGroup*)malloc(sizeof(LsgGroup));
    
    LsgGroup_init(self);
    
    return self;
}

void LsgGroup_init(LsgGroup* self) {
    LsgNode_init(&self->super);
    
    ((LsgObject*)self)->destroy = (void (*)(LsgObject*))LsgGroup_destroy;
    
    ((LsgNode*)self)->clean   = (void (*)(LsgNode*))LsgGroup_clean;
    ((LsgNode*)self)->update  = (void (*)(LsgNode*, float))LsgGroup_update;
    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))LsgGroup_display;
    ((LsgNode*)self)->collide = (int  (*)(LsgNode*, Vertex, Vertex))LsgGroup_collide;
    
    self->children = LsgList_create();
}

void LsgGroup_clean(LsgGroup* self) {
    LsgIterator* it;
    
    it = LsgIterator_create(self->children);
    while (LsgIterator_hasNext(it)) {
        LsgNode* child = (LsgNode*)LsgIterator_next(it);
        child->clean(child);
    }
    LsgObject_free((LsgObject*)it);
    
    LsgNode_clean(&self->super);
}

void LsgGroup_update(LsgGroup* self, float now) {
    LsgIterator* it;
    
    it = LsgIterator_create(self->children);
    while (LsgIterator_hasNext(it)) {
        LsgNode* child = (LsgNode*)LsgIterator_next(it);
        child->update(child, now);
        self->super.dirty = self->super.dirty || child->dirty;
    }
    LsgObject_free((LsgObject*)it);
    
    if (self->super.dirty) {
        LsgBBox_clear(self->super.bbox);

        if (LsgList_count(self->children) > 0) {
            it = LsgIterator_create(self->children);
            do {
                LsgNode* child = (LsgNode*)LsgIterator_next(it);
                LsgBBox_combine(self->super.bbox, child->bbox);
            } while (self->super.bbox->valid && LsgIterator_hasNext(it));
            LsgObject_free((LsgObject*)it);
        }
    }
    
    LsgNode_update(&self->super, now);
}

void LsgGroup_display(LsgGroup* self, LsgFrustum* frust) {
    LsgIterator* it = LsgIterator_create(self->children);
    while (LsgIterator_hasNext(it)) {
        LsgNode* child = (LsgNode*)LsgIterator_next(it);
        if (LsgBBox_visible(child->bbox, frust)) child->display(child, frust);
    }
    LsgObject_free((LsgObject*)it);
    
    LsgNode_display(&self->super, frust);
}

int  LsgGroup_collide(LsgGroup* self, Vertex v, Vertex nearest) {
    LsgIterator* it;
    Vertex tmp_nearest, tmp_dist;
    float distance = FLT_MAX, d;
    int ret = 0;
    
    /* early return if no nearest vertex is wanted and there is no collision
     * with the group bbox */
    if (!(nearest || LsgNode_collide(&self->super, v, NULL))) {
        return 0;
    }
    
    it = LsgIterator_create(self->children);
    while (LsgIterator_hasNext(it)) {
        LsgNode* child = (LsgNode*)LsgIterator_next(it);
        
        if (nearest) {
            ret = ret || child->collide(child, v, tmp_nearest);
        
            vertex_copy(tmp_dist, tmp_nearest);
            vertex_sub(tmp_dist, v);
            d = vertex_length(tmp_dist);
            if (d < distance) {
                vertex_copy(nearest, tmp_nearest);
                distance = d;
            }
        } else {
            ret = ret || child->collide(child, v, NULL);
        }
    }
    LsgObject_free((LsgObject*)it);
    
    return ret;
}

void LsgGroup_destroy(LsgGroup* self) {
    /* TODO: think of a good way to deallocate graphs
    LsgIterator* it = LsgIterator_create(self->children);
    while (LsgIterator_hasNext(it)) {
        LsgObject* child = (LsgObject*)LsgIterator_next(it);
        LsgObject_free(child);
    }
    LsgObject_free((LsgObject*)it);
    */
        
    LsgObject_free((LsgObject*)self->children);

    LsgNode_destroy(&self->super);    
}
