#include <lescegra/sg/perspectivecam.h>

#include <GL/gl.h>
#include <GL/glu.h>

#include <stdlib.h>

#ifndef M_PI
# define M_PI		3.14159265358979323846	/* pi */
#endif

LsgPerspectiveCam* LsgPerspectiveCam_create(void) {
    LsgPerspectiveCam* self = (LsgPerspectiveCam*)malloc(sizeof(LsgPerspectiveCam));
    
    LsgPerspectiveCam_init(self);
    
    return self;
}

void LsgPerspectiveCam_init(LsgPerspectiveCam* self) {
    LsgCamera_init(&self->super);
    
    ((LsgCamera*)self)->display = (void (*)(LsgCamera*, LsgFrustum*, LsgNode*))LsgPerspectiveCam_display;
    
    vertex_assign(self->location, 0.0, 0.0, -1.0);
    vertex_assign(self->lookat,   0.0, 0.0, 0.0);
    vertex_assign(self->up,       0.0, 1.0, 0.0);
    
    self->fovy   = 45.0;
    self->aspect = 1.0;
    self->dmin   = 0.01;
    self->dmax   = 10.0;
}

void LsgPerspectiveCam_display(LsgPerspectiveCam* self, LsgFrustum* frust, LsgNode* node) {
    LsgFrustum nfrust;
    Matrix tp, tmv;
    
    /* calculate new view frustum */
    matrix_load_perspective(tp, self->fovy * M_PI / 180.0, self->aspect, self->dmin, self->dmax);
    matrix_load_lookat(tmv, self->location, self->lookat, self->up);
    matrix_premult(tp, frust->projection);
    matrix_premult(tmv, frust->modelview);
    
    LsgFrustum_init(&nfrust, tp, tmv);
    
    /* transform opengl projection and modelview matrices */
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    gluPerspective(self->fovy, self->aspect, self->dmin, self->dmax);

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    gluLookAt(self->location[0], self->location[1], self->location[2],
              self->lookat[0],   self->lookat[1],   self->lookat[2],
              self->up[0],       self->up[1],       self->up[2]);
    
    /* display children via groupnode_display */
    node->display(node, &nfrust);

    /* restore opengl projection and modelview matrices */    
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
}
