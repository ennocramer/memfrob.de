#include <lescegra/sg/observercam.h>

#include <GL/gl.h>
#include <GL/glu.h>

#include <stdlib.h>

#ifndef M_PI
# define M_PI		3.14159265358979323846	/* pi */
#endif

LsgObserverCam* LsgObserverCam_create(void) {
    LsgObserverCam* self = (LsgObserverCam*)malloc(sizeof(LsgObserverCam));
    
    LsgObserverCam_init(self);
    
    return self;
}

void LsgObserverCam_init(LsgObserverCam* self) {
    LsgCamera_init(&self->super);
    
    ((LsgCamera*)self)->display = (void (*)(LsgCamera*, LsgFrustum*, LsgNode*))LsgObserverCam_display;
    
    vertex_assign(self->location, 0.0, 0.0, -1.0);
    vertex_assign(self->heading,  0.0, 0.0, 1.0);
    vertex_assign(self->up,       0.0, 1.0, 0.0);
    
    self->fovy   = 45.0;
    self->aspect = 1.0;
    self->dmin   = 0.01;
    self->dmax   = 10.0;
}

void LsgObserverCam_display(LsgObserverCam* self, LsgFrustum* frust, LsgNode* node) {
    LsgFrustum nfrust;
    Matrix tp, tmv;
    Vertex lookat;
    
    vertex_copy(lookat, self->location);
    vertex_add(lookat, self->heading);
    
    /* calculate new view frustum */
    matrix_load_perspective(tp, self->fovy * M_PI / 180.0, self->aspect, self->dmin, self->dmax);
    matrix_load_lookat(tmv, self->location, lookat, self->up);
    matrix_premult(tp, frust->projection);
    matrix_premult(tmv, frust->modelview);
    
    LsgFrustum_init(&nfrust, tp, tmv);
    
    /* transform opengl projection and modelview matrices */
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    gluPerspective(self->fovy, self->aspect, self->dmin, self->dmax);

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    gluLookAt(self->location[0], self->location[1], self->location[2],
              lookat[0],         lookat[1],         lookat[2],
              self->up[0],       self->up[1],       self->up[2]);
    
    /* display children via LsgNode_display */
    node->display(node, &nfrust);

    /* restore opengl projection and modelview matrices */    
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
}
