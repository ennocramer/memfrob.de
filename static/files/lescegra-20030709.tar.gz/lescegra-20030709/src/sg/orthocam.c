#include <lescegra/sg/orthocam.h>

#include <GL/gl.h>

#include <stdlib.h>

LsgOrthoCam* LsgOrthoCam_create(void) {
    LsgOrthoCam* self = (LsgOrthoCam*)malloc(sizeof(LsgOrthoCam));
    
    LsgOrthoCam_init(self);
    
    return self;
}

void LsgOrthoCam_init(LsgOrthoCam* self) {
    LsgCamera_init(&self->super);
    
    ((LsgCamera*)self)->display = (void (*)(LsgCamera*, LsgFrustum*, LsgNode*))LsgOrthoCam_display;
    
    vertex_assign(self->min, -1.0, -1.0, -1.0);
    vertex_assign(self->max,  1.0,  1.0,  1.0);
}

void LsgOrthoCam_display(LsgOrthoCam* self, LsgFrustum* frust, LsgNode* node) {
    LsgFrustum nfrust;
    Matrix tp;
    
    /* calculate new view frustum */
    matrix_load_ortho(tp, self->min[0], self->max[0], self->min[1], self->max[1], self->min[2], self->max[2]);
    matrix_premult(tp, frust->projection);
    
    LsgFrustum_init(&nfrust, tp, frust->modelview);
    
    /* transform opengl projection matrix */
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glOrtho(self->min[0], self->max[0], self->min[1], self->max[1], self->min[2], self->max[2]);
    
    glMatrixMode(GL_MODELVIEW);
    
    node->display(node, &nfrust);
    
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    
    glMatrixMode(GL_MODELVIEW);
}
