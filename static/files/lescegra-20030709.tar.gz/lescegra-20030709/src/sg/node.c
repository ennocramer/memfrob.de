#include <lescegra/sg/node.h>

#ifdef DEBUG_BBOX
#include <GL/gl.h>
#endif

void LsgNode_init(LsgNode* self) {
    LsgObject_init(&self->super);
    
    self->super.destroy = (void (*)(LsgObject*))LsgNode_destroy;
    
    self->bbox    = LsgBBox_create();
    self->dirty   = 1;
    self->clean   = LsgNode_clean;
    self->update  = LsgNode_update;
    self->display = LsgNode_display;
    self->collide = LsgNode_collide;
}

void LsgNode_clean(LsgNode* self) {
    self->dirty = 0;
}

void LsgNode_update(LsgNode* self, float now) {
    /* self->dirty = 1; */
}

void LsgNode_display(LsgNode* self, LsgFrustum* frust) {
#ifdef DEBUG_BBOX
    if (self->bbox->valid) {
        glPushAttrib(GL_ENABLE_BIT);
        glDisable(GL_LIGHTING);
        glDisable(GL_NORMALIZE);
        glDisable(GL_TEXTURE_2D);

        glColor3f(1.0, 1.0, 0.0);

        glBegin(GL_LINES);
            glVertex3f(self->bbox->min[0], self->bbox->min[1], self->bbox->min[2]);
            glVertex3f(self->bbox->min[0], self->bbox->min[1], self->bbox->max[2]);

            glVertex3f(self->bbox->min[0], self->bbox->min[1], self->bbox->min[2]);
            glVertex3f(self->bbox->min[0], self->bbox->max[1], self->bbox->min[2]);

            glVertex3f(self->bbox->min[0], self->bbox->min[1], self->bbox->min[2]);
            glVertex3f(self->bbox->max[0], self->bbox->min[1], self->bbox->min[2]);

            glVertex3f(self->bbox->min[0], self->bbox->min[1], self->bbox->max[2]);
            glVertex3f(self->bbox->min[0], self->bbox->max[1], self->bbox->max[2]);

            glVertex3f(self->bbox->min[0], self->bbox->min[1], self->bbox->max[2]);
            glVertex3f(self->bbox->max[0], self->bbox->min[1], self->bbox->max[2]);

            glVertex3f(self->bbox->min[0], self->bbox->max[1], self->bbox->min[2]);
            glVertex3f(self->bbox->min[0], self->bbox->max[1], self->bbox->max[2]);

            glVertex3f(self->bbox->min[0], self->bbox->max[1], self->bbox->min[2]);
            glVertex3f(self->bbox->max[0], self->bbox->max[1], self->bbox->min[2]);

            glVertex3f(self->bbox->max[0], self->bbox->min[1], self->bbox->min[2]);
            glVertex3f(self->bbox->max[0], self->bbox->min[1], self->bbox->max[2]);

            glVertex3f(self->bbox->max[0], self->bbox->min[1], self->bbox->min[2]);
            glVertex3f(self->bbox->max[0], self->bbox->max[1], self->bbox->min[2]);

            glVertex3f(self->bbox->min[0], self->bbox->max[1], self->bbox->max[2]);
            glVertex3f(self->bbox->max[0], self->bbox->max[1], self->bbox->max[2]);

            glVertex3f(self->bbox->max[0], self->bbox->min[1], self->bbox->max[2]);
            glVertex3f(self->bbox->max[0], self->bbox->max[1], self->bbox->max[2]);

            glVertex3f(self->bbox->max[0], self->bbox->max[1], self->bbox->min[2]);
            glVertex3f(self->bbox->max[0], self->bbox->max[1], self->bbox->max[2]);
        glEnd();

        glPopAttrib();    
    }
#endif
}

int  LsgNode_collide(LsgNode* self, Vertex v, Vertex nearest) {
    if (self->bbox->valid) {
        if (nearest) LsgBBox_nearest(self->bbox, v, nearest);
        return LsgBBox_contains(self->bbox, v);
    } else {
        return 0;
    }
}

void LsgNode_destroy(LsgNode* self) {
    LsgObject_free((LsgObject*)self->bbox);
    
    LsgObject_free(&self->super);
}
