#include <lescegra/sg/light.h>

#include <GL/gl.h>

#include <stdlib.h>

LsgLight* LsgLight_create(int num) {
    LsgLight* self;
    
    self = (LsgLight*)malloc(sizeof(LsgLight));
    LsgLight_init(self, num);
    
    return self;
}

void LsgLight_init(LsgLight* self, int num) {
    LsgNode_init(&self->super);
    
    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))LsgLight_display;

    self->num = num;
    self->color[0] = self->color[1] = self->color[2] = self->color[3] = 1.0;
    self->location[0] = self->location[1] = self->location[2] = self->location[3] = 0.0;
}

void LsgLight_display(LsgLight* self, LsgFrustum* frust) {
    glLightfv(self->num, GL_POSITION, self->location);

    glLightfv(self->num, GL_DIFFUSE, self->color);
    glLightfv(self->num, GL_SPECULAR, self->color);
    
    LsgNode_display(&self->super, frust);
}

void LsgLight_enable(LsgLight* self) {
    glEnable(self->num);
}

void LsgLight_disable(LsgLight* self) {
    glDisable(self->num);
}
