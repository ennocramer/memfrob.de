#include <lescegra/sg/fog.h>

#include <GL/gl.h>

#include <stdlib.h>

LsgFog* LsgFog_create(enum LsgFogType type) {
    LsgFog* self = (LsgFog*)malloc(sizeof(LsgFog));
    
    LsgFog_init(self, type);
    
    return self;
}

void LsgFog_init(LsgFog* self, enum LsgFogType type) {
    LsgGroup_init(&self->super);
    
    ((LsgNode*)self)->display = (void (*)(LsgNode*, LsgFrustum*))LsgFog_display;
    
    self->type = type;
    vertex_assign(self->color, 0.0, 0.0, 0.0); self->color[3] = 1.0;
    self->start =  0.0;
    self->end   = 10.0;
    self->density = 1.0;
}

void LsgFog_display(LsgFog* self, LsgFrustum* frust) {
    glPushAttrib(GL_FOG_BIT);

    glFogfv(GL_FOG_COLOR, self->color);
        
    if (self->type == FOG_LINEAR) {
        glFogi(GL_FOG_MODE, GL_LINEAR);
        glFogf(GL_FOG_START, self->start);
        glFogf(GL_FOG_END, self->end);
    } else {
        glFogi(GL_FOG_MODE, self->type == FOG_EXP ? GL_EXP : GL_EXP2);
        glFogf(GL_FOG_DENSITY, self->density);
    }
    
    LsgGroup_display(&self->super, frust);
    
    glPopAttrib();
}

