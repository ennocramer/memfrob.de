#include <lescegra/sg/sine_anim.h>

#include <stdlib.h>
#include <math.h>

SineAnim* sine_anim_create(float* target, float omega, float phi, float amp, float offs) {
    SineAnim* self = (SineAnim*)malloc(sizeof(SineAnim));
    
    sine_anim_init(self, target, omega, phi, amp, offs);
    
    return self;
}

void sine_anim_init(SineAnim* self, float* target, float omega, float phi, float amp, float offs) {
    node_init(&self->super);
    
    ((Node*)self)->update = (void (*)(Node*, float))sine_anim_update;
    
    self->target = target;
    self->omega = omega;
    self->phi = phi;
    self->amplitude = amp;
    self->offset = offs;
}

void sine_anim_update(SineAnim* self, float time) {
    *(self->target) = self->offset + self->amplitude * sin(self->omega * time + self->phi);
}
