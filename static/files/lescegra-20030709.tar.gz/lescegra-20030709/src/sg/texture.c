#include <lescegra/sg/texture.h>

#include <GL/gl.h>

#include <stdlib.h>

LsgTexture* LsgTexture_create(LsgImage* data, int type, unsigned int mode, unsigned int unit) {
    LsgTexture* self = (LsgTexture*)malloc(sizeof(LsgTexture));
    
    LsgTexture_init(self, data, type, mode, unit);
    
    return self;
}

void LsgTexture_init(LsgTexture* self, LsgImage* data, int type, unsigned int mode, unsigned int unit) {
    LsgGroup_init(&self->super);
    
    ((LsgObject*)self)->destroy = (void (*)(LsgObject*))LsgTexture_destroy;
    
    ((LsgNode*)self)->display   = (void (*)(LsgNode*, LsgFrustum*))LsgTexture_display;
    
    self->mode = mode;
    self->unit = unit;
    
    glGenTextures(1, &self->id);
    if (unit) glActiveTextureARB(unit);
    glBindTexture(GL_TEXTURE_2D, self->id);
    
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    
    glTexImage2D(GL_TEXTURE_2D, 0, data->bpp, data->width, data->height, 0,
            type, GL_UNSIGNED_BYTE, data->data);
}

void LsgTexture_display(LsgTexture* self, LsgFrustum* frustum) {
    if (self->unit) glActiveTextureARB(self->unit);
    
    glPushAttrib(GL_TEXTURE_BIT);
    
    glBindTexture(GL_TEXTURE_2D, self->id);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, self->mode);
    
    LsgGroup_display(&self->super, frustum);
    
    glPopAttrib();
}

void LsgTexture_destroy(LsgTexture* self) {
    glDeleteTextures(1, &self->id);
}
