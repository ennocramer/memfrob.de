/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_IMAGE_H
#define LSG_IMAGE_H 1

#include <lescegra/util/object.h>

/**
 * \file  image.h
 * \brief Bitmap
 */

#define IMAGE_GRAYSCALE 1
#define IMAGE_RGB       3
#define IMAGE_RGBA      4

/**
 * \brief Bitmap
 *
 * A bitmap with a variable number of channel.
 * Every channel has a resolution of 8 bit per pixel.
 */
typedef struct {
    LsgObject super;
    int width;
    int height;
    int bpp;
    unsigned char* data;
} LsgImage;

/**
 * Allocate and initialize an image with the given resolution and number
 * of channels.
 * @param width     The width of the bitmap
 * @param height    The height of the bitmap
 * @param bpp       The number of channels
 * @return An image with the given width, height and number of channels
 */
LsgImage* LsgImage_create(int width, int height, int bpp);

void LsgImage_init(LsgImage* self, int width, int height, int bpp);
void LsgImage_destroy(LsgImage* self);

/**
 * Load an image stored in PCX format.
 * @param filename  The name of the PCX file
 * @return The bitmap stored in the file referenced by filename
 */
LsgImage* LsgImage_loadPCX(const char* filename);

/* LsgImage* LsgImage_loadTGA(const char* filename); */

#endif
