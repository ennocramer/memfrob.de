/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_FRUSTUM_H
#define LSG_FRUSTUM_H 1

/**
 * \file  frustum.h
 * \brief View Frustum
 */

#include <lescegra/util/object.h>

#include <lescegra/util/vertex.h>
#include <lescegra/util/matrix.h>

/**
 * \brief Clipping plane
 *
 * A view frustum clipping plane
 */
typedef struct {
    Vertex normal;
    float distance;
} LsgPlane;

/**
 * \brief View Frustum
 *
 * A view frustum defined by two matrizes (modelview and projection)
 * and the six clipping planes.
 */
typedef struct {
    LsgObject super;
    Matrix projection;
    Matrix modelview;
    LsgPlane planes[6];
} LsgFrustum;

/**
 * Allocate and initialize a view frustum.
 * @param projection    The projection matrix
 * @param modelview     The modelview matrix
 * @return The view frustum as defined by projection and modelview
 */
LsgFrustum* LsgFrustum_create(const Matrix projection, const Matrix modelview);

/**
 * Constructor method for LsgFrustum.
 * @param self          The instance variable
 * @param projection    The projection matrix
 * @param modelview     The modelview matrix
 */
void LsgFrustum_init(LsgFrustum* self, const Matrix projection, const Matrix modelview);

/**
 * Transform a view frustum.
 * @param self          The instance variable
 * @param projection    The transformation matrix for the projection matrix
 * @param modelview     The transformation matrix for the modelview matrix
 */
void LsgFrustum_transform(LsgFrustum* self, const Matrix projection, const Matrix modelview);

/**
 * Update the clipping planes after transforming the defining projection
 * and/or modelview matrix.
 * @param self          The instance variable
 */
void LsgFrustum_updatePlanes(LsgFrustum* self);

/**
 * The destructor method for LsgFrustum. Reuse parent implementation.
 */
#define LsgFrustum_destroy(self) LsgObject_destroy(&(self)->super)

#endif
