/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_LIST_H
#define LSG_LIST_H

/**
 * \file  list.h
 * \brief Linked list
 */

#include <lescegra/util/object.h>

typedef struct LsgListElement_s LsgListElement;
struct LsgListElement_s {
    LsgListElement* next;
    void* value;
};

/**
 * \ingroup util
 * \brief   Linked list
 *
 * A linked list
 */
typedef struct {
    LsgObject super;
    LsgListElement* first;
} LsgList;

/**
 * \brief LsgList iterator
 *
 * An LsgIterator for the LsgList
 */
typedef struct {
    LsgObject super;
    LsgListElement* element;
    int index;
} LsgIterator;

/**
 * You know the deal :)
 */
LsgList* LsgList_create(void);
void LsgList_init(LsgList* self);
unsigned int LsgList_count(const LsgList* self);
void LsgList_append(LsgList* self, void* data);
void LsgList_insert(LsgList* list, unsigned int index, void* data);
void LsgList_remove(LsgList* list, unsigned int index);
void LsgList_removeObject(LsgList* list, void* data);
void LsgList_empty(LsgList* list);
void* LsgList_set(LsgList* list, unsigned int index, void* data);
void* LsgList_get(const LsgList* list, unsigned int index);
void LsgList_destroy(LsgList* self);

LsgIterator* LsgIterator_create(const LsgList* list);
void LsgIterator_init(LsgIterator* self, const LsgList* list);
int LsgIterator_hasNext(const LsgIterator* self);
void* LsgIterator_next(LsgIterator* self);
int LsgIterator_index(const LsgIterator* self);

#endif

