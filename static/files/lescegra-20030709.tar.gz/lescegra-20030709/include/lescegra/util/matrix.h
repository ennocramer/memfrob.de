/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_MATRIX_H
#define LSG_MATRIX_H 1

/**
 * \file  matrix.h
 * \brief 4x4 Matrix
 */

#include <lescegra/util/vertex.h>

/**
 * \brief 4x4 matrix
 *
 * A 4x4 matrix
 */
typedef float Matrix[16];

/**
 * The identity matrix
 */
extern const Matrix matrix_identity;

/**
 * Reset a matrix to the identity.
 * @param m     The matrix to reset
 */
void matrix_load_identity(Matrix m);

/**
 * Create a translation matrix.
 * @param m     The destination matrix
 * @param x     The first translation component
 * @param y     The second translation component
 * @param z     The third translation component
 */
void matrix_load_translate(Matrix m, float x, float y, float z);

/**
 * Create a translation matrix from a vertex.
 * @param m     The destination matrix
 * @param v     The translation vertex
 */
void matrix_load_translatev(Matrix m, Vertex v);

/**
 * Create a scaling matrix.
 * @param m     The destination matrix
 * @param x     The first scaling component
 * @param y     The second scaling component
 * @param z     The third scaling component
 */
void matrix_load_scale(Matrix m, float x, float y, float z);

/**
 * Create a scaling matrix from a scaling vertex.
 * @param m     The destination matrix
 * @param v     The scaling vertex
 */
void matrix_load_scalev(Matrix m, Vertex v);

/**
 * Create a rotation matrix.
 */
void matrix_load_rotate(Matrix m, float x, float y, float z);
void matrix_load_rotatev(Matrix m, Vertex v);

/**
 * Create an orthogonal projection matrix.
 */
void matrix_load_ortho(Matrix m, float x1, float x2, float y1, float y2, float z1, float z2);

/**
 * Create a frustum projection matrix.
 */
void matrix_load_frustum(Matrix m, float x1, float x2, float y1, float y2, float z1, float z2);

/**
 * Create a perspective projection matrix.
 */
void matrix_load_perspective(Matrix m, float fovy, float aspect, float near, float far);

/**
 * Create a lookat matrix.
 */
void matrix_load_lookat(Matrix m, Vertex from, Vertex to, Vertex up);

/**
 * Create a pick matrix.
 */
void matrix_load_pick(Matrix m, float x, float y, float w, float h,
        float vp_x, float vp_y, float vp_w, float vp_h);

/**
 * Copy a matrix into another.
 * @param dst   The destination matrix
 * @param src   The source matrix
 */
void matrix_copy(Matrix dst, const Matrix src);

/**
 * Post-Multiply a matrix with another.
 * @param dst   The destination matrix
 * @param src   The source matrix
 */
void matrix_mult(Matrix dst, const Matrix src);

/**
 * Pre-Multiply a matrix with another.
 * @param dst   The destination matrix
 * @param src   The source matrix
 */
void matrix_premult(Matrix dst, const Matrix src);

/**
 * Transpose a matrix.
 * @param m     The matrix to transpose
 */
void matrix_transpose(Matrix m);

/**
 * Invert a matrix.
 * @param m     The matrix to invert
 */
void matrix_invert(Matrix m);

/**
 * Post-Multiply a matrix and a vertex.
 * v = M * v
 * @param m     The transformation matrix
 * @param v     The vertex to be transformed
 */
void matrix_apply(const Matrix m, Vertex v);

/**
 * Pre-Multiply a matrix and a vertex.
 * v = v * M
 * @param m     The transformation matrix
 * @param v     The vertex to be transformed
 */
void matrix_preapply(const Matrix m, Vertex v);

#endif
