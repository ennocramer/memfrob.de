/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_PARTICLE_H
#define LSG_PARTICLE_H 1

/**
 * \file  particle/particle.h
 * \brief Abstract particle base class
 */

#include <lescegra/sg/node.h>

#include <lescegra/util/vertex.h>

/**
 * \ingroup particle
 * \brief   Abstract particle base class
 */
typedef struct {
    LsgNode super;
    float birth;
    float time;
    Vertex location;
    Vertex speed;
} LsgParticle;

void LsgParticle_init(LsgParticle* self, Vertex location, Vertex speed, float time);
void LsgParticle_update(LsgParticle* self, float now);

#define LsgParticle_display(self, frust) LsgNode_display(&(self)->super, frust)
#define LsgParticle_clean(self)   LsgNode_clean(&(self)->super)
#define LsgParticle_destroy(self) LsgNode_destroy(&(self)->super)

#endif
