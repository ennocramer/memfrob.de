/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_PARTICLESYSTEM_H
#define LSG_PARTICLESYSTEM_H 1

/**
 * \file  particlesystem.h
 * \brief Particle system container
 */

#include <lescegra/sg/group.h>

#include <lescegra/particle/particle.h>

#include <lescegra/util/list.h>

/**
 * \ingroup particle
 * \brief   Particle system container
 *
 * LsgGroup node to encapsulate all particles and modifiers that belong to one
 * particle system.
 */
typedef struct {
    LsgGroup super;
    LsgList* modifiers;
} LsgParticleSystem;

/**
 * Allocate and initialize a new LsgParticleSystem instance.
 */
LsgParticleSystem* LsgParticleSystem_create(void);

/**
 * Constructor for LsgParticleSystem. Create an initially empty particle system.
 * @param self      The instance variable
 */
void LsgParticleSystem_init(LsgParticleSystem* self);

/**
 * Update the particle system by updating all containd particles and running all
 * modifiers update methods.
 * @param self      The instance variable
 * @param now       The current time
 */
void LsgParticleSystem_update(LsgParticleSystem* self, float now);

/**
 * Destroy the particle system.
 * @param self      The instance variable
 */
void LsgParticleSystem_destroy(LsgParticleSystem* self);

/**
 * Display the particle system. Reuse parent implementation.
 */
#define LsgParticleSystem_display(self) LsgGroup_display(&(self)->super)

/**
 * Clean the particle system. Reuse parant implementation.
 */
#define LsgParticleSystem_clean(self)   LsgGroup_clean(&(self)->super)

#endif
