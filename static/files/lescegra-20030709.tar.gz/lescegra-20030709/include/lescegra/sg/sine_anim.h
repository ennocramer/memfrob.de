/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_SINE_ANIM_H
#define LSG_SINE_ANIM_H 1

/**
 * \file  sine_anim.h
 * \brief Animate a float using the sine function.
 *
 * \deprecated Can only update a single float value which leads to 
 * out-of-date bounding boxes when used on node members.
 */

#include <lescegra/sg/node.h>

/**
 * \brief Animate a float using the sine function.
 *
 * \deprecated Can only update a single float value which leads to 
 * out-of-date bounding boxes when used on node members.
 */
typedef struct {
    Node super;
    float* target;
    float omega;
    float phi;
    float amplitude;
    float offset;
} SineAnim;

SineAnim* sine_anim_create(float* target, float omega, float phi, float amp, float offs);
void sine_anim_init(SineAnim* self, float* target, float omega, float phi, float amp, float offs);
void sine_anim_update(SineAnim* self, float time);

#define sine_anim_clean(self)          node_clean(&(self)->super)
#define sine_anim_display(self, frust) node_display(&(self)->super, frust)
#define sine_anim_destroy(self)        node_destroy(&(self)->super)

#endif
