/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_TERRAIN_H
#define LSG_TERRAIN_H 1

/**
 * \file  terrain.h
 * \brief Heightfield/Terrain
 */

#include <lescegra/sg/gllist.h>

#include <lescegra/util/vertex.h>
#include <lescegra/util/image.h>

/**
 * \ingroup geometry
 * \brief   Heightfield/Terrain
 *
 * Heightfield/Terrain using a single OpenGL list to store vertex /
 * normal data.
 */
typedef struct {
    LsgGLList super;
} LsgTerrain;

/**
 * Allocate and initialize a terrain node.
 * @param hf        The bitmap used to construct the terrain
 * @param dim       The dimension of the constructed terrain
 * @return A new terrain node
 */
LsgTerrain* LsgTerrain_create(LsgImage* hf, Vertex dim);

/**
 * Constructor method for LsgTerrain. Convert a bitmaps pixel values to vertices
 * and store them in an OpenGL list alongside with calculated normals.
 * @param self      The instance variable
 * @param hf        The bitmap used to construct the terrain
 * @param dim       The dimension of the constructed terrain
 */
void LsgTerrain_init(LsgTerrain* self, LsgImage* hf, Vertex dim);

/**
 * Clean this node. Reuse parent implementation.
 */
#define LsgTerrain_clean(self)          LsgGLList_clean(&(self)->super)

/**
 * Update this node. Reuse parent implementation.
 */
#define LsgTerrain_update(self, now)    LsgGLList_update(&(self)->super, now)

/**
 * Display this node. Reuse parent implementation.
 */
#define LsgTerrain_display(self, frust) LsgGLList_display(&(self)->super, frust)

/**
 * Destructor for LsgTerrain. Reuse parent implementation.
 */
#define LsgTerrain_destroy(self)        LsgGLList_destroy(&(self)->super)

#endif
