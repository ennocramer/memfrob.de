/*********************************************************************
* lescegra                                                           *
*                                                                    *
* http://geeky.kicks-ass.org/projects/lescegra.html                  *
*                                                                    *
* Copyright 2003 by Enno Cramer <uebergeek@web.de>                   *
*                                                                    *
* This library is free software; you can redistribute it and/or      *
* modify it under the terms of the GNU Library General Public        *
* License as published by the Free Software Foundation; either       *
* version 2 of the License, or (at your option) any later version.   *
*                                                                    *
* This library is distributed in the hope that it will be useful,    *
* but WITHOUT ANY WARRANTY; without even the implied warranty of     *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
* Library General Public License for more details.                   *
*                                                                    *
* You should have received a copy of the GNU Library General Public  *
* License along with this library; if not, write to the Free         *
* Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. *
*********************************************************************/

#ifndef LSG_INTERPOLATOR_H
#define LSG_INTERPOLATOR_H 1

/**
 * \file  interpolator.h
 * \brief Animate a vertex through keyframe interpolation
 *
 * \deprecated Can only update a single vertex which leads to out-of-date
 * bounding boxes when used on node members.
 */

#include <lescegra/sg/node.h>

#include <lescegra/util/list.h>
#include <lescegra/util/vertex.h>


typedef enum interpolate_mode {
    STEP,
    LINEAR,
    BEZIER,
    CATMULL_ROM
} InterpolatorMode;

/**
 * \brief Animate a vertex through keyframe interpolation
 *
 * \deprecated Can only update a single vertex which leads to out-of-date
 * bounding boxes when used on node members.
 */
typedef struct {
    Node super;
    float* target;
    InterpolatorMode mode;
    List* control;
} Interpolator;

Interpolator* interpolator_create(Vertex target, InterpolatorMode mode);
void interpolator_init(Interpolator* self, Vertex target, InterpolatorMode mode);
void interpolator_update(Interpolator* self, float now);
void interpolator_destroy(Interpolator* self);

#define interpolator_clean(self)          node_clean(&(self)->super)
#define interpolator_display(self, frust) node_disply(&(self)->super, frust)
#define interpolator_collide(self, v, n)  node_collide(&(self)->super, v, n)

void interpolator_add_control(Interpolator* self, Vertex v, float time);

#endif
