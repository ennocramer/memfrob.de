function activate_firewall() {
    # set up policies
    $IPT -P INPUT DROP
    $IPT -P FORWARD DROP
    $IPT -P OUTPUT DROP

    $IPT -t nat -P PREROUTING ACCEPT
    $IPT -t nat -P OUTPUT ACCEPT
    $IPT -t nat -P POSTROUTING ACCEPT

    $IPT -t mangle -P PREROUTING ACCEPT
    $IPT -t mangle -P OUTPUT ACCEPT

    # drop invalid packets
    $IPT -A INPUT -m state --state INVALID -j DROP
    $IPT -A OUTPUT -m state --state INVALID -j DROP
    $IPT -A FORWARD -m state --state INVALID -j DROP
    
    # do not fiddle with existing connections
    $IPT -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
    $IPT -A OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
    $IPT -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT

    # add scan protection chain
    $IPT -N SCANPROTECT
    ## XMAS packets. 
    $IPT -A SCANPROTECT -p tcp --tcp-flags ALL          ALL         -j DROP
    ## NULL packets. 
    $IPT -A SCANPROTECT -p tcp --tcp-flags ALL          NONE        -j DROP
    ## FIN/URG/PSH packets.
    $IPT -A SCANPROTECT -p tcp --tcp-flags ALL          FIN,URG,PSH -j DROP
    ## SYN/RST packets.
    $IPT -A SCANPROTECT -p tcp --tcp-flags SYN,RST      SYN,RST     -j DROP
    ## SYN/FIN scan.
    $IPT -A SCANPROTECT -p tcp --tcp-flags SYN,FIN      SYN,FIN     -j DROP
    ## ACK scan.
    #$IPT -A SCANPROTECT -p tcp --tcp-flags SYN,ACK,RST  ACK         -j DROP
    ## FIN packet without ACK.
    $IPT -A SCANPROTECT -p tcp --tcp-flags FIN,ACK      FIN         -j DROP
    
    if [ -f $CFG_DIR/private_networks ]; then
        $IPT -t mangle -N NOPRIV

        while read network; do
            $IPT -t mangle -A NOPRIV -s $network -j DROP
            $IPT -t mangle -A NOPRIV -d $network -j DROP
        done < $CFG_DIR/private_networks
    fi
    
    # setup zones
    for zone in $ZONES; do
        if [ -r $CFG_DIR/zone_$zone.conf ]; then
            if [ "$DEBUG" = yes ]; then
                echo "setting up zone $zone"
            fi
            setup_zone $zone
        else
            echo "configuration for zone $zone not found!" >&2
        fi
    done
}

function deactivate_firewall() {
    # Flush every table
    $IPT -F
    $IPT -t nat -F
    $IPT -t mangle -F

    # Delete any user-defined chain
    $IPT -X
    $IPT -t nat -X
    $IPT -t mangle -X

    # Reset packet counter
    $IPT -Z
    $IPT -t nat -Z
    $IPT -t mangle -Z

    # Set every policy to ACCEPT
    $IPT -P INPUT ACCEPT
    $IPT -P OUTPUT ACCEPT
    $IPT -P FORWARD DROP

    $IPT -t nat -P PREROUTING ACCEPT
    $IPT -t nat -P OUTPUT ACCEPT
    $IPT -t nat -P POSTROUTING ACCEPT

    $IPT -t mangle -P PREROUTING ACCEPT
    $IPT -t mangle -P OUTPUT ACCEPT
}

function load_modules() {
        for module in $MODULES_NAT; do
            modprobe ip_nat_$module >/dev/null 2>/dev/null
        done

        for module in $MODULES_CONNTRACK; do
            modprobe ip_conntrack_$module >/dev/null 2>/dev/null
        done
}

function unload_modules() {
        for module in $MODULES_CONNTRACK; do
            rmmod ip_conntrack_$module >/dev/null 2>/dev/null
        done

        for module in $MODULES_NAT; do
            rmmod ip_nat_$module >/dev/null 2>/dev/null
        done
}

function setup_zone() {
    for var in ZONE DEVICE IP STATIC SCANPROTECT CLAMP_MSS INPUT OUTPUT FORWARD SNAT DNAT; do
        unset $var
    done
    
    ZONE=$1
    
    source $CFG_DIR/zone_$ZONE.conf
    
#    if [ "$STATIC" = yes ]; then
#        IP=`$IFC $DEVICE | grep "inet addr:" | cut -d : -f 2 | cut -d " " -f 1`
#    fi

    if [ "$PUBLIC" = yes ]; then
        $IPT -t mangle -A PREROUTING -i "$DEVICE" -j NOPRIV
        if [ $EXTENDED_MANGLE = yes ]; then
            $IPT -t mangle -A POSTROUTING -o "$DEVICE" -j NOPRIV
        fi
    fi
    
    # add input rules
    if [ ${#INPUT[*]} -gt 0 -o "$SCANPROTECT" = yes ]; then
        $IPT -N INPUT_$ZONE
        $IPT -A INPUT -m state --state new -i "$DEVICE" -j INPUT_${ZONE}

        if [ "$SCANPROTECT" = yes ]; then
            add_zone_rule $ZONE INPUT SCANPROTECT tcp
        fi

        for ((I=0; I<${#INPUT[*]}; I++)); do
            add_zone_rule $ZONE INPUT ${INPUT[I]}
        done
    fi
    
    # add output rules
    if [ ${#OUTPUT[*]} -gt 0 ]; then
        $IPT -N OUTPUT_$ZONE
        $IPT -A OUTPUT -m state --state new -o "$DEVICE" -j OUTPUT_${ZONE}
        
        for ((I=0; I<${#OUTPUT[*]}; I++)); do
            add_zone_rule $ZONE OUTPUT ${OUTPUT[I]}
        done
    fi
    
    # add forward rules
    if [ ${#FORWARD[*]} -gt 0 ]; then
        $IPT -N FORWARD_$ZONE
        $IPT -A FORWARD -m state --state new -o "$DEVICE" -j FORWARD_$ZONE

        for ((I=0; I<${#FORWARD[*]}; I++)); do
            add_zone_rule $ZONE FORWARD ${FORWARD[I]}
        done
    fi
    
    # add snat rules
    if [ ${#SNAT[*]} -gt 0 ]; then
        $IPT -t nat -N SNAT_$ZONE
        $IPT -t nat -A POSTROUTING -m state --state new -o "$DEVICE" -j SNAT_$ZONE

        for ((I=0; I<${#SNAT[*]}; I++)); do
            add_zone_rule $ZONE SNAT ${SNAT[I]}
        done
    fi

    # add dnat rules
    if [ ${#DNAT[*]} -gt 0 ]; then
        $IPT -t nat -N DNAT_$ZONE
        $IPT -t nat -A PREROUTING -m state --state new -i "$DEVICE" -j DNAT_$ZONE

        for ((I=0; I<${#DNAT[*]}; I++)); do
            add_zone_rule $ZONE DNAT ${DNAT[I]}
        done
    fi
}

# add_zone_rule zone type params
function add_zone_rule() {
    for var in CHAIN ZONE TYPE TARGET PROTO DEST SOURCE DPORT SPORT DIP SIP PARAM; do
        unset $var
    done
    
    ZONE=$1
    TYPE=$2
    
    shift 2
    
    case $TYPE in
        INPUT)
            TABLE=""
            CHAIN="INPUT"
            
            TARGET=$1
            PROTO=$2
            DEST=$3
            SOURCE=$4
            
            MAX_ARGS=4
        ;;
        
        OUTPUT)
            TABLE=""
            CHAIN="OUTPUT"
            
            TARGET=$1
            PROTO=$2
            DEST=$3
            SOURCE=$4

            MAX_ARGS=4            
        ;;
        
        FORWARD)
            TABLE=""
            CHAIN="FORWARD"
            
            TARGET=$1
            PROTO=$2
            SOURCE=$3
            DEST=$4

            MAX_ARGS=4            
        ;;
        
        SNAT)
            TABLE="-t nat"
            CHAIN="SNAT"
            
            TARGET="SNAT"
            PROTO=$1
            SOURCE=$2
            DEST=$3

            MAX_ARGS=4
            
            if [ -n "$4" ]; then
                PARAM="--to-source $4"
            elif [ "$STATIC" != yes ]; then
                TARGET=MASQUERADE
                MAX_ARGS=3
            fi
        ;;
        
        DNAT)
            TABLE="-t nat"
            CHAIN="DNAT"
            
            TARGET="DNAT"
            PROTO=$1
            DEST=$2
            SOURCE=$3
            
            if [ -n "$4" ]; then
                PARAM="--to-destination $4"
            fi

            MAX_ARGS=4
        ;;
    esac
    
    # remove defined parameter from parameter list
    if [ "$MAX_ARGS" -gt $# ]; then
        shift $#
    else
        shift $MAX_ARGS
    fi
    
    CHAIN="$TABLE -A ${CHAIN}_$ZONE"
    TARGET="-j $TARGET"
    
    if [ -n "$PROTO" -a "$PROTO" != ANY ]; then
        PROTO=`echo $PROTO | sed 's/^!/! /'`
        PROTO="-p $PROTO"
    else
        PROTO=""
    fi
    
    if [ -n "$DEST"  -a "$DEST" != ANY ]; then
        DIP=`echo $DEST | cut -d: -f1`
        DPORT=`echo $DEST | cut -s -d: -f2`
        
        if [ -n "$DIP" ]; then
            DIP=`echo $DIP | sed 's/^!/! /'`
            DIP="-d $DIP"
        fi
        
        if [ -n "$DPORT" ]; then
            if [ "(" "$PROTO" != "-p tcp" ")" -a "(" "$PROTO" != "-p udp" ")" ]; then
                echo "ports are available with protocols tcp or udp only" >/&2
                DPORT=""
            else
                DPORT=`echo $DPORT | sed 's/-/:/g' | sed 's/^!/! /'`
                if [ -n "`echo $DPORT | grep ','`" ]; then
                    DPORT="-m multiport --dports $DPORT"
                else
                    DPORT="--dport $DPORT"
                fi
            fi
        fi
    fi
    
    if [ -n "$SOURCE"  -a "$SOURCE" != ANY ]; then
        SIP=`echo $SOURCE | cut -d: -f1`
        SPORT=`echo $SOURCE | cut -s -d: -f2`
        
        if [ -n "$SIP" ]; then
            SIP=`echo $SIP | sed 's/^!/! /'`
            SIP="-s $SIP"
        fi
        
        if [ -n "$SPORT" ]; then
            if [ "(" "$PROTO" != "-p tcp" ")" -a "(" "$PROTO" != "-p udp" ")" ]; then
                echo "ports are available with protocol tcp or udp only" >/&2
                SPORT=""
            else
                SPORT=`echo $SPORT | sed 's/-/:/g' | sed 's/^!/! /'`
                if [ -n "`echo $SPORT | grep ','`" ]; then
                    SPORT="-m multiport --sports $SPORT"
                else
                    SPORT="--sport $SPORT"
                fi
            fi
        fi
    fi

    if [ "$DEBUG" = yes ]; then
        eval echo $IPT $CHAIN $PROTO $SIP $SPORT $DIP $DPORT $TARGET $PARAM $@
    fi
    eval $IPT $CHAIN $PROTO $SIP $SPORT $DIP $DPORT $TARGET $PARAM $@
}
